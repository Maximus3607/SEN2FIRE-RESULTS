# Results and Discussion: figures, tables and references

Twelve CSV files: eight graphs and four tables. Each file is plain CSV: one header row, then data. To make a graph, paste the file into Excel or Google Sheets, select everything, and insert the chart named below.

For a line chart against beta0, use **XY scatter with lines**, because the haze steps are uneven. Rebuild the files with `python scripts/build_csvs.py && python scripts/build_paper_figures.py`.

| # | File | Section | Chart | x axis → y axis |
|---|---|---|---|---|
| Fig 1 | Figure_1_confidence_vs_accuracy_on_fire | 3.1 | line | beta0 → probability (0–1) |
| Fig 2 | Figure_2_true_fire_ECE_calibrators_and_SAEA | 3.1 | line or grouped bar | beta0 → true-fire ECE |
| Fig 3 | Figure_3_trained_gate_abstention_by_pixel_type | 3.2 | grouped bar | pixel type → mean p(abstain) |
| Fig 4 | Figure_4_error_detection_AUROC_evidence_head_vs_readouts | 3.3 | grouped bar (y axis from 0.5) | readout → AUROC |
| Table 1 | Table_1_every_readout_MODIS_labels_model_A | 3.3 | table | – |
| Table 2 | Table_2_MODIS_label_check_and_agreement_labels | 3.4 | table | – |
| Fig 5 | Figure_5_IoU_network_vs_SWIR_rule_scene4 | 3.5 | line | beta0 → IoU |
| Fig 6 | Figure_6_confidence_on_missed_fire_every_readout | 3.5 | line | beta0 → mean confidence on missed fire |
| Fig 7 | Figure_7_height_gate_selectivity_MODIS_vs_agreement | 3.5 | bar, **log y axis** | network → selectivity |
| Table 3 | Table_3_pixel_by_pixel_test_beta4_scene4 | 3.5 | table | – |
| Fig 8 | Figure_8_true_fire_ECE_vs_haze_every_readout | 3.5 | line | beta0 → true-fire ECE |
| Table 4 | Table_4_grey_haze_every_readout_scene4 | 3.5 / limitations | table | – |

Seeds are numbered 1 and 2 throughout, matching the paper (they are seeds 0 and 1 in the code and in `csv/`).

## Suggested captions

**Figure 1.**
- **Caption:** Haze dose response of model A (MODIS labels, scene 4, aerosol haze α = 1.3). As haze rises from β₀ = 0 to 2, accuracy on fire pixels falls from 0.27 to 0.02, while mean confidence on fire stays at 0.92–0.94.

**Figure 2.**
- **Caption:** True-fire ECE of the standard calibrators and of SAEA on model A (scene 4). No calibrator lowers fire ECE meaningfully. Platt scaling and both versions of SAEA raise it.
- **Text note:** SAEA's selectivity was 1.32–1.39, i.e. it abstained almost evenly everywhere.

**Figure 3.**
- **Caption:** Where model B's trained gate abstains (scene 3, clear). It abstains by predicted class rather than by error: heavily on pixels called fire (correct fire 0.68–0.74, false alarm 0.72), and little on missed fire (0.19–0.21).

**Figure 4.**
- **Caption:** Error-detection AUROC of every readout against the learned evidence head (model A seed 1). The evidence head reaches 0.853 on scene 3 and 0.711 on scene 4, barely above softmax (0.831 / 0.744). So little extra information about the network's errors is available to any readout built on top of it.

**Table 1.**
- **Caption:** Every readout on model A seed 1 with MODIS labels. Scene 3 (clear) is the held-out half; scene 4 is a new region.
- **Text notes:**
  - Platt, beta and isotonic change the decision boundary (IoU falls from 0.29 to 0.13–0.16).
  - The trained gate exists only in model B.
  - The other three models are in `csv/graph_ready/E3_limits_of_post_hoc/E3-09 … E3-20`.

**Table 2.**
- **Caption:** The MODIS label check and the agreement labels. About 95% of MODIS-labelled fire shows no fire signature in Sentinel-2. The network finds 83–94% of the fire that is visible, and agreement labels keep only 1.0–1.4% of MODIS fire as fire.

**Figure 5.**
- **Caption:** IoU of the agreement-label networks against the SWIR rule that labelled them (scene 4). Under aerosol haze, the networks hold an IoU of 0.87–0.89 at β₀ = 4, while the rule falls to 0. Under grey haze (α = 0), both fail by β₀ = 2.

**Figure 6.**
- **Caption:** Pixel-by-pixel test (scene 4, aerosol haze, seed 1, every pixel scored against visible fire). The figure shows mean confidence on the fire each readout still misses. Platt and beta stay at 0.88–0.93, the height gate at 0.18–0.35.
- **Text note:** β₀ = 0 is omitted because almost no fire is missed there.

**Figure 7.**
- **Caption:** Selectivity of the same height gate (abstention on missed fire ÷ abstention on correct background). It is 1.1–4.3 on MODIS-label networks and 593–3,702 on agreement-label networks.

**Table 3.**
- **Caption:** Pixel-by-pixel test at the heaviest haze (β₀ = 4, aerosol haze, scene 4, every pixel scored against visible fire), for both seeds.
- **Text notes:**
  - Platt and beta have the lowest true-fire ECE and fire Brier, but lose IoU (0.72–0.74 against 0.78–0.80).
  - The height gate keeps softmax's IoU and has the lowest fire NLL on both seeds.
  - The height gate has much lower confidence on missed fire.
  - Its confidence Brier is slightly *higher* than softmax's.

**Figure 8.**
- **Caption:** Haze dose response of every readout in the pixel-by-pixel test (aerosol haze, scene 4, seed 1, every pixel scored against visible fire). True-fire ECE rises with haze for softmax and both temperature scalings, reaching 0.088–0.103 at β₀ = 4. Platt, beta and the height gate stay at 0.022–0.025, and isotonic at 0.034.
- **Text note:** Platt and beta reach their low values partly by moving the decision boundary (Table 3, IoU). Seed 2 is in `csv/graph_ready/E5_height_gate_and_every_pixel/E5-22`.

**Table 4.**
- **Caption:** Grey haze (α = 0), scene 4, every pixel scored against visible fire, both seeds. At β₀ = 2 the network itself fails (IoU 0.002–0.031) and the height gate cannot help. Platt, beta and isotonic recover IoU (0.69–0.81) by moving the decision boundary, but when the same calibrators are applied to clear images, IoU falls from 0.50–0.51 to 0.20–0.27.
- **Text note:** confidence on missed fire stays at 0.89–0.98 for every readout except the height gate (0.71–0.83), so under grey haze nothing is reliably uncertain about its errors.

## References to read and cite

**Uncertainty under dataset shift (the mainline paper)**
1. Ovadia, Y., Fertig, E., Ren, J., Nado, Z., Sculley, D., Nowozin, S., Dillon, J. V., Lakshminarayanan, B., & Snoek, J. (2019). Can you trust your model's uncertainty? Evaluating predictive uncertainty under dataset shift. *NeurIPS 32*. https://papers.nips.cc/paper/2019/hash/8558cb408c1d76621371888657d2eb1d-Abstract.html

**Calibration and the baselines**
2. Guo, C., Pleiss, G., Sun, Y., & Weinberger, K. Q. (2017). On calibration of modern neural networks. *ICML*, PMLR 70, 1321–1330. *(temperature scaling, ECE)*
3. Naeini, M. P., Cooper, G. F., & Hauskrecht, M. (2015). Obtaining well calibrated probabilities using Bayesian binning. *AAAI*. *(origin of ECE)*
4. Platt, J. (1999). Probabilistic outputs for support vector machines and comparisons to regularized likelihood methods. In *Advances in Large Margin Classifiers*. MIT Press.
5. Zadrozny, B., & Elkan, C. (2002). Transforming classifier scores into accurate multiclass probability estimates. *KDD*. *(isotonic regression)*
6. Kull, M., Silva Filho, T., & Flach, P. (2017). Beta calibration: a well-founded and easily implemented improvement on logistic calibration for binary classifiers. *AISTATS*, PMLR 54, 623–631. https://proceedings.mlr.press/v54/kull17a
7. Brier, G. W. (1950). Verification of forecasts expressed in terms of probability. *Monthly Weather Review*, 78(1), 1–3.
8. Gneiting, T., & Raftery, A. E. (2007). Strictly proper scoring rules, prediction, and estimation. *Journal of the American Statistical Association*, 102(477), 359–378. *(why NLL and Brier are "proper")*

**Calibration of segmentation networks**
9. Mehrtash, A., Wells, W. M., Tempany, C. M., Abolmaesumi, P., & Kapur, T. (2020). Confidence calibration and predictive uncertainty estimation for deep medical image segmentation. *IEEE Transactions on Medical Imaging*, 39(12), 3868–3878. https://pmc.ncbi.nlm.nih.gov/articles/PMC7704933
10. Wang, D., Gong, B., & Wang, L. (2023). On calibrating semantic segmentation models: analyses and an algorithm. *CVPR*. https://openaccess.thecvf.com/content/CVPR2023/html/Wang_On_Calibrating_Semantic_Segmentation_Models_Analyses_and_an_Algorithm_CVPR_2023_paper.html
11. Ding, Z., Han, X., Liu, P., & Niethammer, M. (2021). Local temperature scaling for probability calibration. *ICCV*.
12. Ronneberger, O., Fischer, P., & Brox, T. (2015). U-Net: convolutional networks for biomedical image segmentation. *MICCAI*, LNCS 9351, 234–241.

**MaxLogit, MSP and logit-sum (energy) readouts**
13. Hendrycks, D., & Gimpel, K. (2017). A baseline for detecting misclassified and out-of-distribution examples in neural networks. *ICLR*. *(MSP, and error detection measured by AUROC, as in Figure 4)*
14. Hendrycks, D., Basart, S., Mazeika, M., Zou, A., Kwon, J., Mostajabi, M., Steinhardt, J., & Song, D. (2022). Scaling out-of-distribution detection for real-world settings. *ICML*, PMLR 162. https://proceedings.mlr.press/v162/hendrycks22a.html *(MaxLogit, also applied to segmentation)*
15. Liu, W., Wang, X., Owens, J., & Li, Y. (2020). Energy-based out-of-distribution detection. *NeurIPS 33*. *(logsumexp of the logits)*
16. Wei, H., Xie, R., Cheng, H., Feng, L., An, B., & Li, Y. (2022). Mitigating neural network overconfidence with logit normalization. *ICML*, PMLR 162. https://proceedings.mlr.press/v162/wei22d.html *(logit magnitude grows during training; supports the antisymmetry / weight-decay discussion)*

**Abstention**
17. Chow, C. K. (1970). On optimum recognition error and reject tradeoff. *IEEE Transactions on Information Theory*, 16(1), 41–46. *(the original reject option)*
18. Geifman, Y., & El-Yaniv, R. (2017). Selective classification for deep neural networks. *NeurIPS 30*. *(risk-coverage, AURC)*
19. Thulasidasan, S., Bhattacharya, T., Bilmes, J., Chennupati, G., & Mohd-Yusof, J. (2019). Combating label noise in deep learning using abstention. *ICML*, PMLR 97. https://arxiv.org/abs/1905.10964 *(an extra "abstain" class in the softmax, as in your three-outcome readout; also relevant to the noisy-label story)*

**Data: Sentinel-2, Sen2Fire, MODIS, SWIR fire signature**
20. Xu, Y., Berg, A., & Haglund, L. (2024). Sen2Fire: a challenging benchmark dataset for wildfire detection using Sentinel data. *IGARSS 2024*. doi:10.1109/IGARSS53475.2024.10641441. https://arxiv.org/abs/2403.17884
21. Drusch, M., et al. (2012). Sentinel-2: ESA's optical high-resolution mission for GMES operational services. *Remote Sensing of Environment*, 120, 25–36.
22. Giglio, L., Schroeder, W., & Justice, C. O. (2016). The collection 6 MODIS active fire detection algorithm and fire products. *Remote Sensing of Environment*, 178, 31–41. *(the 1 km MOD14A1 labels, and why they are coarse)*
23. Hu, X., Ban, Y., & Nascetti, A. (2021). Sentinel-2 MSI data for active fire detection in major fire-prone biomes: a multi-criteria approach. *International Journal of Applied Earth Observation and Geoinformation*, 101, 102347. *(SWIR fire signatures in Sentinel-2, the basis of the agreement labels)*

**Training and the fire-signature rule**
26. Loshchilov, I., & Hutter, F. (2019). Decoupled weight decay regularization. *ICLR*. *(AdamW, and weight decay)*
27. Murphy, S. W., de Souza Filho, C. R., Wright, R., Sabatino, G., & Correa Pabon, R. (2016). HOTMAP: Global hot target detection at moderate spatial resolution. *Remote Sensing of Environment*, 177, 78–88. *(the SWIR fire-signature rule behind the agreement labels)*
28. *(optional)* Ioffe, S., & Szegedy, C. (2015). Batch normalization: accelerating deep network training by reducing internal covariate shift. *ICML*, PMLR 37, 448–456.

**Synthetic haze**
29. Narasimhan, S. G., & Nayar, S. K. (2002). Vision and the atmosphere. *International Journal of Computer Vision*, 48(3), 233–254. *(the Koschmieder scattering model I = J·t + A(1 − t))*
30. Ångström, A. (1929). On the atmospheric transmission of sun radiation and on dust in the air. *Geografiska Annaler*, 11, 156–166. *(the Ångström exponent α)*
