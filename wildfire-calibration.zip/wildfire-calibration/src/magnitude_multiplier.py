r"""
MAGNITUDE MULTIPLIER: drop the third class, use magnitude as a per-pixel
temperature instead.

    p(fire) = sigmoid( m(s) * (z1 - z0) ),     m(s) = softplus(a_c + b_c * s)

s = (z0 + z1)/2 is the logit sum. m is a per-pixel sharpness: low evidence
pulls a pixel toward 50/50, high evidence leaves it alone. There is NO null
term, NO third class and NOTHING added to the softmax denominator. Because
softplus keeps m > 0, the sign of the gap -- and so every prediction -- is
unchanged. Accuracy is preserved exactly and asserted.

a_c and b_c are fitted SEPARATELY for each predicted class c, because the gate
failed by learning the class split: fitting per class takes that shortcut away.

THE QUESTION THIS ANSWERS
Does magnitude add anything, as a multiplier, beyond an ordinary temperature?
So four readouts are compared on identical logits:
    identity            plain softmax
    global T            one temperature for every pixel
    class-cond T        one temperature per predicted class   (b_c = 0)
    magnitude mult.     class-cond T PLUS the dependence on s (b_c free)
The last two differ ONLY in whether s is used. If they tie, magnitude as a
multiplier adds nothing -- which is what the -0.991 correlation between s and
the gap within predicted background predicts. If the multiplier wins, s carries
something a temperature cannot express.

Fitted by minimising NLL -- the standard objective for temperature scaling --
on the held-in half of the scene, scored on the held-out half. Same split as
every other scene-3 analysis.

Usage:
  python3 magnitude_multiplier.py gated_scene3_haze_0p00_logits.npz \
      gated_scene3_haze_0p20_logits.npz gated_scene3_haze_0p50_logits.npz
"""

import sys
import numpy as np


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


def softplus(x):
    return np.where(x > 30, x, np.log1p(np.exp(np.clip(x, -60, 30))))


def load(path, idx):
    z = np.load(path)
    lg = z["logits"][idx].astype(np.float32); y = z["labels"][idx]
    if y.ndim == 4: y = y[:, 0]
    z0, z1 = lg[:, 0].ravel(), lg[:, 1].ravel()
    return (z1 - z0, 0.5*(z0 + z1), y.ravel().astype(np.float64),
            float(z["beta0"]) if "beta0" in z.files else float("nan"))


def fit(g, s, y, use_s, iters=600, lr=0.05):
    """Minimise BCE of sigmoid(softplus(a + b*s) * g). Adam, numpy only.
    Starts at m = 1 (a = log(e-1), b = 0), i.e. at plain softmax."""
    p = np.array([np.log(np.e - 1.0), 0.0]); mo = np.zeros(2); ve = np.zeros(2)
    for t in range(1, iters + 1):
        u = p[0] + (p[1]*s if use_s else 0.0)
        m = softplus(u); z = m * g
        r = (sigmoid(z) - y) * g * sigmoid(u)          # dL/du, per pixel
        grad = np.array([r.mean(), (r*s).mean() if use_s else 0.0])
        mo = 0.9*mo + 0.1*grad; ve = 0.999*ve + 0.001*grad**2
        p -= lr * (mo/(1-0.9**t)) / (np.sqrt(ve/(1-0.999**t)) + 1e-8)
    return p


def apply(p, g, s, use_s):
    return sigmoid(softplus(p[0] + (p[1]*s if use_s else 0.0)) * g)


def ece(conf, corr, nb=20):
    e = np.linspace(0, 1, nb + 1); n = conf.size; t = 0.0
    if n == 0: return float("nan")
    for i in range(nb):
        sel = (conf > e[i]) & (conf <= e[i+1]); k = int(sel.sum())
        if k: t += (k/n) * abs(corr[sel].mean() - conf[sel].mean())
    return float(t)


def metrics(pf, y, pred):
    """pred comes from the SIGN OF THE GAP, never from pf. When magnitude is
    very low the multiplier drives m toward 0 and pf to exactly 0.5 in float64
    -- a legitimate 'no idea' -- and a tie there must not be read as a flip."""
    conf = np.where(pred, pf, 1 - pf)
    corr = (pred == (y == 1)).astype(np.float64)
    f, b = y == 1, y == 0
    pt = np.clip(np.where(y == 1, pf, 1 - pf), 1e-9, 1)
    tp = float((pred & f).sum()); fp = float((pred & b).sum()); fn = float((~pred & f).sum())
    return dict(ece=ece(conf, corr), ef=ece(conf[f], corr[f]), eb=ece(conf[b], corr[b]),
                nll=float(-np.log(pt).mean()), brier=float(((pf - y)**2).mean()),
                iou=tp/(tp+fp+fn+1e-9), cf=float(conf[f].mean()), af=float(corr[f].mean()))


def main(paths):
    n = int(np.load(paths[0])["logits"].shape[0])
    perm = np.random.default_rng(0).permutation(n)       # SAME split as before
    fit_idx, ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])

    g, s, y, _ = load(paths[0], fit_idx)
    rng = np.random.default_rng(1)
    pred = g > 0
    params = {}
    # global temperature: one m for everything, no s
    k = rng.choice(g.size, min(g.size, 3_000_000), replace=False)
    params["global T"] = {c: fit(g[k], s[k], y[k], False) for c in (0, 1)}
    for tag, use_s in (("class-cond T", False), ("magnitude mult.", True)):
        params[tag] = {}
        for c in (0, 1):
            idx = np.flatnonzero(pred == bool(c))
            if idx.size > 3_000_000:
                idx = rng.choice(idx, 3_000_000, replace=False)
            params[tag][c] = fit(g[idx], s[idx], y[idx], use_s)

    print(f"fitted on {len(fit_idx)} held-in patches (NLL objective)")
    for tag in ("class-cond T", "magnitude mult."):
        for c, nm in ((0, "pred bg  "), (1, "pred fire")):
            a, b = params[tag][c]
            print(f"  {tag:<16}{nm}  a={a:+.3f}  b={b:+.3f}"
                  + ("   (b = weight on magnitude s)" if tag == "magnitude mult." else ""))

    for path in paths[1:]:
        g, s, y, beta = load(path, ev_idx)
        pred = g > 0
        out = {"identity": sigmoid(g)}
        for tag, use_s in (("global T", False), ("class-cond T", False),
                           ("magnitude mult.", True)):
            pf = np.empty_like(g)
            for c in (0, 1):
                mk = pred == bool(c)
                pf[mk] = apply(params[tag][c], g[mk], s[mk], use_s)
            # m > 0 keeps pf on the same side of 0.5 as the gap; exact ties at
            # 0.5 are allowed (m underflowed to ~0), strict crossings are not
            assert np.all(pf[pred] >= 0.5) and np.all(pf[~pred] <= 0.5), \
                f"{tag} moved a pixel to the other side of 0.5"
            out[tag] = pf

        print(f"\n{path.split('/')[-1]}   beta0 = {beta}   ({len(ev_idx)} held-out patches)")
        print("  predictions verified identical across all four readouts")
        print(f"  {'readout':<17}{'ECE':>9}{'ECE(fire)':>11}{'ECE(bg)':>10}"
              f"{'NLL':>9}{'Brier':>9}{'conf|fire':>11}{'acc|fire':>10}")
        for tag, pf in out.items():
            m = metrics(pf, y, pred)
            print(f"  {tag:<17}{m['ece']:>9.5f}{m['ef']:>11.5f}{m['eb']:>10.5f}"
                  f"{m['nll']:>9.5f}{m['brier']:>9.5f}{m['cf']:>11.4f}{m['af']:>10.4f}")

    print("\nHOW TO READ THIS")
    print("  Compare 'class-cond T' with 'magnitude mult.'. They are identical")
    print("  except that the multiplier also reads the logit sum s.")
    print("  If they tie, magnitude adds nothing as a multiplier -- s is just the")
    print("  gap re-expressed, as the -0.991 correlation suggested.")
    print("  If the multiplier clearly wins on ECE(fire) WITHOUT a large rise in")
    print("  ECE(bg), magnitude carries something a temperature cannot.")
    print("  Unlike the gate, nothing here can abstain, so NLL and Brier are fair")
    print("  tests: every readout keeps all its probability on the two real classes.")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    main(sys.argv[1:])
