r"""
FINAL COMPARISON: the height gate against every relevant baseline, on the
same patches, with paired intervals. One script, one table per severity.

READOUTS (all applied to the SAME logits; predictions never change)
  softmax          plain two-class softmax
  temperature      one temperature for every pixel          (fitted by NLL)
  class-cond T     one temperature PER PREDICTED CLASS      (fitted by NLL)
                   -- the strongest simple baseline: it also treats fire and
                   background differently, with no abstention at all
  height gate      abstention driven by the logit of the predicted class,
                   one threshold per predicted class

FAIRNESS
  - Everything is fitted on the HELD-IN half of the first file (clear scene 3)
    and scored on the HELD-OUT half of the others. Same split as every run.
  - The height gate uses FIXED shape constants c = -5.658, k = 8.486,
    gamma = 2.751 for every model; only its thresholds are fitted. So when this
    runs on model A and model B, the readout is identical -- only the logits
    differ.

PRIMARY ENDPOINT: predicted-fire ECE -- calibration of the model's fire calls,
the standard class-wise definition. True-fire ECE is reported directly beneath
it; it rewards lowering confidence on missed fire rather than calibration as
such (see ece_anatomy.py), so it is secondary.

ALSO REPORTED
  - bin-count sensitivity of the primary endpoint (10/15/20/30 bins): ECE
    depends on binning, and a result that only holds at one bin count is weak
  - a 10-bin reliability table for the fire calls, for a paper figure

THE 2x2 DESIGN THIS ENABLES
Run it on a model-A file and a model-B file. Softmax-vs-height-gate on each
model separates the READOUT's effect from the LOSS's effect:
    gate helps on A and B   -> the readout is the contribution
    gate helps only on B    -> it needs the auxiliary loss's logits

Usage (reverse_gate.py and paired_height.py in the same folder):
  python3 final_compare.py --boot 1000 gated_scene3_haze_0p00_logits.npz \
      gated_scene3_haze_0p20_logits.npz gated_scene3_haze_0p50_logits.npz
  (and the same with model A's scene3_haze_* files)
"""

import sys, argparse
import numpy as np
from reverse_gate import load, evidence, readout as gate_readout, fit as gate_fit, sigmoid
from paired_height import patch_stats, metrics

FIX_C, FIX_K, FIX_G = -5.658, 8.486, 2.751


def fixed(d):
    d = dict(d); d["c"], d["k"], d["g"] = FIX_C, FIX_K, FIX_G
    return d


def fit_T(g, y, n=3_000_000, seed=1):
    """Temperature minimising binary NLL, golden-section search on log T."""
    if g.size > n:
        i = np.random.default_rng(seed).choice(g.size, n, replace=False); g, y = g[i], y[i]
    y = y.astype(np.float64)
    def nll(lt):
        p = np.clip(sigmoid(g / np.exp(lt)), 1e-9, 1 - 1e-9)
        return float(-(y*np.log(p) + (1-y)*np.log(1-p)).mean())
    a, b, r = -3.0, 3.0, (np.sqrt(5) - 1) / 2
    c, e = b - r*(b-a), a + r*(b-a)
    for _ in range(60):
        if nll(c) < nll(e): b, e = e, c; c = b - r*(b-a)
        else:               a, c = c, e; e = a + r*(b-a)
    return float(np.exp((a + b) / 2))


def two_class(pf, pred, y):
    conf = np.where(pred, pf, 1 - pf)
    return conf, (pred == y).astype(np.float64)


def ece_bins(conf, corr, nb):
    if conf.size == 0: return float("nan")
    b = np.clip((conf * nb).astype(int), 0, nb - 1)
    return float(np.abs(np.bincount(b, corr, nb) - np.bincount(b, conf, nb)).sum() / conf.size)


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("files", nargs="*")
    a = ap.parse_args()
    if len(a.files) < 2:
        print(__doc__); sys.exit(1)

    n = int(np.load(a.files[0])["logits"].shape[0])
    perm = np.random.default_rng(0).permutation(n)          # SAME split as every run
    fit_idx, ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])
    df = fixed(load(a.files[0], fit_idx))
    # provenance first: a matched model A also carries gate parameters, so
    # "has a gate" alone would mislabel it as model B
    if df["nu"] is not None:
        model = ("MODEL B" if df["nu"] > 0 else "MODEL A (matched)") + \
                (f", seed {df['seed']}" if df["seed"] is not None and df["seed"] >= 0 else ", seed 0")
    else:
        model = "MODEL B, seed 0" if df["has_gate"] else "MODEL A (original)"
    g = df["z1"] - df["z0"]; y = df["y"] == 1; pred = g > 0
    T = fit_T(g, y)
    Tc = {c: fit_T(g[pred == c], y[pred == c]) for c in (False, True)}
    print(f"{model}: fitting on {len(fit_idx)} held-in patches")
    print(f"  temperature T = {T:.4f}")
    print(f"  class-cond T  pred bg {Tc[False]:.4f}   pred fire {Tc[True]:.4f}")
    taus, gams = gate_fit(df, "height gate")
    fmt = lambda t: "OFF" if t is None else f"{t:+.3f}"
    print(f"  height gate   tau pred bg {fmt(taus[False])}   tau pred fire {fmt(taus[True])}")

    names = ["softmax", "temperature", "class-cond T", "height gate"]
    rows = ["pred fire", "TRUE fire", "TRUE bg", "pred bg", "all", "AURC"]
    for path in a.files[1:]:
        d = fixed(load(path, ev_idx))
        P = len(ev_idx); HW = d["z0"].size // P
        g = d["z1"] - d["z0"]; y = d["y"] == 1; pred = g > 0
        Tpx = np.where(pred, Tc[True], Tc[False])
        R = {"softmax": two_class(sigmoid(g), pred, y),
             "temperature": two_class(sigmoid(g / T), pred, y),
             "class-cond T": two_class(sigmoid(g / Tpx), pred, y)}
        ch, oh, _, _ = gate_readout(d, evidence(d, "height gate"), taus, gams)
        R["height gate"] = (ch, oh)
        for k, (_, corr) in R.items():
            assert np.array_equal(corr, R["softmax"][1]), f"{k} changed a prediction"

        S = {k: patch_stats(c, o, y, pred, P, HW) for k, (c, o) in R.items()}
        M = {k: metrics(H.sum(0), Rr.sum(0)) for k, (H, Rr) in S.items()}
        print(f"\n=== {path.split('/')[-1]}   {model}   beta0 = {d['beta']}   ({P} held-out patches)")
        print(f"  {'readout':<14}" + "".join(f"{r:>11}" for r in rows))
        for k in names:
            print(f"  {k:<14}" + "".join(f"{M[k][r]:>11.4f}" for r in rows))

        rng = np.random.default_rng(3)
        D = {(ref, r): [] for ref in names[:3] for r in rows}
        for _ in range(a.boot):
            pk = rng.integers(0, P, P)
            b = {k: metrics(H[pk].sum(0), Rr[pk].sum(0)) for k, (H, Rr) in S.items()}
            for ref in names[:3]:
                for r in rows:
                    D[(ref, r)].append(b["height gate"][r] - b[ref][r])
        print(f"\n  height gate MINUS each baseline, {a.boot} paired replicates"
              "  (negative = height gate better)")
        for ref in names[:3]:
            print(f"    vs {ref}")
            for r in rows:
                v = np.array(D[(ref, r)]); v = v[np.isfinite(v)]
                lo, hi = np.percentile(v, [2.5, 97.5])
                sig = " *" if (hi < 0 or lo > 0) else "  "
                tag = "   <- PRIMARY" if r == "pred fire" else ""
                print(f"      {r:<11}{np.mean(v):>+9.4f}   [{lo:+.4f}, {hi:+.4f}]{sig}"
                      f"  better {(v < 0).mean():>6.1%}{tag}")

        print("\n  bin-count sensitivity of the PRIMARY endpoint (pred-fire ECE)")
        print(f"  {'bins':<8}" + "".join(f"{k:>14}" for k in names))
        for nb in (10, 15, 20, 30):
            print(f"  {nb:<8}" + "".join(f"{ece_bins(R[k][0][pred], R[k][1][pred], nb):>14.4f}" for k in names))

        print("\n  reliability of the FIRE CALLS (10 bins): accuracy / mean confidence / pixels")
        e = np.linspace(0, 1, 11)
        for k in ("softmax", "height gate"):
            c, o = R[k][0][pred], R[k][1][pred]
            cells = []
            for i in range(10):
                s = (c > e[i]) & (c <= e[i+1])
                if s.sum(): cells.append(f"[{e[i]:.1f}-{e[i+1]:.1f}] {o[s].mean():.2f}/{c[s].mean():.2f}/{int(s.sum()):,}")
            print(f"  {k}:"); [print(f"      {x}") for x in cells]

    print("\nHOW TO READ THIS")
    print("  PRIMARY = pred-fire ECE. The claim holds if the height gate beats ALL")
    print("  THREE baselines on it, with intervals excluding zero, at both severities.")
    print("  'vs class-cond T' is the hardest test: if two temperatures do as well,")
    print("  the abstention mechanism is not what helps.")
    print("  The primary result should survive every bin count in the sensitivity table.")
    print("  Background rows are the cost; report them next to the gain.")
    print("  Run on model A too: that separates the readout's effect from the loss's.")


if __name__ == "__main__":
    main()
