r"""
VERIFY the evidence dumps are paired with the right split.

Both scene 3 and scene 4 have 504 patches, so a mix-up would pass the shape
assertion in evidence_check.py silently. This checks it properly.

The decisive test: the training log reported val error-AUROC 0.8650 on scene 3.
If evidence_val scores ~0.86 against val_logits, the head, the dump loop and
the file naming are all correct -- and the ~0.60 measured on scene 4 is a
genuine failure to transfer, not a bookkeeping mistake.

The cross-pairings should score near 0.50. Evidence computed on one region has
no reason to predict errors in a different one, so anything well above chance
there would mean the files are not what their names say.

This AUROC is over ALL pixels, matching the training-time computation, not the
predicted-background subset used in evidence_check.py -- so the numbers are
comparable to the log, not to that table.

Usage:
  python3 verify_evidence.py
"""

import numpy as np


def auroc(score, target, n=1_000_000, seed=0):
    s = score.ravel().astype(np.float64)
    t = target.ravel().astype(np.float64)
    if s.size > n:
        rng = np.random.default_rng(seed)
        i = rng.choice(s.size, n, replace=False)
        s, t = s[i], t[i]
    npos, nneg = t.sum(), (1 - t).sum()
    if npos == 0 or nneg == 0:
        return float("nan")
    o = np.argsort(s)
    r = np.empty(s.size); r[o] = np.arange(1, s.size + 1)
    return (r[t == 1].sum() - npos * (npos + 1) / 2) / (npos * nneg)


def errors(path):
    z = np.load(path)
    lg = z["logits"].astype(np.float32)
    lb = z["labels"]
    if lb.ndim == 4:
        lb = lb[:, 0]
    return (lg.argmax(1) != lb.astype(np.int64)).astype(np.float32)


def ev(path):
    e = np.load(path)["evidence"].astype(np.float32)
    return e[:, 0] if e.ndim == 4 else e


print("AUROC of evidence for predicting error, over ALL pixels")
print("(comparable to the training log, which reported 0.8650 on scene 3)\n")

err_val = errors("val_logits.npz")
err_test = errors("test_logits.npz")
e_val = ev("evidence_val_0p00.npz")
e_test = ev("evidence_test_0p00.npz")

print(f"  {'evidence file':<28}{'scored against':<22}{'AUROC':>8}   expect")
print("  " + "-" * 68)
rows = [
    ("evidence_val_0p00", e_val, "val_logits  (scene 3)", err_val, "~0.86"),
    ("evidence_test_0p00", e_test, "test_logits (scene 4)", err_test, "measured"),
    ("evidence_test_0p00", e_test, "val_logits  (scene 3)", err_val, "~0.50"),
    ("evidence_val_0p00", e_val, "test_logits (scene 4)", err_test, "~0.50"),
]
for name, e, tgt_name, tgt, exp in rows:
    if e.shape != tgt.shape:
        print(f"  {name:<28}{tgt_name:<22}{'shape!':>8}   {e.shape} vs {tgt.shape}")
        continue
    print(f"  {name:<28}{tgt_name:<22}{auroc(e, tgt):>8.4f}   {exp}")

print("\n  Row 1 near 0.86 confirms the pipeline. Rows 3 and 4 near 0.50")
print("  confirm the files are from different regions. If row 1 comes back")
print("  near 0.60 instead, the dump used the wrong split and the scene-4")
print("  result needs re-measuring.")
