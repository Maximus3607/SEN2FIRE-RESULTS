r"""
COMPILE RESULTS: every readout, every model, every calibration score -- one
consistent protocol, saved to CSV so each number in the paper traces to a row.

READOUTS (fitted on the HELD-IN half of each model's clear scene-3 file,
scored on the HELD-OUT half at every severity given)
  softmax          plain two-class softmax
  temperature      one temperature                                (NLL)
  class-cond T     one temperature per predicted class            (NLL)
  Platt            sigmoid(a*gap + b)                             (NLL; can move predictions)
  isotonic         monotone map of the gap                        (can move predictions)
  trained gate     the null logit model B learned in training     (model B files only)
  height gate      abstention driven by the predicted class's logit (fixed c, k, gamma)
  evidence null    gate-free: null logit slides with that logit

SCORES, for every readout x model x severity
  standard ECE | pred-fire ECE (PRIMARY) | pred-bg ECE | true-fire ECE | true-bg ECE
  NLL | Brier (three-outcome form: for two-class readouts it equals twice the
  binary Brier) | AURC | IoU | confidence and accuracy on true fire
  and, per pixel type (detected fire / false alarm / missed fire / correct bg),
  the EXACT mean confidence and mean abstention -- replacing earlier estimates.
  Pixel types are defined by each readout's OWN prediction; Platt and isotonic
  can shift the decision boundary, so their groups can differ slightly.

ANTISYMMETRY, per model x severity -- measured directly for the first time
  mean |z0+z1|, mean |z1-z0|, their ratio, and the fraction of pixels whose two
  logits have opposite signs. Exact antisymmetry would give |z0+z1| = 0. Then,
  within predicted background: corr(sum, gap), and error-AUROC of the gap, the
  sum, the predicted class's logit, and the best possible function of both
  logits (the ceiling, fitted on held-in, scored on held-out).

WHAT THIS DOES NOT DO: confidence intervals. Those come from final_compare.py
(readout vs baselines) and paired_compare.py (model vs model). This is the full
point-estimate ledger. Earlier custom readouts (null-term, soft-cap, hinge,
SAEA) were tested on model A, scene 4, under a different protocol -- report them
separately, labelled as such.

Usage: one --model per model, a label then its 0p00, 0p20, 0p50 files.
  python3 compile_results.py \
    --model A_s0 scene3_haze_0p00_logits.npz scene3_haze_0p20_logits.npz scene3_haze_0p50_logits.npz \
    --model B_s0 gated_scene3_haze_0p00_logits.npz gated_scene3_haze_0p20_logits.npz gated_scene3_haze_0p50_logits.npz \
    --model A_s1 A_s1_scene3_haze_0p00_logits.npz A_s1_scene3_haze_0p20_logits.npz A_s1_scene3_haze_0p50_logits.npz \
    --model B_s1 B_s1_scene3_haze_0p00_logits.npz B_s1_scene3_haze_0p20_logits.npz B_s1_scene3_haze_0p50_logits.npz
Writes all_results.csv and antisymmetry.csv.
"""

import sys, argparse, csv
import numpy as np
from reverse_gate import load, evidence, readout as gate_readout, fit as gate_fit, sigmoid
from evidence_null import readout as en_readout, fit as en_fit
from final_compare import fit_T, fixed
from height_check import auroc, ceiling

NB, NR = 20, 2000
_trapz = getattr(np, "trapezoid", None) or getattr(np, "trapz")
GROUPS = ("detected", "false_alarm", "missed", "correct_bg")


# ------------------------------------------------------------------ metrics
def ece(conf, corr):
    if conf.size == 0: return float("nan")
    b = np.clip((conf * NB).astype(int), 0, NB - 1)
    return float(np.abs(np.bincount(b, corr, NB) - np.bincount(b, conf, NB)).sum() / conf.size)


def aurc(conf, corr):
    b = np.clip((conf * NR).astype(int), 0, NR - 1)
    n = np.bincount(b, minlength=NR)[::-1].astype(float)
    e = np.bincount(b, 1 - corr, NR)[::-1]
    cn, ce = np.cumsum(n), np.cumsum(e); k = cn > 0
    return float(_trapz(ce[k] / cn[k], cn[k] / cn[-1]))


def score(pb, pf, pn, y, pred):
    """Every metric from a (bg, fire, abstain) distribution and a prediction."""
    conf = np.where(pred, pf, pb).astype(np.float64)
    corr = (pred == y).astype(np.float64)
    f, b = y, ~y
    pt = np.clip(np.where(y, pf, pb), 1e-9, 1.0)
    brier = (pb - b)**2 + (pf - f)**2 + pn**2
    tp = float((pred & f).sum()); fp = float((pred & b).sum()); fn = float((~pred & f).sum())
    g = {"detected": pred & f, "false_alarm": pred & b, "missed": ~pred & f, "correct_bg": ~pred & b}
    r = dict(standard_ece=ece(conf, corr), pred_fire_ece=ece(conf[pred], corr[pred]),
             pred_bg_ece=ece(conf[~pred], corr[~pred]), true_fire_ece=ece(conf[f], corr[f]),
             true_bg_ece=ece(conf[b], corr[b]), nll=float(-np.log(pt).mean()),
             brier=float(brier.mean()), aurc=aurc(conf, corr), iou=tp / (tp + fp + fn + 1e-9),
             conf_fire=float(conf[f].mean()), acc_fire=float(corr[f].mean()))
    for k, m in g.items():
        r[f"conf_{k}"] = float(conf[m].mean()) if m.any() else float("nan")
        r[f"abst_{k}"] = float(pn[m].mean()) if m.any() else float("nan")
    return r


# ----------------------------------------------------------------- readouts
def two_class(pf):
    pf = pf.astype(np.float32)
    return 1 - pf, pf, np.zeros_like(pf), pf > 0.5


def three_class(z0, z1, eta):
    m = np.maximum(np.maximum(z0, z1), eta)
    lse = m + np.log(np.exp(z0 - m) + np.exp(z1 - m) + np.exp(eta - m))
    return np.exp(z0 - lse), np.exp(z1 - lse), np.exp(eta - lse), z1 > z0


def fit_platt(g, y, n=3_000_000):
    if g.size > n:
        i = np.random.default_rng(1).choice(g.size, n, replace=False); g, y = g[i], y[i]
    X = np.column_stack([np.ones_like(g), g]).astype(np.float64); y = y.astype(np.float64)
    w = np.array([0.0, 1.0])
    for _ in range(30):
        p = sigmoid(X @ w); H = (X * (p * (1 - p))[:, None]).T @ X + 1e-6 * np.eye(2)
        step = np.linalg.solve(H, X.T @ (p - y)); w -= step
        if np.abs(step).max() < 1e-8: break
    return w


def fit_isotonic(g, y, nb=2000):
    """Pool-adjacent-violators on quantile bins of the gap -> monotone P(fire | gap)."""
    edges = np.unique(np.quantile(g, np.linspace(0, 1, nb + 1)))
    b = np.clip(np.searchsorted(edges, g, "right") - 1, 0, len(edges) - 2)
    n = np.bincount(b, minlength=len(edges) - 1).astype(float)
    s = np.bincount(b, y.astype(float), len(edges) - 1)
    keep = n > 0; val, wt, blocks = [], [], []
    for v, w, idx in zip(s[keep] / n[keep], n[keep], np.flatnonzero(keep)):
        val.append(v); wt.append(w); blocks.append([idx])
        while len(val) > 1 and val[-2] > val[-1]:
            v2, w2, b2 = val.pop(), wt.pop(), blocks.pop()
            val[-1] = (val[-1] * wt[-1] + v2 * w2) / (wt[-1] + w2); wt[-1] += w2; blocks[-1] += b2
    table = np.zeros(len(edges) - 1)
    for v, bl in zip(val, blocks): table[bl] = v
    # fill empty bins from neighbours so every gap maps somewhere
    for i in range(len(table)):
        if not keep[i]: table[i] = table[i - 1] if i else val[0]
    return edges, np.clip(table, 1e-6, 1 - 1e-6)


def apply_isotonic(model, g):
    edges, table = model
    return table[np.clip(np.searchsorted(edges, g, "right") - 1, 0, len(table) - 1)]


# -------------------------------------------------------------------- model
class Model:
    def __init__(self, label, files):
        self.label, self.files = label, files
        z = np.load(files[0])
        self.is_B = ("nu_target" in z.files and float(z["nu_target"]) > 0) or \
                    ("nu_target" not in z.files and "null_logit" in z.files)
        n = int(z["logits"].shape[0])
        perm = np.random.default_rng(0).permutation(n)          # SAME split everywhere
        self.fit_idx, self.ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])

    def fit(self):
        d = fixed(load(self.files[0], self.fit_idx))
        g, y = d["z1"] - d["z0"], d["y"] == 1; pred = g > 0
        self.T = fit_T(g, y)
        self.Tc = {c: fit_T(g[pred == c], y[pred == c]) for c in (False, True)}
        self.platt = fit_platt(g, y)
        self.iso = fit_isotonic(g, y)
        print(f"  [{self.label}] fitting height gate ...", flush=True)
        self.gate = gate_fit(d, "height gate")
        print(f"  [{self.label}] fitting evidence null ...", flush=True)
        self.en = en_fit(d)
        print(f"  [{self.label}] T={self.T:.4f}  class-cond T bg={self.Tc[False]:.4f} "
              f"fire={self.Tc[True]:.4f}  Platt a={self.platt[1]:.4f} b={self.platt[0]:+.4f}", flush=True)

    def readouts(self, path):
        d = fixed(load(path, self.ev_idx)); g = d["z1"] - d["z0"]
        out = {"softmax": two_class(sigmoid(g)),
               "temperature": two_class(sigmoid(g / self.T)),
               "class-cond T": two_class(sigmoid(g / np.where(g > 0, self.Tc[True], self.Tc[False]))),
               "Platt": two_class(sigmoid(self.platt[1] * g + self.platt[0])),
               "isotonic": two_class(apply_isotonic(self.iso, g))}
        if self.is_B:
            eta = np.load(path)["null_logit"][self.ev_idx].astype(np.float32).ravel()
            out["trained gate"] = three_class(d["z0"], d["z1"], eta)
        cg, _, pn, pr = gate_readout(d, evidence(d, "height gate"), *self.gate)
        # rebuild the full distribution for the height gate from its own pieces
        pb = np.where(pr, (1 - pn) - cg, cg); pf = np.where(pr, cg, (1 - pn) - cg)
        out["height gate"] = (pb, pf, pn, pr)
        c, _, pn2 = en_readout(d, self.en); pr2 = d["z1"] > d["z0"]
        out["evidence null"] = (np.where(pr2, (1 - pn2) - c, c), np.where(pr2, c, (1 - pn2) - c), pn2, pr2)
        return d, out


def antisymmetry(model, path):
    zf, ze = np.load(path), None
    def get(idx):
        lg = zf["logits"][idx].astype(np.float32); y = zf["labels"][idx]
        if y.ndim == 4: y = y[:, 0]
        return lg[:, 0].ravel(), lg[:, 1].ravel(), y.ravel() == 1
    z0f, z1f, yf = get(model.fit_idx); z0, z1, y = get(model.ev_idx)
    s, g = z0 + z1, z1 - z0
    pb = z1 <= z0; wrong = (z1 > z0) != y
    pbf = z1f <= z0f; wrongf = ((z1f > z0f) != yf).astype(float)
    sb, gb, wb = 0.5 * s[pb], g[pb], wrong[pb].astype(float)
    k = np.random.default_rng(1).choice(pbf.sum(), min(int(pbf.sum()), 3_000_000), replace=False)
    ceil = auroc(ceiling(z0f[pbf][k], z1f[pbf][k], wrongf[pbf][k], z0[pb], z1[pb]), wb)
    return dict(mean_abs_sum=float(np.abs(s).mean()), mean_abs_gap=float(np.abs(g).mean()),
                ratio_sum_to_gap=float(np.abs(s).mean() / np.abs(g).mean()),
                frac_opposite_signs=float((z0 * z1 < 0).mean()),
                corr_sum_gap_predbg=float(np.corrcoef(sb, gb)[0, 1]),
                auroc_gap_predbg=auroc(gb, wb), auroc_sum_predbg=auroc(sb, wb),
                auroc_winner_predbg=auroc(z0[pb], wb), ceiling_predbg=ceil)


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--model", action="append", nargs="+", default=[])
    ap.add_argument("--out", default="all_results.csv")
    a = ap.parse_args()
    if not a.model:
        print(__doc__); sys.exit(1)
    models = [Model(m[0], m[1:]) for m in a.model]

    rows, anti = [], []
    for M in models:
        print(f"\n=== {M.label}  ({'model B' if M.is_B else 'model A'})", flush=True)
        M.fit()
        for path in M.files:
            beta = float(np.load(path)["beta0"])
            d, out = M.readouts(path); y = d["y"] == 1
            for name, (pb, pf, pn, pred) in out.items():
                r = score(pb, pf, pn, y, pred)
                rows.append(dict(model=M.label, beta0=beta, readout=name, **r))
            anti.append(dict(model=M.label, beta0=beta, **antisymmetry(M, path)))
            print(f"  scored beta0={beta}", flush=True)

    with open(a.out, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    with open("antisymmetry.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(anti[0].keys())); w.writeheader(); w.writerows(anti)

    labels = [M.label for M in models]
    names = ["softmax", "temperature", "class-cond T", "Platt", "isotonic",
             "trained gate", "height gate", "evidence null"]
    betas = sorted({r["beta0"] for r in rows})
    for metric, title in [("pred_fire_ece", "PREDICTED-FIRE ECE (primary)"),
                          ("true_fire_ece", "TRUE-FIRE ECE"), ("true_bg_ece", "TRUE-BACKGROUND ECE"),
                          ("aurc", "AURC")]:
        for bt in betas:
            print(f"\n{title}, beta0 = {bt}")
            print(f"  {'readout':<15}" + "".join(f"{l:>11}" for l in labels))
            for nm in names:
                vals = [next((r[metric] for r in rows if r["model"] == l and r["beta0"] == bt
                              and r["readout"] == nm), None) for l in labels]
                if all(v is None for v in vals): continue
                print(f"  {nm:<15}" + "".join(f"{'--':>11}" if v is None else f"{v:>11.4f}" for v in vals))

    print("\nANTISYMMETRY (held-out patches)")
    print(f"  {'model':<8}{'beta0':>6}{'|z0+z1|':>10}{'|gap|':>9}{'ratio':>8}{'opp.sign':>10}"
          f"{'corr pb':>9}{'AUROC gap':>11}{'sum':>7}{'winner':>8}{'ceiling':>9}")
    for r in anti:
        print(f"  {r['model']:<8}{r['beta0']:>6.2f}{r['mean_abs_sum']:>10.3f}{r['mean_abs_gap']:>9.3f}"
              f"{r['ratio_sum_to_gap']:>8.3f}{r['frac_opposite_signs']:>10.3f}{r['corr_sum_gap_predbg']:>9.3f}"
              f"{r['auroc_gap_predbg']:>11.4f}{r['auroc_sum_predbg']:>7.3f}{r['auroc_winner_predbg']:>8.4f}"
              f"{r['ceiling_predbg']:>9.4f}")
    print(f"\nWrote {a.out} ({len(rows)} rows) and antisymmetry.csv ({len(anti)} rows).")
    print("Every number above traces to a row in those files -- use them as the claims ledger.")


if __name__ == "__main__":
    main()
