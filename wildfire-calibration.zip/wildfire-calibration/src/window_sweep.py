"""
WINDOW SWEEP: what is the ceiling on the spatial abstention gate?

The SAEA energy is

    E_i = z_0,i - C + lambda * S_i(W) * omega(A_i)

where S_i(W) is the fraction of a W x W neighbourhood the model predicted as
fire. Note the PLUS sign: opening the gates must push E UP toward z_0 so the
abstention term expands. Earlier drafts had a minus, which shrank abstention
exactly when it should have grown.

WHY THIS SWEEP DECIDES EVERYTHING

Where S_i = 0 the gate term vanishes and E_i = z_0,i - C for every possible
parameter setting. Those pixels can NEVER be flagged, by any Theta. So the
maximum reachable population is exactly the COVERAGE of S: the fraction of
missed fire with S_i > 0. That is a structural ceiling, not a tuning problem.

At W = 9 the measured coverage was 2.4%, capping any ECE(fire) gain near 0.008.
The hypothesis is that a larger window fixes this, because a 9x9 window spans
90 m while the MODIS label cell is 1000 m -- the window is an order of
magnitude smaller than the structure it is meant to detect. That hypothesis is
untested, and this script tests it.

WHAT IS REPORTED, per window size

  coverage      share of missed fire with S > 0. THE CEILING. Everything else
                is irrelevant if this stays small.
  precision     share of pixels with S > 0 that are actually missed fire.
                Low precision means the gate also fires on correct background,
                which damages calibration that is currently near-perfect
                (background ECE -0.008).
  AUROC         how well S ranks missed fire above correct background.
  ECE gain      an UPPER BOUND on the achievable improvement, computed as if
                every reachable missed-fire pixel were softened perfectly to
                confidence 0.5 and no correct pixel were touched. Real gains
                will be lower. If even this bound is small, stop here.

Larger windows raise coverage but lower precision -- the sweep finds where that
trade turns over.

numpy only. Usage:
  python3 window_sweep.py test_logits.npz haze_0p20_logits.npz ...
"""

import sys
import numpy as np

WINDOWS = [9, 21, 51, 101, 151, 201]


def load(path):
    z = np.load(path)
    lg = z["logits"].astype(np.float32)
    lb = z["labels"]
    if lb.ndim == 4:
        lb = lb[:, 0]
    beta = float(z["beta0"]) if "beta0" in z.files else float("nan")
    return lg, lb.astype(np.int64), beta


def box_mean(x, k):
    """Mean over a k x k neighbourhood via summed-area table. x is (N,H,W)."""
    p = k // 2
    xp = np.pad(x.astype(np.float32), ((0, 0), (p, p), (p, p)), mode="edge")
    c = xp.cumsum(1).cumsum(2)
    c = np.pad(c, ((0, 0), (1, 0), (1, 0)))
    H, W = x.shape[1], x.shape[2]
    return (c[:, k:k+H, k:k+W] - c[:, 0:H, k:k+W]
            - c[:, k:k+H, 0:W] + c[:, 0:H, 0:W]) / (k * k)


def auroc(score, target, n=600_000, seed=0):
    s = score.ravel().astype(np.float64)
    t = target.ravel().astype(np.float64)
    if s.size > n:
        rng = np.random.default_rng(seed)
        i = rng.choice(s.size, n, replace=False)
        s, t = s[i], t[i]
    npos, nneg = t.sum(), (1 - t).sum()
    if npos == 0 or nneg == 0:
        return float("nan")
    o = np.argsort(s)
    r = np.empty(s.size); r[o] = np.arange(1, s.size + 1)
    return (r[t == 1].sum() - npos * (npos + 1) / 2) / (npos * nneg)


def main(paths):
    for path in paths:
        lg, lb, beta = load(path)
        pred = lg.argmax(1)
        prob = 1.0 / (1.0 + np.exp(-(lg[:, 1] - lg[:, 0])))     # p(fire)
        conf_bg = 1.0 - prob                                     # conf when bg
        pb = pred == 0
        miss = pb & (lb == 1)
        corr = pb & (lb == 0)
        fire_total = int((lb == 1).sum())

        print(f"\n{path}   beta0 = {beta}")
        print(f"  predicted background {int(pb.sum()):,}  "
              f"| missed fire {int(miss.sum()):,}  "
              f"| correct bg {int(corr.sum()):,}")
        if miss.sum() == 0:
            print("  no missed fire, skipping"); continue

        # mean confidence on the missed-fire pixels, needed for the bound
        c_miss = float(conf_bg[miss].mean())
        print(f"  mean confidence on missed fire: {c_miss:.4f}   "
              f"(true accuracy there is 0 by definition)")
        print(f"\n  {'W':>5}{'span':>8}{'coverage':>10}{'precision':>11}"
              f"{'AUROC':>8}{'ECE gain (upper bd)':>21}")

        yhat = (pred == 1).astype(np.float32)
        for W in WINDOWS:
            S = box_mean(yhat, W)
            sm, sc = S[miss], S[corr]
            hit_m = sm > 0
            cov = float(hit_m.mean())
            n_hit_m = float(hit_m.sum())
            n_hit_c = float((sc > 0).sum())
            prec = n_hit_m / max(n_hit_m + n_hit_c, 1)
            a = auroc(np.concatenate([sc, sm]),
                      np.concatenate([np.zeros(sc.size), np.ones(sm.size)]))
            # upper bound: every reachable missed-fire pixel softened to 0.5,
            # nothing else touched. ECE(fire) is over ALL true fire pixels.
            bound = (n_hit_m / max(fire_total, 1)) * max(c_miss - 0.5, 0.0)
            print(f"  {W:>5}{W*10:>7}m{cov:>10.2%}{prec:>11.2%}"
                  f"{a:>8.4f}{bound:>21.5f}")

    print("\nHOW TO READ THIS")
    print("  COVERAGE is the ceiling. If it stays low at every W, the spatial")
    print("  gate cannot reach the failures and SAEA is capped no matter how")
    print("  the parameters are fitted -- report that as a finding and move to")
    print("  a different signal.")
    print("  PRECISION falling as W grows means the gate starts firing on")
    print("  correct background. Since background calibration is currently")
    print("  near-perfect (-0.008), that damage can exceed the fire-side gain.")
    print("  ECE GAIN is an UPPER BOUND assuming perfect softening of every")
    print("  reachable pixel and zero collateral damage. Real gains are lower.")
    print("  For scale: adaptive T beat uncalibrated by 0.0070 on ECE(fire).")
    print("  If the bound is not comfortably above that, the method is not")
    print("  worth building.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    main(sys.argv[1:])
