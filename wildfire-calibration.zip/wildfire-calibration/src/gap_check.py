r"""
GAP CHECK: is the logit SUM genuinely new information, or does model B's own
GAP already carry it?

The finding to test. Within pixels PREDICTED BACKGROUND, the logit sum
s = (z0+z1)/2 separated missed fire from correct background at usable AUROC
0.77 on model B -- far above anything on model A (best 0.65).

But model B's logits differ from model A's everywhere, the gap included. If
model B's GAP also separates missed fire at ~0.77, then s adds nothing: plain
softmax reads the gap, so it already sees the signal, and the improvement is
"model B has better logits", not "reading the sum helps". The claim that the
sum is a new channel requires s to carry something the gap does not.

WHAT IT REPORTS, within each predicted class
  AUROC(s)          sum alone
  AUROC(gap)        gap alone -- what plain softmax can see
  corr(s, gap)      how redundant they are
  AUROC(s + gap)    a two-feature logistic model, FITTED ON THE HELD-IN HALF
                    and scored on the held-out half, so the combination is not
                    flattered by fitting and scoring on the same pixels

HOW TO READ IT
  s clearly > gap        -> the sum is a genuinely new channel. The core claim holds.
  s ~ gap, high corr     -> redundant. s is the gap in disguise; MSP already sees it.
  combined > both        -> complementary. A gate reading BOTH should beat either,
                            which justifies the two-dimensional gate.
  combined ~ max(s,gap)  -> no complementarity; a 2-D gate would not help.

Runs on model A's files too. Model A's logits are antisymmetric, so its s is
near-constant and AUROC(s) should sit near 0.5 -- a built-in sanity check.

Usage:
  python3 gap_check.py gated_scene3_haze_0p20_logits.npz scene3_haze_0p20_logits.npz
"""

import sys
import numpy as np


def auroc(score, target):
    """Usable AUROC -- max(a, 1-a), since a signal ranking errors LOWER is
    equally usable once inverted. Returns (usable, raw)."""
    s = score.astype(np.float64); t = target.astype(np.float64)
    if s.size > 2_000_000:
        i = np.random.default_rng(0).choice(s.size, 2_000_000, replace=False)
        s, t = s[i], t[i]
    npos, nneg = t.sum(), (1-t).sum()
    if npos == 0 or nneg == 0: return float("nan"), float("nan")
    o = np.argsort(s); r = np.empty(s.size); r[o] = np.arange(1, s.size+1)
    a = float((r[t == 1].sum() - npos*(npos+1)/2) / (npos*nneg))
    return max(a, 1-a), a


def fit_logistic(X, y, iters=25):
    """Class-balanced logistic regression by Newton's method. Two features plus
    a bias -- three parameters, so there is nothing to overfit on millions of
    pixels. Balanced so the rare error class is not ignored."""
    mu, sd = X.mean(0), X.std(0) + 1e-9
    Z = np.column_stack([np.ones(len(X)), (X - mu) / sd])
    w = np.where(y == 1, 0.5/max(y.mean(), 1e-9), 0.5/max(1-y.mean(), 1e-9))
    b = np.zeros(Z.shape[1])
    for _ in range(iters):
        p = 1/(1 + np.exp(-np.clip(Z @ b, -30, 30)))
        g = Z.T @ (w*(p - y))
        H = (Z * (w*p*(1-p))[:, None]).T @ Z + 1e-6*np.eye(Z.shape[1])
        step = np.linalg.solve(H, g); b -= step
        if np.abs(step).max() < 1e-7: break
    return mu, sd, b


def apply_logistic(model, X):
    mu, sd, b = model
    Z = np.column_stack([np.ones(len(X)), (X - mu) / sd])
    return Z @ b


def load(path, idx):
    z = np.load(path)
    lg = z["logits"][idx].astype(np.float32); y = z["labels"][idx]
    if y.ndim == 4: y = y[:, 0]
    z0, z1 = lg[:, 0].ravel(), lg[:, 1].ravel()
    return z0, z1, y.ravel().astype(np.int8)


def main(paths):
    for path in paths:
        n = int(np.load(path)["logits"].shape[0])
        perm = np.random.default_rng(0).permutation(n)       # same split as before
        fit_idx, ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])
        tag = "MODEL B (gated)" if "null_logit" in np.load(path).files else "MODEL A"
        beta = np.load(path)["beta0"] if "beta0" in np.load(path).files else "?"
        print(f"\n=== {path.split('/')[-1]}   {tag}   beta0 = {float(beta)}")
        print(f"  {'population':<34}{'AUROC(s)':>10}{'AUROC(gap)':>12}"
              f"{'corr':>8}{'AUROC(s+gap)':>14}")

        z0f, z1f, yf = load(path, fit_idx)
        z0e, z1e, ye = load(path, ev_idx)
        for nm, want_pred in [("pred BACKGROUND: missed vs correct", False),
                              ("pred FIRE: false alarm vs detected", True)]:
            pf = (z1f > z0f) == want_pred; pe = (z1e > z0e) == want_pred
            sf, gf = 0.5*(z0f+z1f)[pf], (z1f-z0f)[pf]
            se, ge = 0.5*(z0e+z1e)[pe], (z1e-z0e)[pe]
            wf = ((z1f > z0f) != (yf == 1))[pf].astype(np.float64)
            we = ((z1e > z0e) != (ye == 1))[pe].astype(np.float64)
            if we.sum() == 0 or wf.sum() == 0:
                print(f"  {nm:<34}  no errors in this population"); continue
            a_s, _ = auroc(se, we); a_g, _ = auroc(ge, we)
            # s is near-constant on an antisymmetric model, so guard the division
            c = (float(np.corrcoef(se, ge)[0, 1])
                 if se.size > 1 and se.std() > 1e-6 and ge.std() > 1e-6 else float("nan"))
            # fit on held-in, score held-out
            if pf.sum() > 2_000_000:
                k = np.random.default_rng(1).choice(pf.sum(), 2_000_000, replace=False)
                sf, gf, wf = sf[k], gf[k], wf[k]
            m = fit_logistic(np.column_stack([sf, gf]), wf)
            a_c, _ = auroc(apply_logistic(m, np.column_stack([se, ge])), we)
            print(f"  {nm:<34}{a_s:>10.4f}{a_g:>12.4f}{c:>8.3f}{a_c:>14.4f}")

    print("\nHOW TO READ THIS")
    print("  The predicted-BACKGROUND row is the one that matters: missed fire")
    print("  lives there, and it drives ECE(fire).")
    print("  AUROC(s) clearly above AUROC(gap) -> the sum is a genuinely new")
    print("    channel that plain softmax cannot see. The core claim holds.")
    print("  AUROC(s) ~ AUROC(gap) with high corr -> the sum is the gap in")
    print("    disguise; model B simply has better logits, and MSP already sees it.")
    print("  AUROC(s+gap) above both -> complementary information; a gate that")
    print("    reads both should beat either one alone.")
    print("  On MODEL A, AUROC(s) should sit near 0.5: its logits are")
    print("    antisymmetric, so the sum carries nothing. That is a sanity check.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    main(sys.argv[1:])
