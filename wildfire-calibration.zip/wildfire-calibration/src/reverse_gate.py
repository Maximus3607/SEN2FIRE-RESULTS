r"""
REVERSE THE GATE? Three versions of the same gated null readout, differing ONLY
in what the gate reads -- i.e. only in WHEN abstention is applied.

    eta = c + k * sigmoid( gamma * (tau - x) )      abstention high when x < tau
    p(abstain) = e^eta / (e^z0 + e^z1 + e^eta)

c and k are kept from training (closed gate: c ~ -5.7, so abstention ~0 --
effectively "forced to zero" when the evidence is sufficient). tau is fitted
separately for each predicted class on the HELD-IN half; gamma is rescaled to
each input's spread so the gate's sharpness is comparable across versions.

    trained gate    x = s = (z0+z1)/2        as trained: abstains where s is low
    reversed on s   x = -s                   the literal reversal: abstains where s is HIGH
    height gate     x = logit of the PREDICTED class
                                             abstains where the prediction itself is
                                             weakly supported -- a short background
                                             logit for a background call, a short fire
                                             logit for a fire call

The first thing printed for each version is WHAT IT ABSTAINS ON: mean
p(abstain) for detected fire, false alarms, missed fire and correct
background. That table answers the question directly. Then ECE three ways and
AURC -- the risk-coverage metric, which is the right test of abstention.

Usage:
  python3 reverse_gate.py gated_scene3_haze_0p00_logits.npz \
      gated_scene3_haze_0p20_logits.npz gated_scene3_haze_0p50_logits.npz
"""

import sys
import numpy as np

_trapz = getattr(np, "trapezoid", None) or getattr(np, "trapz")
NB = 20


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


def ece(conf, corr):
    if conf.size == 0: return float("nan")
    b = np.clip((conf * NB).astype(int), 0, NB - 1)
    return float(np.abs(np.bincount(b, corr, NB) - np.bincount(b, conf, NB)).sum() / conf.size)


def aurc(conf, corr, nb=2000):
    b = np.clip((conf * nb).astype(int), 0, nb - 1)
    n = np.bincount(b, minlength=nb)[::-1].astype(float)
    er = np.bincount(b, 1 - corr, nb)[::-1]
    cn, ce = np.cumsum(n), np.cumsum(er); k = cn > 0
    return float(_trapz(ce[k] / cn[k], cn[k] / cn[-1]))


def load(path, idx):
    z = np.load(path)
    lg = z["logits"][idx].astype(np.float32); y = z["labels"][idx]
    if y.ndim == 4: y = y[:, 0]
    # Files without gate parameters (model A dumps) get model B's trained values.
    # The height gate only borrows c, k and gamma as FIXED shape constants and
    # refits tau, so this makes the readout identical in form across models.
    get = lambda k, dflt: float(z[k]) if k in z.files else dflt
    return dict(z0=lg[:, 0].ravel(), z1=lg[:, 1].ravel(), y=y.ravel().astype(np.int8),
                c=get("gate_c", -5.658), k=get("gate_k", 8.486), g=get("gate_gamma", 2.751),
                tau=get("gate_tau", -0.210), has_gate="gate_c" in z.files,
                nu=float(z["nu_target"]) if "nu_target" in z.files else None,
                seed=int(z["seed"]) if "seed" in z.files else None,
                beta=float(z["beta0"]) if "beta0" in z.files else float("nan"))


def evidence(d, version):
    s = 0.5 * (d["z0"] + d["z1"]); pred = d["z1"] > d["z0"]
    if version == "trained gate":  return s
    if version == "reversed on s": return -s
    if version == "height gate":   return np.where(pred, d["z1"], d["z0"])
    raise ValueError(version)


def readout(d, x, taus, gammas):
    """Class-conditional gate. taus/gammas: dict pred-class -> value (None = off)."""
    pred = d["z1"] > d["z0"]
    gate = np.zeros_like(x)
    for c in (False, True):
        m = pred == c
        if taus[c] is not None:
            gate[m] = sigmoid(gammas[c] * (taus[c] - x[m]))
    eta = d["c"] + d["k"] * gate
    mx = np.maximum(np.maximum(d["z0"], d["z1"]), eta)
    lse = mx + np.log(np.exp(d["z0"]-mx) + np.exp(d["z1"]-mx) + np.exp(eta-mx))
    pb, pf, pn = np.exp(d["z0"]-lse), np.exp(d["z1"]-lse), np.exp(eta-lse)
    conf = np.where(pred, pf, pb)                    # NOT renormalised
    corr = (pred == (d["y"] == 1)).astype(np.float64)
    return conf, corr, pn, pred


def fit(d, version, n_fire=400_000, n_bg=1_600_000):
    """Grid over tau per predicted class (plus OFF), objective ECE(fire)+ECE(bg)
    -- the same objective as the earlier class-conditional gate, for comparability."""
    rng = np.random.default_rng(0)
    fi = np.flatnonzero(d["y"] == 1); bi = np.flatnonzero(d["y"] == 0)
    i = np.sort(np.concatenate([rng.choice(fi, min(n_fire, fi.size), replace=False),
                                rng.choice(bi, min(n_bg, bi.size), replace=False)]))
    ds = {k: (v[i] if isinstance(v, np.ndarray) else v) for k, v in d.items()}
    x = evidence(ds, version); pred = ds["z1"] > ds["z0"]
    s_all = 0.5 * (ds["z0"] + ds["z1"])
    gam, grids = {}, {}
    for c in (False, True):
        xm = x[pred == c]
        # rescale the trained sharpness to this input's spread
        gam[c] = d["g"] * (s_all[pred == c].std() + 1e-6) / (xm.std() + 1e-6)
        grids[c] = [None] + list(np.quantile(xm, np.linspace(0.02, 0.6, 15)))
    best = None
    for tb in grids[False]:
        for tf in grids[True]:
            conf, corr, _, _ = readout(ds, x, {False: tb, True: tf}, gam)
            f = ds["y"] == 1
            obj = ece(conf[f], corr[f]) + ece(conf[~f], corr[~f])
            if best is None or obj < best[0]:
                best = (obj, {False: tb, True: tf})
    return best[1], gam


def main(paths):
    n = int(np.load(paths[0])["logits"].shape[0])
    perm = np.random.default_rng(0).permutation(n)          # SAME split as before
    fit_idx, ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])
    df = load(paths[0], fit_idx)
    versions = ["trained gate", "reversed on s", "height gate"]
    fitted = {}
    for v in versions:
        if v == "trained gate":
            s_all = 0.5*(df["z0"]+df["z1"])
            fitted[v] = ({False: df["tau"], True: df["tau"]}, {False: df["g"], True: df["g"]})
        else:
            print(f"fitting {v} ...", flush=True)
            fitted[v] = fit(df, v)
    fmt = lambda t: " OFF " if t is None else f"{t:+.3f}"
    print(f"\nfitted on {len(fit_idx)} held-in patches")
    for v in versions:
        t, _ = fitted[v]
        print(f"  {v:<15} tau (pred bg) {fmt(t[False])}   tau (pred fire) {fmt(t[True])}")

    for path in paths[1:]:
        d = load(path, ev_idx)
        pred = d["z1"] > d["z0"]; y = d["y"] == 1
        groups = {"detected fire": y & pred, "false alarm": ~y & pred,
                  "missed fire": y & ~pred, "correct bg": ~y & ~pred}
        print(f"\n=== {path.split('/')[-1]}   beta0 = {d['beta']}   ({len(ev_idx)} held-out patches)")

        print("\n  WHAT EACH VERSION ABSTAINS ON  (mean p(abstain))")
        print(f"  {'version':<16}" + "".join(f"{g:>15}" for g in groups))
        res = {}
        for v in versions:
            conf, corr, pn, _ = readout(d, evidence(d, v), *fitted[v])
            res[v] = (conf, corr)
            print(f"  {v:<16}" + "".join(f"{pn[m].mean():>15.4f}" for m in groups.values()))

        p = sigmoid(d["z1"] - d["z0"])
        conf_id = np.where(pred, p, 1 - p); corr_id = (pred == y).astype(np.float64)
        print(f"\n  {'readout':<16}{'ECE':>8}{'pred fire':>10}{'pred bg':>9}"
              f"{'TRUE fire':>11}{'TRUE bg':>9}{'AURC':>9}{'conf|fire':>11}")
        for nm, (conf, corr) in [("identity", (conf_id, corr_id))] + list(res.items()):
            print(f"  {nm:<16}{ece(conf, corr):>8.4f}{ece(conf[pred], corr[pred]):>10.4f}"
                  f"{ece(conf[~pred], corr[~pred]):>9.4f}{ece(conf[y], corr[y]):>11.4f}"
                  f"{ece(conf[~y], corr[~y]):>9.4f}{aurc(conf, corr):>9.5f}{conf[y].mean():>11.4f}")

    print("\nHOW TO READ THIS")
    print("  The abstention table is the answer. A good version abstains on MISSED")
    print("  FIRE and FALSE ALARMS (the errors) and leaves DETECTED FIRE and CORRECT")
    print("  BACKGROUND alone.")
    print("  'reversed on s' is expected to hit correct background hardest -- that")
    print("  is why a literal reversal does not work.")
    print("  'height gate' should spare detected fire. How much more it puts on")
    print("  missed fire than on correct background is capped by the ~0.76")
    print("  separability you already measured.")
    print("  AURC (lower = better) is the fair test of an abstention mechanism;")
    print("  TRUE-fire ECE punishes honest calibration, as ece_anatomy.py showed.")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    main(sys.argv[1:])
