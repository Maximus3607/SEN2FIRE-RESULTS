"""
Aerosol-aware per-pixel temperature scaling for wildfire segmentation (Sen2Fire).

------------------------------------------------------------------------------
THE PROBLEM THIS CODE IS DESIGNED AROUND
------------------------------------------------------------------------------
Sen2Fire supplies 12 Sentinel-2 reflectance bands plus 1 Sentinel-5P aerosol
layer, and a binary fire mask derived from MODIS MOD14A1.

We want to use the aerosol layer as an *atmospheric degradation signal* that
tells the calibrator "the input is obscured here, so be less confident."

But aerosols are PRODUCED BY FIRES. Aerosol load is therefore correlated with
the fire label. If the aerosol band is fed into the segmentation encoder, then:

  1. Gradient descent will exploit it as fire evidence, because reducing loss is
     the only objective the optimizer has. The network has no concept of
     "aerosol" -- channel 13 is just floats. Its meaning is decided entirely by
     which gradients can reach it.
  2. The temperature would then be conditioned on a variable the prediction
     already depends on. High aerosol would raise fire probability AND modulate
     its own temperature -- so we could end up sharpening exactly where we
     intended to soften.
  3. A temperature conditioned on a label-correlated variable is no longer pure
     post-hoc recalibration; it leaks label information into the calibrator.

This cannot be fixed with a loss term or a comment. There is no way to instruct
the network to "use aerosol for uncertainty but not for detection" -- it has no
representation of that distinction. The only reliable control is STRUCTURAL.

------------------------------------------------------------------------------
THE SOLUTION
------------------------------------------------------------------------------
Cut the gradient path. Two separate consumers of the data:

    12 reflectance bands ---> SEGMENTATION U-NET ---> 2 logits/pixel
    aerosol + haze cue   ---> TEMPERATURE HEAD   ---> T(x,y) > 0

The segmentation network NEVER sees aerosol, so it cannot use it as fire
evidence. The temperature head never receives gradients from the segmentation
loss, because the backbone is frozen before the head is fitted.

Second issue addressed here: Sentinel-5P is a coarse instrument (~km scale).
Resampled to 10 m it is nearly constant within a 512x512 patch (~5 km across),
so aerosol alone gives a per-SCENE temperature, not a per-pixel one. To recover
genuine spatial variation we add a band-disagreement cue computed at native
10 m resolution: smoke attenuates visible wavelengths far more than SWIR, so
visible-vs-SWIR disagreement is large exactly where the visible signal is
compromised -- and it is not a direct fire proxy.

    T(x,y) = softplus( scene term from aerosol  +  pixel term from haze cue )

Accuracy preservation: dividing BOTH logits at a pixel by the same positive
scalar cannot change which is larger. The argmax -- and therefore IoU, F1, and
every hard-decision metric -- is provably unchanged. This is what makes
temperature scaling defensible as post-hoc calibration, and it survives the
move from a global scalar to a per-pixel field.

------------------------------------------------------------------------------
TRAINING PROTOCOL (order matters)
------------------------------------------------------------------------------
Stage 1: train UNet on 12 bands, T fixed at 1.0, CrossEntropyLoss.
Stage 2: freeze ALL UNet weights. Fit TemperatureHead on the VALIDATION area
         (study area 3) by minimising NLL of the temperature-scaled softmax,
         plus a spatial smoothness penalty on T.
Stage 3: evaluate on the TEST area (study area 4) against two baselines:
         uncalibrated, and a single global scalar T.

If any backbone weight updates during Stage 2 you are no longer doing post-hoc
calibration and the accuracy-preservation guarantee is void.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

# -----------------------------------------------------------------------------
# BAND INDICES -- VERIFY THESE AGAINST TABLE 1 OF THE SEN2FIRE PAPER.
# These are placeholders reflecting the usual Sentinel-2 ordering. Getting them
# wrong will silently produce a meaningless haze cue, so check before training.
# -----------------------------------------------------------------------------
IDX_RED = 3       # B4   ~665 nm   -- strongly attenuated by smoke
IDX_NIR = 7       # B8   ~842 nm   -- partially penetrates smoke
IDX_SWIR1 = 10    # B11  ~1610 nm  -- largely penetrates smoke
IDX_SWIR2 = 11    # B12  ~2190 nm  -- largely penetrates smoke
N_REFLECTANCE_BANDS = 12
IDX_AEROSOL = 12  # Sentinel-5P layer -- MUST NOT reach the encoder


def _normalised_difference(a, b, eps=1e-6):
    return (a - b) / (a + b + eps)


def compute_haze_cue(reflectance):
    """Per-pixel smoke indicator at native 10 m resolution.

    Compares a visible-sensitive index against a SWIR-based one. Under clear
    conditions the two broadly agree about vegetation/burn state. Under smoke
    the visible-based index is depressed while the SWIR-based one is not, so
    the disagreement grows. Crucially this is an ATTENUATION signal, not a fire
    signal, which is why it does not reproduce the aerosol confound.

    Args:
        reflectance: (B, 12, H, W) -- reflectance bands ONLY, no aerosol.
    Returns:
        (B, 1, H, W) disagreement magnitude.
    """
    red = reflectance[:, IDX_RED:IDX_RED + 1]
    nir = reflectance[:, IDX_NIR:IDX_NIR + 1]
    swir1 = reflectance[:, IDX_SWIR1:IDX_SWIR1 + 1]
    swir2 = reflectance[:, IDX_SWIR2:IDX_SWIR2 + 1]

    ndvi = _normalised_difference(nir, red)        # visible-dependent
    nbr = _normalised_difference(nir, swir2)       # SWIR-dependent
    nbr2 = _normalised_difference(swir1, swir2)    # SWIR-only reference

    return (0.5 * (ndvi - nbr).abs() + 0.5 * (ndvi - nbr2).abs())


class DoubleConv(nn.Module):
    """Conv -> BatchNorm -> ReLU, twice. The encoder block from your document."""

    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class UNet(nn.Module):
    """Standard U-Net. With base=64 and 4 downsamples this is ~31M parameters,
    which matches the size you quoted -- so this should be close to your model.

    NOTE in_channels defaults to 12, NOT 13. That single integer is the entire
    structural fix for the aerosol confound.
    """

    def __init__(self, in_channels=N_REFLECTANCE_BANDS, n_classes=2, base=64):
        super().__init__()
        self.enc1 = DoubleConv(in_channels, base)
        self.enc2 = DoubleConv(base, base * 2)
        self.enc3 = DoubleConv(base * 2, base * 4)
        self.enc4 = DoubleConv(base * 4, base * 8)
        self.bottleneck = DoubleConv(base * 8, base * 16)
        self.pool = nn.MaxPool2d(2)

        self.up4 = nn.ConvTranspose2d(base * 16, base * 8, 2, stride=2)
        self.dec4 = DoubleConv(base * 16, base * 8)
        self.up3 = nn.ConvTranspose2d(base * 8, base * 4, 2, stride=2)
        self.dec3 = DoubleConv(base * 8, base * 4)
        self.up2 = nn.ConvTranspose2d(base * 4, base * 2, 2, stride=2)
        self.dec2 = DoubleConv(base * 4, base * 2)
        self.up1 = nn.ConvTranspose2d(base * 2, base, 2, stride=2)
        self.dec1 = DoubleConv(base * 2, base)

        self.head = nn.Conv2d(base, n_classes, 1)

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        e4 = self.enc4(self.pool(e3))
        b = self.bottleneck(self.pool(e4))

        d4 = self.dec4(torch.cat([self.up4(b), e4], dim=1))
        d3 = self.dec3(torch.cat([self.up3(d4), e3], dim=1))
        d2 = self.dec2(torch.cat([self.up2(d3), e2], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        return self.head(d1)  # raw logits, (B, 2, H, W)


class TemperatureHead(nn.Module):
    """Predicts a per-pixel temperature field T(x,y) > 0.

    Inputs are ONLY exogenous atmospheric signals -- never the segmentation
    logits, and never any learned feature of the fire predictor. Using the
    logits here would be circular: fixing a miscalibrated output using that
    same output as the evidence.

    T is decomposed into two physically distinct terms at two spatial scales:
      scene term  -- from aerosol, which is near-constant across a patch
      pixel term  -- from the haze cue, which varies at 10 m
    This decomposition also gives a natural ablation table (scene only /
    pixel only / both).
    """

    def __init__(self, hidden=16, t_min=0.05, t_max=10.0):
        super().__init__()
        self.t_min = t_min
        self.t_max = t_max

        # Scene-scale branch: aerosol is spatially flat, so global pooling
        # discards nothing real and avoids fitting resampling artifacts.
        self.scene = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(1, hidden, 1), nn.ReLU(inplace=True),
            nn.Conv2d(hidden, 1, 1),
        )

        # Pixel-scale branch: small receptive field, full resolution.
        self.pixel = nn.Sequential(
            nn.Conv2d(1, hidden, 3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(hidden, hidden, 3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(hidden, 1, 1),
        )

        # Initialise near zero so softplus(0 + 0 + bias) starts close to T=1,
        # i.e. the model begins as an identity transform and can only improve
        # from the uncalibrated starting point.
        nn.init.zeros_(self.scene[-1].weight)
        nn.init.zeros_(self.scene[-1].bias)
        nn.init.zeros_(self.pixel[-1].weight)
        nn.init.constant_(self.pixel[-1].bias, 0.5413)  # softplus(0.5413) ~ 1.0

    def forward(self, aerosol, haze_cue):
        scene_term = self.scene(aerosol)                 # (B,1,1,1)
        pixel_term = self.pixel(haze_cue)                # (B,1,H,W)
        t = F.softplus(scene_term + pixel_term)          # strictly positive
        return t.clamp(self.t_min, self.t_max)


class CalibratedFireNet(nn.Module):
    """Full pipeline with the two data paths kept structurally separate."""

    def __init__(self, base=64, n_classes=2):
        super().__init__()
        self.segmenter = UNet(N_REFLECTANCE_BANDS, n_classes, base)
        self.temperature = TemperatureHead()

    def forward(self, x13, apply_calibration=True):
        """x13: (B, 13, H, W) -- 12 reflectance bands + aerosol at index 12."""
        reflectance = x13[:, :N_REFLECTANCE_BANDS]
        aerosol = x13[:, IDX_AEROSOL:IDX_AEROSOL + 1]

        logits = self.segmenter(reflectance)   # aerosol is NOT passed in
        if not apply_calibration:
            return logits, None

        # detach(): even if someone later unfreezes the backbone, no gradient
        # from the calibration loss can flow back into the segmenter.
        haze = compute_haze_cue(reflectance).detach()
        t = self.temperature(aerosol.detach(), haze)
        return logits / t, t

    def freeze_segmenter(self):
        """Call before Stage 2. Also puts BatchNorm into eval mode so running
        statistics stop updating -- otherwise the 'frozen' network still drifts
        and your calibration is fitted against a moving target."""
        for p in self.segmenter.parameters():
            p.requires_grad_(False)
        self.segmenter.eval()
        return self


def smoothness_penalty(t):
    """Atmospheric conditions are spatially coherent, so T should be too.

    Without this, a free per-pixel T can be driven toward whatever minimises
    pointwise NLL, which is overfitting dressed up as calibration. The penalty
    encodes a genuine physical prior rather than being an arbitrary regulariser.
    """
    dy = (t[:, :, 1:, :] - t[:, :, :-1, :]).abs().mean()
    dx = (t[:, :, :, 1:] - t[:, :, :, :-1]).abs().mean()
    return dy + dx


def calibration_loss(logits, target, t, lam=0.1):
    """Stage 2 objective. NLL is a proper scoring rule, so minimising it
    genuinely rewards calibration rather than mere confidence-flattening."""
    return F.cross_entropy(logits, target) + lam * smoothness_penalty(t)


if __name__ == "__main__":
    model = CalibratedFireNet()

    seg_params = sum(p.numel() for p in model.segmenter.parameters())
    cal_params = sum(p.numel() for p in model.temperature.parameters())
    print(f"Segmenter parameters:   {seg_params:,}")
    print(f"Temperature parameters: {cal_params:,}")

    x = torch.randn(2, 13, 128, 128)
    scaled, t = model(x)
    raw, _ = model(x, apply_calibration=False)

    print(f"\nInput:            {tuple(x.shape)}")
    print(f"Logits:           {tuple(scaled.shape)}")
    print(f"Temperature map:  {tuple(t.shape)}")
    print(f"T range:          [{t.min():.3f}, {t.max():.3f}]")

    # Accuracy preservation check -- must hold for every pixel.
    same = (raw.argmax(1) == scaled.argmax(1)).all()
    print(f"\nArgmax unchanged by scaling: {bool(same)}")

    # Confirm the segmenter is structurally blind to aerosol.
    x_alt = x.clone()
    x_alt[:, IDX_AEROSOL] = torch.randn_like(x_alt[:, IDX_AEROSOL]) * 5
    model.eval()
    with torch.no_grad():
        a, _ = model(x, apply_calibration=False)
        b, _ = model(x_alt, apply_calibration=False)
    print(f"Segmenter output invariant to aerosol: {bool(torch.allclose(a, b))}")

    # Confirm freezing works.
    model.freeze_segmenter()
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Trainable params after freeze: {trainable:,} (should equal {cal_params:,})")
