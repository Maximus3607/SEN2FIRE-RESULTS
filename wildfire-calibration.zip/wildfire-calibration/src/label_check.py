r"""
LABEL CHECK -- is scene 4's "missed fire" visible fire at all?

THE QUESTION
On scene 4 the models miss 73-77% of labelled fire, at 96-97% confidence, and
those misses sit at the same logit height as correct background -- which is
why every readout, the height gate included, lost its selectivity. Two
explanations predict different things:
  LABEL ARTEFACT  the pixels show no fire in the Sentinel-2 image. Labels come
                  from 1 km MODIS cells: a small fire marks all ~10,000 of the
                  cell's 10 m pixels. MODIS and Sentinel-2 also pass at
                  different times, so a fire can end or move in between.
                  Either way, the image the model saw has no fire there.
  MODEL FAILURE   the pixels DO show fire, and the network fails to
                  recognise it -- a representation problem, fixable only by
                  retraining.
This script tests every labelled fire pixel for a visible fire signature and
asks which kind of pixel the confident misses are.

THE FIRE SIGNATURE (fixed, physical, applied identically to both scenes)
Active fire is extremely bright in SWIR2 (B12) relative to near-infrared
(B8A), and SWIR sees through smoke far better than visible bands. Thresholds
from the International Charter Space & Major Disasters Sentinel-2 HOTSPOT
service:
  strict      B12/B8A > 2.0  and  B12 - B8A > 0.15     ("hotspot")
  permissive  B12/B8A > 1.1  and  B12 - B8A > 0.10     ("candidate hotspot")
  water mask  B12 < 0.04 -> never a signature
  near        within 3 pixels (30 m) of a permissive pixel
Only the service's fixed tests are used, not its contextual background test.
The service specifies top-of-atmosphere reflectance; Sen2Fire may be surface
reflectance. The tests are contrast-based, so the difference is small -- but
state it.

OUTPUT (all in /kaggle/working/label_check/)
  report.txt                    everything printed below
  scene_summary.csv             signature share of labelled fire, per scene
  model_summary.csv             per model and scene: missed fire split by
                                visibility, recall on visible fire, logits of
                                each kind of miss, MaxLogit AUROC on each
  cleaned_labels_scene3.npz     original labels + visibility code per pixel:
  cleaned_labels_scene4.npz       0 none, 1 near, 2 permissive, 3 strict
                                (cleaned label = original & (code >= 2), etc.)
  figures/*.png                 patches with the most confident misses

INPUTS: attach Sen2Fire, plus the logit dumps you want checked -- any of
  scene3_haze_0p00_logits.npz / test_logits.npz           (model A seed 0)
  gated_scene3_haze_0p00_logits.npz / gated_scene4_...    (model B seed 0)
  A_s1_scene3_haze_0p00_logits.npz / A_s1_scene4_...      (model A seed 1)
  B_s1_scene3_haze_0p00_logits.npz / B_s1_scene4_...      (model B seed 1)
Patches are found and ordered exactly as dump_gated.py did, and every patch's
label is checked against the dump's label before anything is computed.
No GPU needed.

BAND ORDER is assumed to be the 12-band Sentinel-2 L2A order
  B1 B2 B3 B4 B5 B6 B7 B8 B8A B9 B11 B12
which matches the project's band_idx [3,2,1,7,10,11] for R,G,B,NIR,SWIR1,SWIR2.
The script prints median band values on fire and background pixels so you can
confirm B12 really is the band that lights up on fire.
"""

import os, glob, csv, sys
from pathlib import Path
import numpy as np
from scipy import ndimage

ROOT = os.environ.get("LABELCHECK_ROOT", "/kaggle/input")
OUT = Path(os.environ.get("LABELCHECK_OUT", "/kaggle/working/label_check"))
SCENES = ["scene3", "scene4"]
BAND = dict(B2=1, B3=2, B4=3, B8=7, B8A=8, B11=10, B12=11)
WATER, STRICT, PERMISSIVE = 0.04, (2.0, 0.15), (1.1, 0.10)
NEAR_PX, CONF_MISS, N_FIG = 3, 0.95, 8
CODE = {0: "none", 1: "near (30 m)", 2: "permissive", 3: "strict"}

LOG = []
def say(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); LOG.append(s)


# ---------------------------------------------------------------- data
def find(root, scene):
    """Identical to dump_gated.py, so patch order matches the dumps."""
    return [f for f in sorted(glob.glob(str(Path(root) / "**" / "*.npz"), recursive=True))
            if scene in {p.lower() for p in Path(f).parts[:-1]}]


def load_raw(path):
    with np.load(path, allow_pickle=True) as z:
        ks = list(z.keys())
        ik = next((k for k in ("image", "img", "data", "x") if k in ks), ks[0])
        lk = next((k for k in ("label", "mask", "gt", "y") if k in ks), ks[-1])
        img = np.asarray(z[ik], dtype=np.float32); lab = np.asarray(z[lk])
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2, 0, 1))
    if lab.ndim == 3: lab = lab[0]
    return np.nan_to_num(img), lab > 0


def detect_scale(files):
    v = np.concatenate([load_raw(f)[0][BAND["B12"]].ravel()[::97] for f in files[:: max(1, len(files) // 20)]])
    p99 = float(np.percentile(v, 99))
    scale = 1e-4 if p99 > 5 else 1.0
    say(f"  B12 99th percentile in the files = {p99:.3f} -> treating values as "
        f"{'digital numbers (x 1e-4 = reflectance)' if scale < 1 else 'reflectance already'}")
    return scale


def signature(img, scale):
    b12 = img[BAND["B12"]] * scale; b8a = img[BAND["B8A"]] * scale
    ratio = b12 / np.maximum(b8a, 1e-6); diff = b12 - b8a; ok = b12 >= WATER
    strict = ok & (ratio > STRICT[0]) & (diff > STRICT[1])
    perm = ok & (ratio > PERMISSIVE[0]) & (diff > PERMISSIVE[1])
    near = ndimage.binary_dilation(perm, iterations=NEAR_PX)
    code = np.zeros(b12.shape, np.uint8)
    code[near] = 1; code[perm] = 2; code[strict] = 3
    return code


def find_dumps(root):
    out = {}
    for f in glob.glob(str(Path(root) / "**" / "*.npz"), recursive=True):
        n = Path(f).name
        for sc in SCENES:
            tail = f"{sc}_haze_0p00_logits.npz"
            if n.endswith(tail):
                pre = n[: -len(tail)]
                out[({"": "A_s0", "gated_": "B_s0"}.get(pre, pre.rstrip("_")), sc)] = f
        if n == "test_logits.npz":
            out[("A_s0", "scene4")] = f
    return out


def auroc(score, pos):
    s = np.asarray(score, np.float64); p = np.asarray(pos, bool)
    if p.sum() == 0 or (~p).sum() == 0: return float("nan")
    u, inv = np.unique(s, return_inverse=True)
    P = np.bincount(inv, p.astype(float), len(u)); N = np.bincount(inv, (~p).astype(float), len(u))
    return float((P * (np.cumsum(N) - N + 0.5 * N)).sum() / (P.sum() * N.sum()))


# ------------------------------------------------------------ figures
def stretch(rgb):
    out = np.empty_like(rgb)
    for c in range(3):
        lo, hi = np.percentile(rgb[c], [2, 98]); out[c] = np.clip((rgb[c] - lo) / max(hi - lo, 1e-6), 0, 1)
    return np.transpose(out, (1, 2, 0))


def draw(path, img, scale, lab, code, pred, conf, title):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    edge = lab & ~ndimage.binary_erosion(lab)
    tc = stretch(img[[BAND["B4"], BAND["B3"], BAND["B2"]]] * scale)
    fc = stretch(img[[BAND["B12"], BAND["B8A"], BAND["B4"]]] * scale)
    fcl = fc.copy(); fcl[edge] = [0, 1, 1]
    m = np.full(lab.shape + (3,), 0.15)
    m[pred & lab] = [0.1, 0.8, 0.1]                                   # detected fire
    m[pred & ~lab] = [0.9, 0.2, 0.2]                                  # false alarm
    miss = ~pred & lab
    m[miss] = [1.0, 0.85, 0.1]                                        # missed fire
    m[miss & (conf >= CONF_MISS)] = [1.0, 0.1, 1.0]                   # CONFIDENT miss
    s = np.full(lab.shape + (3,), 0.15)
    s[code == 1] = [0.9, 0.9, 0.2]; s[code == 2] = [1.0, 0.55, 0.0]; s[code == 3] = [1.0, 0.1, 0.1]
    s[edge] = [0, 1, 1]
    fig, ax = plt.subplots(1, 5, figsize=(22, 4.8))
    for a, im, t in zip(ax, [tc, fc, fcl, m, s],
                        ["true colour (B4 B3 B2)", "fire composite (B12 B8A B4)\nactive fire glows bright",
                         "fire composite + MODIS label (cyan)",
                         "model: green detected, red false alarm,\nyellow missed, MAGENTA confident miss",
                         "fire signature: red strict, orange\npermissive, yellow near; cyan label"]):
        a.imshow(im); a.set_title(t, fontsize=9); a.axis("off")
    fig.suptitle(title, fontsize=11); fig.tight_layout(rect=[0, 0, 1, 0.88])
    fig.savefig(path, dpi=80); plt.close(fig)


# ---------------------------------------------------------------- main
def main():
    OUT.mkdir(parents=True, exist_ok=True); (OUT / "figures").mkdir(exist_ok=True)
    dumps = find_dumps(ROOT)
    say("LABEL CHECK\n  logit dumps found:", ", ".join(f"{m}/{s}" for m, s in sorted(dumps)) or "NONE")
    scene_rows, model_rows = [], []

    for sc in SCENES:
        files = find(ROOT, sc)
        if not files:
            say(f"\n{sc}: no Sen2Fire patches found -- skipped"); continue
        say(f"\n==================== {sc}: {len(files)} patches ====================")
        scale = detect_scale(files)
        n = len(files); LAB, SIG = None, None
        fire_px, bg_px = [], []
        for i, f in enumerate(files):
            img, lab = load_raw(f)
            if LAB is None:
                LAB = np.zeros((n,) + lab.shape, bool); SIG = np.zeros((n,) + lab.shape, np.uint8)
            LAB[i] = lab; SIG[i] = signature(img, scale)
            if i % 25 == 0:
                sel = [BAND[b] for b in ("B4", "B8A", "B11", "B12")]
                if lab.any(): fire_px.append(img[sel][:, lab][:, ::50] * scale)
                bg_px.append(img[sel][:, ~lab][:, ::500] * scale)
        if fire_px:
            fm = np.median(np.concatenate(fire_px, 1), 1); bm = np.median(np.concatenate(bg_px, 1), 1)
            say("  band check -- median reflectance  B4 / B8A / B11 / B12")
            say(f"    labelled fire : {fm[0]:.3f} / {fm[1]:.3f} / {fm[2]:.3f} / {fm[3]:.3f}")
            say(f"    background    : {bm[0]:.3f} / {bm[1]:.3f} / {bm[2]:.3f} / {bm[3]:.3f}")
            say("    (B12 should be clearly higher on fire; if not, the band order is wrong)")
        lf = LAB.sum()
        share = {k: float((SIG[LAB] == k).sum() / max(lf, 1)) for k in CODE}
        unl = float(((SIG >= 2) & ~LAB).sum())
        say(f"  labelled fire pixels: {int(lf):,}")
        say(f"    with a STRICT signature        {100 * share[3]:6.1f}%")
        say(f"    with a PERMISSIVE signature    {100 * (share[3] + share[2]):6.1f}%  (includes strict)")
        say(f"    within 30 m of one             {100 * (share[3] + share[2] + share[1]):6.1f}%")
        say(f"    NO visible fire at all         {100 * share[0]:6.1f}%")
        say(f"  pixels WITH a permissive signature but labelled background: {int(unl):,}"
            f"  ({100 * unl / max((SIG >= 2).sum(), 1):.1f}% of all signature pixels)")
        scene_rows.append(dict(scene=sc, patches=n, labelled_fire=int(lf), strict=share[3],
                               permissive_or_strict=share[3] + share[2],
                               within_30m=share[3] + share[2] + share[1], no_visible_fire=share[0],
                               signature_pixels_labelled_background=int(unl)))
        np.savez_compressed(OUT / f"cleaned_labels_{sc}.npz", original=LAB.astype(np.uint8), visibility=SIG,
                            codes=np.array(["0 none", "1 within 30 m", "2 permissive", "3 strict"]),
                            files=np.array([Path(f).name for f in files]))

        fig_done = False
        for (mlabel, msc), dpath in sorted(dumps.items()):
            if msc != sc: continue
            z = np.load(dpath); L, Y = z["logits"], z["labels"]
            if L.shape[0] != n:
                say(f"\n  [{mlabel}] {Path(dpath).name}: {L.shape[0]} patches vs {n} in Sen2Fire -- SKIPPED"); continue
            acc = {}                                         # (category, vis) -> [count, sum conf]
            hs = {"missed_vis": [], "missed_none": [], "correct_bg": []}
            conf_miss = {"vis": 0, "none": 0}
            rng = np.random.default_rng(0); worst = []
            ok = True
            for i in range(n):
                y = Y[i]; y = y[0] if y.ndim == 3 else y
                if not np.array_equal(y > 0, LAB[i]):
                    say(f"\n  [{mlabel}] LABEL MISMATCH at patch {i} ({Path(files[i]).name}) -- the dump and "
                        f"Sen2Fire are not in the same order. This model is SKIPPED."); ok = False; break
                lg = L[i].astype(np.float32); z0, z1 = lg[0], lg[1]
                pred = z1 > z0; p = 1 / (1 + np.exp(-np.clip(z1 - z0, -60, 60))); conf = np.where(pred, p, 1 - p)
                h = np.maximum(z0, z1); lab = LAB[i]; vis = SIG[i] >= 2
                for cat, m in (("correct fire", pred & lab), ("false alarm", pred & ~lab),
                               ("missed fire", ~pred & lab), ("correct bg", ~pred & ~lab)):
                    for vn, vm in (("vis", vis), ("none", SIG[i] == 0), ("near", SIG[i] == 1)):
                        k = (cat, vn); a = acc.setdefault(k, [0, 0.0]); mm = m & vm
                        a[0] += int(mm.sum()); a[1] += float(conf[mm].sum())
                mv, mn, cb = ~pred & lab & vis, ~pred & lab & (SIG[i] == 0), ~pred & ~lab
                for key, mm, frac in (("missed_vis", mv, 0.3), ("missed_none", mn, 0.3), ("correct_bg", cb, 0.004)):
                    v = h[mm]
                    if v.size: hs[key].append(v[rng.random(v.size) < frac])
                cm = ~pred & lab & (conf >= CONF_MISS)
                conf_miss["vis"] += int((cm & vis).sum()); conf_miss["none"] += int((cm & (SIG[i] == 0)).sum())
                worst.append((int(cm.sum()), i))
            if not ok: continue
            g = lambda c, v: acc.get((c, v), [0, 0.0])
            tot = lambda c: sum(g(c, v)[0] for v in ("vis", "none", "near"))
            mf, cf, fa = tot("missed fire"), tot("correct fire"), tot("false alarm")
            vis_fire = g("missed fire", "vis")[0] + g("correct fire", "vis")[0]
            none_fire = g("missed fire", "none")[0] + g("correct fire", "none")[0]
            H = {k: (np.concatenate(v) if v else np.array([])) for k, v in hs.items()}
            med = lambda a: float(np.median(a)) if a.size else float("nan")
            au_v = auroc(-np.concatenate([H["missed_vis"], H["correct_bg"]]),
                         np.r_[np.ones(H["missed_vis"].size, bool), np.zeros(H["correct_bg"].size, bool)])
            au_n = auroc(-np.concatenate([H["missed_none"], H["correct_bg"]]),
                         np.r_[np.ones(H["missed_none"].size, bool), np.zeros(H["correct_bg"].size, bool)])
            cmt = conf_miss["vis"] + conf_miss["none"]
            r = dict(model=mlabel, scene=sc,
                     recall_all_labels=cf / max(cf + mf, 1),
                     recall_on_visible_fire=g("correct fire", "vis")[0] / max(vis_fire, 1),
                     recall_on_no_visible_fire=g("correct fire", "none")[0] / max(none_fire, 1),
                     missed_with_visible_fire=g("missed fire", "vis")[0] / max(mf, 1),
                     missed_with_no_visible_fire=g("missed fire", "none")[0] / max(mf, 1),
                     missed_within_30m=g("missed fire", "near")[0] / max(mf, 1),
                     confident_misses_visible=conf_miss["vis"] / max(cmt, 1),
                     confident_misses_no_visible=conf_miss["none"] / max(cmt, 1),
                     conf_missed_visible=g("missed fire", "vis")[1] / max(g("missed fire", "vis")[0], 1),
                     conf_missed_no_visible=g("missed fire", "none")[1] / max(g("missed fire", "none")[0], 1),
                     h_missed_visible=med(H["missed_vis"]), h_missed_no_visible=med(H["missed_none"]),
                     h_correct_bg=med(H["correct_bg"]),
                     auroc_maxlogit_missed_visible_vs_correct_bg=au_v,
                     auroc_maxlogit_missed_no_visible_vs_correct_bg=au_n,
                     false_alarms_with_visible_fire=g("false alarm", "vis")[0] / max(fa, 1))
            model_rows.append(r)
            say(f"\n  [{mlabel}]  labels verified against Sen2Fire for all {n} patches")
            say(f"    recall: all labels {r['recall_all_labels']:.3f}   on VISIBLE fire {r['recall_on_visible_fire']:.3f}"
                f"   on fire with NO visible signature {r['recall_on_no_visible_fire']:.3f}")
            near_share = 1 - r['missed_with_visible_fire'] - r['missed_with_no_visible_fire']
            say(f"    missed fire: {100 * r['missed_with_visible_fire']:.1f}% shows visible fire, "
                f"{100 * near_share:.1f}% is within 30 m of it, {100 * r['missed_with_no_visible_fire']:.1f}% shows none")
            say(f"    CONFIDENT misses (>= {CONF_MISS}): {100 * r['confident_misses_visible']:.1f}% visible fire, "
                f"{100 * r['confident_misses_no_visible']:.1f}% none")
            say(f"    confidence on missed fire: visible {r['conf_missed_visible']:.3f}   none {r['conf_missed_no_visible']:.3f}")
            say(f"    median logit height h: missed-visible {r['h_missed_visible']:.2f}   missed-none "
                f"{r['h_missed_no_visible']:.2f}   correct bg {r['h_correct_bg']:.2f}")
            say(f"    MaxLogit AUROC vs correct bg: missed-VISIBLE {au_v:.3f}   missed-NONE {au_n:.3f}")
            say(f"    false alarms that show visible fire (labels missed it): {100 * r['false_alarms_with_visible_fire']:.1f}%")

            if not fig_done:
                for cnt, i in sorted(worst, reverse=True)[:N_FIG]:
                    img, lab = load_raw(files[i]); lg = L[i].astype(np.float32)
                    pred = lg[1] > lg[0]; p = 1 / (1 + np.exp(-np.clip(lg[1] - lg[0], -60, 60)))
                    conf = np.where(pred, p, 1 - p); miss = ~pred & lab
                    vfrac = (miss & (SIG[i] >= 2)).sum() / max(miss.sum(), 1)
                    draw(OUT / "figures" / f"{sc}_{mlabel}_patch{i:03d}.png", img, scale, lab, SIG[i], pred, conf,
                         f"{sc}  patch {i} ({Path(files[i]).name})  model {mlabel}  |  confident misses {cnt:,}  |  "
                         f"{100 * vfrac:.0f}% of this patch's missed fire shows a visible signature")
                say(f"    figures: {N_FIG} patches with the most confident misses -> figures/{sc}_{mlabel}_*.png")
                fig_done = True
        del LAB, SIG

    for name, rows in (("scene_summary.csv", scene_rows), ("model_summary.csv", model_rows)):
        if rows:
            with open(OUT / name, "w", newline="") as fh:
                w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    say("\nHOW TO READ THIS")
    say("  Compare scene 3 with scene 4 for the SAME model.")
    say("  LABEL ARTEFACT: scene 4's missed fire (especially its confident misses) mostly")
    say("    shows NO visible fire, while scene 3's mostly does; recall on VISIBLE fire is")
    say("    far higher than on all labels; and MaxLogit separates missed-VISIBLE fire from")
    say("    correct background much better than missed-NONE. Then the gate's scene 4")
    say("    collapse came largely from counting non-visible pixels as errors.")
    say("  MODEL FAILURE: scene 4's missed fire mostly SHOWS visible fire, at high")
    say("    confidence, at correct-background logit heights. Then the network does not")
    say("    recognise real fire there -- a representation problem; retraining is the fix.")
    say("  CAVEATS: a fixed SWIR test misses smouldering or sub-pixel fire, and MODIS and")
    say("    Sentinel-2 overpass at different times. 'No visible fire' means no fire in the")
    say("    image the model was given -- the fairest standard to judge it by -- not that")
    say("    there was never fire there.")
    (OUT / "report.txt").write_text("\n".join(LOG))
    say(f"\nWrote everything to {OUT}")


if __name__ == "__main__":
    main()
