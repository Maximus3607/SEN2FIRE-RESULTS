r"""
EVIDENCE READOUT: a modified softmax gated by a learned error signal.

    p(fire) = exp(z1) / ( exp(z0) + exp(z1) + lambda * sigmoid(e/tau) )
    p(bg)   = exp(z0) / ( same )
    p(empty)= lambda*sigmoid(e/tau) / ( same )

Two learnable parameters. e is the evidence-head output at that pixel.

WHY THIS FORM

Earlier readouts (null term, soft-cap, hinge, SAEA energy) all failed for one of
two reasons. Either they read only the logits -- and this model learned
ANTISYMMETRIC logits, so gap and |z0|+|z1| agree to four significant figures and
there is one number per pixel, the one MSP already reads. Or they gated on a
spatial neighbourhood count that reaches only ~25% of missed fire, leaving three
quarters unreachable by any parameter setting.

Evidence has neither problem. It is external to the logit vector, and it is
defined at every pixel. It is also the strongest all-pixel error signal
measured: AUROC 0.7105 on the held-out region against 0.60-0.63 for the best
hand-designed alternative.

WHAT TO EXPECT

Tempered. Over ALL pixels evidence reaches 0.7105 on scene 4, down from 0.8534
on the split it was trained beside. But within the PREDICTED-BACKGROUND subset
-- the population ECE(fire) is actually computed over -- it falls to 0.54-0.62
with 83-91% overlap, level with the neighbourhood count. The head learned to
flag errors in general but not the specific hard errors that drive the metric.

AUROC and ECE are different axes, so this still has to be measured rather than
inferred. That is the point of running it.

BUDGET CONSTRAINT

    L = CE_3class + mu * (mean(p_empty) - budget)^2

Without it the optimiser inflates abstention everywhere, which captures every
error including the ones the signal cannot locate, and wrecks ECE. That is
exactly what happened in SAEA v1: tau ran to its ceiling and selectivity came
out at 1.36:1. Pinning the mass forces the optimiser to choose WHERE to spend a
fixed allowance.

ACCURACY IS PRESERVED: the gate term is identical in both class denominators,
so argmax over {fire, background} cannot move. Asserted at evaluation.

Usage:
  python3 fit_evidence_readout.py --budget 0.02 \
      val_logits.npz evidence_val_0p00.npz \
      test_logits.npz evidence_test_0p00.npz \
      haze_0p20_logits.npz evidence_test_0p20.npz \
      haze_0p50_logits.npz evidence_test_0p50.npz
"""

import sys, argparse, time
import numpy as np

N_FIT = 64
ITERS = 300


def load(lg_path, ev_path, idx=None):
    z = np.load(lg_path)
    lg, lb = z["logits"], z["labels"]
    e = np.load(ev_path)["evidence"]
    if idx is not None:
        lg, lb, e = lg[idx], lb[idx], e[idx]
    lg = lg.astype(np.float32)
    if lb.ndim == 4:
        lb = lb[:, 0]
    e = e.astype(np.float32)
    if e.ndim == 4:
        e = e[:, 0]
    lb = lb.astype(np.int64)
    assert e.shape == lb.shape, f"evidence {e.shape} vs labels {lb.shape}"
    pred = lg.argmax(1)
    return dict(z0=lg[:, 0], z1=lg[:, 1], e=e, lb=lb, pred=pred,
                T=np.where(pred == lb, lb, 2),
                beta=float(z["beta0"]) if "beta0" in z.files else float("nan"))


def unpack(th):
    log_lam, log_tau = th
    sp = lambda v: np.log1p(np.exp(np.clip(v, -30, 30)))
    return sp(log_lam), sp(log_tau) + 0.1


def probs(d, th):
    lam, tau = unpack(th)
    gate = lam / (1.0 + np.exp(-np.clip(d["e"] / tau, -30, 30)))
    m = np.maximum(d["z0"], d["z1"])
    e0 = np.exp(d["z0"] - m); e1 = np.exp(d["z1"] - m)
    ga = gate * np.exp(-m)
    Z = e0 + e1 + ga
    return e1 / Z, e0 / Z, ga / Z


def loss(d, th, cost, budget, mu=50.0):
    pf, pb, pe = probs(d, th)
    T, lb = d["T"], d["lb"]
    p_t = np.where(T == 1, pf, np.where(T == 0, pb, pe))
    w = np.where((T == 2) & (lb == 1), cost, 1.0)
    ce = float(-(w * np.log(p_t + 1e-9)).sum() / w.sum())
    return ce + mu * (float(pe.mean()) - budget) ** 2


def fit(d, cost, budget):
    th = np.array([0.0, 0.0]); best = loss(d, th, cost, budget)
    step = np.array([0.5, 0.5])
    for _ in range(ITERS):
        moved = False
        for k in range(2):
            for s in (+1, -1):
                c = th.copy(); c[k] += s * step[k]
                v = loss(d, c, cost, budget)
                if v < best - 1e-10:
                    best, th, moved = v, c, True
        if not moved:
            step *= 0.5
            if step.max() < 1e-5:
                break
    return th, best


def ece(conf, correct, n_bins=20):
    edges = np.linspace(0.0, 1.0, n_bins + 1); tot = 0.0
    for i in range(n_bins):
        s = (conf > edges[i]) & (conf <= edges[i + 1]); k = int(s.sum())
        if k:
            tot += (k / conf.size) * abs(correct[s].mean() - conf[s].mean())
    return float(tot)


def evaluate(d, th):
    pf, pb, pe = probs(d, th)
    conf = np.maximum(pf, pb)          # NOT renormalised: that cancels the gate
    correct = (d["pred"] == d["lb"]).astype(np.float32)
    fire, bg = d["lb"] == 1, d["lb"] == 0
    miss = fire & (d["pred"] == 0); ok = correct.astype(bool)
    return dict(ece=ece(conf.ravel(), correct.ravel()),
                ece_fire=ece(conf[fire], correct[fire]),
                ece_bg=ece(conf[bg], correct[bg]),
                mass=float(pe.mean()),
                on_miss=float(pe[miss].mean()) if miss.any() else float("nan"),
                on_ok=float(pe[ok].mean()) if ok.any() else float("nan"))


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--cost", type=float, default=5.0)
    ap.add_argument("--budget", type=float, default=0.02)
    ap.add_argument("files", nargs="*")
    a = ap.parse_args()
    if len(a.files) < 4 or len(a.files) % 2:
        print(__doc__); sys.exit(1)
    pairs = list(zip(a.files[0::2], a.files[1::2]))

    print(f"cost={a.cost}  abstention budget={a.budget:.1%}")
    n = int(np.load(pairs[0][0])["logits"].shape[0])
    idx = np.sort(np.random.default_rng(0).choice(n, min(N_FIT, n), replace=False))
    print(f"fitting on {len(idx)} of {n} CLEAR validation patches")

    dv = load(pairs[0][0], pairs[0][1], idx)
    th, best = fit(dv, a.cost, a.budget)
    lam, tau = unpack(th)
    print(f"  fitted: lambda={lam:.4f}  tau={tau:.4f}  loss={best:.6f}")
    if lam < 1e-3:
        print("  WARNING gate collapsed -- no placement beat none.")

    hdr = (f"\n{'file':<24}{'beta0':>7}{'ECE(fire)':>11}{'delta':>9}"
           f"{'ECE(bg)':>10}{'delta':>9}{'on miss':>9}{'on ok':>8}{'ratio':>7}")
    print(hdr); print("-" * (len(hdr) - 1))
    null = np.array([-30.0, 0.0])
    for lg_p, ev_p in pairs[1:]:
        d = load(lg_p, ev_p)
        b = evaluate(d, null); r = evaluate(d, th)
        print(f"{lg_p.split('/')[-1][:23]:<24}{d['beta']:>7.2f}"
              f"{r['ece_fire']:>11.5f}{r['ece_fire']-b['ece_fire']:>+9.5f}"
              f"{r['ece_bg']:>10.5f}{r['ece_bg']-b['ece_bg']:>+9.5f}"
              f"{r['on_miss']:>9.4f}{r['on_ok']:>8.4f}"
              f"{r['on_miss']/max(r['on_ok'],1e-9):>7.2f}")
        assert np.array_equal(d["pred"],
                              np.stack([d["z0"], d["z1"]]).argmax(0)), \
            "argmax changed -- accuracy NOT preserved"

    print("\nHOW TO READ THIS")
    print("  ECE(fire) delta NEGATIVE is the win; ECE(bg) delta POSITIVE is the")
    print("  cost. Report both -- the method buys one by spending the other.")
    print("  'ratio' is abstention on missed fire over abstention on correct")
    print("  pixels. SAEA v1 and v2 both got ~1.35, near-indiscriminate. Above 2")
    print("  means the budget is genuinely landing on failures.")
    print("  Benchmarks on ECE(fire): adaptive T beat uncalibrated by 0.0070,")
    print("  SAEA v2 was WORSE by +0.02 to +0.04.")
    print("  Accuracy identical in every row by construction, and asserted.")


if __name__ == "__main__":
    t = time.time(); main(); print(f"\ndone in {time.time()-t:.0f}s")
