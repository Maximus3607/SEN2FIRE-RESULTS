r"""
GATE SWEEP: does the soft-cap earn its place alongside the spatial gate?

Replaces window_sweep.py. That version measured the spatial gate alone. This
one measures the spatial gate, the soft-cap, and their product, so the value of
adding the second term is visible rather than assumed.

THE GATE BEING TESTED

    E_i = z_0,i - C + lambda * S_i(W) * omega(A_i) * exp(-alpha * Delta_i)
                      \_____________/   \________/   \_________________/
                        spatial          aerosol        soft-cap

Note the PLUS. Opening the gates must push E UP toward z_0 so the abstention
term expands; earlier drafts used a minus, which shrank abstention exactly when
it should have grown.

  S_i(W)   fraction of a W x W neighbourhood predicted as fire. Fire is
           contiguous and MODIS label cells are 1 km, so a missed fire pixel
           should sit near a detected one. Reaches the right REGION.
  Delta_i  z_0 - z_1, the decision margin. Measured within predicted
           background: correct bg 4.19, missed fire 3.70. Missed fire sits
           CLOSER to the boundary, so exp(-alpha*Delta) opens preferentially on
           it. Discriminates WITHIN that region.

The two are weak individually and roughly independent, which is exactly when a
product is worth trying: the spatial term says where to look, the soft-cap says
which pixels there are suspect.

Aerosol is omitted here. It is flat within a patch (Sentinel-5P is km-scale),
so it cannot change the ordering of pixels inside one patch and therefore
cannot alter precision or coverage. It matters when fitting, not when measuring
separability.

WHAT IS REPORTED, at a fixed flag budget

Comparing raw gate values across formulations is meaningless because lambda and
alpha rescale them arbitrarily. Instead every variant is thresholded to flag
the SAME number of pixels, and precision is compared at that fixed budget. This
is the only fair comparison.

  coverage    share of missed fire flagged. The ceiling: where the gate is
              zero, no Theta can ever flag the pixel.
  precision   share of flagged pixels that are genuine misses. Low precision
              means collateral damage to background calibration, which is
              currently near-perfect (-0.008).
  ECE bound   optimistic upper bound on ECE(fire) gain, assuming every flagged
              miss is softened to 0.5 and nothing else is harmed.

numpy only. Usage:
  python3 gate_sweep.py test_logits.npz haze_0p20_logits.npz ...
"""

import sys
import numpy as np

WINDOWS = [101, 201]
BUDGETS = [0.01, 0.03, 0.06]         # share of the predicted-bg set flagged

# Variants. "spatial" is the baseline the others must beat.
#   softcap  exp(-a*Delta)                     -- smooth, suppresses EVERY pixel
#   hinge    max(0, 1 - a*max(0, Delta-delta)) -- flat below delta, then linear
# The soft-cap already lost at every setting: because it varies over orders of
# magnitude while S is bounded in [0,1], the product ends up ranked by Delta,
# and Delta separates worse than S does. The hinge is structurally different --
# it is EXACTLY 1.0 below delta, so S's ordering survives untouched there and
# only the high-gap tail is clipped. Whether that tail is enriched in correct
# background is an empirical question about distribution SHAPE, which the
# difference in means (4.19 vs 3.70) cannot answer.
SOFTCAP_ALPHAS = [1.0]
HINGE_PARAMS = [(d, a) for d in (3.5, 4.0, 4.5, 5.0) for a in (0.5, 1.0, 2.0)]


def load(path):
    z = np.load(path)
    lg = z["logits"].astype(np.float32)
    lb = z["labels"]
    if lb.ndim == 4:
        lb = lb[:, 0]
    beta = float(z["beta0"]) if "beta0" in z.files else float("nan")
    return lg, lb.astype(np.int64), beta


def box_mean(x, k):
    """Mean over a k x k neighbourhood via summed-area table."""
    p = k // 2
    xp = np.pad(x.astype(np.float32), ((0, 0), (p, p), (p, p)), mode="edge")
    c = np.pad(xp.cumsum(1).cumsum(2), ((0, 0), (1, 0), (1, 0)))
    H, W = x.shape[1], x.shape[2]
    return (c[:, k:k+H, k:k+W] - c[:, 0:H, k:k+W]
            - c[:, k:k+H, 0:W] + c[:, 0:H, 0:W]) / (k * k)


def at_budget(gate, miss, corr, budget, fire_total, conf_miss):
    """Threshold the gate to flag `budget` of the predicted-bg set, then score."""
    pool = np.concatenate([gate[corr], gate[miss]])
    is_miss = np.concatenate([np.zeros(int(corr.sum()), bool),
                              np.ones(int(miss.sum()), bool)])
    n_flag = max(int(round(budget * pool.size)), 1)
    if n_flag >= pool.size:
        idx = np.arange(pool.size)
    else:
        idx = np.argpartition(-pool, n_flag)[:n_flag]
    sel = is_miss[idx]
    # a zero gate can never be flagged by any Theta -- exclude those
    live = pool[idx] > 0
    sel, n_live = sel & live, int(live.sum())
    n_hit = int(sel.sum())
    cov = n_hit / max(int(miss.sum()), 1)
    prec = n_hit / max(n_live, 1)
    bound = (n_hit / max(fire_total, 1)) * max(conf_miss - 0.5, 0.0)
    return cov, prec, bound, n_live


def main(paths):
    for path in paths:
        lg, lb, beta = load(path)
        pred = lg.argmax(1)
        delta = lg[:, 0] - lg[:, 1]
        conf_bg = 1.0 / (1.0 + np.exp(-delta))
        pb = pred == 0
        miss, corr = pb & (lb == 1), pb & (lb == 0)
        fire_total = int((lb == 1).sum())
        if miss.sum() == 0:
            continue
        cm = float(conf_bg[miss].mean())

        print(f"\n{path}   beta0 = {beta}")
        print(f"  missed fire {int(miss.sum()):,} | correct bg "
              f"{int(corr.sum()):,} | mean conf on misses {cm:.4f}")
        print(f"  Delta: correct bg {float(delta[corr].mean()):.4f}  "
              f"missed fire {float(delta[miss].mean()):.4f}")

        yhat = (pred == 1).astype(np.float32)
        for W in WINDOWS:
            S = box_mean(yhat, W)
            print(f"\n  W = {W} ({W*10} m)")
            print(f"    {'variant':>15}{'budget':>8}{'coverage':>10}"
                  f"{'precision':>11}{'ECE bound':>11}  vs spatial")
            variants = [("spatial", S)]
            for a in SOFTCAP_ALPHAS:
                variants.append((f"soft a{a:g}", S * np.exp(-a * delta)))
            for d, a in HINGE_PARAMS:
                H = np.maximum(0.0, 1.0 - a * np.maximum(0.0, delta - d))
                variants.append((f"hinge d{d:g} a{a:g}", S * H))

            base = {}
            for tag, gate in variants:
                for b in BUDGETS:
                    cov, prec, bd, nl = at_budget(gate, miss, corr, b,
                                                  fire_total, cm)
                    if tag == "spatial":
                        base[b] = prec
                        mark = ""
                    else:
                        d_prec = prec - base[b]
                        mark = f"  {d_prec:+.2%}"
                    print(f"    {tag:>15}{b:>8.0%}{cov:>10.2%}"
                          f"{prec:>11.2%}{bd:>11.5f}{mark}")

    print("\nHOW TO READ THIS")
    print("  The last column is precision MINUS the spatial-only precision at")
    print("  the same budget. Positive means the extra term earns its keep.")
    print("  Every variant is thresholded to flag the same number of pixels, so")
    print("  the comparison is fair: lambda and alpha only rescale a gate, they")
    print("  cannot change how well it ranks, and only ranking matters here.")
    print("  If every hinge row is negative or ~0, the high-gap tail is NOT")
    print("  enriched in correct background, the 1-DOF logit carries nothing S")
    print("  does not already have, and the energy should use S alone. Report")
    print("  that: it is a clean negative result about what the logits contain.")
    print("  For scale: adaptive T beat uncalibrated by 0.0070 on ECE(fire).")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    main(sys.argv[1:])
