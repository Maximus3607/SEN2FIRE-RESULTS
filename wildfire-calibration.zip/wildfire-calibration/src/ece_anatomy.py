r"""
ECE ANATOMY: why is ECE(fire) so high for every readout?

ECE(fire), as used in this project, is computed only over pixels whose TRUE
label is fire. About 57% of those are MISSED fire -- predicted background. For
each, the confidence being scored is confidence in BACKGROUND and correctness is
zero, so every missed-fire pixel adds its full confidence to the error.

To lower that, a readout must lower confidence on missed fire. But missed fire
and correct background are nearly indistinguishable from the logits (usable
AUROC ~0.76), so lowering one lowers the other. ECE(fire) and ECE(bg) trade
against each other, and the exchange rate is set by that separability.

This script demonstrates it in four parts.

PART 1  WHERE ECE(fire) COMES FROM
    Confidence and correctness for detected fire and missed fire separately.

PART 2  THE BEST-CALIBRATED READOUT POSSIBLE FROM THE LOGITS
    For every cell of a 40x40 quantile grid over (z0, z1), and each predicted
    class, the fraction of predictions that are correct is measured on the
    HELD-IN half. That fraction IS the calibrated confidence: the most honest
    number any function of the two logits can report. Predictions never change.
    It is then scored on the HELD-OUT half with THREE kinds of ECE:
        standard ECE              all pixels
        by PREDICTED class        what calibration is meant to fix
        by TRUE class             this project's ECE(fire) and ECE(bg)
    If this readout is near-perfect on the first two but still high on
    ECE(fire), then high ECE(fire) is not a calibration failure at all. It is
    the cost of not being able to find missed fire.

PART 3  THE TRADE-OFF
    Squash confidence toward 50/50 separately for each predicted class and
    trace the best ECE(bg) achievable at each level of ECE(fire). Every readout
    on these logits lives on or behind this frontier.

PART 4  THE REFERENCE POINT
    ECE(fire) if missed fire could be identified PERFECTLY and pushed to 50/50
    while nothing else changed -- what perfect separation would buy.

Usage:
  python3 ece_anatomy.py gated_scene3_haze_0p00_logits.npz gated_scene3_haze_0p20_logits.npz
  (first file: held-in half used to build the Part 2 readout)
"""

import sys
import numpy as np

NB = 20


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


def ece(conf, corr):
    """Vectorised 20-bin ECE."""
    if conf.size == 0: return float("nan")
    b = np.clip((conf * NB).astype(int), 0, NB - 1)
    sc = np.bincount(b, weights=conf, minlength=NB)
    sa = np.bincount(b, weights=corr, minlength=NB)
    return float(np.abs(sa - sc).sum() / conf.size)


def load(path, idx):
    z = np.load(path)
    lg = z["logits"][idx].astype(np.float32); y = z["labels"][idx]
    if y.ndim == 4: y = y[:, 0]
    z0, z1 = lg[:, 0].ravel(), lg[:, 1].ravel()
    return z0, z1, y.ravel().astype(np.int8), (float(z["beta0"]) if "beta0" in z.files else float("nan"))


def grid(z0, z1, nb=40):
    qa = np.unique(np.quantile(z0, np.linspace(0, 1, nb + 1)))
    qb = np.unique(np.quantile(z1, np.linspace(0, 1, nb + 1)))
    return qa, qb


def cell(qa, qb, z0, z1, pred):
    ia = np.clip(np.searchsorted(qa, z0, "right") - 1, 0, len(qa) - 2)
    ib = np.clip(np.searchsorted(qb, z1, "right") - 1, 0, len(qb) - 2)
    return (ia * (len(qb) - 1) + ib) * 2 + pred.astype(int)


def report(nm, conf, corr, pred, y):
    f, b = y == 1, y == 0
    return (f"  {nm:<22}{ece(conf, corr):>9.4f}"
            f"{ece(conf[pred], corr[pred]):>10.4f}{ece(conf[~pred], corr[~pred]):>10.4f}"
            f"{ece(conf[f], corr[f]):>11.4f}{ece(conf[b], corr[b]):>10.4f}")


def main(paths):
    n = int(np.load(paths[0])["logits"].shape[0])
    perm = np.random.default_rng(0).permutation(n)         # SAME split as before
    fit_idx, ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])

    # ---- build the best-calibrated readout on the held-in half ----
    z0f, z1f, yf, _ = load(paths[0], fit_idx)
    predf = z1f > z0f; corrf = (predf == (yf == 1)).astype(float)
    qa, qb = grid(z0f, z1f)
    K = (len(qa) - 1) * (len(qb) - 1) * 2
    cf = cell(qa, qb, z0f, z1f, predf)
    cnt = np.bincount(cf, minlength=K).astype(float)
    hit = np.bincount(cf, weights=corrf, minlength=K)
    prior = corrf.mean()
    table = (hit + 20 * prior) / (cnt + 20)                # smoothed P(correct | cell)

    for path in paths[1:]:
        z0, z1, y, beta = load(path, ev_idx)
        pred = z1 > z0
        corr = (pred == (y == 1)).astype(float)
        p = sigmoid(z1 - z0)
        conf_id = np.where(pred, p, 1 - p)
        conf_best = table[cell(qa, qb, z0, z1, pred)]
        f = y == 1; det = f & pred; mis = f & ~pred

        print(f"\n=== {path.split('/')[-1]}   beta0 = {beta}   ({len(ev_idx)} held-out patches)")

        print("\nPART 1  where ECE(fire) comes from (true-fire pixels only)")
        print(f"  {'group':<16}{'share':>8}{'correct':>9}{'conf, softmax':>15}{'conf, best':>12}")
        for nm, g, c in (("detected fire", det, 1), ("missed fire", mis, 0)):
            print(f"  {nm:<16}{g.sum()/f.sum():>8.1%}{c:>9}{conf_id[g].mean():>15.4f}{conf_best[g].mean():>12.4f}")
        print("  every missed-fire pixel adds its whole confidence to the error,")
        print("  because it is scored as a WRONG prediction of background.")

        print("\nPART 2  three kinds of ECE")
        print(f"  {'readout':<22}{'standard':>9}{'pred fire':>10}{'pred bg':>10}"
              f"{'TRUE fire':>11}{'TRUE bg':>10}")
        print(f"  {'':<22}{'':>9}{'-- what calibration fixes --':>20}{'-- this project --':>21}")
        print(report("plain softmax", conf_id, corr, pred, y))
        print(report("best possible readout", conf_best, corr, pred, y))

        # ---- PART 3: trade-off frontier ----
        rng = np.random.default_rng(2)
        fi = np.flatnonzero(f); bi = np.flatnonzero(~f)
        fi = rng.choice(fi, min(fi.size, 1_000_000), replace=False)
        bi = rng.choice(bi, min(bi.size, 3_000_000), replace=False)
        alphas = [1.0, 0.8, 0.6, 0.4, 0.2, 0.05]
        pts = []
        for ab in alphas:          # squash factor on predicted-background pixels
            for af in alphas:      # squash factor on predicted-fire pixels
                a = np.where(pred, af, ab)
                c2 = 0.5 + a * (conf_id - 0.5)
                pts.append((ece(c2[fi], corr[fi]), ece(c2[bi], corr[bi]), ab, af))
        pts.sort()
        front, best_bg = [], 9.0
        for ef, eb, ab, af in pts:
            if eb < best_bg - 1e-4:
                front.append((ef, eb, ab, af)); best_bg = eb
        print("\nPART 3  the trade-off: best ECE(bg) reachable at each ECE(fire)")
        print("  (confidence squashed toward 50/50 by factor a, per predicted class)")
        print(f"  {'ECE(fire)':>11}{'ECE(bg)':>10}{'a, pred bg':>12}{'a, pred fire':>14}")
        for ef, eb, ab, af in front:
            print(f"  {ef:>11.4f}{eb:>10.4f}{ab:>12.2f}{af:>14.2f}")

        # ---- PART 4: what perfect separation would buy ----
        c4a = conf_id.copy(); c4a[mis] = 0.5            # two-class limit
        c4b = conf_id.copy(); c4b[mis] = 0.0            # with abstention
        print("\nPART 4  if missed fire could be identified PERFECTLY")
        print(f"  {'':<34}{'ECE(fire)':>11}{'ECE(bg)':>10}")
        print(f"  {'plain softmax':<34}{ece(conf_id[f], corr[f]):>11.4f}{ece(conf_id[~f], corr[~f]):>10.4f}")
        print(f"  {'missed fire -> 50% (two-class max)':<34}{ece(c4a[f], corr[f]):>11.4f}{ece(c4a[~f], corr[~f]):>10.4f}")
        print(f"  {'missed fire -> 0%  (full abstention)':<34}{ece(c4b[f], corr[f]):>11.4f}{ece(c4b[~f], corr[~f]):>10.4f}")
        print("  Watch the middle row: it can be WORSE than plain softmax. In softmax,")
        print("  detected and missed fire share confidence bins, and within a bin their")
        print("  errors partly CANCEL. Separating them perfectly removes that")
        print("  cancellation. So ECE(fire) is not even monotone in how well a readout")
        print("  finds its own mistakes -- a known weakness of binned ECE.")

    print("\nHOW TO READ THIS")
    print("  PART 2 is the diagnosis. If the best-possible readout scores near zero")
    print("  on 'standard' and 'by predicted class' but stays high on TRUE fire,")
    print("  then high ECE(fire) is NOT a calibration failure. The readout is already")
    print("  as honest as the logits allow; what it cannot do is FIND missed fire.")
    print("  PART 3 shows the price of lowering ECE(fire) anyway: every step down")
    print("  costs ECE(bg), because missed fire and correct background share logits.")
    print("  PART 4 shows that ECE(fire) only falls decisively with ABSTENTION --")
    print("  and only if missed fire can be found. A two-class readout cannot push")
    print("  confidence below 50%, and binning can make even perfect separation")
    print("  look worse. Report TRUE-fire ECE alongside standard and predicted-class")
    print("  ECE, and state which is which.")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    main(sys.argv[1:])
