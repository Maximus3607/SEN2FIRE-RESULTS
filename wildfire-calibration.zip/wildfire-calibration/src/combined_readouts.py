r"""
COMBINED READOUTS: a more malleable gate, a softplus base, and both together.

Every readout here has the form

    confidence = base(y_hat) x (1 - a),      a = abstention

which is EXACTLY the height gate written differently: with a softmax base and
a = sigmoid(eta - LSE(z0, z1)), this equals e^{z_yhat} / (e^z0 + e^z1 + e^eta).
So "magnitude kept outside the softmax" and "null term in the denominator" are
one readout. Only two things vary here, independently:

  BASE        softmax                       e^z1 / (e^z0 + e^z1)
              softplus-normalised           sp(z1) / (sp(z0) + sp(z1))
              (softplus is monotone, so the prediction never changes; unlike
              softmax it depends on the logits' HEIGHT, not only their gap)

  ABSTENTION  none
              height gate    eta = c + k * sigmoid(gamma * (tau - h))
                             original: c, k, gamma FIXED; only tau fitted
                             flexible: tau AND gamma AND k fitted -- the gate
                             can be anything from a near-switch to a slow fade
              evidence null  eta = h - s * (h - t)       (no gate at all)
              where h = logit of the predicted class

PRE-SPECIFIED
  - The fitting OBJECTIVE is held fixed for every variant: true-fire ECE +
    true-bg ECE on the held-in half (the original height gate's objective),
    so differences come from the readout's FORM alone.
  - Prediction written before running: the flexible gate improves slightly on
    that objective but lands on the same fire-versus-background trade-off; the
    softplus base changes little.
  - Everything is exploratory. The ORIGINAL height gate stays the
    pre-specified method; a variant that wins here needs confirming elsewhere.

WHAT TO WATCH: whether any variant improves true-fire ECE WITHOUT paying more
on background and WITHOUT lower selectivity. Improving one while paying on the
other is the same trade-off again, whatever the readout.

Checks built in: the original height gate and evidence null are recomputed in
the new form and asserted to match the earlier scripts exactly.

Usage (reverse_gate.py, evidence_null.py, final_compare.py, paired_height.py
in the same folder):
  python3 combined_readouts.py --boot 1000 \
    --model A_s0 scene3_haze_0p00_logits.npz scene3_haze_0p20_logits.npz scene3_haze_0p50_logits.npz \
    --model B_s0 gated_scene3_haze_0p00_logits.npz gated_scene3_haze_0p20_logits.npz gated_scene3_haze_0p50_logits.npz \
    --model A_s1 A_s1_scene3_haze_0p00_logits.npz A_s1_scene3_haze_0p20_logits.npz A_s1_scene3_haze_0p50_logits.npz \
    --model B_s1 B_s1_scene3_haze_0p00_logits.npz B_s1_scene3_haze_0p20_logits.npz B_s1_scene3_haze_0p50_logits.npz
"""

import sys, argparse
import numpy as np
from reverse_gate import load, evidence, readout as gate_readout, fit as gate_fit, sigmoid
from evidence_null import readout as en_readout, fit as en_fit, S_GRID
from final_compare import fit_T, fixed, FIX_C, FIX_K
from paired_height import patch_stats, metrics

NB = 20
GAMMA_MULT = (0.25, 0.5, 1.0, 2.0, 4.0)       # 0.25 = slow fade ... 4 = near-switch
K_GRID = (4.0, FIX_K, 12.0)                   # maximum abstention strength


def ece(conf, corr):
    if conf.size == 0: return float("nan")
    b = np.clip((conf * NB).astype(int), 0, NB - 1)
    return float(np.abs(np.bincount(b, corr, NB) - np.bincount(b, conf, NB)).sum() / conf.size)


def softplus(x):
    return np.where(x > 30, x, np.log1p(np.exp(np.minimum(x, 30))))


def lse(z0, z1):
    m = np.maximum(z0, z1)
    return m + np.log(np.exp(z0 - m) + np.exp(z1 - m))


class Cache:
    """Everything a readout needs, computed once per pixel set."""
    def __init__(self, d):
        self.z0, self.z1, self.y = d["z0"], d["z1"], d["y"] == 1
        self.pred = self.z1 > self.z0
        self.h = np.where(self.pred, self.z1, self.z0)
        self.L = lse(self.z0, self.z1)
        self.corr = (self.pred == self.y).astype(np.float64)
        p = sigmoid(self.z1 - self.z0)
        self.base = {"softmax": np.where(self.pred, p, 1 - p)}
        s0, s1 = softplus(self.z0), softplus(self.z1); q = s1 / (s0 + s1)
        self.base["softplus"] = np.where(self.pred, q, 1 - q)


def abstention(C, kind, P, gam0):
    """a = sigmoid(eta - LSE). P: {predicted class: params or None}."""
    eta = np.full(C.h.shape, -1e4)
    for c in (False, True):
        if P is None or P[c] is None: continue
        m = C.pred == c; h = C.h[m]
        if kind == "gate":
            tau, gm, k = P[c]; eta[m] = FIX_C + k * sigmoid(gam0[c] * gm * (tau - h))
        else:
            t, s = P[c]; eta[m] = h - s * (h - t)
    return sigmoid(eta - C.L)


def conf_of(C, base, kind, P, gam0):
    if kind is None: return C.base[base], np.zeros_like(C.h)
    a = abstention(C, kind, P, gam0)
    return C.base[base] * (1 - a), a


def fit(C, base, kind, gam0, taus_q):
    """Coordinate descent (bg | fire off, fire | bg, bg again) on the fixed
    objective true-fire ECE + true-bg ECE."""
    def obj(P):
        conf, _ = conf_of(C, base, kind, P, gam0)
        return ece(conf[C.y], C.corr[C.y]) + ece(conf[~C.y], C.corr[~C.y])
    cands = {}
    for c in (False, True):
        if kind == "gate":
            cands[c] = [None] + [(t, gm, k) for t in taus_q[c] for gm in GAMMA_MULT for k in K_GRID]
        else:
            cands[c] = [None] + [(t, s) for t in taus_q[c] for s in S_GRID]
    P = {False: None, True: None}
    for c in (False, True, False):
        P[c] = min(cands[c], key=lambda p: obj({**P, c: p}))
    return P


def stratified(d, n_fire=400_000, n_bg=1_600_000):
    """The SAME stratified sample the original fits used (seed 0)."""
    rng = np.random.default_rng(0)
    fi = np.flatnonzero(d["y"] == 1); bi = np.flatnonzero(d["y"] == 0)
    i = np.sort(np.concatenate([rng.choice(fi, min(n_fire, fi.size), replace=False),
                                rng.choice(bi, min(n_bg, bi.size), replace=False)]))
    return {k: (v[i] if isinstance(v, np.ndarray) else v) for k, v in d.items()}


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("--model", action="append", nargs="+", default=[])
    a = ap.parse_args()
    if not a.model:
        print(__doc__); sys.exit(1)
    rows = ["pred fire", "TRUE fire", "TRUE bg", "pred bg", "AURC"]
    fmtp = lambda p: "OFF" if p is None else "(" + ", ".join(f"{v:+.3f}" if abs(v) < 100 else f"{v:.0f}" for v in p) + ")"

    for spec in a.model:
        label, files = spec[0], spec[1:]
        n = int(np.load(files[0])["logits"].shape[0])
        perm = np.random.default_rng(0).permutation(n)          # SAME split everywhere
        fit_idx, ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])
        d = fixed(load(files[0], fit_idx))
        print(f"\n######## {label}: fitting on {len(fit_idx)} held-in patches", flush=True)

        # originals, from the original scripts
        G_tau, gam0 = gate_fit(d, "height gate")
        EN = en_fit(d)
        g = d["z1"] - d["z0"]; y = d["y"] == 1; pr = g > 0
        Tc = {c: fit_T(g[pr == c], y[pr == c]) for c in (False, True)}

        ds = stratified(d); Cs = Cache(ds)
        taus_q = {c: list(np.quantile(Cs.h[Cs.pred == c], np.linspace(0.02, 0.60, 15))) for c in (False, True)}
        orig_gate = {c: (None if G_tau[c] is None else (G_tau[c], 1.0, FIX_K)) for c in (False, True)}

        V = {}                                                  # name -> (base, kind, params)
        V["softmax"] = ("softmax", None, None)
        V["softplus base"] = ("softplus", None, None)
        V["height gate"] = ("softmax", "gate", orig_gate)
        V["evidence null"] = ("softmax", "null", EN)
        print("  fitting flexible gate (softmax base) ...", flush=True)
        V["flexible gate"] = ("softmax", "gate", fit(Cs, "softmax", "gate", gam0, taus_q))
        print("  fitting softplus + evidence null ...", flush=True)
        V["softplus+null"] = ("softplus", "null", fit(Cs, "softplus", "null", gam0, taus_q))
        print("  fitting softplus + flexible gate ...", flush=True)
        V["softplus+gate"] = ("softplus", "gate", fit(Cs, "softplus", "gate", gam0, taus_q))
        for nm in ("height gate", "evidence null", "flexible gate", "softplus+null", "softplus+gate"):
            b, kd, P = V[nm]
            extra = "   (tau, gamma multiple, k)" if kd == "gate" else "   (t, s)"
            print(f"  {nm:<15} pred bg {fmtp(P[False]):<26} pred fire {fmtp(P[True])}{extra}")
        print(f"  class-cond T    pred bg {Tc[False]:.4f}   pred fire {Tc[True]:.4f}")

        for path in files[1:]:
            e = fixed(load(path, ev_idx)); P_ = len(ev_idx); HW = e["z0"].size // P_
            C = Cache(e)

            # --- the two originals must match the earlier scripts exactly ---
            cg, _, _, _ = gate_readout(e, evidence(e, "height gate"), G_tau, gam0)
            cn, _, _ = en_readout(e, EN)
            c1, _ = conf_of(C, *V["height gate"][:2], V["height gate"][2], gam0)
            c2, _ = conf_of(C, *V["evidence null"][:2], V["evidence null"][2], gam0)
            assert np.allclose(c1, cg, atol=2e-5), "height gate does not reproduce"
            assert np.allclose(c2, cn, atol=2e-5), "evidence null does not reproduce"

            S, AB = {}, {}
            pT = sigmoid((C.z1 - C.z0) / np.where(C.pred, Tc[True], Tc[False]))
            S["class-cond T"] = patch_stats(np.where(C.pred, pT, 1 - pT), C.corr, C.y, C.pred, P_, HW)
            for nm, (b, kd, P) in V.items():
                conf, ab = conf_of(C, b, kd, P, gam0)
                S[nm] = patch_stats(conf, C.corr, C.y, C.pred, P_, HW)
                if kd is not None: AB[nm] = ab
                del conf
            M = {nm: metrics(H.sum(0), R.sum(0)) for nm, (H, R) in S.items()}
            beta = float(np.load(path)["beta0"])
            order = ["softmax", "class-cond T", "softplus base", "height gate", "evidence null",
                     "flexible gate", "softplus+null", "softplus+gate"]

            print(f"\n=== {label}   beta0 = {beta}   ({P_} held-out patches)   originals verified")
            print(f"  {'readout':<15}" + "".join(f"{r:>11}" for r in rows))
            for nm in order:
                print(f"  {nm:<15}" + "".join(f"{M[nm][r]:>11.4f}" for r in rows))

            grp = {"detected": C.y & C.pred, "false alarm": ~C.y & C.pred,
                   "missed": C.y & ~C.pred, "correct bg": ~C.y & ~C.pred}
            print(f"\n  abstention by pixel type" + " " * 4 + "".join(f"{k:>12}" for k in grp) + f"{'missed/bg':>11}")
            for nm, ab in AB.items():
                v = [float(ab[m].mean()) for m in grp.values()]
                print(f"  {nm:<28}" + "".join(f"{x:>12.4f}" for x in v) + f"{v[2] / max(v[3], 1e-9):>11.2f}")

            rng = np.random.default_rng(3)
            new = ["flexible gate", "softplus+null", "softplus+gate", "softplus base"]
            refs = ["softmax", "height gate"]
            D = {(nw, rf, r): [] for nw in new for rf in refs for r in rows}
            for _ in range(a.boot):
                pk = rng.integers(0, P_, P_)
                bm = {nm: metrics(H[pk].sum(0), R[pk].sum(0)) for nm, (H, R) in S.items()}
                for nw in new:
                    for rf in refs:
                        for r in rows:
                            D[(nw, rf, r)].append(bm[nw][r] - bm[rf][r])
            print(f"\n  new MINUS reference, {a.boot} paired replicates (negative = new better; * = CI excludes 0)")
            for nw in new:
                for rf in refs:
                    cells = []
                    for r in rows:
                        v = np.array(D[(nw, rf, r)]); v = v[np.isfinite(v)]
                        lo, hi = np.percentile(v, [2.5, 97.5])
                        cells.append(f"{np.mean(v):+.4f}{'*' if (hi < 0 or lo > 0) else ' '}")
                    print(f"    {nw:<14} vs {rf:<12}" + "".join(f"{c:>11}" for c in cells))
            print(f"    {'':<30}" + "".join(f"{r:>11}" for r in rows))

    print("\nHOW TO READ THIS")
    print("  The fitted gamma multiple answers the malleability question directly:")
    print("  0.25 = the fit wanted a slow fade, 4 = a near-switch, 1 = the original.")
    print("  'vs height gate' is the key comparison. A genuine improvement lowers")
    print("  TRUE fire WITHOUT raising TRUE bg and WITHOUT lowering missed/bg.")
    print("  Gains on one side paid for on the other are the same trade-off again.")
    print("  All variants are exploratory; the original height gate remains the")
    print("  pre-specified method.")


if __name__ == "__main__":
    main()
