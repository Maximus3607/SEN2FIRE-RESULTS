r"""
DUMP LOGITS from model B (the gated-null model), matching model A's format.

train_gated.py saved only best.pt and history.json -- no logit dumps -- so
nothing downstream can run yet. This produces them.

WHAT IT WRITES, and why each field is there

  logits      (N,2,H,W) fp16   the two class logits. Everything model A's
                               analysis scripts read.
  null_logit  (N,H,W)   fp16   eta = c + k*sigmoid(gamma*(tau - s)). NOT in
                               model A's dumps and NOT recoverable from the
                               logits alone without the gate parameters, so it
                               must be saved. Without it the gated readout
                               cannot be evaluated at all -- only the standard
                               calibrators could be.
  labels, aerosol, haze_cue    identical to model A's dumps, so
                               calibrate_full.py, diagnose.py and
                               separation_check.py run unchanged.
  gate params + beta0/alpha    provenance, so a dump is self-describing.

MATCHING MODEL A EXACTLY

Same scenes, same nine beta0 values, same alpha = 1.3, same lambda0 = 550 nm,
same per-scene atmospheric light from the 99th percentile of that scene's clear
imagery, haze applied to RAW reflectance before standardisation. Any difference
here would confound the two-model comparison, which is the entire point of
having trained model B.

Note norm_stats.npz comes from MODEL B's own training run -- it computed its
own mean/std over its own training split (1313 patches after the 10% holdout,
not model A's 1458). Using model A's stats would misnormalise the input.

Kaggle: attach Sen2Fire AND this model's training output (for best.pt and
norm_stats.npz). GPU T4. ~40 min for both scenes at nine severities.
"""

import glob, time, gc
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from readout_core import GatedNullReadout


class CFG:
    data_root   = "/kaggle/input"
    out_dir     = "/kaggle/working"
    scenes      = {"val": "scene3", "test": "scene4"}
    band_idx    = [3, 2, 1, 7, 10, 11]
    wavelen     = np.array([665., 560., 490., 842., 1610., 2190.])
    lambda0     = 550.0
    alpha       = 1.3
    betas       = [0.0, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 1.00, 2.00]
    batch       = 4
    a_sample    = 120
    in_ch, out_ch, base = 6, 2, 64

DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT = Path(CFG.out_dir); OUT.mkdir(parents=True, exist_ok=True)
print("device:", DEV, flush=True)


# ------------------------------------------------------------------- model
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co*2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2)-x.size(-2); dx = skip.size(-1)-x.size(-1)
            x = F.pad(x, [dx//2, dx-dx//2, dy//2, dy-dy//2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b*2), Down(b*2, b*4)
        self.d3, self.d4 = Down(b*4, b*8), Down(b*8, b*16)
        self.u1, self.u2 = Up(b*16, b*8), Up(b*8, b*4)
        self.u3, self.u4 = Up(b*4, b*2), Up(b*2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)


# -------------------------------------------------------------------- haze
def transmission(b0):
    return np.exp(-b0 * (CFG.wavelen / CFG.lambda0) ** (-CFG.alpha)
                  ).astype(np.float32)[:, None, None]

def apply_haze(img, b0, A):
    if b0 == 0.0:
        return img
    t = transmission(b0)
    return img * t + A[:, None, None] * (1.0 - t)

def _nd(a, b, eps=1e-6):
    return (a - b) / (a + b + eps)

def haze_cue(img):
    """From the HAZED bands -- a deployed calibrator never sees the clean image."""
    ndvi = _nd(img[3], img[0]); nbr = _nd(img[3], img[5]); nbr2 = _nd(img[4], img[5])
    return np.nan_to_num(0.5*np.abs(ndvi-nbr) + 0.5*np.abs(ndvi-nbr2)).astype(np.float32)


# -------------------------------------------------------------------- data
def find(root, scene):
    return [f for f in sorted(glob.glob(str(Path(root)/"**"/"*.npz"), recursive=True))
            if scene in {p.lower() for p in Path(f).parts[:-1]}]

def load_patch(path, scale):
    with np.load(path, allow_pickle=True) as z:
        ks = list(z.keys())
        ik = next((k for k in ("image","img","data","x") if k in ks), ks[0])
        lk = next((k for k in ("label","mask","gt","y") if k in ks), ks[-1])
        ak = next((k for k in ("aerosol","s5p","aod") if k in ks), None)
        img = np.asarray(z[ik], dtype=np.float32); lab = np.asarray(z[lk])
        aer = np.asarray(z[ak], dtype=np.float32) if ak else None
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2,0,1))
    if lab.ndim == 3: lab = lab[0]
    if aer is None: aer = np.zeros(lab.shape, np.float32)
    if aer.ndim == 3: aer = aer[0]
    return (np.nan_to_num(img[CFG.band_idx])*scale, (lab>0).astype(np.uint8),
            np.nan_to_num(aer))


def main():
    sp = glob.glob(str(Path(CFG.data_root)/"**"/"norm_stats.npz"), recursive=True)
    assert sp, "norm_stats.npz not found -- attach model B's training output"
    zs = np.load(sp[0]); MEAN, STD, SCALE = zs["mean"], zs["std"], float(zs["scale"])
    M3, S3 = MEAN[:,None,None], STD[:,None,None]

    cp = glob.glob(str(Path(CFG.data_root)/"**"/"best.pt"), recursive=True)
    assert cp, "best.pt not found"
    ck = torch.load(cp[0], map_location=DEV, weights_only=False)
    # Name output files by run, so seed runs never overwrite each other or the
    # original seed-0 dumps. Checkpoints from before seeding was added carry no
    # seed, and keep the original "gated_" prefix.
    SEED, NU = ck.get("seed"), ck.get("nu_target")
    if SEED is None:
        PREFIX = "gated_"
        print("RUN: original model B (seed 0, pre-seeding checkpoint)")
    else:
        PREFIX = f"{'B' if NU > 0 else 'A'}_s{SEED}_"
        print(f"RUN: {'MODEL B' if NU > 0 else 'MODEL A, MATCHED'}   seed {SEED}"
              f"   nu_target {NU}   -> files named {PREFIX}scene..._logits.npz")
    assert "readout" in ck, (
        "this checkpoint has no readout state -- it is model A's best.pt, not "
        "model B's. Attach the gated training run's output.")

    model = UNet(CFG.in_ch, CFG.out_ch, CFG.base).to(DEV)
    model.load_state_dict(ck["model"]); model.eval()
    readout = GatedNullReadout().to(DEV)
    readout.load_state_dict(ck["readout"]); readout.eval()
    print(f"loaded {cp[0]}  epoch {ck.get('epoch','?')}  best val IoU {ck.get('best',float('nan')):.4f}")
    print(f"gate: {readout.describe()}", flush=True)

    gp = dict(c=float(readout.c), k=float(readout.k),
              gamma=float(readout.gamma), tau=float(readout.tau_clamped()))

    for split, scene in CFG.scenes.items():
        files = find(CFG.data_root, scene)
        if not files:
            print(f"\n{scene}: not found, skipping"); continue
        print(f"\n=== {scene} ({split}) : {len(files)} patches ===", flush=True)

        # atmospheric light from a SAMPLE of this scene's clear imagery, as in
        # the model A sweep -- sampling avoids holding the scene in memory
        step = max(1, len(files)//CFG.a_sample)
        samp = np.stack([load_patch(f, SCALE)[0] for f in files[::step]])
        A = np.percentile(samp, 99, axis=(0,2,3)).astype(np.float32)
        del samp; gc.collect()
        print(f"  atmospheric light A = {np.round(A,4)}", flush=True)

        for b in CFG.betas:
            L, NL, C, LB, AE = [], [], [], [], []
            tp=fp=fn=0; conf=0.0; hit=0; nfire=0; pe_s=0.0; pe_e=0.0; ne=0; npx=0
            for i in range(0, len(files), CFG.batch):
                raw, labs, aers = zip(*[load_patch(f, SCALE)
                                        for f in files[i:i+CFG.batch]])
                raw = np.stack(raw); labs = np.stack(labs); aers = np.stack(aers)
                hz = np.stack([apply_haze(im, b, A) for im in raw])
                if b == 0.0:
                    assert np.allclose(hz, raw), "beta0=0 must reproduce input"
                nm = (hz - M3) / (S3 + 1e-6)
                with torch.no_grad():
                    lg = model(torch.from_numpy(nm).to(DEV)).float()
                    nl = readout.null_logit(lg)
                    _, _, pe = readout(lg)
                lab_t = torch.from_numpy(labs.astype(np.int64)).to(DEV)
                pred = lg.argmax(1)
                tp += int(((pred==1)&(lab_t==1)).sum())
                fp += int(((pred==1)&(lab_t==0)).sum())
                fn += int(((pred==0)&(lab_t==1)).sum())
                fm = lab_t == 1
                if fm.any():
                    conf += float(lg.softmax(1).max(1).values[fm].sum())
                    hit  += int((pred[fm]==1).sum()); nfire += int(fm.sum())
                w = pred != lab_t
                pe_s += float(pe.sum()); npx += pe.numel()
                if w.any():
                    pe_e += float(pe[w].sum()); ne += int(w.sum())
                L.append(lg.cpu().numpy().astype(np.float16))
                NL.append(nl.cpu().numpy().astype(np.float16))
                C.append(np.stack([haze_cue(h) for h in hz])[:,None].astype(np.float16))
                LB.append(labs); AE.append(aers[:,None].astype(np.float16))
                del raw, labs, aers, hz, nm, lg, nl, pe, lab_t

            tag = f"{b:.2f}".replace(".", "p")
            path = OUT/f"{PREFIX}{scene}_haze_{tag}_logits.npz"
            np.savez_compressed(
                path, logits=np.concatenate(L), null_logit=np.concatenate(NL),
                labels=np.concatenate(LB), aerosol=np.concatenate(AE),
                haze_cue=np.concatenate(C),
                beta0=b, alpha=CFG.alpha, lambda0=CFG.lambda0,
                transmission=transmission(b).ravel(), atmospheric_light=A,
                gate_c=gp["c"], gate_k=gp["k"], gate_gamma=gp["gamma"],
                gate_tau=gp["tau"], epoch=ck.get("epoch",-1),
                seed=-1 if SEED is None else SEED,
                nu_target=0.5 if NU is None else NU)
            e = 1e-9
            sel = (pe_e/max(ne,1)) / max(pe_s/max(npx,1), 1e-9)
            print(f"  beta0 {b:<5.2f} IoU {tp/(tp+fp+fn+e):.4f} "
                  f"R {tp/(tp+fn+e):.3f} conf|fire {conf/max(nfire,1):.4f} "
                  f"acc|fire {hit/max(nfire,1):.4f} "
                  f"gap {conf/max(nfire,1)-hit/max(nfire,1):+.4f} "
                  f"| p(0) {pe_s/max(npx,1):.4f} sel {sel:.2f} -> {path.name}",
                  flush=True)
            del L, NL, C, LB, AE; gc.collect()
        if DEV == "cuda": torch.cuda.empty_cache()

    print("\nNEXT")
    print("  These npz files carry the same keys as model A's, so diagnose.py,")
    print("  separation_check.py and calibrate_full.py run on them unchanged --")
    print("  that gives the STANDARD calibrators on model B's logits.")
    print("  null_logit is the extra field. It is what the gated readout needs,")
    print("  and it cannot be recomputed from the logits without the gate")
    print("  parameters, which are also saved here for provenance.")
    print("  The comparison that matters: model A vs model B on ECE(fire) at")
    print("  each severity. Model A's best was adaptive T at 0.68363 clean,")
    print("  0.69154 at beta0=0.20, 0.70964 at 0.50.")


if __name__ == "__main__":
    t = time.time(); main(); print(f"\ndone in {(time.time()-t)/60:.1f}m")
