r"""
THE READOUT AND LOSS -- the two pieces that differ from the baseline model.

Everything else (U-Net, data pipeline, optimiser) is unchanged from
train_sen2fire_softmax.py. This file is the contribution, isolated so it can be
read and checked on its own.

    readout:  p(fire) = e^z1 / ( e^z1 + e^z0 + e^(null_logit) )
              null_logit = c + k * sigmoid( gamma * (tau - LSE(z0,z1)) )

    loss:     L = CE(z0,z1,y) + nu * weightedBCE( null_logit, 1[wrong] )
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================ THE READOUT
class GatedNullReadout(nn.Module):
    r"""Softmax with a third denominator term gated on total logit evidence.

    WHY A THIRD TERM AT ALL

    Ordinary softmax over two logits is invariant to adding a constant to both:
    softmax([z0+a, z1+a]) == softmax([z0, z1]), because e^(z+a) = e^z * e^a and
    the e^a cancels. Cross-entropy therefore has EXACTLY zero gradient along the
    (z0 + z1) direction -- measured as 0.000e+00 at every point tested. That
    direction is flat, weight decay is the only force acting on it, and it gets
    pulled to zero. The result is z1 = -z0, which is what the baseline model
    learned: gap and |z0|+|z1| agreed to four significant figures.

    With z1 = -z0 the two logits carry ONE number, and it is the gap that MSP
    already reads. That is why four post-hoc readouts (null term, soft-cap,
    hinge, spatial-aerosol energy) all failed identically -- they were four
    rescalings of the same quantity.

    A third denominator term that depends on LSE breaks the invariance, so the
    sum direction gains a gradient and stops collapsing.

    WHY LSE AND NOT |z0| + |z1|

    |z0| + |z1| equals |z0 - z1| whenever the two logits have OPPOSITE SIGNS --
    which is every antisymmetric pair, but also every merely opposite-signed
    pair. Nothing in the gradient pushes both logits onto the same side of zero,
    so that form stays trapped as a function of the gap even after the sum is
    freed. LSE ~ max(z0, z1) tracks the overall level instead, and separates
    from the gap as soon as the sum is nonzero.

    THE FOUR PARAMETERS, each doing a distinct job

      tau    WHERE the gate switches, in LSE units. Below tau the null term is
             on; above it, off. This is the strict evidence threshold -- a
             plateau then a transition, rather than the immediate exponential
             decay of a bare e^(-gamma*LSE).
      gamma  HOW SHARP the transition is. Bounded: gamma -> 0 makes the gate
             constant so LSE drops out, and gamma -> inf makes it a step with
             zero gradient almost everywhere, so tau could never be learned.
      k      HOW FAR the null logit travels between closed and open. Without it
             the gate moves the null logit by only 1 (sigmoid spans [0,1]),
             which is negligible against class logits of 2-4. With k = 8 it
             swings c to c+8, i.e. e^-6 = 0.0025 (irrelevant) up to e^2 = 7.4
             (comparable to e^z0), so the term can be decisive when open and
             invisible when closed.
      c      THE FLOOR when the gate is shut. Sets how completely the term
             vanishes.

    ARGMAX IS UNCHANGED: the null term is identical in both class denominators,
    so whichever of e^z0, e^z1 is larger stays larger. Accuracy is preserved by
    construction and asserted at evaluation.
    """

    # bounds chosen from the gradient-health and joint-grid audits
    GAMMA_MIN, GAMMA_MAX = 0.3, 5.0
    C_MIN, C_MAX = -20.0, 0.0

    def __init__(self, c_init=-6.0, k_init=8.0, gamma_init=2.0, tau_init=3.0):
        super().__init__()
        self._c = nn.Parameter(torch.tensor(float(c_init)))
        # softplus keeps k > 0; inverse-softplus the init so k starts at k_init
        self._k = nn.Parameter(torch.tensor(float(np.log(np.expm1(k_init)))))
        self._gamma = nn.Parameter(torch.tensor(0.0))       # -> midpoint
        self.tau = nn.Parameter(torch.tensor(float(tau_init)))
        self.set_gamma(gamma_init)
        # filled in after warmup so tau can be clamped to where the data lives,
        # and REFRESHED periodically -- see refresh_bounds
        self.register_buffer("lse_lo", torch.tensor(float("nan")))
        self.register_buffer("lse_hi", torch.tensor(float("nan")))

    # -- parameter views ---------------------------------------------------
    @property
    def c(self):
        """Floor, clamped to [-20, 0].

        A joint grid over (c, k, gamma, tau) showed c and tau TRADE OFF: as c
        rises the optimal tau falls, because a high floor already supplies
        abstention mass and the gate has less work to do. At c = +2 the optimum
        drove both tau and k to their minima -- the gate shutting itself down.
        The loss opposes this strongly (1.233 against the optimum's 0.361), so
        the clamp is insurance rather than necessity, but c above 0 makes the
        null term competitive with the class logits even when fully closed,
        which defeats the point of having a gate at all.
        """
        return self._c.clamp(self.C_MIN, self.C_MAX)

    @property
    def k(self):
        return F.softplus(self._k)

    @property
    def gamma(self):
        # sigmoid-bounded: cannot reach 0 (gate goes constant, LSE drops out)
        # nor blow up (gate becomes a step, zero gradient, tau unlearnable)
        s = torch.sigmoid(self._gamma)
        return self.GAMMA_MIN + (self.GAMMA_MAX - self.GAMMA_MIN) * s

    def set_gamma(self, value):
        v = (value - self.GAMMA_MIN) / (self.GAMMA_MAX - self.GAMMA_MIN)
        v = float(np.clip(v, 1e-4, 1 - 1e-4))
        with torch.no_grad():
            self._gamma.fill_(float(np.log(v / (1 - v))))

    def tau_clamped(self):
        """tau confined to the observed LSE range.

        At tau = 9.0 the gate was saturated on 99.4% of pixels with
        dL/dtau = +0.003 -- the optimiser would be stranded with no gradient to
        climb back on. At tau = 3.5 only 5.7% saturated. The clamp guarantees
        tau stays somewhere the data actually is.
        """
        if torch.isnan(self.lse_lo):
            return self.tau
        return self.tau.clamp(self.lse_lo, self.lse_hi)

    # -- the readout itself ------------------------------------------------
    @staticmethod
    def lse(logits):
        """log(e^z0 + e^z1). Kept for diagnostics only -- NOT the gate signal."""
        return torch.logsumexp(logits, dim=1)

    @staticmethod
    def evidence(logits):
        """s = (z0 + z1) / 2 -- the gate's evidence signal.

        WHY THE SUM AND NOT LSE. Write z0 = s - g/2, z1 = s + g/2, so s is the
        logit sum and g the gap. Cross-entropy depends only on g (softmax
        invariance). The second loss term exists to supervise s.

        But LSE = s + log(2 cosh(g/2)) depends on BOTH. Its gradient along the
        gap is tanh(g/2)/2 -- measured 0.231 at gap 1, 0.482 at gap 4, 0.500 at
        gap 8. So a BCE term on LSE was not only pushing on the sum; it was
        pushing on the GAP, which is what decides the prediction. That leak is
        what made the classifier oscillate between val IoU ~0.26 and ~0.01 in
        the first model-B run.

        s has EXACTLY zero gradient along g. Gating on s makes the two losses
        act on orthogonal directions -- CE on the gap only, BCE on the sum only
        -- so the second term can no longer reshape the classifier.

        Why LSE was chosen originally: on the frozen, antisymmetric model A,
        s is identically zero, so a post-hoc readout reading s would be
        constant and useless. LSE at least varied (as ~gap/2). But when
        TRAINING, making s informative is the entire goal, and s is the only
        choice that does not leak.
        """
        return logits.mean(dim=1)

    def null_logit(self, logits):
        """c + k * sigmoid(gamma * (tau - s)),  s = (z0 + z1)/2.

        Gate OPEN  (LSE < tau, low evidence):  sigmoid -> 1, null_logit -> c + k
        Gate SHUT  (LSE > tau, high evidence): sigmoid -> 0, null_logit -> c
        """
        gate = torch.sigmoid(self.gamma * (self.tau_clamped() - self.evidence(logits)))
        return self.c + self.k * gate

    def forward(self, logits):
        """Returns (p_fire, p_background, p_abstain), summing to 1 over three.

        Note these are NOT renormalised over the two real classes. Renormalising
        would cancel the null term exactly -- p_f/(p_f+p_b) = e^z1/(e^z0+e^z1) --
        making the whole mechanism a no-op for every calibration metric. The
        abstention mass is supposed to REDUCE the confidence attached to the
        surviving prediction; that is the mechanism, not a side effect.
        """
        lp = self.log_probs(logits)
        return lp[:, 1].exp(), lp[:, 0].exp(), lp[:, 2].exp()

    def log_probs(self, logits):
        """log p over (background, fire, abstain), computed in LOG space.

        Why not exponentiate directly: when both class logits are strongly
        negative and the null logit is large -- which is exactly what a
        low-evidence pixel looks like once the sum is free -- e^(z - max)
        underflows to 0.0 in float32 for BOTH classes. They tie, and argmax on
        the probabilities picks the wrong class. Measured: z0 = -87.8,
        z1 = -75.3, null = 30 gave p_bg = p_fire = 0.000.

        In log space, log p_fire - log p_bg = z1 - z0 EXACTLY, whatever the
        magnitudes. Use this for anything that ranks or compares classes.
        The model's prediction should always come from logits.argmax anyway.
        """
        nl = self.null_logit(logits)
        return torch.log_softmax(
            torch.stack([logits[:, 0], logits[:, 1], nl], dim=1), dim=1)

    @torch.no_grad()
    def _lse_quantiles(self, logits_list, qs=(0.05, 0.5, 0.95), max_pix=1_000_000):
        vals = torch.cat([self.evidence(l).flatten() for l in logits_list]).float()
        if vals.numel() > max_pix:          # torch.quantile has a size limit
            idx = torch.randperm(vals.numel(), device=vals.device)[:max_pix]
            vals = vals[idx]
        q = torch.quantile(vals, torch.tensor(qs, device=vals.device))
        return [float(v) for v in q]

    @torch.no_grad()
    def set_tau_from_data(self, logits_list):
        """Place tau at the median LSE and record the 5-95% range as bounds.

        Called ONCE after the CE-only warmup. tau cannot be hardcoded because
        the LSE distribution is not known until the network has produced logits,
        and it differs from the baseline model's (median ~2.1) because this one
        trains under a different loss.

        Placement matters for the GRADIENT, not just the loss value: at
        tau = 9.0 the gate was saturated on 99.4% of pixels with dL/dtau
        = +0.003, so the optimiser would have nothing to climb back on. At
        tau = 3.5, only 5.7% saturated.
        """
        lo, q25, md, hi = self._lse_quantiles(
            logits_list, qs=(0.05, 0.25, 0.5, 0.95))
        self.lse_lo.fill_(lo); self.lse_hi.fill_(hi)
        # tau starts at the 25th percentile, NOT the median. Measured at
        # switch-on: median gives mean p(empty) = 0.231, which is a large
        # discontinuity for the network to absorb the moment nu becomes
        # non-zero; the 25th percentile gives 0.125 and the 10th gives 0.058.
        # The joint grid optimum also sat BELOW the overall median (tau 3.5
        # against a median near 4.1), so this starts nearer where it ends up
        # while leaving the gate room to open further if the loss wants it.
        self.tau.fill_(q25)
        return lo, q25, hi

    @torch.no_grad()
    def refresh_bounds(self, logits_list, widen=0.5):
        """Re-measure the LSE range and move the clamp with it.

        WHY THIS IS NEEDED. The clamp added to protect tau from bad
        initialisation becomes a way to STRAND it if the bounds go stale. The
        LSE distribution drifts during training -- that is the entire point,
        since the BCE term is pushing on it. If LSE drifts upward while
        lse_hi stays at its warmup value, then LSE > tau everywhere, the gate
        is permanently shut, and the null term is dead with no gradient to
        recover. The bounds are widened slightly beyond the measured 5-95%
        range so tau is not pinned exactly at the edge.

        Returns (lo, median, hi, tau_at_edge) -- tau_at_edge is the warning
        sign: tau resting on its clamp means the optimiser wanted to go
        further and could not.
        """
        lo, md, hi = self._lse_quantiles(logits_list)
        lo, hi = lo - widen, hi + widen
        self.lse_lo.fill_(lo); self.lse_hi.fill_(hi)
        t = float(self.tau)
        at_edge = (t <= lo + 1e-3) or (t >= hi - 1e-3)
        return lo, md, hi, at_edge

    @torch.no_grad()
    def describe(self):
        return (f"c={float(self.c):+.3f} k={float(self.k):.3f} "
                f"gamma={float(self.gamma):.3f} tau={float(self.tau_clamped()):.3f} "
                f"[lse {float(self.lse_lo):.2f}-{float(self.lse_hi):.2f}]")

    def gate_params(self):
        """The four readout parameters, for a separate optimiser group.

        They need their own group because they must be EXCLUDED FROM WEIGHT
        DECAY -- decaying them toward zero is the same trap that collapsed the
        logit sum in the first place -- and because four scalars among 31M
        network parameters barely move at the network's learning rate.
        """
        return [self._c, self._k, self._gamma, self.tau]


# ================================================================ THE LOSS
class GatedNullLoss(nn.Module):
    r"""L = CE(z, y) + nu * weightedBCE( null_logit, 1[model is wrong] )

    WHY TWO TERMS AND NOT ONE

    Putting the null term in the readout alone does break shift invariance, so
    cross-entropy does gain a gradient along the sum direction. But that
    gradient points the WRONG WAY. The null term steals probability mass from
    the true class whether the model is right or wrong -- measured loss rose
    from 0.049 to 1.167 on a correct pixel and 3.049 to 4.167 on a wrong one as
    the null term grew. So plain CE drives it to zero everywhere and the readout
    reverts to ordinary softmax.

    There is also an escape through the network: with 31M parameters it can
    raise LSE everywhere, shrinking the null term without touching c at all.
    At LSE = 6, p(empty) falls to 0.0005.

    The BCE term supplies the missing REASON to use the channel. It trains the
    null logit to be HIGH where the model errs -- which, since null_logit falls
    with LSE, means training LSE to be LOW on errors. d(LSE)/d(sum) = 1.0000
    exactly, so that force lands directly on z0 + z1 and opposes weight decay.
    It also closes the network escape: inflating LSE would stop the model
    flagging errors, which now costs loss.

    THE TWO WEIGHTINGS ARE DIFFERENT AXES

      class_weight [1, 5] in CE   -- fire matters more than background
      w_miss / w_fa / 1 in BCE    -- being WRONG matters more than being right,
                                     and a missed fire matters more than a
                                     false alarm

    Errors are only ~6% of pixels. Unweighted, "never wrong" is already a cheap
    BCE solution (cost 0.254), and taking it means driving the null logit low
    everywhere -- which is the readout collapse arriving by another path. But
    over-weighting inverts the problem: at high pos_weight "always abstain"
    becomes cheapest, which is uniform softening and reproduces the SAEA v1
    failure (selectivity 1.36:1). Measured, the tuned gate beats both trivial
    solutions across pos_weight 1-20, with ~6 near the centre of the window.

    NU IS RAMPED FROM ZERO

    The error target is NON-STATIONARY: early in training the model is wrong
    almost everywhere, so 1[wrong] is mostly 1 and the gate would learn to open
    universally, then have to unlearn it. Warmup with nu = 0 lets the network
    learn to segment before it learns to abstain.

    CE AND BCE ARE IN TENSION, DELIBERATELY

    One way to predict errors accurately is to make more of them. If IoU falls
    below the baseline's 0.1997, nu is too high. Watch it.
    """

    def __init__(self, class_weight=(1.0, 5.0), w_miss=12.0, w_fa=3.0,
                 nu_target=0.5, warmup_epochs=3, ramp_epochs=3):
        super().__init__()
        self.register_buffer("cw", torch.tensor(list(class_weight)))
        self.w_miss, self.w_fa = w_miss, w_fa
        self.nu_target = nu_target
        self.warmup_epochs, self.ramp_epochs = warmup_epochs, ramp_epochs

    def nu(self, epoch):
        """0 during warmup, then linear ramp to nu_target."""
        if epoch <= self.warmup_epochs:
            return 0.0
        t = (epoch - self.warmup_epochs) / max(self.ramp_epochs, 1)
        return self.nu_target * min(t, 1.0)

    def forward(self, logits, labels, readout, epoch):
        # ---- term 1: ordinary class-weighted CE. Trains the GAP. -----------
        # Unchanged from the baseline, so the accuracy path is untouched and
        # the two models remain comparable.
        ce = F.cross_entropy(logits, labels, weight=self.cw.to(logits.dtype))

        nu = self.nu(epoch)
        if nu == 0.0:
            return ce, float(ce.detach()), 0.0, 0.0

        # ---- term 2: weighted BCE on the null logit. Trains the SUM. -------
        with torch.no_grad():
            # detached: no gradient flows through the correctness comparison
            # itself, only through null_logit
            pred = logits.argmax(dim=1)
            wrong = (pred != labels).float()
            # a missed fire is worse than a false alarm; correct pixels weight 1
            w = torch.where(wrong.bool(),
                            torch.where(labels == 1, self.w_miss, self.w_fa),
                            torch.ones_like(wrong))

        nl = readout.null_logit(logits)
        bce = F.binary_cross_entropy_with_logits(nl, wrong, weight=w)

        return ce + nu * bce, float(ce.detach()), float(bce.detach()), nu


# ------------------------------------------------------------------ checks
if __name__ == "__main__":
    torch.manual_seed(0)
    B, H, W = 4, 64, 64
    lg = torch.randn(B, 2, H, W) * 2.0
    lab = (torch.rand(B, H, W) < 0.06).long()

    ro = GatedNullReadout()
    lo, md, hi = ro.set_tau_from_data([lg])
    print(f"tau placed from data: 5% {lo:.3f}  median {md:.3f}  95% {hi:.3f}")
    print("readout:", ro.describe())

    pf, pb, pe = ro(lg)
    print(f"\nprobabilities sum to 1: {float((pf+pb+pe).mean()):.6f}")
    print(f"mean p(abstain): {float(pe.mean()):.5f}")

    # accuracy preservation -- the whole point of the identical null term
    same = torch.equal(lg.argmax(1), torch.stack([pb, pf]).argmax(0))
    print(f"argmax over the two real classes unchanged: {same}")

    crit = GatedNullLoss()
    for ep in [1, 3, 4, 5, 6, 8]:
        L, ce, bce, nu = crit(lg, lab, ro, ep)
        print(f"  epoch {ep}:  nu={nu:.3f}  CE={ce:.4f}  BCE={bce:.4f}  L={float(L):.4f}")
