r"""
FINAL TESTS -- every readout, every model, every condition, one run.

Writes, into final_results/ :
  1a_readouts_all_metrics.csv          + _TABLES.csv   (File 1, part A)
  1b_fire_ece_mce.csv                  + _TABLES.csv   (File 1, part B)
  2_height_gate_vs_baselines.csv       + _TABLES.csv   (File 2)
  3_confidence_by_category.csv         + _TABLES.csv   (File 3)
  scene_aerosol.csv                                    (is scene 4 smokier?)
The plain .csv files are "long" (one row per number, with confidence
intervals). The _TABLES.csv files are the same numbers arranged as small
tables ready to paste into Google Sheets and chart.

CONDITIONS
  scene 3, synthetic haze beta0 = 0.0, 0.1, 0.2, 0.3, 0.4, 0.5 (evenly spaced),
  scored on the HELD-OUT half of the patches (same split as every earlier run)
  scene 4, natural conditions, NO synthetic haze, ALL patches. Nothing was
  ever fitted or selected on scene 4, so it is the cleanest test available.
  Scenes 1 and 2 are excluded: they are the training data, so calibration
  measured there would be meaningless.
Every readout is fitted ONCE, on the held-in half of CLEAR scene 3, and then
applied unchanged everywhere.

READOUTS
  softmax          plain two-class softmax (the reference)
  temperature      one temperature                              (NLL)
  class-cond T     one temperature per predicted class          (NLL)
  Platt            sigmoid(a*gap + b)                           (NLL)
  beta             sigmoid(a*ln p + b*(-ln(1-p)) + c)           (NLL)
  isotonic         monotone map of the gap                      (PAV)
  SAEA             abstention logit (z0 - C + lam*S)/tau, S = fraction of a
                   201x201 neighbourhood called fire (the 3-parameter form,
                   aerosol dropped as in v2). Refitted here on the same
                   objective as the height gate, so it is compared fairly.
  trained gate     the null logit model B learned in training (model B only)
  height gate      abstention driven by the predicted class's logit
  evidence null    gate-free version of the same idea
  Platt, beta and isotonic can move the decision boundary; the IoU column
  shows when they do.

METRICS
  ECE                standard, all pixels (20 equal-width bins)
  ECE fire (pred)    pixels the model CALLED fire  -- the standard class-wise
                     definition, and this project's primary endpoint
  ECE fire (true)    pixels that ARE fire, including missed fire
  NLL, Brier         Brier in three-outcome form (= 2x binary Brier for
                     two-class readouts); both penalise abstention by design
  MCE                largest single-bin gap, ignoring bins with fewer than
                     max(30, 0.1% of the pixels) -- MCE is otherwise dominated
                     by near-empty bins
  AUROC              misclassification detection: how often a correct pixel
                     gets higher confidence than a wrong one (higher = better)
  IoU                segmentation quality, to show which readouts change it

PAIRED BOOTSTRAP
  Patches are resampled with replacement; every readout is scored on the SAME
  resample, and differences are taken within it. 95% intervals; * = the
  interval excludes zero. Resampled patches overlap spatially, so intervals
  are somewhat optimistic -- say so in the paper.

CATEGORIES (File 3), each defined by the readout's own call
  correct fire   called fire, really fire           (accuracy 1)
  false alarm    called fire, really background     (accuracy 0)
  missed fire    called background, really fire     (accuracy 0)
  correct bg     called background, really background (accuracy 1)

USAGE -- one --model per model: label, file prefix for scene 3, scene-4 file.
Scene-3 files are found as <prefix>scene3_haze_<tag>_logits.npz, tags
0p00 0p10 0p20 0p30 0p40 0p50. Missing files are skipped with a warning.
  python3 final_tests.py --boot 1000 \
    --model A_s0 ""     test_logits.npz \
    --model B_s0 gated_ gated_scene4_haze_0p00_logits.npz \
    --model A_s1 A_s1_  A_s1_scene4_haze_0p00_logits.npz \
    --model B_s1 B_s1_  B_s1_scene4_haze_0p00_logits.npz
Needs reverse_gate.py, evidence_null.py, final_compare.py, paired_height.py,
compile_results.py and height_check.py in the same folder.
"""

import sys, os, csv, argparse
import numpy as np
from reverse_gate import load, evidence, readout as gate_readout, fit as gate_fit, sigmoid
from evidence_null import readout as en_readout, fit as en_fit
from final_compare import fit_T, fixed, FIX_C, FIX_K, FIX_G
from compile_results import fit_platt, fit_isotonic, apply_isotonic

NB, NR = 20, 1000
BETAS = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]
CHUNK = 48
W_SPATIAL = 201
READOUTS = ["softmax", "temperature", "class-cond T", "Platt", "beta", "isotonic",
            "SAEA", "trained gate", "height gate", "evidence null"]
POPS = ["all", "pred_fire", "pred_bg", "true_fire", "true_bg"]
CATS = ["correct fire", "false alarm", "missed fire", "correct bg"]
M1A = [("ECE", "ece_all"), ("ECE fire (pred)", "ece_pred_fire"), ("ECE fire (true)", "ece_true_fire"),
       ("NLL", "nll"), ("Brier", "brier"), ("MCE", "mce_all"), ("AUROC", "auroc"), ("IoU", "iou")]
M1B = [("ECE fire (pred)", "ece_pred_fire"), ("ECE fire (true)", "ece_true_fire"),
       ("MCE fire (pred)", "mce_pred_fire"), ("MCE fire (true)", "mce_true_fire")]
M2 = [m for m in M1A if m[1] != "iou"]
HIGHER_BETTER = {"auroc", "iou"}
# results/ next to this script -- i.e. inside the Calibration folder, wherever
# the command is run from. Override with --out.
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")

# column layout of the per-patch statistics matrix
F_ECE = len(POPS) * 3 * NB
O_NLL, O_BRIER, O_N = F_ECE, F_ECE + 1, F_ECE + 2
O_AUC = F_ECE + 3
O_IOU = O_AUC + 2 * NR
O_CAT = O_IOU + 3
F_TOT = O_CAT + len(CATS) * 3


def tag(b):
    return f"{b:.2f}".replace(".", "p")


def cond_label(scene, b):
    return "scene4 natural" if scene == "scene4" else f"scene3 b0={b:.1f}"


# ----------------------------------------------------------------- fitting
def fit_beta(g, y, n=3_000_000):
    if g.size > n:
        i = np.random.default_rng(1).choice(g.size, n, replace=False); g, y = g[i], y[i]
    p = np.clip(sigmoid(g.astype(np.float64)), 1e-7, 1 - 1e-7)
    X = np.column_stack([np.ones_like(p), np.log(p), -np.log(1 - p)]); yy = y.astype(np.float64)
    w = np.array([0.0, 1.0, 1.0])
    for _ in range(40):
        q = sigmoid(X @ w); H = (X * (q * (1 - q))[:, None]).T @ X + 1e-6 * np.eye(3)
        step = np.linalg.solve(H, X.T @ (q - yy)); w -= step
        if np.abs(step).max() < 1e-8: break
    return w


def apply_beta(w, g):
    p = np.clip(sigmoid(g), 1e-7, 1 - 1e-7)
    return sigmoid(w[0] + w[1] * np.log(p) - w[2] * np.log(1 - p))


def spatial_frac(pred):
    """Fraction of a W x W neighbourhood called fire, per pixel, per patch."""
    P, H, W = pred.shape; r = W_SPATIAL // 2
    ys, xs = np.arange(H), np.arange(W)
    y0, y1 = np.clip(ys - r, 0, H), np.clip(ys + r + 1, 0, H)
    x0, x1 = np.clip(xs - r, 0, W), np.clip(xs + r + 1, 0, W)
    cnt = ((y1 - y0)[:, None] * (x1 - x0)[None, :]).astype(np.float32)
    ii = np.zeros((P, H + 1, W + 1), np.float32)
    ii[:, 1:, 1:] = pred.astype(np.float32).cumsum(1).cumsum(2)
    s = ii[:, y1][:, :, x1] - ii[:, y0][:, :, x1] - ii[:, y1][:, :, x0] + ii[:, y0][:, :, x0]
    return s / cnt


def three(z0, z1, e):
    m = np.maximum(np.maximum(z0, z1), e)
    a, b, c = np.exp(z0 - m), np.exp(z1 - m), np.exp(e - m); Z = a + b + c
    return a / Z, b / Z, c / Z, z1 > z0


def saea(z0, z1, S, C, lam, tau):
    return three(z0, z1, (z0 - C + lam * S) / tau)


def ece_pair(conf, corr, y):
    def e(c, o):
        if c.size == 0: return 0.0
        b = np.clip((c * NB).astype(int), 0, NB - 1)
        return float(np.abs(np.bincount(b, o, NB) - np.bincount(b, c, NB)).sum() / c.size)
    return e(conf[y], corr[y]) + e(conf[~y], corr[~y])


def fit_saea(z0, z1, S, yb):
    """Grid search on true-fire ECE + true-bg ECE -- the height gate's objective."""
    rng = np.random.default_rng(0)
    fi, bi = np.flatnonzero(yb), np.flatnonzero(~yb)
    i = np.sort(np.concatenate([rng.choice(fi, min(400_000, fi.size), replace=False),
                                rng.choice(bi, min(1_600_000, bi.size), replace=False)]))
    a0, a1, s, y = z0[i], z1[i], S[i], yb[i]
    best = None
    for C in (2.0, 3.0, 4.0, 5.0, 6.0, 8.0):
        for lam in (0.0, 1.0, 2.0, 4.0, 6.0, 8.0):
            for tau in (0.5, 1.0, 2.0):
                pb, pf, pn, pr = saea(a0, a1, s, C, lam, tau)
                conf = np.where(pr, pf, pb); corr = (pr == y).astype(np.float64)
                o = ece_pair(conf, corr, y)
                if best is None or o < best[0]: best = (o, C, lam, tau)
    return best[1:]


class Model:
    def __init__(self, label, prefix, s4file):
        self.label, self.prefix, self.s4 = label, prefix, s4file
        self.s3 = {b: f"{prefix}scene3_haze_{tag(b)}_logits.npz" for b in BETAS}
        base = self.s3[0.0]
        if not os.path.exists(base):
            sys.exit(f"[{label}] clear scene-3 file {base} is required for fitting")
        z = np.load(base)
        self.is_B = ("nu_target" in z.files and float(z["nu_target"]) > 0) or \
                    ("nu_target" not in z.files and "null_logit" in z.files)
        n = int(z["logits"].shape[0])
        perm = np.random.default_rng(0).permutation(n)          # SAME split as every run
        self.fit_idx, self.ev_idx = np.sort(perm[:n // 2]), np.sort(perm[n // 2:])

    def fit(self):
        print(f"\n######## {self.label} ({'model B' if self.is_B else 'model A'}): "
              f"fitting on {len(self.fit_idx)} held-in patches of clear scene 3", flush=True)
        d = fixed(load(self.s3[0.0], self.fit_idx))
        g, yb = d["z1"] - d["z0"], d["y"] == 1; pr = g > 0
        self.T = fit_T(g, yb)
        self.Tc = {c: fit_T(g[pr == c], yb[pr == c]) for c in (False, True)}
        self.platt = fit_platt(g, yb)
        self.beta = fit_beta(g, yb)
        self.iso = fit_isotonic(g, yb)
        print("  fitting height gate ...", flush=True)
        self.gate, self.gams = gate_fit(d, "height gate")
        print("  fitting evidence null ...", flush=True)
        self.en = en_fit(d)
        print("  fitting SAEA ...", flush=True)
        zz = np.load(self.s3[0.0]); LG = zz["logits"]
        S = np.concatenate([spatial_frac((LG[self.fit_idx[i:i + CHUNK], 1] > LG[self.fit_idx[i:i + CHUNK], 0])).ravel()
                            for i in range(0, len(self.fit_idx), CHUNK)])
        self.saea = fit_saea(d["z0"], d["z1"], S, yb)
        print(f"  T={self.T:.3f}  class-cond T bg={self.Tc[False]:.3f} fire={self.Tc[True]:.3f}  "
              f"SAEA C={self.saea[0]} lambda={self.saea[1]} tau={self.saea[2]}", flush=True)
        del d, S

    def readouts(self, ch):
        """All readouts for one chunk. ch: dict of flat arrays + spatial S."""
        z0, z1, yb = ch["z0"], ch["z1"], ch["y"] == 1
        g = z1 - z0; out = {}
        tc = lambda pf: (1 - pf, pf, np.zeros_like(pf), pf > 0.5)
        out["softmax"] = tc(sigmoid(g))
        out["temperature"] = tc(sigmoid(g / self.T))
        out["class-cond T"] = tc(sigmoid(g / np.where(g > 0, self.Tc[True], self.Tc[False])))
        out["Platt"] = tc(sigmoid(self.platt[1] * g + self.platt[0]))
        out["beta"] = tc(apply_beta(self.beta, g))
        out["isotonic"] = tc(apply_isotonic(self.iso, g).astype(np.float32))
        out["SAEA"] = saea(z0, z1, ch["S"], *self.saea)
        if self.is_B and ch.get("eta") is not None:
            out["trained gate"] = three(z0, z1, ch["eta"])
        d = dict(z0=z0, z1=z1, y=ch["y"], c=FIX_C, k=FIX_K, g=FIX_G)
        cg, _, pn, pr = gate_readout(d, evidence(d, "height gate"), self.gate, self.gams)
        out["height gate"] = (np.where(pr, 1 - pn - cg, cg), np.where(pr, cg, 1 - pn - cg), pn, pr)
        ce, _, pe = en_readout(d, self.en); pr2 = z1 > z0
        out["evidence null"] = (np.where(pr2, 1 - pe - ce, ce), np.where(pr2, ce, 1 - pe - ce), pe, pr2)
        return out


# ---------------------------------------------------------- statistics
def chunk_stats(pb, pf, pn, pred, yb, pid, P):
    """Per-patch sufficient statistics -> (P, F_TOT)."""
    conf = np.where(pred, pf, pb).astype(np.float64)
    corr = (pred == yb).astype(np.float64)
    M = np.zeros((P, F_TOT))
    bins = np.clip((conf * NB).astype(int), 0, NB - 1)
    masks = [None, pred, ~pred, yb, ~yb]
    for k, m in enumerate(masks):
        idx = pid * NB + bins if m is None else (pid * NB + bins)[m]
        c = conf if m is None else conf[m]; o = corr if m is None else corr[m]
        base = k * 3 * NB
        M[:, base:base + NB] = np.bincount(idx, minlength=P * NB).reshape(P, NB)
        M[:, base + NB:base + 2 * NB] = np.bincount(idx, c, P * NB).reshape(P, NB)
        M[:, base + 2 * NB:base + 3 * NB] = np.bincount(idx, o, P * NB).reshape(P, NB)
    pt = np.clip(np.where(yb, pf, pb), 1e-9, 1.0)
    M[:, O_NLL] = np.bincount(pid, -np.log(pt), P)
    M[:, O_BRIER] = np.bincount(pid, (pb - ~yb) ** 2 + (pf - yb) ** 2 + pn ** 2, P)
    M[:, O_N] = np.bincount(pid, minlength=P)
    rb = np.clip((conf * NR).astype(int), 0, NR - 1)
    ok = corr > 0.5
    M[:, O_AUC:O_AUC + NR] = np.bincount((pid * NR + rb)[ok], minlength=P * NR).reshape(P, NR)
    M[:, O_AUC + NR:O_AUC + 2 * NR] = np.bincount((pid * NR + rb)[~ok], minlength=P * NR).reshape(P, NR)
    M[:, O_IOU] = np.bincount(pid, (pred & yb).astype(float), P)
    M[:, O_IOU + 1] = np.bincount(pid, (pred & ~yb).astype(float), P)
    M[:, O_IOU + 2] = np.bincount(pid, (~pred & yb).astype(float), P)
    for k, m in enumerate([pred & yb, pred & ~yb, ~pred & yb, ~pred & ~yb]):
        M[:, O_CAT + 3 * k] = np.bincount(pid[m], minlength=P)
        M[:, O_CAT + 3 * k + 1] = np.bincount(pid[m], conf[m], P)
        M[:, O_CAT + 3 * k + 2] = np.bincount(pid[m], pn[m].astype(np.float64), P)
    return M


def metrics(V):
    """Vectorised over the first axis. V: (B, F_TOT) -> dict of (B,) arrays."""
    B = V.shape[0]; out = {}
    E = V[:, :F_ECE].reshape(B, len(POPS), 3, NB)
    cnt, sc, sa = E[:, :, 0], E[:, :, 1], E[:, :, 2]
    n = cnt.sum(-1)
    with np.errstate(invalid="ignore", divide="ignore"):
        ece = np.abs(sa - sc).sum(-1) / n
        thr = np.maximum(30, 0.001 * n)[..., None]
        gap = np.where(cnt >= thr, np.abs(sa / cnt - sc / cnt), -np.inf)
        mce = gap.max(-1); mce[~np.isfinite(mce)] = np.nan
        for k, p in enumerate(POPS):
            out[f"ece_{p}"], out[f"mce_{p}"] = ece[:, k], mce[:, k]
        N = V[:, O_N]
        out["nll"], out["brier"] = V[:, O_NLL] / N, V[:, O_BRIER] / N
        hc, hi = V[:, O_AUC:O_AUC + NR], V[:, O_AUC + NR:O_AUC + 2 * NR]
        above = hc.sum(-1, keepdims=True) - np.cumsum(hc, -1)
        out["auroc"] = (hi * (above + 0.5 * hc)).sum(-1) / (hc.sum(-1) * hi.sum(-1))
        tp, fp, fn = V[:, O_IOU], V[:, O_IOU + 1], V[:, O_IOU + 2]
        out["iou"] = tp / (tp + fp + fn)
        for k, c in enumerate(CATS):
            ct = V[:, O_CAT + 3 * k]
            out[f"n_{c}"] = ct
            out[f"conf_{c}"] = V[:, O_CAT + 3 * k + 1] / ct
            out[f"abst_{c}"] = V[:, O_CAT + 3 * k + 2] / ct
    return out


# --------------------------------------------------------------- per run
def evaluate(model, scene, b, path, boot):
    if not os.path.exists(path):
        print(f"  WARNING: {path} not found -- skipping {cond_label(scene, b)}", flush=True)
        return None
    z = np.load(path)
    LG, Y = z["logits"], z["labels"]
    NL = z["null_logit"] if "null_logit" in z.files else None
    idx = model.ev_idx if scene == "scene3" else np.arange(LG.shape[0])
    P = len(idx); stats = {}
    for s in range(0, P, CHUNK):
        sel = idx[s:s + CHUNK]; p = len(sel)
        lg = LG[sel].astype(np.float32); y = Y[sel]
        if y.ndim == 4: y = y[:, 0]
        HW = lg.shape[2] * lg.shape[3]
        ch = dict(z0=lg[:, 0].ravel(), z1=lg[:, 1].ravel(), y=y.ravel().astype(np.int8),
                  S=spatial_frac(lg[:, 1] > lg[:, 0]).ravel(),
                  eta=None if NL is None else NL[sel].astype(np.float32).ravel())
        pid = np.repeat(np.arange(p), HW)
        for nm, (pb, pf, pn, pr) in model.readouts(ch).items():
            Mc = chunk_stats(pb, pf, pn, pr, ch["y"] == 1, pid, p)
            stats.setdefault(nm, []).append(Mc)
    stats = {k: np.vstack(v) for k, v in stats.items()}
    rng = np.random.default_rng(3)
    Wt = np.stack([np.bincount(rng.integers(0, P, P), minlength=P) for _ in range(boot)]).astype(np.float64)
    res = {}
    for nm, M in stats.items():
        res[nm] = dict(point={k: float(v[0]) for k, v in metrics(M.sum(0)[None]).items()},
                       boot=metrics(Wt @ M))
    aer = None
    if "aerosol" in z.files:
        a = z["aerosol"][idx].astype(np.float32)
        aer = (float(np.nanmean(a)), float(np.nanmedian(a)), float(np.nanpercentile(a, 90)))
    print(f"  scored {cond_label(scene, b)}  ({P} patches)", flush=True)
    return dict(res=res, aer=aer, P=P)


def diff(res, a, ref, key):
    if a not in res or ref not in res: return None
    d = res[a]["boot"][key] - res[ref]["boot"][key]; d = d[np.isfinite(d)]
    if d.size == 0: return None
    lo, hi = np.percentile(d, [2.5, 97.5])
    better = (d > 0).mean() if key in HIGHER_BETTER else (d < 0).mean()
    pt = res[a]["point"][key] - res[ref]["point"][key]
    return pt, lo, hi, bool(hi < 0 or lo > 0), better


# ----------------------------------------------------------------- output
def fmt(v):
    return "" if v is None or (isinstance(v, float) and not np.isfinite(v)) else f"{v:.6f}"


def write_tables(path, blocks):
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        for title, header, rows in blocks:
            w.writerow([title]); w.writerow(header)
            for r in rows: w.writerow(r)
            w.writerow([])
    return len(blocks)


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("--model", action="append", nargs=3, default=[])
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    if not a.model:
        print(__doc__); sys.exit(1)
    global OUT
    if a.out: OUT = os.path.abspath(a.out)
    os.makedirs(OUT, exist_ok=True)
    print(f"writing everything to {OUT}", flush=True)
    R = {}                                                    # (model, cond) -> result
    models = [Model(*m) for m in a.model]
    for M in models:
        M.fit()
        for b in BETAS:
            r = evaluate(M, "scene3", b, M.s3[b], a.boot)
            if r: R[(M.label, cond_label("scene3", b))] = r
        r = evaluate(M, "scene4", 0.0, M.s4, a.boot)
        if r: R[(M.label, cond_label("scene4", 0.0))] = r

    labels = [M.label for M in models]
    s3c = [cond_label("scene3", b) for b in BETAS]; s4c = cond_label("scene4", 0.0)
    short = {cond_label("scene3", b): f"{b:.1f}" for b in BETAS}   # numeric x-axis for Sheets
    conds = s3c + [s4c]
    avail = lambda m: [nm for nm in READOUTS if any(nm in R[(m, c)]["res"] for c in conds if (m, c) in R)]
    n_tables = {}

    # ---------------- 1a ----------------
    with open(f"{OUT}/1a_readouts_all_metrics.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["model", "condition", "readout", "metric", "value", "diff_vs_softmax",
                    "ci_low", "ci_high", "significant", "pct_boot_better"])
        for (m, c), r in R.items():
            for nm in READOUTS:
                if nm not in r["res"]: continue
                for name, key in M1A:
                    dv = diff(r["res"], nm, "softmax", key) if nm != "softmax" else None
                    w.writerow([m, c, nm, name, fmt(r["res"][nm]["point"][key])] +
                               ([fmt(dv[0]), fmt(dv[1]), fmt(dv[2]), "*" if dv[3] else "", f"{dv[4]:.3f}"]
                                if dv else ["", "", "", "", ""]))
    blocks = []
    for m in labels:
        rd = avail(m)
        for name, key in M1A:
            rows = [[short[c]] + [fmt(R[(m, c)]["res"][nm]["point"][key]) if (m, c) in R and nm in R[(m, c)]["res"] else ""
                           for nm in rd] for c in s3c]
            blocks.append((f"{m} | {name} | scene 3, synthetic haze", ["beta0"] + rd, rows))
        if (m, s4c) in R:
            rows = [[nm] + [fmt(R[(m, s4c)]["res"][nm]["point"][k]) for _, k in M1A]
                    for nm in rd if nm in R[(m, s4c)]["res"]]
            blocks.append((f"{m} | all metrics | scene 4, natural", ["readout"] + [n for n, _ in M1A], rows))
    n_tables["1a"] = write_tables(f"{OUT}/1a_readouts_all_metrics_TABLES.csv", blocks)

    # ---------------- 1b ----------------
    with open(f"{OUT}/1b_fire_ece_mce.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["model", "condition", "readout", "metric", "value", "diff_vs_softmax",
                    "ci_low", "ci_high", "significant", "pct_boot_better"])
        for (m, c), r in R.items():
            for nm in READOUTS:
                if nm not in r["res"]: continue
                for name, key in M1B:
                    dv = diff(r["res"], nm, "softmax", key) if nm != "softmax" else None
                    w.writerow([m, c, nm, name, fmt(r["res"][nm]["point"][key])] +
                               ([fmt(dv[0]), fmt(dv[1]), fmt(dv[2]), "*" if dv[3] else "", f"{dv[4]:.3f}"]
                                if dv else ["", "", "", "", ""]))
    blocks = []
    for m in labels:
        rd = avail(m); rdn = [x for x in rd if x != "softmax"]
        for name, key in M1B:
            rows = [[short[c]] + [fmt(R[(m, c)]["res"][nm]["point"][key]) if (m, c) in R and nm in R[(m, c)]["res"] else ""
                           for nm in rd] for c in s3c]
            blocks.append((f"{m} | {name} | values | scene 3", ["beta0"] + rd, rows))
            rows = []
            for c in s3c:
                row = [short[c]]
                for nm in rdn:
                    dv = diff(R[(m, c)]["res"], nm, "softmax", key) if (m, c) in R else None
                    row.append(fmt(dv[0]) if dv else "")
                rows.append(row)
            blocks.append((f"{m} | {name} | readout MINUS softmax (negative = better) | scene 3",
                           ["beta0"] + rdn, rows))
        if (m, s4c) in R:
            res = R[(m, s4c)]["res"]
            blocks.append((f"{m} | fire ECE and MCE | values | scene 4, natural",
                           ["readout"] + [n for n, _ in M1B],
                           [[nm] + [fmt(res[nm]["point"][k]) for _, k in M1B] for nm in rd if nm in res]))
            rows = []
            for nm in rdn:
                if nm not in res: continue
                row = [nm]
                for _, k in M1B:
                    dv = diff(res, nm, "softmax", k)
                    row += [fmt(dv[0]), fmt(dv[1]), fmt(dv[2]), "*" if dv and dv[3] else ""] if dv else ["", "", "", ""]
                rows.append(row)
            hdr = ["readout"] + [f"{n} {s}" for n, _ in M1B for s in ("diff", "ci_low", "ci_high", "sig")]
            blocks.append((f"{m} | fire ECE and MCE | MINUS softmax with 95% CI | scene 4, natural", hdr, rows))
    n_tables["1b"] = write_tables(f"{OUT}/1b_fire_ece_mce_TABLES.csv", blocks)

    # ---------------- 2 ----------------
    bases = ["softmax", "temperature", "class-cond T"]
    with open(f"{OUT}/2_height_gate_vs_baselines.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["model", "condition", "baseline", "metric", "height_gate", "baseline_value",
                    "diff_height_minus_baseline", "ci_low", "ci_high", "significant", "pct_height_better"])
        for (m, c), r in R.items():
            for bs in bases:
                for name, key in M2:
                    dv = diff(r["res"], "height gate", bs, key)
                    if dv is None: continue
                    w.writerow([m, c, bs, name, fmt(r["res"]["height gate"]["point"][key]),
                                fmt(r["res"][bs]["point"][key]), fmt(dv[0]), fmt(dv[1]), fmt(dv[2]),
                                "*" if dv[3] else "", f"{dv[4]:.3f}"])
    blocks = []
    for m in labels:
        for bs in bases:
            rows = []
            for c in s3c:
                row = [short[c]]
                for _, key in M2:
                    dv = diff(R[(m, c)]["res"], "height gate", bs, key) if (m, c) in R else None
                    row.append(fmt(dv[0]) if dv else "")
                rows.append(row)
            blocks.append((f"{m} | height gate MINUS {bs} (negative = height gate better; AUROC: positive = better) | scene 3",
                           ["beta0"] + [n for n, _ in M2], rows))
        if (m, s4c) in R:
            res = R[(m, s4c)]["res"]; rows = []
            for bs in bases:
                row = [bs]
                for _, key in M2:
                    dv = diff(res, "height gate", bs, key)
                    row += [fmt(dv[0]), "*" if dv and dv[3] else ""] if dv else ["", ""]
                rows.append(row)
            hdr = ["baseline"] + [f"{n} {s}" for n, _ in M2 for s in ("diff", "sig")]
            blocks.append((f"{m} | height gate MINUS baseline | scene 4, natural", hdr, rows))
    n_tables["2"] = write_tables(f"{OUT}/2_height_gate_vs_baselines_TABLES.csv", blocks)

    # ---------------- 3 ----------------
    with open(f"{OUT}/3_confidence_by_category.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["model", "condition", "readout", "category", "pixels", "accuracy", "mean_confidence",
                    "ci_low", "ci_high", "confidence_minus_accuracy", "change_vs_softmax",
                    "change_ci_low", "change_ci_high", "change_significant", "mean_abstention"])
        for (m, c), r in R.items():
            for nm in READOUTS:
                if nm not in r["res"]: continue
                for cat in CATS:
                    acc = 1.0 if cat in ("correct fire", "correct bg") else 0.0
                    pt = r["res"][nm]["point"]; bt = r["res"][nm]["boot"][f"conf_{cat}"]
                    bt = bt[np.isfinite(bt)]
                    lo, hi = np.percentile(bt, [2.5, 97.5]) if bt.size else (np.nan, np.nan)
                    dv = diff(r["res"], nm, "softmax", f"conf_{cat}") if nm != "softmax" else None
                    w.writerow([m, c, nm, cat, int(pt[f"n_{cat}"]), acc, fmt(pt[f"conf_{cat}"]), fmt(lo), fmt(hi),
                                fmt(pt[f"conf_{cat}"] - acc)] +
                               ([fmt(dv[0]), fmt(dv[1]), fmt(dv[2]), "*" if dv[3] else ""] if dv else ["", "", "", ""]) +
                               [fmt(pt[f"abst_{cat}"])])
    blocks = []
    for m in labels:
        rd = avail(m)
        for cat in CATS:
            rows = [[short[c]] + [fmt(R[(m, c)]["res"][nm]["point"][f"conf_{cat}"]) if (m, c) in R and nm in R[(m, c)]["res"] else ""
                           for nm in rd] for c in s3c]
            acc = "1" if cat in ("correct fire", "correct bg") else "0"
            blocks.append((f"{m} | mean confidence on {cat.upper()} (true accuracy = {acc}) | scene 3",
                           ["beta0"] + rd, rows))
        if (m, s4c) in R:
            res = R[(m, s4c)]["res"]
            blocks.append((f"{m} | mean confidence by category | scene 4, natural",
                           ["readout"] + CATS,
                           [[nm] + [fmt(res[nm]["point"][f"conf_{c}"]) for c in CATS] for nm in rd if nm in res]))
    n_tables["3"] = write_tables(f"{OUT}/3_confidence_by_category_TABLES.csv", blocks)

    # ---------------- aerosol ----------------
    with open(f"{OUT}/scene_aerosol.csv", "w", newline="") as fh:
        w = csv.writer(fh); w.writerow(["model", "condition", "mean_aerosol_index", "median", "p90"])
        for (m, c), r in R.items():
            if r["aer"] and (c == s4c or c == s3c[0]):
                w.writerow([m, c] + [f"{x:.4f}" for x in r["aer"]])

    print("\n================ SUMMARY ================")
    for m in labels:
        if (m, s4c) not in R: continue
        res = R[(m, s4c)]["res"]
        print(f"\n{m}, scene 4 natural -- point estimates")
        print(f"  {'readout':<15}" + "".join(f"{n:>17}" for n, _ in M1A))
        for nm in READOUTS:
            if nm in res:
                print(f"  {nm:<15}" + "".join(f"{res[nm]['point'][k]:>17.4f}" for _, k in M1A))
    tot = sum(n_tables.values()) + 1
    desc = {
        "1a_readouts_all_metrics.csv": "File 1A, long: every readout x ECE, ECE fire (pred/true), NLL, Brier, MCE, AUROC, IoU, with paired difference vs softmax and 95% CI",
        "1a_readouts_all_metrics_TABLES.csv": f"File 1A as {n_tables['1a']} chart-ready tables",
        "1b_fire_ece_mce.csv": "File 1B, long: fire ECE and MCE (pred and true), paired difference vs softmax and 95% CI",
        "1b_fire_ece_mce_TABLES.csv": f"File 1B as {n_tables['1b']} chart-ready tables (values and differences)",
        "2_height_gate_vs_baselines.csv": "File 2, long: height gate minus softmax / temperature / class-cond T, 95% CI",
        "2_height_gate_vs_baselines_TABLES.csv": f"File 2 as {n_tables['2']} chart-ready tables",
        "3_confidence_by_category.csv": "File 3, long: mean confidence on correct fire, false alarm, missed fire, correct bg, 95% CI",
        "3_confidence_by_category_TABLES.csv": f"File 3 as {n_tables['3']} chart-ready tables",
        "scene_aerosol.csv": "Sentinel-5P aerosol index, clear scene 3 vs scene 4 (1 table)",
        "run_log.txt": "full terminal output of this run (written by the command's tee)",
    }
    with open(f"{OUT}/README.txt", "w") as fh:
        fh.write("FINAL TEST RESULTS\n\nModels: " + ", ".join(labels) + "\n")
        fh.write("Conditions: scene 3 held-out half at beta0 0.0-0.5 (step 0.1); scene 4 natural, all patches\n")
        fh.write(f"Bootstrap replicates: {a.boot}\n\nFILES\n")
        for f, d in desc.items():
            there = ("present" if os.path.exists(f"{OUT}/{f}") else "MISSING") if f != "run_log.txt" \
                    else "(saved by the run command; see below)"
            fh.write(f"  {f:<42} {there:<8} {d}\n")
        fh.write(f"\nTotal tables: {tot}\n")
        missing = [f"{m} | {c}" for m in labels for c in conds if (m, c) not in R]
        fh.write("Conditions skipped (file not found): " + (", ".join(missing) if missing else "none") + "\n")
    print(f"\nWrote to {OUT}/:")
    for k, v in n_tables.items():
        print(f"  file {k}: long CSV + TABLES CSV with {v} tables")
    print(f"  scene_aerosol.csv (1 table)\n  README.txt (what every file contains)\n  total tables: {tot}")


if __name__ == "__main__":
    main()
