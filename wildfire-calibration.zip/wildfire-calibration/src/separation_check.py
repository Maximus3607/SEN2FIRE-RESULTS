r"""
SEPARATION CHECK: can ANY available signal find missed fire at test time?

Among pixels the frozen model predicts as background, can a test-time-computable
signal separate genuine background from missed fire? That is the population the
method must act on -- roughly three quarters of true fire pixels are predicted
background, and they are what drives ECE(fire) = 0.691.

WHAT HAS ALREADY BEEN RULED OUT

This model learned ANTISYMMETRIC logits: z_1 = -z_0, so gap and |z_0|+|z_1|
agreed to four significant figures. The cause is structural -- softmax is
invariant to adding a constant to both logits, so cross-entropy gives EXACTLY
zero gradient along the (z_0+z_1) direction. Weight decay is then the only force
acting there and pulls the sum to zero.

Consequence: the logit vector carries ONE number per pixel, which MSP already
reads. Every logit-derived score below is a rescaling of that number, which is
why four functional forms (null term, soft-cap, hinge, SAEA energy) all failed.
They are kept here as controls, not candidates.

THE SIGNALS

  gap        z0 - z1                the decision margin. Control.
  abs        |z0| + |z1|            equals gap under antisymmetry. Control.
  lse        logsumexp(z0, z1)      the energy score. Control.
  nbr_fire   fraction of a W x W    SPATIAL. From the PREDICTION MAP, not the
             neighbourhood          logits. Escapes the 1-DOF bottleneck.
             predicted as fire      Best so far: AUROC ~0.60 at W=201.
  haze_cue   NDVI vs SWIR index     SPECTRAL, per-pixel at 10 m, computed from
             divergence             the reflectance bands. THE UNTESTED ONE.
                                    It fitted to b=0.0014 in adaptive T, but
                                    that fit was on CLEAR data where the cue
                                    carries no degradation signal. Under haze it
                                    genuinely varies, and unlike aerosol it
                                    varies WITHIN a patch.
  aerosol    Sentinel-5P AOD        km-scale, so flat within a 5 km patch. It
                                    cannot reorder pixels inside one patch and
                                    therefore cannot affect precision. Included
                                    only to confirm that.

HOW TO READ IT

AUROC is for detecting MISSED FIRE within the predicted-background set; 0.5 is
useless. The overlap column is the share of missed fire whose value falls inside
the middle 90% of the correct-background distribution -- high overlap means no
threshold separates them however the means differ.

numpy only. Usage:
  python3 separation_check.py test_logits.npz haze_0p20_logits.npz ...
"""

import sys
import numpy as np

W_SPATIAL = 201


def load(path):
    z = np.load(path)
    out = dict(logits=z["logits"].astype(np.float32))
    lb = z["labels"]
    if lb.ndim == 4:
        lb = lb[:, 0]
    out["labels"] = lb.astype(np.int64)
    for k in ("aerosol", "haze_cue"):
        if k in z.files:
            a = z[k].astype(np.float32)
            if a.ndim == 4:
                a = a[:, 0]
            out[k] = a
    out["beta"] = float(z["beta0"]) if "beta0" in z.files else float("nan")
    return out


def box_mean(x, k):
    p = k // 2
    xp = np.pad(x.astype(np.float32), ((0, 0), (p, p), (p, p)), mode="edge")
    c = np.pad(xp.cumsum(1).cumsum(2), ((0, 0), (1, 0), (1, 0)))
    H, W = x.shape[1], x.shape[2]
    return (c[:, k:k+H, k:k+W] - c[:, 0:H, k:k+W]
            - c[:, k:k+H, 0:W] + c[:, 0:H, 0:W]) / (k * k)


def auroc(score, target, n=800_000, seed=0):
    s = score.ravel().astype(np.float64)
    t = target.ravel().astype(np.float64)
    if s.size > n:
        rng = np.random.default_rng(seed)
        i = rng.choice(s.size, n, replace=False)
        s, t = s[i], t[i]
    npos, nneg = t.sum(), (1 - t).sum()
    if npos == 0 or nneg == 0:
        return float("nan")
    o = np.argsort(s)
    r = np.empty(s.size); r[o] = np.arange(1, s.size + 1)
    return (r[t == 1].sum() - npos * (npos + 1) / 2) / (npos * nneg)


def main(paths):
    for path in paths:
        d = load(path)
        lg, lb = d["logits"], d["labels"]
        pred = lg.argmax(1)
        z0, z1 = lg[:, 0], lg[:, 1]
        m = np.maximum(z0, z1)
        lse = m + np.log(np.exp(z0 - m) + np.exp(z1 - m))

        sig = {"gap": z0 - z1, "abs": np.abs(z0) + np.abs(z1), "lse": lse,
               "nbr_fire": box_mean((pred == 1).astype(np.float32), W_SPATIAL)}
        for k in ("haze_cue", "aerosol"):
            if k in d:
                sig[k] = d[k]

        pb = pred == 0
        miss, corr = pb & (lb == 1), pb & (lb == 0)
        print(f"\n{path}   beta0 = {d['beta']}")
        print(f"  predicted background {int(pb.sum()):,} "
              f"| missed fire {int(miss.sum()):,} "
              f"| correct bg {int(corr.sum()):,}")
        if miss.sum() == 0 or corr.sum() == 0:
            print("  degenerate, skipping"); continue

        print(f"  {'signal':<10}{'correct bg':>12}{'missed fire':>13}"
              f"{'AUROC':>8}{'flipped':>9}{'overlap':>9}")
        for name, s in sig.items():
            sc, sm = s[corr], s[miss]
            lo, hi = np.percentile(sc, [5, 95])
            ov = float(((sm >= lo) & (sm <= hi)).mean())
            a = auroc(np.concatenate([sc, sm]),
                      np.concatenate([np.zeros(sc.size), np.ones(sm.size)]))
            # a signal is equally useful inverted; report the usable direction
            print(f"  {name:<10}{sc.mean():>12.4f}{sm.mean():>13.4f}"
                  f"{a:>8.4f}{max(a, 1-a):>9.4f}{ov:>9.2%}")

    print("\nHOW TO READ THIS")
    print("  'flipped' is max(AUROC, 1-AUROC): a signal that ranks missed fire")
    print("  LOWER is just as usable, you invert it. That is the real number.")
    print("  gap / abs / lse are CONTROLS. Under antisymmetry they are the same")
    print("  quantity and should score identically -- if they do, that confirms")
    print("  the 1-DOF finding on this file.")
    print("  haze_cue is the one genuinely untested signal. If its flipped")
    print("  AUROC beats nbr_fire's ~0.60 with lower overlap, it is a better")
    print("  gate and the energy should use it. If it sits near 0.5, every")
    print("  available signal has now been tested and the honest conclusion is")
    print("  that this model exposes nothing that separates its own failures.")
    print("  aerosol should look useless here BY CONSTRUCTION -- it is constant")
    print("  within a patch, so it cannot reorder pixels inside one.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    main(sys.argv[1:])
