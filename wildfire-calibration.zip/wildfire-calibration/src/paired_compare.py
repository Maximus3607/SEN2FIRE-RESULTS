r"""
PAIRED COMPARISON: model A vs model B on the same patches.

Why paired. The per-model bootstrap in calibrate_full.py resamples each model
INDEPENDENTLY, so patch-to-patch difficulty inflates both intervals. At
beta0 = 0.50, model A's ECE(fire) interval was [0.456, 0.669] and model B's
[0.342, 0.535] -- overlapping, so not distinguishable on that test.

But both models were evaluated on identical ground. A patch that is hard for
one is hard for the other. Resampling the SAME patches for both and recording
the DIFFERENCE cancels that shared variation, which is the correct test for a
model-vs-model claim and typically much tighter.

THE ACCURACY CONFOUND

ECE(fire) is roughly confidence minus accuracy on fire pixels. Model B kept
IoU flat under haze (0.2774 -> 0.2795) while model A fell (0.2700 -> 0.2243).
So model B's smaller ECE(fire) could come from better CONFIDENCE, or simply from
better DETECTION -- a model that finds more fire has a smaller gap for free.

This reports conf|fire and acc|fire separately for both models, so the source
of the improvement is visible rather than assumed:

  B's conf|fire falls, acc|fire similar  -> genuine calibration gain
  B's acc|fire rises, conf|fire similar  -> the gain is accuracy, not calibration
  both move                              -> mixed; report both

Usage (pairs of A-file then B-file, same scene and severity):
  python3 paired_compare.py --boot 1000 \
      scene3_haze_0p20_logits.npz gated_scene3_haze_0p20_logits.npz \
      scene3_haze_0p50_logits.npz gated_scene3_haze_0p50_logits.npz
"""

import sys, argparse
import numpy as np


def load(path, idx):
    z = np.load(path)
    lg = z["logits"][idx].astype(np.float32)
    lb = z["labels"][idx]
    if lb.ndim == 4:
        lb = lb[:, 0]
    return lg[:, 1] - lg[:, 0], lb.astype(np.int8)


def ece(conf, correct, n_bins=20):
    e = np.linspace(0.0, 1.0, n_bins + 1); tot = 0.0; n = conf.size
    if n == 0:
        return float("nan")
    for i in range(n_bins):
        s = (conf > e[i]) & (conf <= e[i+1]); k = int(s.sum())
        if k:
            tot += (k/n) * abs(correct[s].mean() - conf[s].mean())
    return float(tot)


def fire_stats(gap, y):
    """ECE(fire), mean confidence and accuracy on true-fire pixels."""
    p = 1.0 / (1.0 + np.exp(-np.clip(gap, -60, 60)))
    pred = (p > 0.5).astype(np.int8)
    conf = np.maximum(p, 1 - p)
    corr = (pred == y).astype(np.float32)
    f = y == 1
    return (ece(conf[f], corr[f]), float(conf[f].mean()), float(corr[f].mean()))


def fire_hist(gap, y, n_bins=20):
    """Per-patch sufficient statistics for ECE on true-fire pixels.

    H[p] = (count, sum of confidence, sum of correctness) in each confidence
    bin, for patch p. Uses EXACTLY the binning of ece() above -- bin i holds
    conf in (e_i, e_{i+1}] -- so summing these over a resample of patches gives
    the same ECE as rebuilding the resampled images, which is what the old
    bootstrap did 1,000 times over ~66 million pixels per model. Same numbers,
    a small fraction of the time.
    """
    e = np.linspace(0.0, 1.0, n_bins + 1)
    P = gap.shape[0]; H = np.zeros((P, 3, n_bins))
    for i in range(P):
        f = y[i] == 1
        if not f.any():
            continue
        p = 1.0 / (1.0 + np.exp(-np.clip(gap[i][f], -60, 60)))
        conf = np.maximum(p, 1 - p)
        corr = (p > 0.5).astype(np.float64)             # true fire: right iff called fire
        b = np.searchsorted(e, conf, side="left") - 1
        k = (b >= 0) & (b < n_bins)
        H[i, 0] = np.bincount(b[k], minlength=n_bins)
        H[i, 1] = np.bincount(b[k], conf[k].astype(np.float64), n_bins)
        H[i, 2] = np.bincount(b[k], corr[k], n_bins)
    return H


def ece_from_hist(h):
    n = h[0].sum()
    return float(np.abs(h[2] - h[1]).sum() / n) if n else float("nan")


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("files", nargs="*")
    a = ap.parse_args()
    if len(a.files) < 2 or len(a.files) % 2:
        print(__doc__); sys.exit(1)

    for fa, fb in zip(a.files[0::2], a.files[1::2]):
        n = int(np.load(fa)["logits"].shape[0])
        # SAME split as calibrate_full.py --split, so these are the SAME 252
        # held-out patches that produced the tables already in hand
        perm = np.random.default_rng(0).permutation(n)
        ev = np.sort(perm[n//2:])

        ga, ya = load(fa, ev)
        gb, yb = load(fb, ev)
        # patches must be the same ground, or the pairing is meaningless
        assert ya.shape == yb.shape and np.array_equal(ya, yb), (
            f"labels differ between {fa} and {fb} -- the files do not cover the "
            "same patches in the same order, so a paired test is invalid")

        beta = float(np.load(fa)["beta0"]) if "beta0" in np.load(fa).files else float("nan")
        ea, ca, aa = fire_stats(ga, ya)
        eb, cb, ab = fire_stats(gb, yb)

        print(f"\n=== beta0 = {beta}   ({len(ev)} held-out patches, labels verified identical)")
        print(f"  {'':<10}{'ECE(fire)':>11}{'conf|fire':>11}{'acc|fire':>10}{'gap':>9}")
        print(f"  {'model A':<10}{ea:>11.5f}{ca:>11.4f}{aa:>10.4f}{ca-aa:>9.4f}")
        print(f"  {'model B':<10}{eb:>11.5f}{cb:>11.4f}{ab:>10.4f}{cb-ab:>9.4f}")
        print(f"  {'B - A':<10}{eb-ea:>+11.5f}{cb-ca:>+11.4f}{ab-aa:>+10.4f}")

        # ---- paired bootstrap on the DIFFERENCE ----
        H, W = ya.shape[1], ya.shape[2]
        Ha, Hb = fire_hist(ga, ya), fire_hist(gb, yb)       # one pass per model
        rng = np.random.default_rng(1)
        d = []
        for _ in range(a.boot):
            pk = rng.integers(0, len(ev), len(ev))
            e1 = ece_from_hist(Ha[pk].sum(0))
            e2 = ece_from_hist(Hb[pk].sum(0))
            if np.isfinite(e1) and np.isfinite(e2):
                d.append(e2 - e1)
        d = np.array(d)
        lo, hi = np.percentile(d, [2.5, 97.5])
        frac = float((d < 0).mean())
        print(f"\n  paired bootstrap, {len(d)} replicates on identical patches:")
        print(f"    ECE(fire) B - A  95% CI [{lo:+.5f}, {hi:+.5f}]"
              + ("   * excludes zero" if hi < 0 or lo > 0 else "   includes zero"))
        print(f"    model B better in {frac:.1%} of replicates")

    print("\nHOW TO READ THIS")
    print("  The paired interval is the test that matters. If it excludes zero,")
    print("  model B's lower ECE(fire) is not patch-sampling luck.")
    print("  Then read WHERE the gain comes from:")
    print("    conf|fire falls, acc|fire flat -> genuine calibration improvement")
    print("    acc|fire rises, conf|fire flat -> B finds more fire; the smaller")
    print("                                     gap is an accuracy effect")
    print("    both move                      -> mixed; report both honestly")
    print("  Single training seed for each model -- this tests sampling")
    print("  uncertainty over patches, NOT run-to-run training variance.")


if __name__ == "__main__":
    main()
