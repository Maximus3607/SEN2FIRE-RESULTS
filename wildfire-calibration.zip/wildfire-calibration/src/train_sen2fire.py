"""
Wildfire segmentation - U-Net on Sen2Fire.
Stage 1 of a two-stage calibration study: train the segmenter, then dump logits
for offline per-pixel temperature scaling.

Kaggle:  Session options > Accelerator > GPU T4    <- DO THIS FIRST
         NOT P100: it is sm_60, and Kaggle's torch 2.10+cu128 build supports
         only sm_70..sm_120. CUDA init warns but does not fail; the run dies
         later with AcceleratorError on the first forward pass. T4 is sm_75.
         Add Data > Sen2Fire
         Save Version > Save & Run All (Commit)      <- not plain Run

Dataset: https://zenodo.org/records/10881058  (CC-BY-4.0)

==============================================================================
WHAT CHANGED FROM THE PREVIOUS VERSION, AND WHY
==============================================================================
1. pos_weight 20.0 -> 1.0, dice_weight 1.0 -> 0.0.
   Weighted BCE adds a roughly CONSTANT OFFSET to the logits. Temperature
   scaling DIVIDES logits, so it can only change the slope of the logit ->
   probability map. A scale cannot undo a shift. Training with pos_weight=20
   would hand the calibration stage logits carrying a systematic bias that
   temperature scaling is structurally incapable of correcting -- and you would
   wrongly conclude the method failed. Dice loss compounds this: it optimises
   overlap, is not a proper scoring rule, and pushes probabilities toward 0/1.
   Class imbalance is now handled by SAMPLING (fire-containing patches drawn
   more often), which leaves the loss a proper scoring rule.

2. Reflectance rescaling is now decided ONCE GLOBALLY, not per patch.
   The old `if np.nanmax(img) > 100: img /= 10000` fired per file. A dark patch
   (deep water, cloud shadow) whose bands all max below 100 skipped the divide
   and entered the network at 10000x the scale of every other patch.

3. Normalisation statistics are sampled RANDOMLY across the whole train split.
   The old code used the first 200 files in glob order, which is sorted, so
   they were nearly all scene1 -- stats for one study area, not the split.

4. Logits are dumped for VAL (scene3) AND TEST (scene4).
   Temperature must be FIT on val and EVALUATED on test. Dumping only test
   would force fitting and reporting on the same data, invalidating the result.

5. The dumps now include the AEROSOL band and the HAZE CUE per pixel.
   The calibrator conditions on these. Without them in the file, the offline
   stage is impossible and the whole GPU session has to be repeated.

6. The RNG is built once in __init__ instead of per __getitem__ call.

NOTE ON AEROSOL: band_idx selects indices 0-11 only, so the aerosol layer at
index 12 never reaches the encoder. The segmenter therefore cannot use aerosol
as fire evidence. This matters because aerosols are PRODUCED BY fires, so the
band is label-correlated; conditioning temperature on a variable the prediction
already depends on would be circular. Here it stays exogenous by construction.
==============================================================================
"""

import os, glob, json, time, collections
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler

# ================================ CONFIG ================================
class CFG:
    data_root   = "/kaggle/input"        # searched recursively, nesting is fine
    out_dir     = "/kaggle/working"
    # VERIFY against Sen2Fire docs. Assumes 12 Sentinel-2 bands (B10 dropped)
    # then Sentinel-5P aerosol last. Wrong indices produce a plausible-looking
    # but meaningless haze cue, which fails silently.
    band_idx    = [3, 2, 1, 7, 10, 11]   # R, G, B, NIR, SWIR1, SWIR2
    # Aerosol lives under its OWN npz key ('aerosol'), NOT as a 13th channel of
    # 'image'. The image array holds exactly 12 Sentinel-2 bands.
    # positions WITHIN the selected 6-band stack, for the haze cue
    sel_red, sel_nir, sel_swir1, sel_swir2 = 0, 3, 4, 5

    splits      = {"train": ["scene1", "scene2"], "val": ["scene3"], "test": ["scene4"]}
    in_ch, out_ch, base = 6, 1, 64
    batch_size  = 4
    epochs      = 60
    lr          = 1e-3
    weight_decay= 1e-4

    # --- calibration-clean loss settings (see note 1 above) ---
    pos_weight   = 1.0     # keep at 1.0; imbalance handled by sampling
    dice_weight  = 0.0     # keep at 0.0; dice is not a proper scoring rule
    fire_sampling = True   # oversample fire-containing patches
    fire_ratio    = 0.3    # only 10.5% of train patches have fire; 0.5 would
                           # redraw those 153 patches ~5x/epoch -> memorisation

    amp         = True
    workers     = 2
    stats_n     = 300      # patches sampled for normalisation statistics
    max_hours   = 8.0
    fresh_start = False

torch.manual_seed(0); np.random.seed(0)
torch.backends.cudnn.benchmark = True
DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT = Path(CFG.out_dir); OUT.mkdir(parents=True, exist_ok=True)
print("torch", torch.__version__, "| device:", DEV)
if DEV == "cuda":
    print("GPU:", torch.cuda.get_device_name(0))
else:
    print("!! NO GPU -> Session options > Accelerator > GPU T4 x1, then re-run")

# ================================ MODEL ================================
class DoubleConv(nn.Module):
    """(conv3x3 -> BN -> ReLU) x2.  padding=1 keeps H,W unchanged."""
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(inplace=True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(inplace=True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    """maxpool 2x2 (halve H,W) then DoubleConv (double channels)."""
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    """convT 2x2 stride 2 (double H,W), concat skip, DoubleConv."""
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2)
        self.conv = DoubleConv(co * 2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2) - x.size(-2); dx = skip.size(-1) - x.size(-1)
            x = F.pad(x, [dx//2, dx-dx//2, dy//2, dy-dy//2])
        return self.conv(torch.cat([skip, x], dim=1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=1, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b*2), Down(b*2, b*4)
        self.d3, self.d4 = Down(b*4, b*8), Down(b*8, b*16)
        self.u1, self.u2 = Up(b*16, b*8), Up(b*8, b*4)
        self.u3, self.u4 = Up(b*4, b*2), Up(b*2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)                                    # logits, NO sigmoid

_m = UNet(CFG.in_ch, CFG.out_ch, CFG.base)
_c = collections.Counter(type(x).__name__ for x in _m.modules() if not list(x.children()))
print("\narchitecture:")
for k, v in {"Conv2d":19,"BatchNorm2d":18,"ReLU":18,"MaxPool2d":4,"ConvTranspose2d":4}.items():
    assert _c[k] == v, f"{k}: got {_c[k]}, expected {v}"
    print(f"  {k:16s} {_c[k]:3d}  OK")
print("  parameters:", f"{sum(p.numel() for p in _m.parameters()):,}")
del _m

# ================================ DATA ================================
def find_files(root, tags):
    """Recursive search; a file belongs to a split if one of its PARENT
    DIRECTORIES is exactly a tag (not a substring), so 'scene1-backup'
    cannot pollute a split."""
    out = []
    for f in sorted(glob.glob(str(Path(root) / "**" / "*.npz"), recursive=True)):
        parts = {p.lower() for p in Path(f).parts[:-1]}
        if any(t.lower() in parts for t in tags):
            out.append(f)
    return out

print("\ndata:")
files = {s: find_files(CFG.data_root, t) for s, t in CFG.splits.items()}
for s, f in files.items():
    print(f"  {s:6s} {len(f):5d} files" + (f"   e.g. {f[0]}" if f else ""))
n_total = sum(len(f) for f in files.values())
assert n_total > 0, (
    "No .npz matched. Check Add Data attached the dataset and that the "
    "scene1..scene4 folders exist. Debug with:\n"
    "  import glob; print(glob.glob('/kaggle/input/**/*.npz', recursive=True)[:5])")
print(f"  total {n_total} (expected 2466: 1458 train / 504 val / 504 test)")


def _nd(a, b, eps=1e-6):
    """Normalised difference index."""
    return (a - b) / (a + b + eps)


def haze_cue_from_raw(img_raw):
    """Per-pixel smoke indicator, computed from RAW REFLECTANCE.

    Must NOT use standardised bands: these are ratio indices, and subtracting a
    per-band mean destroys the physical ratio they encode.

    Smoke attenuates visible wavelengths far more than SWIR, so a visible-
    dependent index (NDVI) and SWIR-dependent indices (NBR, NBR2) diverge
    exactly where the visible signal is compromised. This is an ATTENUATION
    signal, not a fire signal, so it does not reproduce the aerosol confound.

    Args: img_raw (6, H, W) selected bands, reflectance scale.
    Returns: (1, H, W) float32 disagreement magnitude.
    """
    red   = img_raw[CFG.sel_red]
    nir   = img_raw[CFG.sel_nir]
    swir1 = img_raw[CFG.sel_swir1]
    swir2 = img_raw[CFG.sel_swir2]
    ndvi = _nd(nir, red)        # visible-dependent
    nbr  = _nd(nir, swir2)      # SWIR-dependent
    nbr2 = _nd(swir1, swir2)    # SWIR-only reference
    cue = 0.5*np.abs(ndvi - nbr) + 0.5*np.abs(ndvi - nbr2)
    return np.nan_to_num(cue).astype(np.float32)[None]


class Sen2Fire(Dataset):
    """return_aux=True additionally yields the aerosol band and haze cue, which
    the calibration stage needs. The segmenter never receives them."""

    def __init__(self, files, mean=None, std=None, augment=False,
                 scale=1.0, return_aux=False, seed=0):
        self.files = files
        self.mean, self.std = mean, std
        self.augment, self.scale, self.return_aux = augment, scale, return_aux
        self.rng = np.random.default_rng(seed)     # built ONCE, not per item
        self.ik = self.lk = self.ak = None

    def __len__(self): return len(self.files)

    def _keys(self, z):
        if self.ik is None:
            ks = list(z.keys())
            self.ik = next((k for k in ("image","img","data","x") if k in ks), ks[0])
            self.lk = next((k for k in ("label","mask","gt","y") if k in ks), ks[-1])
            self.ak = next((k for k in ("aerosol","s5p","aod") if k in ks), None)
            assert self.ik != self.lk, f"image/label key collision in npz: {ks}"
            assert self.ak is not None, f"no aerosol key in npz: {ks}"
        return self.ik, self.lk

    def _load(self, i):
        """Returns (bands, label, aerosol). No normalisation, no band selection."""
        z = np.load(self.files[i], allow_pickle=True)
        ik, lk = self._keys(z)
        img = np.asarray(z[ik], dtype=np.float32)
        if img.ndim == 3 and img.shape[2] < img.shape[0]:
            img = np.transpose(img, (2, 0, 1))                 # (H,W,C)->(C,H,W)
        lab = np.asarray(z[lk], dtype=np.float32)
        if lab.ndim == 2: lab = lab[None]
        # Aerosol is a SEPARATE key, not a channel of `image`. The previous
        # version sliced channel 12 of `image` and silently substituted zeros
        # when it did not exist -- which is exactly what happened.
        aer = np.asarray(z[self.ak], dtype=np.float32)
        if aer.ndim == 2: aer = aer[None]
        return (np.nan_to_num(img), (lab > 0).astype(np.float32),
                np.nan_to_num(aer))

    def raw(self, i):
        """Selected bands at reflectance scale, plus label and aerosol."""
        allb, lab, aer = self._load(i)
        assert allb.shape[0] == 12, f"expected 12 bands, got {allb.shape[0]}"
        img = allb[CFG.band_idx] * self.scale                  # GLOBAL scale
        return img, lab, aer

    def __getitem__(self, i):
        img, lab, aer = self.raw(i)
        cue = haze_cue_from_raw(img)                           # from RAW bands

        if self.mean is not None:
            img = (img - self.mean[:,None,None]) / (self.std[:,None,None] + 1e-6)

        if self.augment:                                       # GEOMETRIC ONLY:
            r = self.rng                                       # photometric edits
            if r.random() < .5:                                # would alter the
                img, lab = img[:,:,::-1], lab[:,:,::-1]        # test variable
                aer, cue = aer[:,:,::-1], cue[:,:,::-1]
            if r.random() < .5:
                img, lab = img[:,::-1], lab[:,::-1]
                aer, cue = aer[:,::-1], cue[:,::-1]
            k = int(r.integers(4))
            if k:
                img, lab = np.rot90(img,k,(1,2)), np.rot90(lab,k,(1,2))
                aer, cue = np.rot90(aer,k,(1,2)), np.rot90(cue,k,(1,2))

        t = lambda a: torch.from_numpy(np.ascontiguousarray(a))
        if self.return_aux:
            return t(img), t(lab), t(aer), t(cue)
        return t(img), t(lab)


# ---- global reflectance scale, decided ONCE (fix 2) ----
STATS = OUT / "norm_stats.npz"
probe = Sen2Fire(files["train"])
if STATS.exists():
    z = np.load(STATS)
    MEAN, STD, SCALE = z["mean"], z["std"], float(z["scale"])
    print("\n  loaded cached norm stats")
else:
    rng = np.random.default_rng(0)
    idx = rng.choice(len(probe), size=min(CFG.stats_n, len(probe)), replace=False)

    maxes = []
    for i in idx[:50]:
        allb, _, _ = probe._load(int(i))
        maxes.append(float(np.nanmax(allb[CFG.band_idx])))
    SCALE = 1e-4 if float(np.median(maxes)) > 100 else 1.0
    print(f"\n  reflectance probe: median max {np.median(maxes):.1f} -> scale {SCALE:g}")
    probe.scale = SCALE

    print(f"  computing norm stats from {len(idx)} RANDOM train patches ...")
    n = 0; s1 = np.zeros(CFG.in_ch); s2 = np.zeros(CFG.in_ch)
    for i in idx:
        im, _, _ = probe.raw(int(i)); v = im.reshape(CFG.in_ch, -1)
        s1 += v.sum(1); s2 += (v**2).sum(1); n += v.shape[1]
    MEAN = (s1/n).astype(np.float32)
    STD  = np.sqrt(np.maximum(s2/n - MEAN**2, 1e-8)).astype(np.float32)
    np.savez(STATS, mean=MEAN, std=STD, scale=SCALE)
probe.scale = SCALE
print("  scale", SCALE); print("  mean", np.round(MEAN,4)); print("  std ", np.round(STD,4))

# ---- sanity check on one real patch BEFORE committing hours to training ----
print("\nsanity check (one training patch):")
_allb, _, _ = probe._load(0)
print(f"  npz image channels: {_allb.shape[0]} (band_idx assumes 12, B10 dropped)")
_i, _l, _a = probe.raw(0)
_cue = haze_cue_from_raw(_i)
print(f"  image {_i.shape} range [{_i.min():.4f}, {_i.max():.4f}]")
print(f"  label {_l.shape} fire = {_l.mean()*100:.2f}% of pixels")
print(f"  aerosol {_a.shape} range [{_a.min():.4f}, {_a.max():.4f}] std {_a.std():.6f}")
print(f"  haze cue {_cue.shape} range [{_cue.min():.4f}, {_cue.max():.4f}]")
assert _i.shape[0] == CFG.in_ch, f"expected {CFG.in_ch} bands, got {_i.shape[0]}"
assert _i.shape[1:] == _l.shape[1:], f"image/label size mismatch"
# If aerosol std is ~0 the band is flat per patch -> it can only drive a
# SCENE-level temperature term, not a per-pixel one. The haze cue supplies
# the per-pixel variation in that case.
if _a.std() < 1e-6:
    print("  NOTE aerosol is flat within this patch -> scene-level term only")

# ---- fire-containing patch index, for balanced sampling (fix 1) ----
FIREIDX = OUT / "fire_index.json"
if CFG.fire_sampling:
    if FIREIDX.exists():
        has_fire = np.array(json.loads(FIREIDX.read_text()), dtype=bool)
        print("\n  loaded cached fire index")
    else:
        print("\n  scanning train labels for fire content (one pass) ...")
        has_fire = np.zeros(len(probe), dtype=bool)
        for i in range(len(probe)):
            _, lab, _ = probe._load(i)
            has_fire[i] = lab.sum() > 0
        FIREIDX.write_text(json.dumps(has_fire.tolist()))
    nf = int(has_fire.sum())
    print(f"  {nf}/{len(has_fire)} train patches contain fire ({100*nf/len(has_fire):.1f}%)")
    if nf == 0 or nf == len(has_fire):
        print("  -> degenerate, disabling fire sampling")
        CFG.fire_sampling = False
del probe

# ============================ LOSS / METRICS ============================
def dice_loss(lg, y, eps=1.0):
    p = torch.sigmoid(lg).flatten(1); t = y.flatten(1)
    inter = (p*t).sum(1)
    return (1 - (2*inter+eps)/(p.sum(1)+t.sum(1)+eps)).mean()

PW = torch.tensor([CFG.pos_weight], device=DEV)
def criterion(lg, y):
    # pos_weight=1.0 and dice_weight=0.0 keep this a PROPER SCORING RULE, which
    # is what makes the downstream calibration numbers meaningful.
    l = F.binary_cross_entropy_with_logits(lg, y, pos_weight=PW)
    return l + CFG.dice_weight*dice_loss(lg, y) if CFG.dice_weight > 0 else l

@torch.no_grad()
def counts(lg, y, thr=0.5):
    p = (torch.sigmoid(lg) > thr).float()
    return (p*y).sum().item(), (p*(1-y)).sum().item(), ((1-p)*y).sum().item()

# ================================ TRAIN ================================
def mk(split, aug, aux=False):
    return Sen2Fire(files[split], MEAN, STD, aug, scale=SCALE, return_aux=aux)

dl_kw = dict(num_workers=CFG.workers, pin_memory=(DEV == "cuda"))
train_ds = mk("train", True)
if CFG.fire_sampling:
    # Balance by SAMPLING rather than by reweighting the loss, so the loss
    # stays proper and the logits stay calibratable by a pure scale.
    w = np.where(has_fire, CFG.fire_ratio/max(has_fire.sum(),1),
                           (1-CFG.fire_ratio)/max((~has_fire).sum(),1))
    sampler = WeightedRandomSampler(torch.as_tensor(w, dtype=torch.double),
                                    num_samples=len(train_ds), replacement=True)
    train_dl = DataLoader(train_ds, batch_size=CFG.batch_size,
                          sampler=sampler, drop_last=True, **dl_kw)
    print("  using fire-balanced sampling")
else:
    train_dl = DataLoader(train_ds, batch_size=CFG.batch_size,
                          shuffle=True, drop_last=True, **dl_kw)
val_dl = DataLoader(mk("val", False), batch_size=CFG.batch_size, **dl_kw)

model  = UNet(CFG.in_ch, CFG.out_ch, CFG.base).to(DEV)
opt    = torch.optim.AdamW(model.parameters(), lr=CFG.lr, weight_decay=CFG.weight_decay)
sched  = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=CFG.epochs)
scaler = torch.amp.GradScaler("cuda", enabled=(CFG.amp and DEV == "cuda"))

LAST, BEST = OUT/"last.pt", OUT/"best.pt"
if CFG.fresh_start and LAST.exists():
    LAST.unlink(); print("\nfresh_start: deleted old checkpoint")

ep0, best, hist = 1, -1.0, []
if LAST.exists():
    ck = torch.load(LAST, map_location=DEV, weights_only=False)
    model.load_state_dict(ck["model"]); opt.load_state_dict(ck["opt"])
    sched.load_state_dict(ck["sched"]); scaler.load_state_dict(ck["scaler"])
    ep0, best, hist = ck["epoch"]+1, ck["best"], ck["hist"]
    print(f"\nRESUMED from epoch {ck['epoch']} (best IoU {best:.4f})")
else:
    print("\nstarting fresh")

def run(dl, train):
    model.train(train); tp = fp = fn = tot = nb = 0.0
    with torch.enable_grad() if train else torch.no_grad():
        for img, lab in dl:
            img, lab = img.to(DEV, non_blocking=True), lab.to(DEV, non_blocking=True)
            with torch.amp.autocast("cuda", enabled=(CFG.amp and DEV == "cuda")):
                lg = model(img)
            loss = criterion(lg.float(), lab)
            if train:
                opt.zero_grad(set_to_none=True)
                scaler.scale(loss).backward()
                scaler.unscale_(opt)                 # MUST precede clipping
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                scaler.step(opt); scaler.update()
            a, b, c = counts(lg.float(), lab); tp += a; fp += b; fn += c
            tot += loss.item(); nb += 1
    e = 1e-9                                  # global TP/FP/FN, not per-image mean
    return tot/max(nb,1), tp/(tp+fp+fn+e), tp/(tp+fp+e), tp/(tp+fn+e)

print(f"\ntraining {len(files['train'])} patches, "
      f"{len(train_dl)} steps/epoch\n")
t0 = time.time()
for ep in range(ep0, CFG.epochs + 1):
    trl, tri, _, _  = run(train_dl, True)
    vl,  vi, vp, vr = run(val_dl, False)
    sched.step()
    hist.append(dict(epoch=ep, train_loss=trl, train_iou=tri, val_loss=vl,
                     val_iou=vi, val_prec=vp, val_rec=vr))
    print(f"ep {ep:3d} | train {trl:.4f} IoU {tri:.4f} | val {vl:.4f} "
          f"IoU {vi:.4f} P {vp:.3f} R {vr:.3f} | {(time.time()-t0)/60:.1f}m", flush=True)
    ck = dict(model=model.state_dict(), opt=opt.state_dict(), sched=sched.state_dict(),
              scaler=scaler.state_dict(), epoch=ep, best=best, hist=hist)
    torch.save(ck, LAST)
    if vi > best:
        best = vi; ck["best"] = best; torch.save(ck, BEST)
        print(f"    new best {best:.4f}")
    (OUT/"history.json").write_text(json.dumps(hist, indent=2))
    if (time.time()-t0)/3600 > CFG.max_hours:
        print(f"\nstopping at {CFG.max_hours}h - re-commit to resume from epoch {ep+1}")
        break

print(f"\ndone. best val IoU {best:.4f}  ->  {BEST}")

# ================= LOGIT DUMP: VAL (fit) + TEST (evaluate) =================
# Both splits are required. Temperature is FIT on val (scene3) and EVALUATED
# on test (scene4). Dumping only test would force fitting and reporting on the
# same data. Aerosol and haze cue travel with the logits so the entire
# calibration stage can run offline without another GPU session.
@torch.no_grad()
def dump(split):
    dl = DataLoader(mk(split, False, aux=True), batch_size=CFG.batch_size, **dl_kw)
    L, Y, A, C = [], [], [], []; tp = fp = fn = 0.0
    for img, lab, aer, cue in dl:
        img = img.to(DEV, non_blocking=True)
        with torch.amp.autocast("cuda", enabled=(CFG.amp and DEV == "cuda")):
            lg = model(img)
        lg = lg.float().cpu()
        a, b, c = counts(lg, lab); tp += a; fp += b; fn += c
        L.append(lg.numpy().astype(np.float16))       # fp16 halves the file
        Y.append(lab.numpy().astype(np.uint8))
        A.append(aer.numpy().astype(np.float16))
        C.append(cue.numpy().astype(np.float16))
    e = 1e-9
    iou, prec, rec = tp/(tp+fp+fn+e), tp/(tp+fp+e), tp/(tp+fn+e)
    L, Y, A, C = (np.concatenate(x) for x in (L, Y, A, C))
    path = OUT/f"{split}_logits.npz"
    np.savez_compressed(path, logits=L, labels=Y, aerosol=A, haze_cue=C,
                        epoch=ck["epoch"], val_iou=ck["best"],
                        band_idx=np.array(CFG.band_idx), scale=SCALE)
    print(f"  {split:5s} IoU {iou:.4f}  P {prec:.3f}  R {rec:.3f}"
          f"  -> {path.name}  ({L.nbytes/1e6:.0f} MB raw)")
    return iou

if BEST.exists():
    print("\ndumping logits for the calibration stage ...")
    ck = torch.load(BEST, map_location=DEV, weights_only=False)
    model.load_state_dict(ck["model"]); model.eval()
    for split in ("val", "test"):
        if files[split]: dump(split)
    print("\n  -> download BOTH .npz files; all calibration runs on them offline")
    print("  -> fit temperature on val_logits.npz, report on test_logits.npz")
