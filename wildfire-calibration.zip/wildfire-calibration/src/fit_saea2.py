r"""
SAEA v2: budget-constrained spatial abstention.

WHAT WENT WRONG IN v1

tau fitted to 30.0010 -- exactly its ceiling. With tau that large E/tau is
nearly constant across pixels, so the abstention term became a near-uniform mass
added everywhere. Selectivity was 1.36:1 (0.1325 abstention on missed fire vs
0.0975 on correct pixels) and ECE(fire) got WORSE by +0.12.

That was not a coding bug. It was the optimiser answering the objective it was
given. The spatial gate reaches only ~25% of missed fire, so under a loss
weighting misses 5x, blanket abstention captures ALL misses including the 75%
the gate cannot see, while selective abstention captures a quarter. Flat wins
the weighted cross-entropy.

The real defect is a MISMATCH: the fit optimises cross-entropy, which rewards
blanket abstention, while the evaluation is ECE, which punishes it. The method
was being judged by a different standard than it was trained on.

THE FIX: CONSTRAIN THE BUDGET

    L = CE_3class + mu * (mean(p_empty) - budget)^2

Now the optimiser cannot buy coverage by inflating abstention everywhere -- the
total mass is pinned. It must decide WHERE to spend a fixed allowance, which is
exactly the selectivity question. Sweeping the budget traces the frontier
directly, and each point is an operating choice a reader can pick from rather
than a single number they must take on faith.

ALSO SIMPLIFIED

The aerosol sigmoid is gone by default. Aerosol is km-scale and therefore flat
within a 5 km patch, so it cannot reorder pixels inside one -- measured overlap
between correct background and missed fire was 99.74%, the worst of any signal.
It can only scale whole scenes, which the budget constraint already handles.
Dropping it takes the parameter count from six to three (C, lambda, tau) and
removes three ways for the fit to find a degenerate optimum.

    E_i = z_0,i - C + lambda * S_i(W)

tau stays bounded to [0.3, 3.0] so the abstention term must track E.

ACCURACY IS PRESERVED: the abstention term is identical in both class
denominators, so argmax over {fire, background} cannot move. Asserted.

Usage:
  python3 fit_saea2.py --budget 0.02 val_logits.npz test_logits.npz haze_0p20_logits.npz
  python3 fit_saea2.py --budget 0.05 --w 201 val_logits.npz test_logits.npz ...
"""

import sys, argparse, time
import numpy as np

TAU_MIN, TAU_MAX = 0.3, 3.0
N_FIT = 48
ITERS = 300


def load(path, idx=None):
    z = np.load(path)
    lg, lb = z["logits"], z["labels"]
    if idx is not None:
        lg, lb = lg[idx], lb[idx]
    lg = lg.astype(np.float32)
    if lb.ndim == 4:
        lb = lb[:, 0]
    beta = float(z["beta0"]) if "beta0" in z.files else float("nan")
    return lg, lb.astype(np.int64), beta


def box_mean(x, k):
    p = k // 2
    xp = np.pad(x, ((0, 0), (p, p), (p, p)), mode="edge")
    c = np.pad(xp.cumsum(1).cumsum(2), ((0, 0), (1, 0), (1, 0)))
    H, W = x.shape[1], x.shape[2]
    return (c[:, k:k+H, k:k+W] - c[:, 0:H, k:k+W]
            - c[:, k:k+H, 0:W] + c[:, 0:H, 0:W]) / (k * k)


def prepare(path, W, idx=None):
    lg, lb, beta = load(path, idx)
    pred = lg.argmax(1)
    return dict(z0=lg[:, 0], z1=lg[:, 1], lb=lb, pred=pred, beta=beta,
                S=box_mean((pred == 1).astype(np.float32), W),
                T=np.where(pred == lb, lb, 2))


def unpack(th):
    C, log_lam, log_tau = th
    sp = lambda v: np.log1p(np.exp(np.clip(v, -30, 30)))
    tau = TAU_MIN + (TAU_MAX - TAU_MIN) / (1 + np.exp(-np.clip(log_tau, -30, 30)))
    return C, sp(log_lam), tau


def probs(d, th):
    C, lam, tau = unpack(th)
    E = d["z0"] - C + lam * d["S"]
    m = np.maximum(np.maximum(d["z0"], d["z1"]), E / tau)
    e0 = np.exp(d["z0"] - m); e1 = np.exp(d["z1"] - m); ea = np.exp(E / tau - m)
    Z = e0 + e1 + ea
    return e1 / Z, e0 / Z, ea / Z


def loss(d, th, cost, budget, mu=50.0):
    pf, pb, pe = probs(d, th)
    T, lb = d["T"], d["lb"]
    p_t = np.where(T == 1, pf, np.where(T == 0, pb, pe))
    w = np.where((T == 2) & (lb == 1), cost, 1.0)
    ce = float(-(w * np.log(p_t + 1e-9)).sum() / w.sum())
    # budget penalty: the optimiser cannot inflate abstention everywhere, so it
    # must place a FIXED allowance where it does the most good
    return ce + mu * (float(pe.mean()) - budget) ** 2


def fit(d, cost, budget, iters=ITERS):
    th = np.array([4.0, 0.0, 0.0])
    best = loss(d, th, cost, budget)
    step = np.array([1.0, 0.5, 0.5])
    for it in range(iters):
        moved = False
        for k in range(3):
            for s in (+1, -1):
                c = th.copy(); c[k] += s * step[k]
                v = loss(d, c, cost, budget)
                if v < best - 1e-10:
                    best, th, moved = v, c, True
        if not moved:
            step *= 0.5
            if step.max() < 1e-5:
                break
        if (it + 1) % 100 == 0:
            print(f"    iter {it+1:>4}  loss {best:.6f}", flush=True)
    return th, best


def ece(conf, correct, n_bins=20):
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    tot = 0.0
    for i in range(n_bins):
        s = (conf > edges[i]) & (conf <= edges[i + 1])
        k = int(s.sum())
        if k:
            tot += (k / conf.size) * abs(correct[s].mean() - conf[s].mean())
    return float(tot)


def evaluate(d, th):
    pf, pb, pe = probs(d, th)
    # NOT renormalised: p_f/(p_f+p_b) cancels the abstention term exactly and
    # would make every metric identical to the uncalibrated baseline
    conf = np.maximum(pf, pb)
    correct = (d["pred"] == d["lb"]).astype(np.float32)
    fire, bg = d["lb"] == 1, d["lb"] == 0
    miss = fire & (d["pred"] == 0)
    ok = correct.astype(bool)
    return dict(ece=ece(conf.ravel(), correct.ravel()),
                ece_fire=ece(conf[fire], correct[fire]),
                ece_bg=ece(conf[bg], correct[bg]),
                mass=float(pe.mean()),
                on_miss=float(pe[miss].mean()) if miss.any() else float("nan"),
                on_ok=float(pe[ok].mean()) if ok.any() else float("nan"))


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--w", type=int, default=201)
    ap.add_argument("--cost", type=float, default=5.0)
    ap.add_argument("--budget", type=float, default=0.02)
    ap.add_argument("files", nargs="*")
    a = ap.parse_args()
    if len(a.files) < 2:
        print(__doc__); sys.exit(1)

    print(f"W={a.w} ({a.w*10} m)  cost={a.cost}  abstention budget={a.budget:.1%}")
    rng = np.random.default_rng(0)
    n = int(np.load(a.files[0])["logits"].shape[0])
    idx = np.sort(rng.choice(n, min(N_FIT, n), replace=False))
    print(f"fitting on {len(idx)} of {n} CLEAR validation patches\n")

    dv = prepare(a.files[0], a.w, idx)
    th, best = fit(dv, a.cost, a.budget)
    C, lam, tau = unpack(th)
    print(f"\n  fitted: C={C:.4f}  lambda={lam:.4f}  tau={tau:.4f}  loss={best:.6f}")
    if lam < 1e-3:
        print("  WARNING gate collapsed: no placement of the budget beat none.")
    if tau > TAU_MAX - 1e-2:
        print("  NOTE tau at ceiling -- abstention flattening again.")

    hdr = (f"\n{'file':<24}{'beta0':>7}{'ECE(fire)':>11}{'delta':>9}"
           f"{'ECE(bg)':>10}{'delta':>9}{'mass':>8}{'on miss':>9}"
           f"{'on ok':>8}{'ratio':>8}")
    print(hdr); print("-" * (len(hdr) - 1))
    null = np.array([1e6, -30.0, 0.0])            # C huge -> no abstention
    for p in a.files[1:]:
        d = prepare(p, a.w)
        b = evaluate(d, null)
        r = evaluate(d, th)
        ratio = r["on_miss"] / max(r["on_ok"], 1e-9)
        print(f"{p.split('/')[-1][:23]:<24}{d['beta']:>7.2f}"
              f"{r['ece_fire']:>11.5f}{r['ece_fire']-b['ece_fire']:>+9.5f}"
              f"{r['ece_bg']:>10.5f}{r['ece_bg']-b['ece_bg']:>+9.5f}"
              f"{r['mass']:>8.4f}{r['on_miss']:>9.4f}{r['on_ok']:>8.4f}"
              f"{ratio:>8.2f}")
        assert np.array_equal(d["pred"],
                              np.stack([d["z0"], d["z1"]]).argmax(0)), \
            "argmax changed -- accuracy NOT preserved"

    print("\nHOW TO READ THIS")
    print("  'ratio' is abstention on missed fire divided by abstention on")
    print("  correct pixels. v1 got 1.36 -- near-indiscriminate. Above ~2 means")
    print("  the budget is genuinely being placed on failures.")
    print("  ECE(fire) delta NEGATIVE is the win, ECE(bg) delta POSITIVE is the")
    print("  cost. Report both.")
    print("  Sweep --budget 0.01 0.02 0.05 0.10 to trace the frontier; each")
    print("  point is an operating choice, not a single number to defend.")
    print("  Accuracy is identical in every row by construction, and asserted.")


if __name__ == "__main__":
    t = time.time(); main(); print(f"\ndone in {time.time()-t:.0f}s")
