r"""
EVALUATE THE GATED NULL-TERM READOUT on model B.

    p(bg)   = e^z0  / (e^z0 + e^z1 + e^eta)
    p(fire) = e^z1  / (e^z0 + e^z1 + e^eta)
    p(abst) = e^eta / (e^z0 + e^z1 + e^eta)
    eta     = c + k * sigmoid(gamma * (tau - s)),   s = (z0 + z1) / 2

Compared on MODEL B's OWN LOGITS against plain softmax (identity) and
temperature scaling. Identical logits throughout, so any difference is the
readout alone.

THE GATED READOUT FITS NOTHING POST-HOC. c, k, gamma, tau were learned during
training. So unlike temperature scaling it touches no evaluation data at all --
only temperature needs the fit half of the split.

DESIGN DECISIONS, each of which would silently corrupt the result if wrong

1. CONFIDENCE IS NOT RENORMALISED. The confidence attached to a prediction is
   p(predicted class) from the THREE-class distribution. Renormalising over the
   two real classes gives p_f/(p_f+p_b) = e^z1/(e^z0+e^z1) -- eta cancels
   EXACTLY and the readout becomes identical to identity on every metric. That
   bug was found once already, in SAEA. Checked below: with eta -> -inf the
   readout must reduce to identity, and with eta finite it must differ.

2. PROBABILITIES IN LOG SPACE. With both logits strongly negative and eta
   large, e^(z - max) underflows to 0 for both classes and they tie. Measured
   earlier: z0=-87.8, z1=-75.3, eta=30 gave p_bg = p_fire = 0.

3. PROPER SCORES PENALISE ABSTENTION BY CONSTRUCTION. NLL and Brier score the
   probability on the TRUE label; "abstain" is never a true label, so any mass
   on it worsens both -- even when it lands correctly on errors. They are
   reported honestly, but they are not the right test of an abstention
   mechanism. The standard one is the RISK-COVERAGE curve: rank pixels by
   confidence, drop the least confident, and measure error on what remains.
   AURC (area under that curve) is lower-is-better and directly asks whether
   low confidence lands on errors.

4. ACCURACY IS ASSERTED IDENTICAL. The null term appears identically in both
   class denominators, so argmax cannot move.

5. eta IS VERIFIED. The saved null_logit is recomputed from the logits and the
   saved gate parameters. A mismatch would mean the dump and the readout
   disagree about what the gate is.

KNOWN LIMITATION, AFFECTING BOTH MODELS EQUALLY
Both best.pt checkpoints were selected by validation IoU on scene 3, and scene
3 is the evaluation set here. Absolute numbers are therefore optimistic. The
readout-vs-identity comparison is unaffected: both use identical logits, so the
selection bias is shared. tau's placement also used unlabelled scene-3 logits
during training -- no labels, so not label leakage, but worth stating.

Usage:
  python3 eval_readout.py --boot 1000 gated_scene3_haze_0p00_logits.npz \
      gated_scene3_haze_0p20_logits.npz gated_scene3_haze_0p50_logits.npz
"""

import sys, argparse
import numpy as np

# np.trapz was removed in NumPy 2.0 in favour of np.trapezoid; support both so
# this runs regardless of which version the local venv has
_trapz = getattr(np, "trapezoid", None) or getattr(np, "trapz")

N_BINS_ECE = 20
N_BINS_RC = 2000           # risk-coverage histogram resolution
FIT_PIX = 4_000_000


# ------------------------------------------------------------------ loading
def load(path, idx):
    z = np.load(path)
    need = ("logits", "labels", "null_logit", "gate_c", "gate_k",
            "gate_gamma", "gate_tau")
    miss = [k for k in need if k not in z.files]
    assert not miss, (
        f"{path} lacks {miss}. This script needs MODEL B's gated dumps from "
        "dump_gated.py, which save null_logit and the gate parameters. "
        "Model A's files do not have them.")
    lg = z["logits"][idx].astype(np.float32)
    lb = z["labels"][idx]
    if lb.ndim == 4:
        lb = lb[:, 0]
    return dict(z0=lg[:, 0], z1=lg[:, 1], eta=z["null_logit"][idx].astype(np.float32),
                y=lb.astype(np.int8), c=float(z["gate_c"]), k=float(z["gate_k"]),
                gamma=float(z["gate_gamma"]), tau=float(z["gate_tau"]),
                beta=float(z["beta0"]) if "beta0" in z.files else float("nan"))


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


def verify_eta(d):
    """Recompute eta from the logits and gate parameters; must match the dump."""
    s = 0.5 * (d["z0"] + d["z1"])
    eta = d["c"] + d["k"] * sigmoid(d["gamma"] * (d["tau"] - s))
    err = float(np.abs(eta - d["eta"]).max())
    # fp16 storage limits agreement to roughly 1e-2 at |eta| ~ 5
    assert err < 0.05, (f"saved null_logit disagrees with the gate formula "
                        f"(max error {err:.4f}) -- dump and readout are inconsistent")
    return err


# ------------------------------------------------------------------ readouts
def logsumexp3(a, b, c):
    m = np.maximum(np.maximum(a, b), c)
    return m + np.log(np.exp(a - m) + np.exp(b - m) + np.exp(c - m))


def gated(d):
    """Three-class distribution, in LOG space so nothing underflows to a tie."""
    lse = logsumexp3(d["z0"], d["z1"], d["eta"])
    return (np.exp(d["z0"] - lse), np.exp(d["z1"] - lse), np.exp(d["eta"] - lse))


def two_class(gap):
    p1 = sigmoid(gap)
    return 1.0 - p1, p1, np.zeros_like(p1)


# ------------------------------------------------------------------ metrics
def per_pixel(pb, pf, pn, y):
    """Prediction, confidence and correctness.

    pred from the class probabilities, which is argmax over (z0, z1) because
    the null term is shared by both denominators. conf is p(pred) from the
    THREE-class distribution -- deliberately NOT renormalised.
    """
    pred = (pf > pb).astype(np.int8)
    conf = np.where(pred == 1, pf, pb)
    corr = (pred == y).astype(np.float32)
    return pred, conf, corr


def ece(conf, corr):
    e = np.linspace(0.0, 1.0, N_BINS_ECE + 1); n = conf.size; tot = 0.0
    if n == 0:
        return float("nan")
    for i in range(N_BINS_ECE):
        s = (conf > e[i]) & (conf <= e[i+1]); k = int(s.sum())
        if k:
            tot += (k/n) * abs(corr[s].mean() - conf[s].mean())
    return float(tot)


def aurc(conf, corr):
    """Area under the risk-coverage curve, via a fine confidence histogram.

    Pixels are admitted most-confident first. At each coverage level the risk
    is the error rate among admitted pixels. Lower AURC means low confidence
    is landing on errors -- exactly what an abstention mechanism should do.
    """
    edges = np.linspace(0.0, 1.0, N_BINS_RC + 1)
    b = np.clip(np.searchsorted(edges, conf, side="right") - 1, 0, N_BINS_RC - 1)
    n = np.bincount(b, minlength=N_BINS_RC)[::-1].astype(np.float64)
    err = np.bincount(b, weights=1.0 - corr, minlength=N_BINS_RC)[::-1]
    cn, ce = np.cumsum(n), np.cumsum(err)
    keep = cn > 0
    risk = ce[keep] / cn[keep]
    cov = cn[keep] / cn[-1]
    return float(_trapz(risk, cov)) if risk.size > 1 else float("nan")


def metrics(pb, pf, pn, y):
    pred, conf, corr = per_pixel(pb, pf, pn, y)
    f, b = y == 1, y == 0
    pt = np.where(y == 1, pf, pb)
    # three-class Brier: the target for "abstain" is always 0
    brier = (pb - (y == 0))**2 + (pf - (y == 1))**2 + pn**2
    tp = float(((pred == 1) & f).sum()); fp = float(((pred == 1) & b).sum())
    fn = float(((pred == 0) & f).sum())
    wrong = corr == 0
    return dict(ece=ece(conf.ravel(), corr.ravel()),
                ece_fire=ece(conf[f], corr[f]), ece_bg=ece(conf[b], corr[b]),
                brier=float(brier.mean()),
                nll=float(-np.log(np.clip(pt, 1e-9, None)).mean()),
                aurc=aurc(conf.ravel(), corr.ravel()),
                iou=tp / (tp + fp + fn + 1e-9),
                conf_fire=float(conf[f].mean()), acc_fire=float(corr[f].mean()),
                pn_all=float(pn.mean()),
                pn_err=float(pn[wrong].mean()) if wrong.any() else float("nan"))


# ----------------------------------------------------------------- fitting T
def fit_T(gap, y):
    lo, hi = -3.0, 3.0; gr = (np.sqrt(5) - 1) / 2
    f = lambda lt: float(-(y * np.log(np.clip(sigmoid(gap/np.exp(lt)), 1e-9, 1))
                           + (1-y) * np.log(np.clip(1-sigmoid(gap/np.exp(lt)), 1e-9, 1))).mean())
    a, b = lo, hi; c, d = b - gr*(b-a), a + gr*(b-a)
    for _ in range(60):
        if f(c) < f(d): b, d = d, c; c = b - gr*(b-a)
        else:           a, c = c, d; d = a + gr*(b-a)
    return float(np.exp((a+b)/2))


# ---------------------------------------------------------------- bootstrap
def patch_hists(pb, pf, pn, y):
    """Per-patch sufficient statistics, so the bootstrap is fast and exact
    for ECE(fire) and near-exact for AURC."""
    P = y.shape[0]
    e = np.linspace(0.0, 1.0, N_BINS_ECE + 1)
    er = np.linspace(0.0, 1.0, N_BINS_RC + 1)
    H = np.zeros((P, 3, N_BINS_ECE)); R = np.zeros((P, 2, N_BINS_RC))
    for i in range(P):
        pred, conf, corr = per_pixel(pb[i], pf[i], pn[i], y[i])
        f = y[i] == 1
        cb = np.clip(np.searchsorted(e, conf[f], side="right") - 1, 0, N_BINS_ECE-1)
        H[i, 0] = np.bincount(cb, minlength=N_BINS_ECE)
        H[i, 1] = np.bincount(cb, weights=conf[f], minlength=N_BINS_ECE)
        H[i, 2] = np.bincount(cb, weights=corr[f], minlength=N_BINS_ECE)
        rb = np.clip(np.searchsorted(er, conf.ravel(), side="right") - 1, 0, N_BINS_RC-1)
        R[i, 0] = np.bincount(rb, minlength=N_BINS_RC)
        R[i, 1] = np.bincount(rb, weights=1.0 - corr.ravel(), minlength=N_BINS_RC)
    return H, R


def ece_from_hist(H):
    cnt, cs, rs = H[0], H[1], H[2]; n = cnt.sum()
    if n == 0: return float("nan")
    m = cnt > 0
    return float(((cnt[m]/n) * np.abs(rs[m]/cnt[m] - cs[m]/cnt[m])).sum())


def aurc_from_hist(R):
    n, err = R[0][::-1], R[1][::-1]
    cn, ce = np.cumsum(n), np.cumsum(err); keep = cn > 0
    if keep.sum() < 2: return float("nan")
    return float(_trapz(ce[keep]/cn[keep], cn[keep]/cn[-1]))


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("files", nargs="*")
    a = ap.parse_args()
    if len(a.files) < 2:
        print(__doc__); sys.exit(1)

    n = int(np.load(a.files[0])["logits"].shape[0])
    # IDENTICAL split to calibrate_full.py --split and paired_compare.py
    perm = np.random.default_rng(0).permutation(n)
    fit_idx, ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])

    df = load(a.files[0], fit_idx)
    g = (df["z1"] - df["z0"]).ravel(); yy = df["y"].ravel().astype(np.float64)
    if g.size > FIT_PIX:
        s = np.random.default_rng(1).choice(g.size, FIT_PIX, replace=False)
        g, yy = g[s], yy[s]
    T = fit_T(g, yy)
    print(f"temperature fitted on {len(fit_idx)} held-in patches: T = {T:.4f}")
    print(f"gate (learned in training): c={df['c']:.3f} k={df['k']:.3f} "
          f"gamma={df['gamma']:.3f} tau={df['tau']:.3f}")
    print(f"eta verified against the gate formula: max error {verify_eta(df):.2e}")

    for path in a.files[1:]:
        d = load(path, ev_idx)
        verify_eta(d)
        gap = d["z1"] - d["z0"]; y = d["y"]
        R = {"identity": two_class(gap), "temperature": two_class(gap / T),
             "gated": gated(d)}

        # --- the two checks that would expose a readout bug ---
        pi = per_pixel(*R["identity"], y)[0]; pg = per_pixel(*R["gated"], y)[0]
        assert np.array_equal(pi, pg), "gated readout changed argmax -- accuracy NOT preserved"
        dd = dict(d); dd["eta"] = np.full_like(d["eta"], -1e4)
        ci = per_pixel(*R["identity"], y)[1]; cz = per_pixel(*gated(dd), y)[1]
        assert np.allclose(ci, cz, atol=1e-5), "gated with eta->-inf must reduce to identity"
        cg = per_pixel(*R["gated"], y)[1]
        assert not np.allclose(ci, cg), ("gated confidence equals identity -- eta "
                                        "is being cancelled (renormalisation bug)")

        print(f"\n=== {path.split('/')[-1]}   beta0 = {d['beta']}   "
              f"({len(ev_idx)} held-out patches)")
        print("  checks: argmax preserved; reduces to identity as eta->-inf; "
              "differs from identity at learned eta")
        hdr = (f"  {'readout':<12}{'ECE':>9}{'ECE(fire)':>11}{'ECE(bg)':>10}"
               f"{'Brier':>9}{'NLL':>9}{'AURC':>9}{'IoU':>8}")
        print(hdr); print("  " + "-"*(len(hdr)-2))
        M = {k: metrics(*v, y) for k, v in R.items()}
        for k, m in M.items():
            print(f"  {k:<12}{m['ece']:>9.5f}{m['ece_fire']:>11.5f}{m['ece_bg']:>10.5f}"
                  f"{m['brier']:>9.5f}{m['nll']:>9.5f}{m['aurc']:>9.5f}{m['iou']:>8.4f}")
        mg = M["gated"]
        print(f"\n  gated: p(abstain) all {mg['pn_all']:.4f}  on errors {mg['pn_err']:.4f}"
              f"  selectivity {mg['pn_err']/max(mg['pn_all'],1e-9):.2f}")
        print(f"  on fire pixels:  identity conf {M['identity']['conf_fire']:.4f}"
              f" acc {M['identity']['acc_fire']:.4f}  |  gated conf "
              f"{mg['conf_fire']:.4f} acc {mg['acc_fire']:.4f}")

        # --- paired bootstrap: gated vs identity and vs temperature ---
        Hs = {k: patch_hists(*v, y) for k, v in R.items()}
        rng = np.random.default_rng(2)
        P = y.shape[0]
        out = {("temperature", "ece"): [], ("gated", "ece"): [],
               ("temperature", "aurc"): [], ("gated", "aurc"): []}
        for _ in range(a.boot):
            pk = rng.integers(0, P, P)
            base_e = ece_from_hist(Hs["identity"][0][pk].sum(0))
            base_a = aurc_from_hist(Hs["identity"][1][pk].sum(0))
            for k in ("temperature", "gated"):
                out[(k, "ece")].append(ece_from_hist(Hs[k][0][pk].sum(0)) - base_e)
                out[(k, "aurc")].append(aurc_from_hist(Hs[k][1][pk].sum(0)) - base_a)
        print(f"\n  paired bootstrap vs identity, {a.boot} replicates on identical patches:")
        for k in ("temperature", "gated"):
            for m in ("ece", "aurc"):
                v = np.array(out[(k, m)]); v = v[np.isfinite(v)]
                lo, hi = np.percentile(v, [2.5, 97.5])
                tag = "ECE(fire)" if m == "ece" else "AURC"
                sig = "  * excludes zero" if (hi < 0 or lo > 0) else ""
                print(f"    {k:<12}{tag:<10} diff [{lo:+.5f}, {hi:+.5f}]  "
                      f"better in {(v<0).mean():.1%}{sig}")

    print("\nHOW TO READ THIS")
    print("  ECE(fire) and AURC are the tests of the readout. Negative paired")
    print("  differences mean the gated readout beats plain softmax on the SAME")
    print("  logits, so the gain is attributable to reading the logit sum.")
    print("  Brier and NLL are expected to WORSEN: they score probability on the")
    print("  true label, and abstention is never a true label. That is a property")
    print("  of proper scoring rules, not a failure of the readout -- but report")
    print("  it rather than omit it.")
    print("  IoU is identical across all three by construction.")


if __name__ == "__main__":
    main()
