r"""
AEROSOL TESTS -- two questions, answered separately.

PART A: IS THE AEROSOL INDEX A DISGUISED LABEL?
Fires produce smoke, so aerosol may be high wherever fire is. If so, its
apparent ability to flag MISSED fire could just mean "this patch has fire".
  A1  Does aerosol predict where fire is?
      patch-level AUROC (patch mean aerosol -> patch contains fire), pixel-level
      AUROC (aerosol -> pixel is fire), and the share of aerosol variation that
      lies BETWEEN patches rather than within them.
  A2  Its ability to separate missed fire from correct background (among
      pixels called background), measured over ALL patches, then over ONLY
      patches that contain fire. Missed fire can only occur in fire patches,
      so the all-patch number mixes "is this a fire patch?" with "is this
      pixel an error?". Restricting to fire patches removes the first part.
      All-patch well above 0.5, fire-patch near 0.5  ->  label proxy.
  A3  The same, using only each pixel's deviation from its patch mean --
      what aerosol says about individual pixels.
  Every AUROC gets a one-sided permutation p-value: aerosol values are
  shuffled between patches (within fire patches for A2's restricted test)
  2,000 times, and p = share of shuffles at least as large as observed.
  AUROC here is raw, not "usable": above 0.5 means HIGHER aerosol marks the
  target, as the smoke hypothesis predicts.

PART B: DOES AN AEROSOL-AWARE GATE HELP ON REAL SMOKE?
  height gate      eta = c + k*sigmoid(gamma*(tau - h))
  aerosol gate     eta = c + k*sigmoid(gamma*(tau - h + delta*A~))
  A~ = standardised aerosol (held-in median and IQR, clipped to +-5).
  Positive delta: smokier -> the gate opens at taller logits -> more
  abstention. delta = 0 IS the height gate, and the fit starts from the height
  gate's own thresholds with delta = 0, accepting only changes that improve
  its objective on held-in clear scene 3. So the aerosol gate is nested: it
  can only depart from the height gate if aerosol helps where it was fitted.
  Tested on scene 3 at beta0 0-0.5 and on scene 4 natural.
  CAUTION: synthetic haze never changes the aerosol layer, so on scene 3 the
  aerosol term cannot respond to the haze. Scene 4 is the real test.
  And if Part A finds a label proxy, any gain here may come from knowing which
  patches contain fire -- legitimate at deployment, since Sentinel-5P is
  available then, but it must be described that way.

Usage (same model arguments as final_tests.py):
  python3 aerosol_tests.py --boot 1000 \
    --model A_s0 ""     test_logits.npz \
    --model B_s0 gated_ gated_scene4_haze_0p00_logits.npz \
    --model A_s1 A_s1_  A_s1_scene4_haze_0p00_logits.npz \
    --model B_s1 B_s1_  B_s1_scene4_haze_0p00_logits.npz
Writes results/aerosol_proxy.csv, results/aerosol_gate.csv and
results/aerosol_gate_TABLES.csv.
"""

import sys, os, csv, argparse
import numpy as np
from reverse_gate import load, evidence, readout as gate_readout, fit as gate_fit, sigmoid
from final_compare import fixed, FIX_C, FIX_K, FIX_G
from final_tests import chunk_stats, metrics, diff, BETAS, CHUNK, tag, cond_label, OUT, fmt, write_tables

DELTAS = (-1.0, -0.5, 0.0, 0.5, 1.0, 2.0)
NPERM = 2000


# ------------------------------------------------------------- Part A tools
def wauroc(score, wpos, wneg):
    """AUROC with per-item weights: P(score of a positive > score of a negative),
    ties counted half. Items here are patches (weights = pixel counts)."""
    u, inv = np.unique(score, return_inverse=True)
    P = np.bincount(inv, wpos, len(u)); N = np.bincount(inv, wneg, len(u))
    below = np.cumsum(N) - N
    den = P.sum() * N.sum()
    return float((P * (below + 0.5 * N)).sum() / den) if den > 0 else float("nan")


def perm_p(score, wpos, wneg, obs, mask=None, seed=11):
    """One-sided permutation p-value: shuffle scores between patches (only
    among `mask` patches if given), keeping each patch's pixel counts."""
    rng = np.random.default_rng(seed); s = score.copy(); idx = np.flatnonzero(mask) if mask is not None else np.arange(len(s))
    ge = 0
    for _ in range(NPERM):
        s[idx] = score[idx][rng.permutation(len(idx))]
        if wauroc(s, wpos, wneg) >= obs: ge += 1
    return (ge + 1) / (NPERM + 1)


def pixel_auroc(score, target, n=2_000_000, seed=0):
    s = score.astype(np.float64); t = target.astype(np.float64)
    if s.size > n:
        i = np.random.default_rng(seed).choice(s.size, n, replace=False); s, t = s[i], t[i]
    u, inv = np.unique(s, return_inverse=True)
    return wauroc(u[np.arange(len(u))], np.bincount(inv, t, len(u)), np.bincount(inv, 1 - t, len(u)))


def part_a(label, scene, path, idx=None):
    z = np.load(path)
    if "aerosol" not in z.files:
        print(f"  [{label} {scene}] no aerosol layer in {path} -- skipped"); return None
    A = z["aerosol"]; Y = z["labels"]; LG = z["logits"]
    idx = np.arange(LG.shape[0]) if idx is None else idx
    pm, ff, npx = [], [], []
    mis, cbg, var_w = [], [], []
    dev_s, dev_t = [], []
    rng = np.random.default_rng(5)
    for s in range(0, len(idx), CHUNK):
        sel = idx[s:s + CHUNK]
        a = A[sel].astype(np.float32); y = Y[sel]; lg = LG[sel].astype(np.float32)
        if a.ndim == 4: a = a[:, 0]
        if y.ndim == 4: y = y[:, 0]
        yb = y == 1; pred = lg[:, 1] > lg[:, 0]
        m = a.reshape(len(sel), -1).mean(1)
        pm.append(m); ff.append(yb.reshape(len(sel), -1).sum(1)); npx.append(np.full(len(sel), yb[0].size))
        mis.append((~pred & yb).reshape(len(sel), -1).sum(1)); cbg.append((~pred & ~yb).reshape(len(sel), -1).sum(1))
        var_w.append(((a - m[:, None, None]) ** 2).reshape(len(sel), -1).sum(1))
        pb = ~pred
        d = (a - m[:, None, None])[pb]; t = (~pred & yb)[pb]
        k = rng.choice(d.size, min(d.size, 60_000), replace=False)
        dev_s.append(d.ravel()[k]); dev_t.append(t.ravel()[k])
    pm, ff, npx = np.concatenate(pm), np.concatenate(ff).astype(float), np.concatenate(npx).astype(float)
    mis, cbg = np.concatenate(mis).astype(float), np.concatenate(cbg).astype(float)
    within = np.concatenate(var_w).sum()
    gm = (pm * npx).sum() / npx.sum(); between = (npx * (pm - gm) ** 2).sum()
    has = ff > 0
    out = dict(model=label, scene=scene, patches=len(pm), fire_patches=int(has.sum()),
               mean_aerosol=float(gm), pct_between=float(100 * between / (between + within)))
    out["A1_patch_auroc"] = wauroc(pm, has.astype(float), (~has).astype(float))
    out["A1_patch_p"] = perm_p(pm, has.astype(float), (~has).astype(float), out["A1_patch_auroc"])
    out["A1_pixel_auroc"] = wauroc(pm, ff, npx - ff)
    out["A1_pixel_p"] = perm_p(pm, ff, npx - ff, out["A1_pixel_auroc"])
    out["A2_all_auroc"] = wauroc(pm, mis, cbg)
    out["A2_all_p"] = perm_p(pm, mis, cbg, out["A2_all_auroc"])
    wm, wc = np.where(has, mis, 0), np.where(has, cbg, 0)
    out["A2_firepatch_auroc"] = wauroc(pm, wm, wc)
    out["A2_firepatch_p"] = perm_p(pm, wm, wc, out["A2_firepatch_auroc"], mask=has)
    out["A3_within_auroc"] = pixel_auroc(np.concatenate(dev_s), np.concatenate(dev_t))
    return out


# ------------------------------------------------------------- Part B tools
class AerosolModel:
    def __init__(self, label, prefix, s4):
        self.label, self.s4 = label, s4
        self.s3 = {b: f"{prefix}scene3_haze_{tag(b)}_logits.npz" for b in BETAS}
        n = int(np.load(self.s3[0.0])["logits"].shape[0])
        perm = np.random.default_rng(0).permutation(n)          # SAME split as every run
        self.fit_idx, self.ev_idx = np.sort(perm[:n // 2]), np.sort(perm[n // 2:])

    def std_aer(self, a):
        return np.clip((a - self.med) / self.iqr, -5, 5)

    def fit(self):
        z = np.load(self.s3[0.0])
        if "aerosol" not in z.files:
            print(f"  [{self.label}] no aerosol in scene 3 -- Part B skipped"); return False
        d = fixed(load(self.s3[0.0], self.fit_idx))
        a = z["aerosol"][self.fit_idx].astype(np.float32)
        if a.ndim == 4: a = a[:, 0]
        a = a.ravel()
        self.med = float(np.median(a)); q1, q3 = np.percentile(a, [25, 75])
        self.iqr = float(q3 - q1) if q3 > q1 else float(a.std() + 1e-6)
        self.taus, self.gams = gate_fit(d, "height gate")
        rng = np.random.default_rng(0); yb = d["y"] == 1
        fi, bi = np.flatnonzero(yb), np.flatnonzero(~yb)
        i = np.sort(np.concatenate([rng.choice(fi, min(400_000, fi.size), replace=False),
                                    rng.choice(bi, min(1_600_000, bi.size), replace=False)]))
        ds = {k: (v[i] if isinstance(v, np.ndarray) else v) for k, v in d.items()}
        As = self.std_aer(a[i]); h = evidence(ds, "height gate"); y = ds["y"] == 1
        pred = ds["z1"] > ds["z0"]

        def obj(P):
            taus = {c: (None if P[c] is None else P[c][0]) for c in (False, True)}
            x = h.copy()
            for c in (False, True):
                if P[c] is not None: x[pred == c] = h[pred == c] - P[c][1] * As[pred == c]
            conf, corr, _, _ = gate_readout(ds, x, taus, self.gams)
            e = lambda cc, oo: float(np.abs(np.bincount(np.clip((cc * 20).astype(int), 0, 19), oo, 20)
                                            - np.bincount(np.clip((cc * 20).astype(int), 0, 19), cc, 20)).sum() / max(cc.size, 1))
            return e(conf[y], corr[y]) + e(conf[~y], corr[~y])

        grid = {c: [None] + [(t, dl) for t in np.quantile(h[pred == c], np.linspace(0.02, 0.60, 15)) for dl in DELTAS]
                for c in (False, True)}
        P = {c: (None if self.taus[c] is None else (self.taus[c], 0.0)) for c in (False, True)}
        start = obj(P); best = start
        for c in (False, True, False):
            for cand in grid[c]:
                trial = {**P, c: cand}; o = obj(trial)
                if o < best - 1e-9: best, P = o, trial
        self.P = P
        f = lambda p: "OFF" if p is None else f"tau={p[0]:+.3f} delta={p[1]:+.1f}"
        print(f"  [{self.label}] aerosol gate: pred bg {f(P[False])}   pred fire {f(P[True])}   "
              f"held-in objective {start:.4f} -> {best:.4f}", flush=True)
        return True

    def evaluate(self, scene, b, path, boot):
        if not os.path.exists(path): return None
        z = np.load(path)
        if "aerosol" not in z.files:
            print(f"  [{self.label}] {path} has no aerosol -- skipped"); return None
        LG, Y, A = z["logits"], z["labels"], z["aerosol"]
        idx = self.ev_idx if scene == "scene3" else np.arange(LG.shape[0])
        P_ = len(idx); stats = {}
        for s in range(0, P_, CHUNK):
            sel = idx[s:s + CHUNK]; p = len(sel)
            lg = LG[sel].astype(np.float32); y = Y[sel]; a = A[sel].astype(np.float32)
            if y.ndim == 4: y = y[:, 0]
            if a.ndim == 4: a = a[:, 0]
            d = dict(z0=lg[:, 0].ravel(), z1=lg[:, 1].ravel(), y=y.ravel().astype(np.int8), c=FIX_C, k=FIX_K, g=FIX_G)
            yb = d["y"] == 1; pid = np.repeat(np.arange(p), lg.shape[2] * lg.shape[3])
            pf = sigmoid(d["z1"] - d["z0"])
            R = {"softmax": (1 - pf, pf, np.zeros_like(pf), pf > 0.5)}
            h = evidence(d, "height gate")
            for nm, x, taus in [("height gate", h, self.taus), ("aerosol gate", None, None)]:
                if nm == "aerosol gate":
                    pred = d["z1"] > d["z0"]; As = self.std_aer(a.ravel()); x = h.copy()
                    taus = {c: (None if self.P[c] is None else self.P[c][0]) for c in (False, True)}
                    for c in (False, True):
                        if self.P[c] is not None: x[pred == c] = h[pred == c] - self.P[c][1] * As[pred == c]
                cg, _, pn, pr = gate_readout(d, x, taus, self.gams)
                R[nm] = (np.where(pr, 1 - pn - cg, cg), np.where(pr, cg, 1 - pn - cg), pn, pr)
            for nm, (pb, pf_, pn, pr) in R.items():
                stats.setdefault(nm, []).append(chunk_stats(pb, pf_, pn, pr, yb, pid, p))
        stats = {k: np.vstack(v) for k, v in stats.items()}
        rng = np.random.default_rng(3)
        Wt = np.stack([np.bincount(rng.integers(0, P_, P_), minlength=P_) for _ in range(boot)]).astype(np.float64)
        res = {nm: dict(point={k: float(v[0]) for k, v in metrics(M.sum(0)[None]).items()}, boot=metrics(Wt @ M))
               for nm, M in stats.items()}
        print(f"  [{self.label}] scored {cond_label(scene, b)}", flush=True)
        return res


METRICS = [("ECE fire (pred)", "ece_pred_fire"), ("ECE fire (true)", "ece_true_fire"),
           ("ECE bg (true)", "ece_true_bg"), ("ECE", "ece_all"), ("AUROC", "auroc")]


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("--model", action="append", nargs=3, default=[])
    a = ap.parse_args()
    if not a.model:
        print(__doc__); sys.exit(1)
    os.makedirs(OUT, exist_ok=True)

    # ---------------- Part A ----------------
    print("PART A: is the aerosol index a disguised label?", flush=True)
    rowsA = []
    for label, prefix, s4 in a.model:
        s3 = f"{prefix}scene3_haze_0p00_logits.npz"
        n = int(np.load(s3)["logits"].shape[0]); ev = np.sort(np.random.default_rng(0).permutation(n)[n // 2:])
        for scene, path, idx in (("scene3 (held-out half)", s3, ev), ("scene4 natural", s4, None)):
            if os.path.exists(path):
                r = part_a(label, scene, path, idx)
                if r: rowsA.append(r); print(f"  [{label}] {scene} done", flush=True)
    keys = list(rowsA[0].keys()) if rowsA else []
    with open(f"{OUT}/aerosol_proxy.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rowsA)
    print(f"\n  {'model':<6}{'scene':<23}{'%between':>9}{'A1 patch':>14}{'A1 pixel':>14}"
          f"{'A2 all':>14}{'A2 fire-only':>14}{'A3 within':>10}")
    for r in rowsA:
        pv = lambda x: "p<.001" if x < 0.001 else f"p={x:.3f}"
        c = lambda k: f"{r[k + '_auroc']:.3f} {pv(r[k + '_p'])}"
        print(f"  {r['model']:<6}{r['scene']:<23}{r['pct_between']:>8.1f}%{c('A1_patch'):>14}{c('A1_pixel'):>14}"
              f"{c('A2_all'):>14}{c('A2_firepatch'):>14}{r['A3_within_auroc']:>10.3f}")

    # ---------------- Part B ----------------
    print("\nPART B: does an aerosol-aware gate help on real smoke?", flush=True)
    longrows, blocks = [], []
    for label, prefix, s4 in a.model:
        M = AerosolModel(label, prefix, s4)
        if not M.fit(): continue
        conds = [("scene3", b, M.s3[b]) for b in BETAS] + [("scene4", 0.0, s4)]
        res = {}
        for scene, b, path in conds:
            r = M.evaluate(scene, b, path, a.boot)
            if r: res[cond_label(scene, b)] = r
        for c, r in res.items():
            for nm in ("softmax", "height gate", "aerosol gate"):
                pt = r[nm]["point"]
                sel = pt["abst_missed fire"] / pt["abst_correct bg"] if pt["abst_correct bg"] > 0 else float("nan")
                for name, key in METRICS:
                    dg = diff(r, nm, "height gate", key) if nm != "height gate" else None
                    ds_ = diff(r, nm, "softmax", key) if nm != "softmax" else None
                    longrows.append([label, c, nm, name, fmt(pt[key])] +
                                    ([fmt(dg[0]), fmt(dg[1]), fmt(dg[2]), "*" if dg[3] else ""] if dg else ["", "", "", ""]) +
                                    ([fmt(ds_[0]), fmt(ds_[1]), fmt(ds_[2]), "*" if ds_[3] else ""] if ds_ else ["", "", "", ""]) +
                                    [fmt(sel)])
        s4c = cond_label("scene4", 0.0)
        if s4c in res:
            r = res[s4c]
            rows = []
            for nm in ("softmax", "height gate", "aerosol gate"):
                pt = r[nm]["point"]
                sel = pt["abst_missed fire"] / pt["abst_correct bg"] if pt["abst_correct bg"] > 0 else float("nan")
                rows.append([nm] + [fmt(pt[k]) for _, k in METRICS] + [fmt(sel)])
            blocks.append((f"{label} | scene 4 natural smoke", ["readout"] + [n for n, _ in METRICS] + ["selectivity missed/bg"], rows))
            rows = []
            for _, key in METRICS:
                dg = diff(r, "aerosol gate", "height gate", key)
                rows.append([key] + ([fmt(dg[0]), fmt(dg[1]), fmt(dg[2]), "*" if dg[3] else ""] if dg else ["", "", "", ""]))
            blocks.append((f"{label} | aerosol gate MINUS height gate, 95% CI | scene 4 natural",
                           ["metric", "diff", "ci_low", "ci_high", "significant"], rows))
        for name, key in METRICS[:3]:
            rows = [[f"{b:.1f}"] + [fmt(res[cond_label('scene3', b)][nm]["point"][key]) if cond_label('scene3', b) in res else ""
                                    for nm in ("softmax", "height gate", "aerosol gate")] for b in BETAS]
            blocks.append((f"{label} | {name} | scene 3 synthetic haze (aerosol layer unchanged by haze)",
                           ["beta0", "softmax", "height gate", "aerosol gate"], rows))
    with open(f"{OUT}/aerosol_gate.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["model", "condition", "readout", "metric", "value", "diff_vs_height_gate", "ci_low", "ci_high",
                    "significant", "diff_vs_softmax", "ci_low", "ci_high", "significant", "selectivity_missed_over_bg"])
        w.writerows(longrows)
    n = write_tables(f"{OUT}/aerosol_gate_TABLES.csv", blocks)
    print(f"\nWrote {OUT}/aerosol_proxy.csv, aerosol_gate.csv, aerosol_gate_TABLES.csv ({n} tables)")
    print("\nHOW TO READ PART A: label proxy if A1 is high and significant, A2 'all' is")
    print("  clearly above 0.5, but A2 'fire-only' falls to about 0.5 -- aerosol then")
    print("  knows WHICH PATCHES have fire, not which pixels are errors. A3 near 0.5")
    print("  confirms it carries no pixel-level information.")
    print("PART B: read scene 4. delta = 0 in the fitted parameters means aerosol")
    print("  added nothing even where it was fitted.")


if __name__ == "__main__":
    main()
