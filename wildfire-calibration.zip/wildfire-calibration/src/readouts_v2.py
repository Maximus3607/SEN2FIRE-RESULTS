r"""
READOUTS v2 -- the height gate, the evidence null and SAEA, each rebuilt around
the failure we measured in its first version.

All three still sit on top of the FROZEN network: they add an abstention outcome
next to fire and background, so p(fire) / p(bg) = e^(z1 - z0) is untouched and the
prediction (argmax over fire vs background) can NEVER change. Asserted in code.

COMMON NOTATION
  z0, z1   background and fire logits;  y_hat = argmax;  h = max(z0, z1)
  g        = z1 - z0;  p_sm = sigmoid(|g|) = softmax confidence
  eta      the abstention logit;  p(k) = e^z_k / (e^z0 + e^z1 + e^eta)
  conf     = p(y_hat), NOT renormalised -- abstention lowers confidence
  d        HAZE CUE: the 1st percentile of blue (B2, 490 nm) reflectance in each
           128 x 128 block of the hazed input -- the dark-object level
           (Chavez 1988; He et al. 2011). Haze adds A(1 - t) to every pixel, so the
           darkest pixels in a block rise with haze. Computed from the input image
           only: nothing about the haze level is given to the readout.
           d~ = (d - mean) / sd, using the fitting samples.
  S_W      fraction of PREDICTED fire in the W x W window around the pixel
           (SAEA's spatial term, box mean with edge padding, as in fit_saea2.py)

GATE v1 (reference, exactly haze_readouts.py's "gate Brier-fit (mixture)")
  eta = c + k * sigmoid(gamma_yhat * (tau_yhat - h)),   c = -5.658, k = 8.486
  one fixed threshold tau per predicted class (or OFF).

GATE v2 -- threshold that moves with measured haze
  eta = c + k * sigmoid(gamma_yhat * (tau_yhat(d~) - h)),  tau_bg(d~) = tau0 + tau1 * d~
  WHY: v1 has ONE threshold for every haze level. Haze lowers the whole logit
  scale, so a single tau is a compromise -- too strict at light haze (seed 1 was
  slightly worse than softmax at beta0 = 1-2) and too lax at heavy haze. Our
  aerosol analysis showed a km-scale atmospheric signal is flat inside a patch
  (99.7% overlap), so it can never RANK pixels -- but it can set the THRESHOLD,
  which is a per-region decision. v2 uses it there and nowhere else.
  Fits 2 numbers on the background side (tau0, tau1); fire side as v1. tau1 = 0
  recovers v1 exactly, so the fit can refuse the haze cue.

EVIDENCE NULL v2 -- the shape is learned, not assumed
  v1:  eta = h - s (h - t)   =>   p_abst / p(y_hat) = e^(-s (h - t))
       no floor and no ceiling: it overshoots on weak claims (confidence -> 0 on
       pixels that are often right) and still leaks abstention onto strong ones.
       That is why v1 was better on true fire but worse everywhere else.
  v2:  p(y_hat) = min( p_sm , q_{y_hat, k}(h) )
       q = P(correct | h) for that predicted class in haze stratum k (5 strata of
       d~), fitted by weighted isotonic regression -- the best MONOTONE map from
       evidence to confidence. Implemented exactly through the null logit:
           eta = h + ln( 1/q - 1/p_sm )      (no abstention where q >= p_sm)
       which gives p(y_hat) = q exactly. Floors and ceilings come from the data.
  It is also a CEILING: no readout that lowers confidence as a monotone function
  of h within a haze stratum can beat it on the fitting data. If gate v2 (3
  numbers) comes close to EN v2 (~thousands of steps), the gate's shape is not
  what limits it.

SAEA v2 -- Spatial-Aerosol-Energy Abstention rebuilt on gate v2
  eta = c + k * sigmoid( gamma_bg * (tau0 + tau1 * d~ - h) + lambda * S_W )   (predicted bg)
  Energy = h (the height); Aerosol = the haze cue, moved from ranking pixels to
  setting the threshold; Spatial = S_W, now INSIDE the bounded gate.
  WHY: v1 fitted tau = 30.0010 (its ceiling) and spread abstention almost
  uniformly; v2 (budget) pinned the mass but selectivity stayed ~1.35. Two causes,
  both fixed here: (1) the cross-entropy objective rewarded blanket abstention --
  this uses the same Brier objective as the gate, which punishes it; (2) under
  MODIS labels ~75% of missed fire was invisible, so no spatial cue could find it
  -- under agreement labels the misses under haze are real fire next to detected
  fire, which is exactly what S_W measures.
  Fits W in {51, 101, 201}, lambda in {0, 0.5, 1, 2, 4, 8, 16}, and re-fits tau0, tau1.
  lambda = 0 recovers gate v2, so the fit can refuse the spatial term.
  CAUTION: agreement labels IGNORE a 30 m ring around weak signatures -- right
  where S_W is high. The VISIBLE-truth tables score those ring pixels as
  background; trust SAEA v2 only if it also wins there.

ALL v2 READOUTS: fitted on hazed held-in scene 3 (same samples, seeds and haze
mixture as haze_readouts.py, agreement labels), objective = weighted confidence
Brier (as gate v1). c, k and the gamma rule are v1's, unchanged. Scored on
held-out scene 3 and all of scene 4 at alpha 1.3 and 0, under agreement labels
and visible-fire truth (every pixel), with the proper scores and paired-bootstrap
95% CIs for each ablation:
  gate v2 - gate v1     does a haze-aware threshold help?
  SAEA v2 - gate v2     does the spatial term add anything?
  EN v2 - gate v2       how far is the 3-number gate from the best monotone shape?
  each v2 - isotonic    does it beat the strongest standard calibrator?

KAGGLE SETUP -- inputs exactly as every_pixel.py:
  Sen2Fire; the agreement-label notebook's output; both training outputs (ag-seed-1, ag-seed-2).
  Optional: the haze_readouts notebook's output (automatic sanity check of gate v1).
  Accelerator GPU T4.  Save Version -> Save & Run All.  Roughly 1.5-2 hours.
OUTPUT (/kaggle/working/readouts_v2/): report.txt, v2_results.csv, v2_cis.csv, v2_fits.txt
"""

import os, glob, csv, time
from pathlib import Path
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F

ROOT = os.environ.get("V2_ROOT", "/kaggle/input")
OUT = Path(os.environ.get("V2_OUT", "/kaggle/working/readouts_v2"))
FIT_BETAS = [0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0]          # identical to haze_readouts.py
SCORE_BETAS = [float(b) for b in os.environ.get("V2_BETAS", "0,1,2,3,4").split(",")]
ALPHAS = [float(a) for a in os.environ.get("V2_ALPHAS", "1.3,0.0").split(",")]
BOOT = int(os.environ.get("V2_BOOT", 300))
MAXP = int(os.environ.get("V2_MAXP", 0))
DEV = "cuda" if torch.cuda.is_available() else "cpu"
BAND_IDX = [3, 2, 1, 7, 10, 11]
WL6 = np.array([665., 560., 490., 842., 1610., 2190.])
LAMBDA0, A_SAMPLE, IGNORE, NB = 550.0, 120, 255, 20
FIX_C, FIX_K, FIX_G = -5.658, 8.486, 2.751
BG_RATE = 0.004
SEEDGROW_BIT = 4
VERSIONS = ["agreement", "visible"]
HAZE_BAND, HAZE_BLOCK, HAZE_PCT = 2, 128, 1.0              # B2 (490 nm) in the six-band stack
W_GRID = [51, 101, 201]
LAM_GRID = [0.5, 1.0, 2.0, 4.0, 8.0, 16.0]
EN_S_GRID = (0.5, 1.0, 2.0, 3.0, 5.0)
N_STRATA = 5
READOUTS = ["softmax", "isotonic", "gate v1", "EN v1", "gate v2", "EN v2", "SAEA v2"]
ABSTAIN = ["gate v1", "EN v1", "gate v2", "EN v2", "SAEA v2"]          # never move the decision
COMPARE = [("gate v2", "gate v1"), ("SAEA v2", "gate v2"), ("EN v2", "gate v2"), ("EN v2", "EN v1"),
           ("gate v1", "softmax"), ("gate v2", "softmax"), ("SAEA v2", "softmax"), ("EN v2", "softmax"),
           ("gate v2", "isotonic"), ("SAEA v2", "isotonic"), ("EN v2", "isotonic")]
CI_METRICS = ["true-fire ECE", "fire Brier", "fire NLL", "conf Brier", "conf NLL"]
EP_NAME = {"gate v1": "gate Brier-fit (mixture)", "isotonic": "isotonic (mixture)", "softmax": "softmax"}

LOG = []
def say(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); LOG.append(s)


# ------------------------------------------------------------- network
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co * 2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2) - x.size(-2); dx = skip.size(-1) - x.size(-1)
            x = F.pad(x, [dx // 2, dx - dx // 2, dy // 2, dy - dy // 2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b * 2), Down(b * 2, b * 4)
        self.d3, self.d4 = Down(b * 4, b * 8), Down(b * 8, b * 16)
        self.u1, self.u2 = Up(b * 16, b * 8), Up(b * 8, b * 4)
        self.u3, self.u4 = Up(b * 4, b * 2), Up(b * 2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)


# ---------------------------------------------------------------- data
def find(root, scene):
    return [f for f in sorted(glob.glob(str(Path(root) / "**" / "*.npz"), recursive=True))
            if scene in {p.lower() for p in Path(f).parts[:-1]}]


def read_patch(path):
    """-> (six input bands, MODIS label as bool)."""
    with np.load(path, allow_pickle=True) as z:
        ks = list(z.keys())
        ik = next((k for k in ("image", "img", "data", "x") if k in ks), ks[0])
        lk = next((k for k in ("label", "mask", "gt", "y") if k in ks), ks[-1])
        img = np.asarray(z[ik], dtype=np.float32); lab = np.asarray(z[lk])
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2, 0, 1))
    if lab.ndim == 3: lab = lab[0]
    return np.nan_to_num(img[BAND_IDX]), lab > 0


def haze(x, b0, A, alpha):
    if b0 == 0.0: return x
    t = np.exp(-b0 * (WL6 / LAMBDA0) ** (-alpha)).astype(np.float32)[:, None, None]
    return x * t + A[:, None, None] * (1.0 - t)


def load_models():
    out = []
    found = sorted(glob.glob(str(Path(ROOT) / "**" / "best.pt"), recursive=True))
    if not found:
        raise SystemExit("No best.pt anywhere under " + ROOT + " -- the training notebooks are not attached. "
                         "Add Input -> Notebook Output -> add ag-seed-1 and ag-seed-2, then run again.")
    for ck in found:
        d = torch.load(ck, map_location=DEV, weights_only=False)
        if "agreement" not in str(d.get("labels", "")):
            say(f"  skipping {ck}: not an agreement-label checkpoint (labels = {d.get('labels', 'not recorded')})"); continue
        ns = Path(ck).parent / "norm_stats.npz"
        if not ns.exists():
            say(f"  skipping {ck}: no norm_stats.npz in the same folder"); continue
        z = np.load(ns); base = d["model"]["inc.block.0.weight"].shape[0]
        m = UNet(6, 2, base).to(DEV); m.load_state_dict(d["model"]); m.eval()
        name = f"seed {d['seed']}"
        if any(x["name"] == name for x in out):
            name += f" (run {sum(x['name'].startswith(name) for x in out) + 1})"
            say(f"  WARNING: two checkpoints share seed {d['seed']} -- same-seed runs show only GPU randomness")
        out.append(dict(name=name, model=m, mean=z["mean"], std=z["std"], scale=float(z["scale"])))
        say(f"  loaded network {name} (best epoch {d['epoch']}) from {ck}")
    if not out: raise SystemExit("No agreement-label best.pt found -- attach the training outputs.")
    return out


@torch.no_grad()
def logits(m, x6):
    xn = (x6 - m["mean"][:, None, None]) / (m["std"][:, None, None] + 1e-6)
    return m["model"](torch.from_numpy(xn).float().to(DEV)).float().cpu().numpy()


# ------------------------------------------------------------ cues
def haze_cue(x6):
    """Dark-object level: 1st percentile of blue reflectance per HAZE_BLOCK x HAZE_BLOCK block."""
    b = x6[HAZE_BAND]; H, W = b.shape; k = min(HAZE_BLOCK, H, W); out = np.empty_like(b)
    for i in range(0, H, k):
        for j in range(0, W, k):
            out[i:i + k, j:j + k] = np.percentile(b[i:i + k, j:j + k], HAZE_PCT)
    return out


def box_mean(x, k):
    """Mean of x over a k x k window, edge padding (as fit_saea2.py)."""
    p = k // 2; H, W = x.shape
    xp = np.pad(x.astype(np.float64), p, mode="edge")
    c = np.pad(xp.cumsum(0).cumsum(1), ((1, 0), (1, 0)))
    return ((c[k:k + H, k:k + W] - c[0:H, k:k + W] - c[k:k + H, 0:W] + c[0:H, 0:W]) / (k * k)).astype(np.float32)


# ------------------------------------------------------------ readouts
def sig(x): return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


def three(z0, z1, eta):
    m = np.maximum(np.maximum(z0, z1), eta)
    a, b, c = np.exp(z0 - m), np.exp(z1 - m), np.exp(eta - m); Z = a + b + c
    return a / Z, b / Z, c / Z


def lookup(model, x):
    edges, table = model
    return table[np.clip(np.searchsorted(edges, x, "right") - 1, 0, len(table) - 1)].astype(np.float64)


def apply(rd, z0, z1, ctx):
    """ctx: 'd' = raw haze cue per pixel, 'S' = {W: spatial map}."""
    g = z1 - z0; pred = g > 0; k = rd["kind"]
    if k == "softmax":
        pf = sig(g); return 1 - pf, pf, np.zeros_like(pf)
    if k == "iso":
        pf = lookup(rd["model"], g); return 1 - pf, pf, np.zeros_like(pf)
    h = np.maximum(z0, z1); eta = np.full(z0.shape, -1e4)
    if k in ("gate1", "gate2", "saea"):
        dt = (ctx["d"] - rd["dmu"]) / rd["dsd"] if k != "gate1" else None
        for c in (0, 1):
            t = rd["tau"][c]
            if t is None: continue
            m = pred == bool(c); tt = t; ex = 0.0
            if c == 0 and k != "gate1":
                tt = t + rd["tau1"] * dt[m]
                if k == "saea" and rd["lam"] > 0: ex = rd["lam"] * ctx["S"][rd["W"]][m]
            eta[m] = FIX_C + FIX_K * sig(rd["gam"][c] * (tt - h[m]) + ex)
    elif k == "en1":
        for c in (0, 1):
            p = rd["ts"][c]
            if p is None: continue
            t, s = p; m = pred == bool(c); eta[m] = h[m] - s * (h[m] - t)
    elif k == "en2":
        dt = (ctx["d"] - rd["dmu"]) / rd["dsd"]
        st = np.searchsorted(rd["dedges"], dt, "right")
        psm = sig(np.abs(g))
        for c in (0, 1):
            for j, mdl in enumerate(rd["iso"][c]):
                if mdl is None: continue
                m = (pred == bool(c)) & (st == j)
                if not m.any(): continue
                q = np.clip(lookup(mdl, h[m]), 1e-6, 1.0); r = 1.0 / q - 1.0 / psm[m]
                eta[m] = np.where(r > 1e-12, h[m] + np.log(np.maximum(r, 1e-12)), -1e4)
    return three(z0, z1, eta)


# ------------------------------------------------------------ fitting
def fit_isotonic(g, y, w, nb=2000):
    """Weighted pool-adjacent-violators on quantile bins -> monotone increasing P(y | g)."""
    edges = np.unique(np.quantile(g, np.linspace(0, 1, nb + 1)))
    if len(edges) < 2: edges = np.array([g.min(), g.min() + 1e-6])
    b = np.clip(np.searchsorted(edges, g, "right") - 1, 0, len(edges) - 2)
    n = np.bincount(b, w, len(edges) - 1); s = np.bincount(b, w * y.astype(float), len(edges) - 1)
    keep = np.flatnonzero(n > 0); val, wt, blocks = [], [], []
    for idx in keep:
        val.append(s[idx] / n[idx]); wt.append(n[idx]); blocks.append([idx])
        while len(val) > 1 and val[-2] > val[-1]:
            v2, w2, b2 = val.pop(), wt.pop(), blocks.pop()
            val[-1] = (val[-1] * wt[-1] + v2 * w2) / (wt[-1] + w2); wt[-1] += w2; blocks[-1] += b2
    table = np.full(len(edges) - 1, np.nan)
    for v, bl in zip(val, blocks): table[bl] = v
    filled = np.flatnonzero(np.isfinite(table))
    table = np.interp(np.arange(len(table)), filled, table[filled])
    return edges, table, len(val)


def brier(rd, D):
    pb, pf, pn = apply(rd, D["z0"], D["z1"], D)
    conf = np.where(D["pred"], pf, pb)
    return float((D["w"] * (conf - D["corr"]) ** 2).sum() / D["wsum"])


def best_of(cands, make, D):
    sc = [brier(make(c), D) for c in cands]; i = int(np.argmin(sc)); return cands[i], sc[i]


def fit_all(D, Wset):
    z0, z1, y, w = D["z0"], D["z1"], D["y"], D["w"]
    g = z1 - z0; pred = g > 0; h = np.maximum(z0, z1); s = 0.5 * (z0 + z1)
    D["pred"] = pred; D["corr"] = (pred == y).astype(np.float64); D["wsum"] = w.sum()
    R = {"softmax": dict(kind="softmax")}
    e, t, nb = fit_isotonic(g, y, w); R["isotonic"] = dict(kind="iso", model=(e, t), blocks=nb)
    gam = [FIX_G * (s[pred == bool(c)].std() + 1e-6) / (h[pred == bool(c)].std() + 1e-6)
           if (pred == bool(c)).sum() > 1 else FIX_G for c in (0, 1)]
    q = [list(np.quantile(h[pred == bool(c)], np.linspace(0.02, 0.98, 25))) if (pred == bool(c)).any() else []
         for c in (0, 1)]
    # gate v1 -- the joint grid of haze_readouts.py / every_pixel.py, unchanged
    (a, b), _ = best_of([(a, b) for a in [None] + q[0] for b in [None] + q[1]],
                        lambda t: dict(kind="gate1", tau=list(t), gam=gam), D)
    R["gate v1"] = dict(kind="gate1", tau=[a, b], gam=gam)
    # haze cue standardisation and strata
    dmu, dsd = float(D["d"].mean()), float(D["d"].std() + 1e-9)
    dt = (D["d"] - dmu) / dsd
    # gate v2 -- background: OFF or (tau0, tau1) jointly; then fire; then background again
    hb_sd = h[~pred].std() if (~pred).any() else 1.0
    T1 = list(hb_sd * np.linspace(-2.5, 2.5, 21)); T1_EDGE = 2.5 * hb_sd
    g2 = lambda t0, t1, tf: dict(kind="gate2", tau=[t0, tf], tau1=t1, gam=gam, dmu=dmu, dsd=dsd)
    tf = None
    for _ in range(2):
        (t0, t1), _s = best_of([(None, 0.0)] + [(a, b) for a in q[0] for b in T1], lambda c: g2(c[0], c[1], tf), D)
        tf, _s = best_of([None] + q[1], lambda c: g2(t0, t1, c), D)
    R["gate v2"] = g2(t0, t1, tf)
    for nm in ("gate v2",): R[nm]["edge"] = T1_EDGE
    # SAEA v2 -- start from gate v2, add the spatial term; lambda = 0 is gate v2
    best = (brier(R["gate v2"], D), R["gate v2"])
    s0, s1 = (t0, t1) if t0 is not None else (float(np.median(h[~pred])), 0.0)
    for W in Wset:
        for lam in LAM_GRID:
            mk = lambda a, b: dict(kind="saea", tau=[a, tf], tau1=b, gam=gam, dmu=dmu, dsd=dsd, W=W, lam=lam)
            a_, _s = best_of(q[0], lambda c: mk(c, s1), D)
            b_, sc = best_of(T1, lambda c: mk(a_, c), D)
            if sc < best[0]: best = (sc, mk(a_, b_))
    R["SAEA v2"] = best[1] if best[1]["kind"] == "saea" else dict(kind="saea", tau=[t0, tf], tau1=t1, gam=gam,
                                                                     dmu=dmu, dsd=dsd, W=Wset[0], lam=0.0)
    # evidence null v1 -- evidence_null.py's grid and coordinate descent, Brier objective
    cands = [[None] + [(t, s_) for t in np.quantile(h[pred == bool(c)], np.linspace(0.02, 0.60, 15)) for s_ in EN_S_GRID]
             if (pred == bool(c)).any() else [None] for c in (0, 1)]
    P = [None, None]
    for c in (0, 1, 0):
        P[c], _s = best_of(cands[c], lambda p: dict(kind="en1", ts=[p if i == c else P[i] for i in (0, 1)]), D)
    R["SAEA v2"]["edge"] = T1_EDGE
    R["EN v1"] = dict(kind="en1", ts=list(P))
    # evidence null v2 -- isotonic P(correct | h) per predicted class and haze stratum
    dedges = np.quantile(dt[y == 0], np.linspace(0, 1, N_STRATA + 1)[1:-1]) if (y == 0).any() else np.array([])
    st = np.searchsorted(dedges, dt, "right"); iso = [[], []]; steps = [[], []]
    for c in (0, 1):
        for j in range(N_STRATA):
            m = (pred == bool(c)) & (st == j)
            if m.sum() < 200: iso[c].append(None); steps[c].append(0); continue
            e, t, nb = fit_isotonic(h[m], D["corr"][m], w[m]); iso[c].append((e, t)); steps[c].append(nb)
    R["EN v2"] = dict(kind="en2", iso=iso, steps=steps, dedges=dedges, dmu=dmu, dsd=dsd)
    for nm in ABSTAIN:                                    # the decision must not move
        pb, pf, _ = apply(R[nm], z0, z1, D)
        assert np.array_equal(pf > pb, pred), f"{nm} moved the decision boundary"
    return R, {nm: brier(rd, D) for nm, rd in R.items()}


def describe(rd):
    f = lambda t: "OFF" if t is None else f"{t:+.2f}"
    k = rd["kind"]
    if k == "softmax": return "--"
    if k == "iso": return f"{rd['blocks']} monotone steps"
    if k == "gate1": return f"tau bg={f(rd['tau'][0])} fire={f(rd['tau'][1])}"
    edge = lambda: "  [tau1 AT GRID EDGE]" if rd["tau"][0] is not None and abs(abs(rd["tau1"]) - rd.get("edge", np.inf)) < 1e-9 else ""
    if k == "gate2":
        return f"tau bg={f(rd['tau'][0])} {rd['tau1']:+.2f}*d~ fire={f(rd['tau'][1])}" + edge()
    if k == "saea":
        return (f"tau bg={f(rd['tau'][0])} {rd['tau1']:+.2f}*d~ lambda={rd['lam']:g} W={rd['W']} fire={f(rd['tau'][1])}"
                + edge() + ("  [lambda AT GRID EDGE]" if rd["lam"] == LAM_GRID[-1] else ""))
    if k == "en1":
        g = lambda p: "OFF" if p is None else f"(t={p[0]:+.2f}, s={p[1]:g})"
        return f"bg {g(rd['ts'][0])} fire {g(rd['ts'][1])}"
    return f"steps per haze stratum: bg {rd['steps'][0]} fire {rd['steps'][1]}"


# --------------------------------------------------------- statistics
F_BIN = 3 * NB
O_B = 3 * F_BIN
O_P = O_B + 4 + 10                                   # proper scores
F_TOT = O_P + 4
EPS = 1e-12                                          # probability floor for log scores: -log(1e-12) = 27.6

def patch_stats(pb, pf, pn, z0, z1, lab):
    """Sufficient statistics for one patch; lab may contain IGNORE (255).
    The prediction is the readout's OWN: p(fire) > p(bg). For softmax, temperature
    scaling and the gate this equals argmax(z0, z1); Platt, beta and isotonic can
    move it, which shows up as a change in IoU."""
    pred = pf > pb; v = lab != IGNORE; y = lab == 1
    conf = np.where(pred, pf, pb); corr = (pred == y).astype(np.float64)
    row = np.zeros(F_TOT); o = 0
    for m in (v & y, v & ~y, v & pred):                    # true fire, true bg, predicted fire
        c, k = conf[m], corr[m]; b = np.clip((c * NB).astype(int), 0, NB - 1)
        row[o:o + NB] = np.bincount(b, minlength=NB); row[o + NB:o + 2 * NB] = np.bincount(b, c, NB)
        row[o + 2 * NB:o + 3 * NB] = np.bincount(b, k, NB); o += F_BIN
    e2 = (conf - corr) ** 2
    row[o] = e2[v].sum(); row[o + 1] = v.sum(); row[o + 2] = e2[v & y].sum(); row[o + 3] = (v & y).sum(); o += 4
    for m in (v & pred & y, v & pred & ~y):                 # detected, false alarm
        row[o] = m.sum(); row[o + 1] = conf[m].sum(); o += 2
    for m in (v & ~pred & y, v & ~pred & ~y):               # missed, correct background
        row[o] = m.sum(); row[o + 1] = conf[m].sum(); row[o + 2] = pn[m].sum(); o += 3
    # proper scores of the FULL distribution -- abstention is never the true class, so these penalise it
    pt = np.where(y, pf, pb)
    row[o] = -np.log(np.maximum(pt, EPS))[v].sum()                                       # NLL
    row[o + 1] = ((pb - (~y)) ** 2 + (pf - y) ** 2 + pn ** 2)[v].sum()                   # three-outcome Brier
    # proper scores of CONFIDENCE as a forecast of being correct -- what calibration measures
    cl = -(corr * np.log(np.maximum(conf, EPS)) + (1 - corr) * np.log(np.maximum(1 - conf, EPS)))
    row[o + 2] = cl[v].sum(); row[o + 3] = cl[v & y].sum()
    return row


def metrics(V):
    out = {}
    def ece(o):
        n, c, k = V[:, o:o + NB], V[:, o + NB:o + 2 * NB], V[:, o + 2 * NB:o + 3 * NB]
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.abs(k - c).sum(1) / n.sum(1)
    out["true-fire ECE"], out["true-bg ECE"], out["pred-fire ECE"] = ece(0), ece(F_BIN), ece(2 * F_BIN)
    o = O_B
    with np.errstate(invalid="ignore", divide="ignore"):
        out["conf Brier"] = V[:, o] / V[:, o + 1]; out["fire Brier"] = V[:, o + 2] / V[:, o + 3]; o += 4
        tp = V[:, o]; out["conf detected"] = V[:, o + 1] / tp; o += 2
        fp = V[:, o]; out["conf false alarm"] = V[:, o + 1] / fp; o += 2
        fn = V[:, o]; out["missed px"] = fn; out["conf missed"] = V[:, o + 1] / fn; am = V[:, o + 2] / fn; o += 3
        out["conf correct bg"] = V[:, o + 1] / V[:, o]; ab = V[:, o + 2] / V[:, o]
        out["selectivity"] = am / ab
        out["abst missed"] = am; out["abst correct bg"] = ab
        out["IoU"] = tp / (tp + fp + fn); out["precision"] = tp / (tp + fp); out["recall"] = tp / (tp + fn)
        out["fire px"] = tp + fn
        n_all, n_fire = V[:, O_B + 1], V[:, O_B + 3]
        out["NLL"] = V[:, O_P] / n_all; out["Brier"] = V[:, O_P + 1] / n_all
        out["conf NLL"] = V[:, O_P + 2] / n_all; out["fire NLL"] = V[:, O_P + 3] / n_fire
    return out


def auroc(score, pos):
    s = np.asarray(score, np.float64); p = np.asarray(pos, bool)
    if p.sum() == 0 or (~p).sum() == 0: return float("nan")
    u, inv = np.unique(s, return_inverse=True)
    P = np.bincount(inv, p.astype(float), len(u)); N = np.bincount(inv, (~p).astype(float), len(u))
    return float((P * (np.cumsum(N) - N + 0.5 * N)).sum() / (P.sum() * N.sum()))


# ------------------------------------------------------------------ main
def main():
    OUT.mkdir(parents=True, exist_ok=True); t_start = time.time()
    say(f"READOUTS v2   device {DEV}   scored beta0 = {SCORE_BETAS}   alpha = {ALPHAS}   bootstrap {BOOT}")
    models = load_models()
    agree, flags = {}, {}
    for sc in ("scene3", "scene4"):
        f = next(iter(glob.glob(str(Path(ROOT) / "**" / f"agreement_{sc}.npz"), recursive=True)), None)
        if f is None: raise SystemExit(f"agreement_{sc}.npz not found -- attach the label notebook's output.")
        z = np.load(f, allow_pickle=True); L = z["label"]; Fl = z["flags"]          # decompress ONCE
        for i, nm in enumerate(z["files"]): agree[str(nm)] = L[i]; flags[str(nm)] = Fl[i]
        say(f"  agreement labels and signature flags loaded: {Path(f).name}")
    files = {sc: find(ROOT, sc) for sc in ("scene3", "scene4")}
    if MAXP: files = {k: v[:MAXP] for k, v in files.items()}
    n3 = len(files["scene3"]); perm = np.random.default_rng(0).permutation(n3)          # SAME split as every run
    held_in, held_out = np.sort(perm[:n3 // 2]), np.sort(perm[n3 // 2:])
    scale = models[0]["scale"]
    A = {}
    for sc, fl in files.items():
        step = max(1, len(fl) // A_SAMPLE)
        A[sc] = np.percentile(np.stack([read_patch(f)[0] * scale for f in fl[::step]]), 99, axis=(0, 2, 3))
        say(f"  {sc}: {len(fl)} patches   atmospheric light {np.round(A[sc], 4)}")

    # ---------------- pass A: fitting samples -- identical draw to haze_readouts.py ----------------
    say("\nPASS A: fitting samples (scene 3, held-in half, agreement labels, as haze_readouts.py) ...")
    rng = np.random.default_rng(5)
    keys = ["z0", "z1", "y", "w", "d"] + [f"S{W}" for W in W_GRID]
    S = {(m["name"], a, b): {k: [] for k in keys} for m in models for a in ALPHAS for b in FIT_BETAS}
    fl = files["scene3"]
    for s0 in range(0, len(held_in), 4):
        sel = held_in[s0:s0 + 4]; raws = [read_patch(fl[i])[0] * scale for i in sel]
        lab = np.stack([agree[Path(fl[i]).name] for i in sel]); v = lab != IGNORE
        keep = v & ((lab == 1) | (rng.random(lab.shape) < BG_RATE))
        wt = np.where(lab == 1, 1.0, 1.0 / BG_RATE)[keep]
        for a in ALPHAS:
            for b in FIT_BETAS:
                if a != ALPHAS[0] and b == 0.0: continue
                x6 = np.stack([haze(r, b, A["scene3"], a) for r in raws])
                dmap = np.stack([haze_cue(x) for x in x6])
                for m in models:
                    lg = logits(m, x6); d = S[(m["name"], a, b)]
                    d["z0"].append(lg[:, 0][keep]); d["z1"].append(lg[:, 1][keep])
                    d["y"].append((lab == 1)[keep]); d["w"].append(wt); d["d"].append(dmap[keep])
                    pf = (lg[:, 1] > lg[:, 0]).astype(np.float32)
                    for W in W_GRID:
                        d[f"S{W}"].append(np.stack([box_mean(p, W) for p in pf])[keep])
    S = {k: {kk: np.concatenate(vv) for kk, vv in d.items()} for k, d in S.items() if d["z0"]}
    for m in models:
        for a in ALPHAS[1:]:
            S[(m["name"], a, 0.0)] = S[(m["name"], ALPHAS[0], 0.0)]
    say("\nFITTING  (gate v1 must equal haze_readouts' / every_pixel's 'gate Brier-fit (mixture)')")
    R, fitlog = {}, []
    for m in models:
        for a in ALPHAS:
            mix = {k: np.concatenate([S[(m["name"], a, b)][k] for b in FIT_BETAS]) for k in keys}
            mix["S"] = {W: mix.pop(f"S{W}") for W in W_GRID}
            t0 = time.time()
            R[(m["name"], a)], fb = fit_all(mix, W_GRID)
            say(f"\n  {m['name']}, alpha {a}   ({mix['z0'].size:,} samples, {time.time() - t0:.0f} s)")
            for nm, rd in R[(m["name"], a)].items():
                line = f"    {nm:9} {describe(rd):70}  fit Brier {fb[nm]:.6f}"
                say(line); fitlog.append(f"{m['name']} alpha {a}: {line.strip()}")
            say(f"    haze cue on the fitting samples: mean {float(mix['d'].mean()):.4f}  sd {float(mix['d'].std()):.4f}")
    (OUT / "v2_fits.txt").write_text("\n".join(fitlog))
    del S, mix

    # ---------------- pass B: scoring every pixel ----------------
    say("\nPASS B: scoring (scene 3 held-out half, all of scene 4) ...")
    ST, CUE = {}, {}
    for sc, idx in (("scene3", held_out), ("scene4", np.arange(len(files["scene4"])))):
        fl = files[sc]
        for s0 in range(0, len(idx), 4):
            sel = idx[s0:s0 + 4]; P = [read_patch(fl[i]) for i in sel]
            raws = [p[0] * scale for p in P]; names = [Path(fl[i]).name for i in sel]
            labs = [dict(agreement=agree[nm], visible=((flags[nm] & SEEDGROW_BIT) > 0).astype(np.uint8)) for nm in names]
            for a in ALPHAS:
                for b in SCORE_BETAS:
                    x6 = np.stack([haze(r, b, A[sc], a) for r in raws])
                    dmap = np.stack([haze_cue(x) for x in x6])
                    CUE.setdefault((a, sc, b), []).extend(float(x.mean()) for x in dmap)
                    for m in models:
                        lg = logits(m, x6); Rm = R[(m["name"], a)]; W = Rm["SAEA v2"]["W"]
                        for k in range(len(sel)):
                            z0, z1 = lg[k, 0], lg[k, 1]
                            ctx = {"d": dmap[k], "S": {W: box_mean((z1 > z0).astype(np.float32), W)}}
                            outs = {nm: apply(Rm[nm], z0, z1, ctx) for nm in READOUTS}
                            for ver in VERSIONS:
                                for nm in READOUTS:
                                    ST.setdefault((m["name"], a, sc, b, ver, nm), []).append(
                                        patch_stats(*outs[nm], z0, z1, labs[k][ver]))
        say(f"  scored {sc}   ({(time.time() - t_start) / 60:.0f} min so far)")
    ST = {k: np.stack(v) for k, v in ST.items()}

    # ---------------- results ----------------
    rows, cis = [], []
    brng = np.random.default_rng(3)
    for m in models:
        for a in ALPHAS:
            for sc in ("scene3", "scene4"):
                P = ST[(m["name"], a, sc, SCORE_BETAS[0], VERSIONS[0], "softmax")].shape[0]
                Wt = np.stack([np.bincount(brng.integers(0, P, P), minlength=P) for _ in range(BOOT)]).astype(np.float64)
                for b in SCORE_BETAS:
                    for ver in VERSIONS:
                        pts, bts = {}, {}
                        for nm in READOUTS:
                            M = ST[(m["name"], a, sc, b, ver, nm)]
                            pts[nm] = {k: float(v[0]) for k, v in metrics(M.sum(0)[None]).items()}
                            bts[nm] = metrics(Wt @ M)
                            rows.append(dict(model=m["name"], alpha=a, scene=sc, beta0=b, labels=ver, readout=nm, **pts[nm]))
                        for new, ref in COMPARE:
                            for met in CI_METRICS:
                                d = bts[new][met] - bts[ref][met]; d = d[np.isfinite(d)]
                                if d.size == 0: continue
                                d = np.where(np.abs(d) < 1e-7, 0.0, d)
                                lo, hi = np.percentile(d, [2.5, 97.5])
                                cis.append(dict(model=m["name"], alpha=a, scene=sc, beta0=b, labels=ver, readout=new,
                                                reference=ref, metric=met, value=pts[new][met], ref_value=pts[ref][met],
                                                diff=pts[new][met] - pts[ref][met], ci_low=lo, ci_high=hi,
                                                significant=bool(hi < 0 or lo > 0)))
    for name, data in (("v2_results.csv", rows), ("v2_cis.csv", cis)):
        with open(OUT / name, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(data[0].keys())); w.writeheader(); w.writerows(data)

    RI = {(r["model"], r["alpha"], r["scene"], r["beta0"], r["labels"], r["readout"]): r for r in rows}
    CI = {(c["model"], c["alpha"], c["scene"], c["beta0"], c["labels"], c["readout"], c["reference"], c["metric"]): c
          for c in cis}
    fmt = lambda v, d=3: f"{v:.{d}f}" if np.isfinite(v) else "--"

    say("\nSANITY CHECK -- gate v1, softmax and isotonic under agreement labels must reproduce every_pixel / haze_readouts")
    prev = [p for p in glob.glob(str(Path(ROOT) / "**" / "*.csv"), recursive=True)
            if Path(p).name in ("readout_results.csv", "every_pixel_results.csv")]
    if prev:
        for pth in prev:
            Pr = list(csv.DictReader(open(pth))); diffs = []
            for p in Pr:
                if p.get("labels", "agreement") != "agreement": continue
                for nm, epn in EP_NAME.items():
                    if p["readout"] != epn: continue
                    r = RI.get((p["model"], float(p["alpha"]), p["scene"], float(p["beta0"]), "agreement", nm))
                    if r is None: continue
                    for met in ("true-fire ECE", "conf Brier"):
                        if p.get(met, "") not in ("", "nan") and np.isfinite(r[met]):
                            diffs.append(abs(float(p[met]) - r[met]))
            mx = max(diffs) if diffs else float("nan")
            say(f"  {Path(pth).name}: compared {len(diffs)} values, largest difference {mx:.2e}  "
                f"{'-> MATCH' if mx < 2e-3 else ('-> nothing comparable' if not diffs else '-> MISMATCH: paste this report before using it')}")
    else:
        say("  no earlier results attached -- compare by eye: gate v1's tau values above should equal every_pixel's FITTING lines.")

    say("\nHAZE CUE -- mean dark-object level (blue 1st percentile) by haze level. It must RISE with beta0;")
    say("  scene 4 vs scene 3 at beta0 = 0 shows how much of it is land cover rather than haze.")
    for a in ALPHAS:
        say(f"  alpha {a}:   " + "   ".join(f"{sc}: " + " ".join(f"{np.mean(CUE[(a, sc, b)]):.4f}" for b in SCORE_BETAS)
                                         for sc in ("scene3", "scene4")))

    titles = {"agreement": "AGREEMENT LABELS (ignored pixels skipped)",
              "visible": "VISIBLE-FIRE TRUTH, EVERY PIXEL (rings around fires count as background)"}
    short = {"softmax": "softmax", "isotonic": "iso", "gate v1": "gate1", "EN v1": "EN1", "gate v2": "gate2",
             "EN v2": "EN2", "SAEA v2": "SAEA2"}
    TABLES = [("true-fire ECE", 4), ("fire Brier", 4), ("fire NLL", 3), ("conf Brier", 6), ("conf NLL", 5),
              ("conf missed", 3), ("conf correct bg", 4), ("abst correct bg", 4), ("selectivity", 1), ("IoU", 3)]
    for ver in VERSIONS:
        say(f"\n######################## {titles[ver]} ########################")
        for a in ALPHAS:
            for sc in ("scene3", "scene4"):
                for m in models:
                    mm = m["name"]
                    say(f"\n  [alpha {a} | {sc} | {mm}]   lower = better except IoU, conf correct bg, selectivity")
                    for met, dd in TABLES:
                        say(f"    {met}")
                        say("    " + f"{'beta0':>6}" + "".join(f"{short[nm]:>10}" for nm in READOUTS))
                        for b in SCORE_BETAS:
                            say("    " + f"{b:>6.1f}" + "".join(f"{fmt(RI[(mm, a, sc, b, ver, nm)][met], dd):>10}"
                                                            for nm in READOUTS))
                    say("    ABLATIONS  new - reference on fire Brier | conf NLL   (* = 95% CI excludes 0; negative = new better)")
                    for b in SCORE_BETAS:
                        cells = []
                        for new, ref in COMPARE:
                            if ref == "softmax" and new != "gate v2": continue
                            x, y_ = CI[(mm, a, sc, b, ver, new, ref, "fire Brier")], CI[(mm, a, sc, b, ver, new, ref, "conf NLL")]
                            cells.append(f"{short[new]}-{short[ref]}: {x['diff']:+.4f}{'*' if x['significant'] else ' '}|"
                                         f"{y_['diff']:+.5f}{'*' if y_['significant'] else ' '}")
                        say(f"    {b:>6.1f}  " + "  ".join(cells))

    say("\nHOW TO READ THIS")
    say("  1. SANITY: gate v1, softmax and isotonic must MATCH earlier runs -- same samples, same fits.")
    say("  2. FITTING: tau1 = 0 means the haze cue was refused; lambda = 0 means the spatial term was refused.")
    say("     A refusal is a result: it says that signal adds nothing beyond the height.")
    say("  3. gate2 - gate1: the value of a haze-aware threshold. Look first at beta0 = 1-2, where v1 was weakest.")
    say("  4. SAEA2 - gate2: the value of the spatial term. Trust it only if it also wins under VISIBLE truth,")
    say("     because agreement labels skip the fire-edge rings where the spatial term is largest.")
    say("  5. EN2 - gate2: EN v2 is the best monotone height-to-confidence map per haze stratum (the ceiling).")
    say("     A small gap means the 3-number gate is already near the best any height-based readout can do.")
    say("     EN v2 beating gate v2 on held-in data but not on scene 4 = its many steps overfit scene 3.")
    say("  6. v2 - iso: the bar every new readout must clear. iso can move the decision (check its IoU); the")
    say("     abstention readouts cannot (asserted at fit time).")
    say("  7. Proper scores: fire Brier / fire NLL / conf Brier / conf NLL are fair to abstention. 'abst correct bg'")
    say("     is the price: abstention spent on pixels that were right.")
    (OUT / "report.txt").write_text("\n".join(LOG))
    say(f"\nWrote {OUT}/report.txt, v2_results.csv, v2_cis.csv, v2_fits.txt   ({(time.time() - t_start) / 60:.0f} min)")


if __name__ == "__main__":
    main()
