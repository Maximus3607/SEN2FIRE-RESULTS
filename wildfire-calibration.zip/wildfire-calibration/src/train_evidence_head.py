r"""
EVIDENCE HEAD: a learned error-detection channel on a FROZEN segmentation model.

WHY THIS EXISTS

Every hand-designed signal has now been tested on this model and none separates
its failures:

  signal      flipped AUROC (clean -> b0=0.50)   overlap
  gap/abs/lse       0.654 -> 0.572                86-92%   (all identical)
  nbr_fire          0.601 -> 0.628                72-75%   best so far
  haze_cue          0.522 -> 0.583                89-95%
  aerosol           0.607 -> 0.617                99.7%    between-patch only

The logit signals are identical because the model learned ANTISYMMETRIC logits
(z_1 = -z_0). That is structural, not accidental: softmax is invariant to adding
a constant to both logits, so cross-entropy gives EXACTLY zero gradient along
the (z_0+z_1) direction. Weight decay is the only force there and pulls the sum
to zero. The 2-channel output therefore carries ONE number per pixel -- the one
MSP already reads.

The bottleneck is the final 1x1 projection to 2 channels, NOT the network. The
decoder feature map feeding that projection has 64 channels. This trains a small
head on those features to predict the one thing the logits cannot express:
whether the frozen model is about to be wrong here.

ACCURACY IS PRESERVED EXACTLY

The segmentation path is untouched -- same backbone, same output conv, same
weights, no gradients. Predictions are bit-identical to the existing model, so
IoU 0.1997 / precision 0.447 / recall 0.265 carry over unchanged and every
number already measured still applies. The evidence head is a PARALLEL branch
whose output never enters the argmax. This is what makes the comparison clean:
the only thing that differs between the baseline and the new readout is the
calibration signal.

It does not remove the antisymmetry from the segmentation head -- that is frozen
and removing it would change the predictions. It ADDS a second degree of freedom
outside the constraint, which is what was missing.

TARGET

    t_i = 1 if the frozen model's argmax is WRONG at pixel i, else 0

Trained on scenes 1-2 only. The head never sees scene 3 (used to fit the
calibrator) or scene 4 (evaluation), so generalisation of the error pattern
across regions is genuinely tested rather than assumed.

Errors are ~6% of pixels, so pos_weight corrects the imbalance.

Kaggle: attach Sen2Fire AND the training version's output. GPU T4.
Roughly 2-3 min/epoch -- no gradients flow through the backbone.
"""

import glob, json, time
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# ------------------------------------------------------------------ config
class CFG:
    data_root = "/kaggle/input"
    out_dir   = "/kaggle/working"
    band_idx  = [3, 2, 1, 7, 10, 11]          # R, G, B, NIR, SWIR1, SWIR2
    wavelen   = np.array([665., 560., 490., 842., 1610., 2190.])
    lambda0   = 550.0
    alpha     = 1.3
    dump_betas = [0.0, 0.20, 0.50]            # haze levels to dump evidence for
    splits    = {"train": ["scene1", "scene2"], "val": ["scene3"], "test": ["scene4"]}
    in_ch, out_ch, base = 6, 2, 64
    hidden    = 32                            # evidence head width
    batch     = 4
    epochs    = 25
    lr        = 1e-3
    pos_weight = 12.0                         # errors are ~6% of pixels
    workers   = 2

DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT = Path(CFG.out_dir); OUT.mkdir(parents=True, exist_ok=True)
print("device:", DEV)


# ------------------------------------------------------------------- model
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co*2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2)-x.size(-2); dx = skip.size(-1)-x.size(-1)
            x = F.pad(x, [dx//2, dx-dx//2, dy//2, dy-dy//2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    """Identical to the trained model. forward_feat also returns the 64-channel
    decoder map that feeds the output conv -- that is what the evidence head
    reads. Nothing about the segmentation path changes."""
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b*2), Down(b*2, b*4)
        self.d3, self.d4 = Down(b*4, b*8), Down(b*8, b*16)
        self.u1, self.u2 = Up(b*16, b*8), Up(b*8, b*4)
        self.u3, self.u4 = Up(b*4, b*2), Up(b*2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward_feat(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2)
        feat = self.u4(x, s1)                      # (B, 64, H, W)
        return self.out(feat), feat
    def forward(self, x):
        return self.forward_feat(x)[0]


class EvidenceHead(nn.Module):
    """Small conv stack on the frozen decoder features.

    Deliberately shallow: it must generalise from scenes 1-2 to scene 4, and a
    deep head on 1458 patches would memorise this model's training-set error
    pattern rather than learning a transferable one. Dilation widens the
    receptive field cheaply, which matters because the best hand-designed signal
    (nbr_fire) was spatial -- the head should be able to use context too.
    """
    def __init__(self, ci=64, h=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(ci, h, 3, padding=1), nn.BatchNorm2d(h), nn.ReLU(True),
            nn.Conv2d(h, h, 3, padding=4, dilation=4), nn.BatchNorm2d(h), nn.ReLU(True),
            nn.Conv2d(h, 1, 1))
    def forward(self, f):
        return self.net(f)[:, 0]                   # (B,H,W) evidence logit


# -------------------------------------------------------------------- haze
def transmission(beta0):
    beta = beta0 * (CFG.wavelen / CFG.lambda0) ** (-CFG.alpha)
    return np.exp(-beta).astype(np.float32)[:, None, None]


def apply_haze(img, beta0, A):
    if beta0 == 0.0:
        return img
    t = transmission(beta0)
    return img * t + A[:, None, None] * (1.0 - t)


# -------------------------------------------------------------------- data
def find(root, tags):
    out = []
    for f in sorted(glob.glob(str(Path(root)/"**"/"*.npz"), recursive=True)):
        if {p.lower() for p in Path(f).parts[:-1]} & set(tags):
            out.append(f)
    return out


class Patches(Dataset):
    def __init__(self, files, mean, std, scale, augment=False, seed=0):
        self.files, self.mean, self.std, self.scale = files, mean, std, scale
        self.augment, self.rng = augment, np.random.default_rng(seed)
    def __len__(self): return len(self.files)
    def raw(self, i):
        z = np.load(self.files[i], allow_pickle=True)
        ks = list(z.keys())
        ik = next((k for k in ("image","img","data","x") if k in ks), ks[0])
        lk = next((k for k in ("label","mask","gt","y") if k in ks), ks[-1])
        img = np.asarray(z[ik], dtype=np.float32)
        if img.ndim == 3 and img.shape[2] < img.shape[0]:
            img = np.transpose(img, (2, 0, 1))
        lab = np.asarray(z[lk])
        if lab.ndim == 3: lab = lab[0]
        return np.nan_to_num(img[CFG.band_idx]) * self.scale, (lab > 0).astype(np.int64)
    def __getitem__(self, i):
        img, lab = self.raw(i)
        if self.augment:
            r = self.rng
            if r.random() < .5: img, lab = img[:, :, ::-1], lab[:, ::-1]
            if r.random() < .5: img, lab = img[:, ::-1], lab[::-1]
        x = (img - self.mean[:, None, None]) / (self.std[:, None, None] + 1e-6)
        t = lambda a: torch.from_numpy(np.ascontiguousarray(a))
        return t(x), t(lab)


# -------------------------------------------------------------------- main
def main():
    files = {s: find(CFG.data_root, t) for s, t in CFG.splits.items()}
    for s, f in files.items():
        print(f"  {s:6s} {len(f):5d}")
    assert files["train"], "no scene1/scene2 patches found"

    sp = glob.glob(str(Path(CFG.data_root)/"**"/"norm_stats.npz"), recursive=True)
    zs = np.load(sp[0]); MEAN, STD, SCALE = zs["mean"], zs["std"], float(zs["scale"])
    cp = glob.glob(str(Path(CFG.data_root)/"**"/"best.pt"), recursive=True)
    ck = torch.load(cp[0], map_location=DEV, weights_only=False)

    seg = UNet(CFG.in_ch, CFG.out_ch, CFG.base).to(DEV)
    seg.load_state_dict(ck["model"])
    seg.eval()
    for p in seg.parameters():
        p.requires_grad_(False)                    # FROZEN. accuracy preserved.
    print(f"loaded {cp[0]} (epoch {ck.get('epoch','?')}) -- frozen")

    head = EvidenceHead(CFG.base, CFG.hidden).to(DEV)
    n_head = sum(p.numel() for p in head.parameters())
    n_seg = sum(p.numel() for p in seg.parameters())
    print(f"evidence head {n_head:,} params vs frozen segmenter {n_seg:,} "
          f"({100*n_head/n_seg:.3f}%)")

    opt = torch.optim.AdamW(head.parameters(), lr=CFG.lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=CFG.epochs)
    pw = torch.tensor([CFG.pos_weight], device=DEV)

    dl = DataLoader(Patches(files["train"], MEAN, STD, SCALE, augment=True),
                    batch_size=CFG.batch, shuffle=True, drop_last=True,
                    num_workers=CFG.workers, pin_memory=(DEV == "cuda"))
    vdl = DataLoader(Patches(files["val"], MEAN, STD, SCALE),
                     batch_size=CFG.batch, num_workers=CFG.workers)

    print(f"\ntraining evidence head, {len(dl)} steps/epoch\n")
    t0 = time.time(); hist = []
    for ep in range(1, CFG.epochs + 1):
        head.train(); tot = nb = 0.0
        for x, lab in dl:
            x, lab = x.to(DEV), lab.to(DEV)
            with torch.no_grad():                  # backbone never gets grads
                lg, feat = seg.forward_feat(x)
                tgt = (lg.argmax(1) != lab).float()
            e = head(feat.detach())
            loss = F.binary_cross_entropy_with_logits(e, tgt, pos_weight=pw)
            opt.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(head.parameters(), 1.0)
            opt.step()
            tot += loss.item(); nb += 1
        sched.step()

        # validation AUROC for error detection on scene3
        head.eval(); S = []; T = []
        with torch.no_grad():
            for x, lab in vdl:
                x, lab = x.to(DEV), lab.to(DEV)
                lg, feat = seg.forward_feat(x)
                S.append(head(feat).flatten().cpu())
                T.append((lg.argmax(1) != lab).float().flatten().cpu())
        s = torch.cat(S).double(); t = torch.cat(T).double()
        g = torch.Generator().manual_seed(0)
        i = torch.randperm(s.numel(), generator=g)[:1_000_000]
        s, t = s[i], t[i]
        o = torch.argsort(s); r = torch.empty_like(s)
        r[o] = torch.arange(1, s.numel()+1, dtype=torch.double)
        npos, nneg = t.sum().item(), (1-t).sum().item()
        auc = (r[t == 1].sum().item() - npos*(npos+1)/2) / max(npos*nneg, 1)
        hist.append(dict(epoch=ep, loss=tot/nb, val_auroc=auc))
        print(f"ep {ep:3d} | loss {tot/nb:.4f} | val error-AUROC {auc:.4f} "
              f"| {(time.time()-t0)/60:.1f}m", flush=True)
        torch.save(head.state_dict(), OUT/"evidence_head.pt")
        (OUT/"evidence_history.json").write_text(json.dumps(hist, indent=2))

    print("\nbaseline for comparison: the best hand-designed signal (nbr_fire)")
    print("reached flipped AUROC 0.60-0.63 on scene4. Anything at or below that")
    print("means the learned head found nothing the neighbourhood count did not.")

    # ---------------- dump evidence maps alongside the existing logits -------
    print("\ndumping evidence maps ...")
    for split in ("val", "test"):
        if not files[split]:
            continue
        ds = Patches(files[split], MEAN, STD, SCALE)
        raw = [ds.raw(i) for i in range(len(ds))]
        imgs = np.stack([r[0] for r in raw]); labs = np.stack([r[1] for r in raw])
        A = np.percentile(imgs, 99, axis=(0, 2, 3)).astype(np.float32)
        for b in (CFG.dump_betas if split == "test" else [0.0]):
            hz = np.stack([apply_haze(im, b, A) for im in imgs])
            nm = (hz - MEAN[:, None, None]) / (STD[:, None, None] + 1e-6)
            E = []
            with torch.no_grad():
                for i in range(0, len(nm), CFG.batch):
                    x = torch.from_numpy(nm[i:i+CFG.batch]).to(DEV)
                    _, feat = seg.forward_feat(x)
                    E.append(head(feat).float().cpu().numpy().astype(np.float16))
            E = np.concatenate(E)
            tag = f"{b:.2f}".replace(".", "p")
            p = OUT/f"evidence_{split}_{tag}.npz"
            np.savez_compressed(p, evidence=E, beta0=b)
            print(f"  {p.name}  {E.shape}")

    print("\n  -> merge these with the matching *_logits.npz and rerun")
    print("     separation_check.py with 'evidence' as an extra signal.")


if __name__ == "__main__":
    t = time.time(); main(); print(f"\ndone in {(time.time()-t)/60:.1f}m")
