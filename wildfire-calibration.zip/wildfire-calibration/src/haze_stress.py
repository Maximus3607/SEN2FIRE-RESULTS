r"""
HAZE STRESS TEST -- does the network outlast the rule as haze thickens?

The agreement labels come from a physical SWIR rule applied to the CLEAR image.
Here the same synthetic haze used throughout the project is applied at
increasing strength, and two things are scored against those clear-image
labels (ignored pixels skipped):
  the NETWORK  each agreement-trained model, on the hazed six-band input
  the RULE     the same seed-and-grow rule that made the labels, applied to
               the hazed B12 and B8A
If the network keeps finding fire after the rule has lost it, the network has
learned something sturdier than the rule -- the answer to "why not just use the
rule?". beta0 is the haze's optical depth at 550 nm; thick wildfire smoke
plumes can reach several, so the sweep goes to 4.

SANITY CHECK: at beta0 = 0 the rule must score IoU 1.0 -- it made the labels.

Also tracked per model: mean softmax confidence on detected fire and on missed
fire, to see whether confidence follows accuracy as the haze thickens.

KAGGLE SETUP -- run AFTER both training runs have finished
  Inputs: Sen2Fire; the agreement-label notebook's output; BOTH training
          notebooks' outputs (each has best.pt and norm_stats.npz).
  Accelerator: GPU T4.  Save Version -> Save & Run All.  About 15-25 minutes.
OUTPUT (/kaggle/working/haze_stress/)
  stress_results.csv          every alpha x scene x haze level x method
  stress_iou_alpha<a>.png     IoU against haze: each network and the rule, one per alpha
  stress_readout_alpha<a>.png confidence on missed fire vs correct background, and AUROC
  report.txt           everything printed
"""

import os, glob, csv, math
from pathlib import Path
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F
from scipy import ndimage

ROOT = os.environ.get("ST_ROOT", "/kaggle/input")
OUT = Path(os.environ.get("ST_OUT", "/kaggle/working/haze_stress"))
BETAS = [float(b) for b in os.environ.get("ST_BETAS", "0,0.5,1,1.5,2,3,4").split(",")]
SCENES = ["scene3", "scene4"]
MAXP = int(os.environ.get("ST_MAXP", 0))          # 0 = every patch (testing only)
DEV = "cuda" if torch.cuda.is_available() else "cpu"
BAND_IDX = [3, 2, 1, 7, 10, 11]                   # model input: R G B NIR(B8) SWIR1 SWIR2
WL6 = np.array([665., 560., 490., 842., 1610., 2190.])
I_B8A, I_B12, WL_B8A, WL_B12 = 8, 11, 865., 2190.
LAMBDA0, ALPHA, A_SAMPLE, IGNORE = 550.0, 1.3, 120, 255
# Both haze types in ONE run: 1.3 = fine aerosol (as every dump), 0.0 = grey haze (thick cloud,
# pyrocumulus, coarse dust -- dims every band equally, so it can hide the SWIR fire signature).
ALPHAS = [float(a) for a in os.environ.get("ST_ALPHAS", "1.3,0.0").split(",")]
BG_KEEP = 0.002                                      # share of correct-background pixels kept for AUROC
SEED, CAND, GROW = (0.35, 4.0), (0.25, 2.0), 2
CROSS = ndimage.generate_binary_structure(2, 1)

LOG = []
def say(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); LOG.append(s)


# ---------------------------------------------------------- model (as trained)
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co * 2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2) - x.size(-2); dx = skip.size(-1) - x.size(-1)
            x = F.pad(x, [dx // 2, dx - dx // 2, dy // 2, dy - dy // 2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b * 2), Down(b * 2, b * 4)
        self.d3, self.d4 = Down(b * 4, b * 8), Down(b * 8, b * 16)
        self.u1, self.u2 = Up(b * 16, b * 8), Up(b * 8, b * 4)
        self.u3, self.u4 = Up(b * 4, b * 2), Up(b * 2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)


# -------------------------------------------------------------------- data
def find(root, scene):
    return [f for f in sorted(glob.glob(str(Path(root) / "**" / "*.npz"), recursive=True))
            if scene in {p.lower() for p in Path(f).parts[:-1]}]


def read_full(path):
    with np.load(path, allow_pickle=True) as z:
        ks = list(z.keys()); ik = next((k for k in ("image", "img", "data", "x") if k in ks), ks[0])
        img = np.asarray(z[ik], dtype=np.float32)
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2, 0, 1))
    return np.nan_to_num(img)


def haze(x, b0, A, wl):
    """I = J t + A (1 - t), t = exp(-b0 (wl / 550)^-1.3) -- identical to every dump."""
    if b0 == 0.0: return x
    t = np.exp(-b0 * (np.asarray(wl, np.float64) / LAMBDA0) ** (-ALPHA)).astype(np.float32)
    if np.ndim(t): t = t[:, None, None]; A = np.asarray(A, np.float32)[:, None, None]
    return x * t + A * (1.0 - t)


def rule(b12, b8a):
    q = np.where(b8a > 1e-6, b12 / np.maximum(b8a, 1e-6), np.inf)
    seed = (b12 >= SEED[0]) & (q >= SEED[1]); cand = (b12 >= CAND[0]) & (q >= CAND[1])
    g = seed.copy()
    for _ in range(GROW):
        g |= ndimage.binary_dilation(g, CROSS) & cand
    return g


def auroc(score, pos):
    """P(score of a positive > score of a negative), ties half."""
    s = np.asarray(score, np.float64); p = np.asarray(pos, bool)
    if p.sum() == 0 or (~p).sum() == 0: return float("nan")
    u, inv = np.unique(s, return_inverse=True)
    P = np.bincount(inv, p.astype(float), len(u)); N = np.bincount(inv, (~p).astype(float), len(u))
    return float((P * (np.cumsum(N) - N + 0.5 * N)).sum() / (P.sum() * N.sum()))


def ceiling(z0, z1, pos):
    """Cross-fitted best possible readout of (z0, z1): error rate per quantile cell,
    learned on one half and scored on the other. Grid shrinks when errors are few."""
    nb = int(np.clip(np.sqrt(min(pos.sum(), (~pos).sum()) / 20), 6, 40))
    q0 = np.quantile(z0, np.linspace(0, 1, nb + 1)[1:-1]); q1 = np.quantile(z1, np.linspace(0, 1, nb + 1)[1:-1])
    cell = np.searchsorted(q0, z0) * nb + np.searchsorted(q1, z1)
    half = np.random.default_rng(7).random(cell.size) < 0.5; sc = np.empty(cell.size)
    for learn in (half, ~half):
        k = np.bincount(cell[learn], pos[learn].astype(float), nb * nb); n = np.bincount(cell[learn], minlength=nb * nb)
        sc[~learn] = np.where(n > 0, k / np.maximum(n, 1), pos[learn].mean())[cell[~learn]]
    return auroc(sc, pos)


def load_models():
    models = []
    for ck in sorted(glob.glob(str(Path(ROOT) / "**" / "best.pt"), recursive=True)):
        d = torch.load(ck, map_location=DEV, weights_only=False)
        if "agreement" not in str(d.get("labels", "")):
            say(f"  skipping {ck}: not an agreement-label checkpoint"); continue
        ns = Path(ck).parent / "norm_stats.npz"
        if not ns.exists():
            say(f"  skipping {ck}: no norm_stats.npz beside it"); continue
        z = np.load(ns); base = d["model"]["inc.block.0.weight"].shape[0]
        m = UNet(6, 2, base).to(DEV); m.load_state_dict(d["model"]); m.eval()
        name = f"network seed {d['seed']}"
        if any(x["name"] == name for x in models):        # e.g. a second run that kept SEED = 0
            name = f"{name} (run {sum(x['name'].startswith(name) for x in models) + 1})"
            say(f"  WARNING: another checkpoint with seed {d['seed']} -- labelled '{name}'. "
                f"Two runs with the SAME seed only show GPU randomness, not seed-to-seed variation.")
        models.append(dict(name=name, model=m, mean=z["mean"], std=z["std"],
                           scale=float(z["scale"]), epoch=d["epoch"]))
        say(f"  loaded {name} (best epoch {d['epoch']}) from {ck}")
    if not models:
        raise SystemExit("No agreement-label best.pt found -- attach both training notebooks' outputs.")
    return models


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    global ALPHA
    say(f"HAZE STRESS TEST   device {DEV}   beta0 = {BETAS}   Angstrom exponents alpha = {ALPHAS}")
    models = load_models()
    labels = {}
    for f in sorted(glob.glob(str(Path(ROOT) / "**" / "agreement_scene*.npz"), recursive=True)):
        if not any(Path(f).name == f"agreement_{sc}.npz" for sc in SCENES):
            continue                                   # scenes 1-2 are never scored here
        z = np.load(f, allow_pickle=True)
        L = z["label"]                                 # decompress ONCE (each z[...] re-reads the file)
        for i, nm in enumerate(z["files"]): labels[str(nm)] = L[i]
        say(f"  agreement labels loaded: {Path(f).name} ({len(L)} patches)")
    if not labels: raise SystemExit("No agreement labels found -- attach the label notebook's output.")
    scale = models[0]["scale"]; rows = []
    for ALPHA in ALPHAS:
        say(f"\n######################## ALPHA = {ALPHA}  "
            f"({'fine aerosol, as every dump' if ALPHA > 0 else 'grey haze: dims every band equally'}) ########################")
        for sc in SCENES:
            files = find(ROOT, sc)
            if MAXP: files = files[:MAXP]
            if not files: say(f"\n{sc}: no patches"); continue
            step = max(1, len(files) // A_SAMPLE)
            need = BAND_IDX + [I_B8A]                      # the eight bands used (B12 is already in BAND_IDX)
            samp = np.stack([read_full(f)[need] * scale for f in files[::step]])   # same patches as every dump
            A6 = np.percentile(samp[:, :6], 99, axis=(0, 2, 3))
            A8a = float(np.percentile(samp[:, 6], 99)); A12 = float(A6[5]); del samp
            say(f"\n==================== {sc}: {len(files)} patches ====================")
            say(f"  atmospheric light: six bands {np.round(A6, 4)}   B8A {A8a:.4f}   B12 {A12:.4f}")
            acc = {(b, n): np.zeros(7) for b in BETAS for n in ["rule"] + [m["name"] for m in models]}
            # logit samples among pixels CALLED background: every missed-fire pixel, a sample of correct background
            smp = {(b, m["name"], g): [] for b in BETAS for m in models for g in ("miss", "cbg")}
            miss_patches = {(b, m["name"]): set() for b in BETAS for m in models}
            rng = np.random.default_rng(11)
            for i in range(0, len(files), 4):
                chunk = files[i:i + 4]; raws = [read_full(f) * scale for f in chunk]
                lab = np.stack([labels[Path(f).name] for f in chunk]); v = lab != IGNORE
                fire, bg = (lab == 1) & v, (lab == 0) & v
                for b in BETAS:
                    hz12 = np.stack([haze(r[I_B12], b, A12, WL_B12) for r in raws])
                    hz8a = np.stack([haze(r[I_B8A], b, A8a, WL_B8A) for r in raws])
                    pr = np.stack([rule(hz12[k], hz8a[k]) for k in range(len(chunk))])
                    acc[(b, "rule")] += [(pr & fire).sum(), (pr & bg).sum(), (~pr & fire).sum(), 0, 0, 0, 0]
                    x6 = np.stack([haze(r[BAND_IDX], b, A6, WL6) for r in raws])
                    for m in models:
                        xn = (x6 - m["mean"][:, None, None]) / (m["std"][:, None, None] + 1e-6)
                        with torch.no_grad():
                            lg = m["model"](torch.from_numpy(xn).float().to(DEV)).float().cpu().numpy()
                        p = 1 / (1 + np.exp(-np.clip(lg[:, 1] - lg[:, 0], -60, 60))); pn = p > 0.5
                        miss, cbg = ~pn & fire, ~pn & bg
                        acc[(b, m["name"])] += [(pn & fire).sum(), (pn & bg).sum(), miss.sum(),
                                                p[pn & fire].sum(), (1 - p)[miss].sum(), cbg.sum(), (1 - p)[cbg].sum()]
                        z0, z1 = lg[:, 0], lg[:, 1]
                        if miss.any():
                            smp[(b, m["name"], "miss")].append(np.stack([z0[miss], z1[miss]]))
                            for k in np.flatnonzero(miss.reshape(len(chunk), -1).any(1)):
                                miss_patches[(b, m["name"])].add(i + int(k))
                        keep = cbg & (rng.random(cbg.shape) < BG_KEEP)
                        smp[(b, m["name"], "cbg")].append(np.stack([z0[keep], z1[keep]]))
            say(f"  {'beta0':>6}  {'method':<16}{'IoU':>8}{'precision':>11}{'recall':>9}"
                f"{'conf, detected fire':>22}{'conf, missed fire':>19}")
            for b in BETAS:
                for n in ["rule"] + [m["name"] for m in models]:
                    tp, fp, fn, cd, cm, nb_, cb = acc[(b, n)]
                    r = dict(alpha=ALPHA, scene=sc, beta0=b, method=n, iou=tp / max(tp + fp + fn, 1), precision=tp / max(tp + fp, 1),
                             recall=tp / max(tp + fn, 1),
                             conf_detected=(cd / tp if tp and n != "rule" else float("nan")),
                             conf_missed=(cm / fn if fn and n != "rule" else float("nan")),
                             conf_correct_bg=(cb / nb_ if nb_ and n != "rule" else float("nan")),
                             tp=int(tp), fp=int(fp), fn=int(fn),
                             patches_with_misses=len(miss_patches[(b, n)]) if n != "rule" else 0,
                             auroc_maxlogit=float("nan"), auroc_msp=float("nan"), ceiling=float("nan"),
                             median_h_missed=float("nan"), median_h_correct_bg=float("nan"))
                    if n != "rule" and smp[(b, n, "miss")]:
                        M = np.concatenate(smp[(b, n, "miss")], 1); C = np.concatenate(smp[(b, n, "cbg")], 1)
                        z0 = np.r_[M[0], C[0]]; z1 = np.r_[M[1], C[1]]
                        pos = np.r_[np.ones(M.shape[1], bool), np.zeros(C.shape[1], bool)]
                        h = np.maximum(z0, z1)                                   # = z0 for background calls
                        r.update(auroc_maxlogit=auroc(-h, pos), auroc_msp=auroc(-np.abs(z1 - z0), pos),
                                 ceiling=ceiling(z0, z1, pos) if pos.sum() >= 20 else float("nan"),
                                 median_h_missed=float(np.median(h[pos])), median_h_correct_bg=float(np.median(h[~pos])))
                    rows.append(r)
                    cdx = "" if n == "rule" else (f"{r['conf_detected']:.3f}" if tp else "--")
                    cmx = "" if n == "rule" else (f"{r['conf_missed']:.3f}" if fn else "--")
                    say(f"  {b:>6.1f}  {n:<16}{r['iou']:>8.4f}{r['precision']:>11.4f}{r['recall']:>9.4f}{cdx:>22}{cmx:>19}")
            say(f"\n  CAN A READOUT FIND THE MISSES?  (among pixels called background: missed fire vs correct background)")
            say(f"  {'beta0':>6}  {'model':<16}{'missed px':>10}{'patches':>9}{'conf missed':>13}{'conf corr bg':>14}"
                f"{'h missed':>10}{'h corr bg':>11}{'MaxLogit':>10}{'MSP':>7}{'ceiling':>9}")
            for r in [x for x in rows if x["alpha"] == ALPHA and x["scene"] == sc and x["method"] != "rule"]:
                if r["fn"] == 0:
                    say(f"  {r['beta0']:>6.1f}  {r['method']:<16}{0:>10}   -- no misses: nothing for a readout to find"); continue
                f = lambda k, w, d=3: f"{r[k]:>{w}.{d}f}" if np.isfinite(r[k]) else f"{'--':>{w}}"
                say(f"  {r['beta0']:>6.1f}  {r['method']:<16}{r['fn']:>10,}{r['patches_with_misses']:>9}{f('conf_missed', 13)}"
                    f"{f('conf_correct_bg', 14, 4)}{f('median_h_missed', 10, 2)}{f('median_h_correct_bg', 11, 2)}"
                    f"{f('auroc_maxlogit', 10)}{f('auroc_msp', 7)}{f('ceiling', 9)}")
            r0 = [r for r in rows if r["alpha"] == ALPHA and r["scene"] == sc and r["beta0"] == 0.0 and r["method"] == "rule"]
            if r0:
                ok = abs(r0[0]["iou"] - 1.0) < 1e-9
                say(f"  sanity check -- rule IoU at beta0 = 0 is {r0[0]['iou']:.6f}: "
                    f"{'PASS' if ok else 'FAIL -- the labels and the rule disagree; paste this output into the chat'}")

    with open(OUT / "stress_results.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    for al in ALPHAS:
        ra = [r for r in rows if r["alpha"] == al]
        if not ra: continue
        scs = [s for s in SCENES if any(r["scene"] == s for r in ra)]
        fig, ax = plt.subplots(1, len(scs), figsize=(6 * len(scs), 4.2), squeeze=False)
        for a, sc in zip(ax[0], scs):
            for n in ["rule"] + [m["name"] for m in models]:
                pts = [(r["beta0"], r["iou"]) for r in ra if r["scene"] == sc and r["method"] == n]
                a.plot(*zip(*pts), marker="o", lw=2 if n == "rule" else 1.5, ls="--" if n == "rule" else "-",
                       label="SWIR rule (made the labels)" if n == "rule" else n)
            a.set_title(f"{sc}, alpha {al}: IoU under synthetic haze"); a.set_xlabel("haze optical depth beta0 at 550 nm")
            a.set_ylabel("IoU against clear-image labels"); a.set_ylim(-0.02, 1.02); a.grid(alpha=0.3); a.legend(fontsize=8)
        fig.tight_layout(); fig.savefig(OUT / f"stress_iou_alpha{al}.png", dpi=110); plt.close(fig)
        fig, ax = plt.subplots(2, len(scs), figsize=(6 * len(scs), 7.6), squeeze=False)
        for j, sc in enumerate(scs):
            for m in models:
                R = [r for r in ra if r["scene"] == sc and r["method"] == m["name"] and r["fn"] > 0]
                if not R: continue
                bx = [r["beta0"] for r in R]
                ax[0][j].plot(bx, [r["conf_missed"] for r in R], marker="o", label=f"{m['name']}: missed fire")
                ax[0][j].plot([r["beta0"] for r in ra if r["scene"] == sc and r["method"] == m["name"]],
                              [r["conf_correct_bg"] for r in ra if r["scene"] == sc and r["method"] == m["name"]],
                              marker="s", ls="--", label=f"{m['name']}: correct background")
                ax[1][j].plot(bx, [r["auroc_maxlogit"] for r in R], marker="o", label=f"{m['name']}: MaxLogit")
                ax[1][j].plot(bx, [r["ceiling"] for r in R], marker="^", ls=":", label=f"{m['name']}: ceiling")
            ax[0][j].set_title(f"{sc}, alpha {al}: confidence in the 'background' call"); ax[0][j].set_ylim(0.45, 1.01)
            ax[1][j].axhline(0.5, color="grey", lw=1); ax[1][j].set_ylim(-0.02, 1.02)
            ax[1][j].set_title(f"{sc}, alpha {al}: missed fire vs correct background")
            for a in ax[:, j]:
                a.set_xlabel("haze optical depth beta0 at 550 nm"); a.grid(alpha=0.3); a.legend(fontsize=7)
            ax[1][j].set_ylabel("AUROC (0.5 = no signal)")
        fig.tight_layout(); fig.savefig(OUT / f"stress_readout_alpha{al}.png", dpi=110); plt.close(fig)
    say("\nHOW TO READ THIS")
    say("  The rule starts at IoU 1.0 by construction. Watch where each line falls.")
    say("  Network stays high after the rule drops -> it learned something sturdier than the rule.")
    say("  Both drop together -> the network learned essentially the rule.")
    say("  Confidence columns: if confidence on MISSED fire stays high while recall falls,")
    say("  the overconfidence problem has come back -- and a readout has work to do again.")
    say("  CAN A READOUT FIND THE MISSES: MaxLogit AUROC well above 0.5 (and below the")
    say("  ceiling) means missed fire looks different from correct background in the")
    say("  logits, so a readout fitted on hazed data could target it. Near 0.5 = no")
    say("  readout can. Check 'patches': misses in only a few patches make it noisy.")
    say("  MaxLogit far BELOW 0.5 means the misses look MORE confident than correct")
    say("  background: a height gate would point the wrong way, though the ceiling may")
    say("  show the logits still hold a (different) signal.")
    (OUT / "report.txt").write_text("\n".join(LOG))
    say(f"\nWrote {OUT}/stress_results.csv, report.txt, and per alpha: stress_iou_alpha*.png, stress_readout_alpha*.png")


if __name__ == "__main__":
    main()
