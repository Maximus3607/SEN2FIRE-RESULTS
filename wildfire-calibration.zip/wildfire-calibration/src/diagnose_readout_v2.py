r"""
DIAGNOSE why the gated readout lowered mean confidence toward accuracy on fire
pixels yet made ECE(fire) WORSE.

Measured on model B, beta0 = 0.20, fire pixels:
    identity  conf 0.8161  acc 0.4291   mean gap 0.387
    gated     conf 0.5149  acc 0.4291   mean gap 0.086   <- closer
but ECE(fire) went 0.396 -> 0.673                         <- worse
and AURC improved in 100% of replicates                   <- ranking is right

Those can only coexist if confidence is being lowered on the WRONG pixels within
the fire population. ECE bins by confidence, so what matters is not the mean but
WHICH pixels move.

THE HYPOTHESIS UNDER TEST
Fire pixels split into two groups with opposite needs:
    detected fire  (pred fire, correct)  accuracy 1 -> wants HIGH confidence
    missed fire    (pred bg,   wrong)    accuracy 0 -> wants LOW confidence
The BCE target was "the model is wrong here". But on this dataset recall was
only ~30-40%, so MOST fire pixels are errors. The gate may therefore have
learned "fire-like pixel -> abstain" rather than "error -> abstain", and be
pushing DETECTED fire down toward 0.5 while its accuracy is 1. That creates
large underconfidence gaps, which ECE punishes, even as the mean improves.

This prints each group separately, plus a reliability table, so the hypothesis
is confirmed or killed by the numbers rather than argued.

Usage:  python3 diagnose_readout.py gated_scene3_haze_0p20_logits.npz
"""

import sys
import numpy as np


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


def main(path):
    z = np.load(path)
    n = int(z["logits"].shape[0])
    ev = np.sort(np.random.default_rng(0).permutation(n)[n//2:])  # same split
    lg = z["logits"][ev].astype(np.float32)
    y = z["labels"][ev]
    if y.ndim == 4: y = y[:, 0]
    eta = z["null_logit"][ev].astype(np.float32)
    z0, z1 = lg[:, 0], lg[:, 1]
    s = 0.5 * (z0 + z1)

    # identity
    pf_i = sigmoid(z1 - z0); pb_i = 1 - pf_i
    # gated, log space
    m = np.maximum(np.maximum(z0, z1), eta)
    lse = m + np.log(np.exp(z0-m) + np.exp(z1-m) + np.exp(eta-m))
    pb_g, pf_g, pn_g = np.exp(z0-lse), np.exp(z1-lse), np.exp(eta-lse)

    pred = (z1 > z0)
    conf_i = np.where(pred, pf_i, pb_i)
    conf_g = np.where(pred, pf_g, pb_g)

    fire = y == 1
    det = fire & pred          # detected fire: correct
    mis = fire & ~pred         # missed fire: wrong
    bg_ok = (y == 0) & ~pred   # correct background
    fa = (y == 0) & pred       # false alarm

    print(f"{path}   beta0 = {float(z['beta0'])}\n")
    print("THE DECISIVE SPLIT -- fire pixels by outcome")
    print(f"  {'group':<22}{'pixels':>11}{'acc':>6}{'conf id':>10}"
          f"{'conf gated':>12}{'p(abst)':>10}{'mean s':>9}")
    for nm, g, acc in [("detected fire", det, 1.0), ("missed fire", mis, 0.0),
                       ("correct background", bg_ok, 1.0), ("false alarm", fa, 0.0)]:
        if g.sum() == 0: continue
        print(f"  {nm:<22}{int(g.sum()):>11,}{acc:>6.0f}{conf_i[g].mean():>10.4f}"
              f"{conf_g[g].mean():>12.4f}{pn_g[g].mean():>10.4f}{s[g].mean():>9.3f}")

    d_det = conf_i[det].mean() - conf_g[det].mean()
    d_mis = conf_i[mis].mean() - conf_g[mis].mean()
    print(f"\n  confidence REMOVED by the gate:  detected fire {d_det:.4f}   "
          f"missed fire {d_mis:.4f}")
    print(f"  ratio missed/detected = {d_mis/max(d_det,1e-9):.2f}  "
          "(want >> 1: the gate should hit errors, spare detections)")

    print("\nRELIABILITY on fire pixels (10 bins). Each row: pixels, accuracy, mean conf.")
    e = np.linspace(0, 1, 11)
    for nm, conf in [("identity", conf_i), ("gated", conf_g)]:
        print(f"  {nm}")
        c, a = conf[fire], (pred[fire] == 1).astype(np.float32)
        for i in range(10):
            sel = (c > e[i]) & (c <= e[i+1])
            if sel.sum() == 0: continue
            print(f"    [{e[i]:.1f},{e[i+1]:.1f}]  {int(sel.sum()):>9,}  "
                  f"acc {a[sel].mean():.3f}  conf {c[sel].mean():.3f}  "
                  f"gap {c[sel].mean()-a[sel].mean():+.3f}")

    print("\nHOW TO READ THIS")
    print("  If 'confidence removed' is similar for detected and missed fire, the")
    print("  gate is NOT separating errors from successes WITHIN the fire class --")
    print("  it has learned 'fire -> abstain'. Detected fire then lands at low")
    print("  confidence with accuracy 1, and ECE punishes the underconfidence.")
    print("  The 'mean s' column shows why: if detected and missed fire have similar")
    print("  logit sums, the gate reading s cannot tell them apart.")
    print("  If the ratio is >> 1 and ECE still worsened, the cause is elsewhere --")
    print("  look for a bin where accuracy and confidence cross in the reliability")
    print("  table.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__); sys.exit(1)
    main(sys.argv[1])
