r"""
HAZE READOUTS -- with clean labels, can a readout fix the overconfidence that haze brings back?

The stress test showed: under heavy haze the agreement-trained networks miss
fire while staying 85-100% confident there is none -- yet MaxLogit separates
those misses from correct background almost perfectly (AUROC 0.98-1.00). So a
readout has real work to do. This script fits readouts on HAZED data and
measures what they achieve.

FITTING (scene 3, held-in half -- the same split as every earlier run)
  clear     fitted at beta0 = 0, as every earlier readout was. Expected to switch
            off: there are no errors to learn from at zero haze.
  mixture   fitted once on all haze levels pooled. THE REALISTIC REGIME: an
            operator does not know the haze level in advance.
  matched   fitted separately at each haze level -- an upper bound, as if the
            haze level were known (e.g. from an aerosol measurement).

READOUTS
  softmax                       nothing fitted
  temperature (clear / mixture) one temperature, by weighted NLL
  class-cond T (mixture)        one temperature per predicted class
  height gate, ECE fit (clear / mixture)
        eta = c + k*sigmoid(gamma_c (tau_c - h)), h = predicted class's logit;
        c, k, gamma as in every earlier run; tau per predicted class chosen by
        the ORIGINAL objective, true-fire ECE + true-background ECE
  height gate, Brier fit (mixture / matched)
        the same gate, tau chosen by the proper confidence Brier score
        mean (confidence - correct)^2 -- no bins to fool
Fitting samples keep every fire pixel and 0.4% of clean background, with
weights restoring the true proportions, so fits see the real class balance.

SCORING (scene 3 held-out half, all of scene 4) at every haze level and both
haze types, for every network: confidence Brier (primary -- proper, bin-free),
true-fire / true-background / predicted-fire ECE, confidence on detected fire,
missed fire and correct background, the gate's selectivity (abstention on
missed fire / on correct background), and its abstention on IGNORED pixels --
the ambiguous ones next to fires that scoring otherwise skips. High abstention
there is a hidden cost.
Paired patch bootstrap (500 replicates) for the key comparisons.

KAGGLE SETUP -- inputs exactly as the stress test:
  Sen2Fire; the agreement-label notebook's output; both training outputs.
  Accelerator GPU T4.  Save Version -> Save & Run All.  Roughly 1-1.5 hours.
OUTPUT (/kaggle/working/haze_readouts/)
  report.txt, readout_results.csv, readout_cis.csv,
  readouts_alpha<a>.png (one per haze type)
"""

import os, glob, csv
from pathlib import Path
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F

ROOT = os.environ.get("HR_ROOT", "/kaggle/input")
OUT = Path(os.environ.get("HR_OUT", "/kaggle/working/haze_readouts"))
BETAS = [float(b) for b in os.environ.get("HR_BETAS", "0,0.5,1,1.5,2,3,4").split(",")]
ALPHAS = [float(a) for a in os.environ.get("HR_ALPHAS", "1.3,0.0").split(",")]
BOOT = int(os.environ.get("HR_BOOT", 500))
MAXP = int(os.environ.get("HR_MAXP", 0))
DEV = "cuda" if torch.cuda.is_available() else "cpu"
BAND_IDX = [3, 2, 1, 7, 10, 11]
WL6 = np.array([665., 560., 490., 842., 1610., 2190.])
LAMBDA0, A_SAMPLE, IGNORE, NB = 550.0, 120, 255, 20
FIX_C, FIX_K, FIX_G = -5.658, 8.486, 2.751
BG_RATE = 0.004
READOUTS = ["softmax", "temperature (clear)", "temperature (mixture)", "class-cond T (mixture)",
            "gate ECE-fit (clear)", "gate ECE-fit (mixture)", "gate Brier-fit (mixture)", "gate Brier-fit (matched)"]
KEY = "gate Brier-fit (mixture)"

LOG = []
def say(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); LOG.append(s)


# ------------------------------------------------------------- network
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co * 2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2) - x.size(-2); dx = skip.size(-1) - x.size(-1)
            x = F.pad(x, [dx // 2, dx - dx // 2, dy // 2, dy - dy // 2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b * 2), Down(b * 2, b * 4)
        self.d3, self.d4 = Down(b * 4, b * 8), Down(b * 8, b * 16)
        self.u1, self.u2 = Up(b * 16, b * 8), Up(b * 8, b * 4)
        self.u3, self.u4 = Up(b * 4, b * 2), Up(b * 2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)


# ---------------------------------------------------------------- data
def find(root, scene):
    return [f for f in sorted(glob.glob(str(Path(root) / "**" / "*.npz"), recursive=True))
            if scene in {p.lower() for p in Path(f).parts[:-1]}]


def read6(path):
    with np.load(path, allow_pickle=True) as z:
        ks = list(z.keys()); ik = next((k for k in ("image", "img", "data", "x") if k in ks), ks[0])
        img = np.asarray(z[ik], dtype=np.float32)
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2, 0, 1))
    return np.nan_to_num(img[BAND_IDX])


def haze(x, b0, A, alpha):
    if b0 == 0.0: return x
    t = np.exp(-b0 * (WL6 / LAMBDA0) ** (-alpha)).astype(np.float32)[:, None, None]
    return x * t + A[:, None, None] * (1.0 - t)


def load_models():
    out = []
    for ck in sorted(glob.glob(str(Path(ROOT) / "**" / "best.pt"), recursive=True)):
        d = torch.load(ck, map_location=DEV, weights_only=False)
        if "agreement" not in str(d.get("labels", "")): continue
        ns = Path(ck).parent / "norm_stats.npz"
        if not ns.exists(): continue
        z = np.load(ns); base = d["model"]["inc.block.0.weight"].shape[0]
        m = UNet(6, 2, base).to(DEV); m.load_state_dict(d["model"]); m.eval()
        name = f"seed {d['seed']}"
        if any(x["name"] == name for x in out):
            name += f" (run {sum(x['name'].startswith(name) for x in out) + 1})"
            say(f"  WARNING: two checkpoints share seed {d['seed']} -- same-seed runs show only GPU randomness")
        out.append(dict(name=name, model=m, mean=z["mean"], std=z["std"], scale=float(z["scale"])))
        say(f"  loaded network {name} (best epoch {d['epoch']}) from {ck}")
    if not out: raise SystemExit("No agreement-label best.pt found -- attach the training outputs.")
    return out


@torch.no_grad()
def logits(m, x6):
    xn = (x6 - m["mean"][:, None, None]) / (m["std"][:, None, None] + 1e-6)
    return m["model"](torch.from_numpy(xn).float().to(DEV)).float().cpu().numpy()


# ------------------------------------------------------------- readouts
def sig(x): return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


def three(z0, z1, eta):
    m = np.maximum(np.maximum(z0, z1), eta)
    a, b, c = np.exp(z0 - m), np.exp(z1 - m), np.exp(eta - m); Z = a + b + c
    return a / Z, b / Z, c / Z


def apply(rd, z0, z1):
    """-> (p_bg, p_fire, p_abstain). The prediction is always argmax(z0, z1)."""
    g = z1 - z0; pred = g > 0
    if rd is None or rd["kind"] == "softmax":
        pf = sig(g); return 1 - pf, pf, np.zeros_like(pf)
    if rd["kind"] == "T":
        pf = sig(g / rd["T"]); return 1 - pf, pf, np.zeros_like(pf)
    if rd["kind"] == "ccT":
        pf = sig(g / np.where(pred, rd["T"][1], rd["T"][0])); return 1 - pf, pf, np.zeros_like(pf)
    if all(t is None for t in rd["tau"]):                  # gate fully off == softmax, exactly
        pf = sig(g); return 1 - pf, pf, np.zeros_like(pf)
    h = np.maximum(z0, z1); eta = np.full(z0.shape, -1e4)
    for c in (0, 1):
        t = rd["tau"][c]
        if t is None: continue
        m = pred == bool(c); eta[m] = FIX_C + FIX_K * sig(rd["gam"][c] * (t - h[m]))
    return three(z0, z1, eta)


def wece(conf, corr, w):
    if conf.size == 0: return 0.0
    b = np.clip((conf * NB).astype(int), 0, NB - 1)
    return float(np.abs(np.bincount(b, w * corr, NB) - np.bincount(b, w * conf, NB)).sum() / max(w.sum(), 1e-12))


def fit(kind, S, obj=None):
    z0, z1, y, w = S["z0"], S["z1"], S["y"].astype(bool), S["w"]
    g = z1 - z0; pred = g > 0; corr = (pred == y).astype(np.float64)
    def nll(T, m):
        p = np.clip(sig(g[m] / T), 1e-12, 1 - 1e-12); yy = y[m]
        return -(w[m] * np.where(yy, np.log(p), np.log(1 - p))).sum() / max(w[m].sum(), 1e-12)
    Ts = np.exp(np.linspace(-4, 4, 161))
    if kind == "T":
        return dict(kind="T", T=float(min(Ts, key=lambda T: nll(T, np.ones_like(y)))))
    if kind == "ccT":
        return dict(kind="ccT", T=[float(min(Ts, key=lambda T: nll(T, pred == bool(c)))) if (pred == bool(c)).any() else 1.0
                                   for c in (0, 1)])
    h = np.maximum(z0, z1); s = 0.5 * (z0 + z1)
    gam = [FIX_G * (s[pred == bool(c)].std() + 1e-6) / (h[pred == bool(c)].std() + 1e-6) if (pred == bool(c)).sum() > 1 else FIX_G
           for c in (0, 1)]
    grid = [[None] + (list(np.quantile(h[pred == bool(c)], np.linspace(0.02, 0.98, 25))) if (pred == bool(c)).any() else [])
            for c in (0, 1)]
    def score(tau):
        pb, pf, pn = apply(dict(kind="gate", tau=tau, gam=gam), z0, z1)
        conf = np.where(pred, pf, pb)
        if obj == "brier": return float((w * (conf - corr) ** 2).sum() / w.sum())
        return wece(conf[y], corr[y], w[y]) + wece(conf[~y], corr[~y], w[~y])
    best = min(((a, b) for a in grid[0] for b in grid[1]), key=lambda t: score(list(t)))
    return dict(kind="gate", tau=list(best), gam=gam)


def describe(rd):
    edge = lambda T: "  <-- AT THE EDGE of the search range" if min(T, 1 / T) < np.exp(-3.95) else ""
    if rd["kind"] == "softmax": return "--"
    if rd["kind"] == "T": return f"T={rd['T']:.3f}{edge(rd['T'])}"
    if rd["kind"] == "ccT": return f"T bg={rd['T'][0]:.3f} fire={rd['T'][1]:.3f}{edge(rd['T'][0]) or edge(rd['T'][1])}"
    f = lambda t: "OFF" if t is None else f"{t:+.2f}"
    return f"tau bg={f(rd['tau'][0])} fire={f(rd['tau'][1])}"


# --------------------------------------------------------- statistics
F_BIN = 3 * NB
F_TOT = 3 * F_BIN + 2 + 13

def patch_stats(pb, pf, pn, z0, z1, lab):
    """One row of sufficient statistics for a single patch."""
    pred = z1 > z0; v = lab != IGNORE; y = lab == 1
    conf = np.where(pred, pf, pb); corr = (pred == y).astype(np.float64)
    row = np.zeros(F_TOT); o = 0
    for m in (v & y, v & ~y, v & pred):                    # true fire, true bg, predicted fire
        c, k = conf[m], corr[m]; b = np.clip((c * NB).astype(int), 0, NB - 1)
        row[o:o + NB] = np.bincount(b, minlength=NB); row[o + NB:o + 2 * NB] = np.bincount(b, c, NB)
        row[o + 2 * NB:o + 3 * NB] = np.bincount(b, k, NB); o += F_BIN
    row[o] = ((conf - corr)[v] ** 2).sum(); row[o + 1] = v.sum(); o += 2
    for m in (v & pred & y, v & pred & ~y):                 # detected, false alarm
        row[o] = m.sum(); row[o + 1] = conf[m].sum(); o += 2
    for m in (v & ~pred & y, v & ~pred & ~y):               # missed, correct background
        row[o] = m.sum(); row[o + 1] = conf[m].sum(); row[o + 2] = pn[m].sum(); o += 3
    ig = ~v; row[o] = ig.sum(); row[o + 1] = pn[ig].sum(); row[o + 2] = 0
    return row


def metrics(V):
    """Vectorised over the first axis. V: (B, F_TOT)."""
    B = V.shape[0]; out = {}
    def ece(o):
        n, c, k = V[:, o:o + NB], V[:, o + NB:o + 2 * NB], V[:, o + 2 * NB:o + 3 * NB]
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.abs(k - c).sum(1) / n.sum(1)
    out["true-fire ECE"], out["true-bg ECE"], out["pred-fire ECE"] = ece(0), ece(F_BIN), ece(2 * F_BIN)
    o = 3 * F_BIN
    with np.errstate(invalid="ignore", divide="ignore"):
        out["conf Brier"] = V[:, o] / V[:, o + 1]; o += 2
        out["conf detected"] = V[:, o + 1] / V[:, o]; o += 2
        out["conf false alarm"] = V[:, o + 1] / V[:, o]; o += 2
        out["missed px"] = V[:, o]; out["conf missed"] = V[:, o + 1] / V[:, o]; am = V[:, o + 2] / V[:, o]; o += 3
        out["conf correct bg"] = V[:, o + 1] / V[:, o]; ab = V[:, o + 2] / V[:, o]; o += 3
        out["selectivity"] = am / ab
        out["abstain ignored"] = V[:, o + 1] / V[:, o]
    return out


# ------------------------------------------------------------------ main
def main():
    OUT.mkdir(parents=True, exist_ok=True)
    say(f"HAZE READOUTS   device {DEV}   beta0 = {BETAS}   alpha = {ALPHAS}   bootstrap {BOOT}")
    models = load_models()
    labels = {}
    for sc in ("scene3", "scene4"):
        f = next(iter(glob.glob(str(Path(ROOT) / "**" / f"agreement_{sc}.npz"), recursive=True)), None)
        if f is None: raise SystemExit(f"agreement_{sc}.npz not found -- attach the label notebook's output.")
        z = np.load(f, allow_pickle=True); L = z["label"]                 # decompress ONCE
        for i, nm in enumerate(z["files"]): labels[str(nm)] = L[i]
        say(f"  agreement labels loaded: {Path(f).name}")
    files = {sc: find(ROOT, sc) for sc in ("scene3", "scene4")}
    if MAXP: files = {k: v[:MAXP] for k, v in files.items()}
    n3 = len(files["scene3"]); perm = np.random.default_rng(0).permutation(n3)     # SAME split as every run
    held_in, held_out = np.sort(perm[:n3 // 2]), np.sort(perm[n3 // 2:])
    scale = models[0]["scale"]
    A = {}
    for sc, fl in files.items():
        step = max(1, len(fl) // A_SAMPLE)
        A[sc] = np.percentile(np.stack([read6(f) * scale for f in fl[::step]]), 99, axis=(0, 2, 3))
        say(f"  {sc}: {len(fl)} patches   atmospheric light {np.round(A[sc], 4)}")

    # ---------------- pass A: fitting samples from scene 3's held-in half ----------------
    say("\nPASS A: collecting fitting samples (scene 3, held-in half) ...")
    rng = np.random.default_rng(5)
    S = {(m["name"], a, b): {k: [] for k in ("z0", "z1", "y", "w")} for m in models for a in ALPHAS for b in BETAS}
    fl = files["scene3"]
    for s0 in range(0, len(held_in), 4):
        sel = held_in[s0:s0 + 4]; raws = [read6(fl[i]) * scale for i in sel]
        lab = np.stack([labels[Path(fl[i]).name] for i in sel]); v = lab != IGNORE
        keep = v & ((lab == 1) | (rng.random(lab.shape) < BG_RATE))
        wt = np.where(lab == 1, 1.0, 1.0 / BG_RATE)[keep]
        for a in ALPHAS:
            for b in BETAS:
                if a != ALPHAS[0] and b == 0.0: continue                       # beta0 = 0 is the same for every alpha
                x6 = np.stack([haze(r, b, A["scene3"], a) for r in raws])
                for m in models:
                    lg = logits(m, x6); d = S[(m["name"], a, b)]
                    d["z0"].append(lg[:, 0][keep]); d["z1"].append(lg[:, 1][keep])
                    d["y"].append((lab == 1)[keep]); d["w"].append(wt)
    S = {k: {kk: np.concatenate(vv) for kk, vv in d.items()} for k, d in S.items() if d["z0"]}
    for m in models:
        for a in ALPHAS[1:]:
            S[(m["name"], a, 0.0)] = S[(m["name"], ALPHAS[0], 0.0)]

    # ---------------- fitting ----------------
    say("\nFITTING")
    R = {}
    for m in models:
        for a in ALPHAS:
            clear = S[(m["name"], a, 0.0)]
            mix = {k: np.concatenate([S[(m["name"], a, b)][k] for b in BETAS]) for k in ("z0", "z1", "y", "w")}
            base = {"softmax": dict(kind="softmax"), "temperature (clear)": fit("T", clear),
                    "temperature (mixture)": fit("T", mix), "class-cond T (mixture)": fit("ccT", mix),
                    "gate ECE-fit (clear)": fit("gate", clear, "ece"), "gate ECE-fit (mixture)": fit("gate", mix, "ece"),
                    "gate Brier-fit (mixture)": fit("gate", mix, "brier")}
            for b in BETAS:
                R[(m["name"], a, b)] = dict(base, **{"gate Brier-fit (matched)": fit("gate", S[(m["name"], a, b)], "brier")})
            say(f"  {m['name']}, alpha {a}:")
            for nm, rd in base.items():
                if nm != "softmax": say(f"    {nm:<26} {describe(rd)}")
            say("    gate Brier-fit (matched)   " + "   ".join(
                f"b{b:g}: {describe(R[(m['name'], a, b)]['gate Brier-fit (matched)'])}" for b in BETAS))

    # ---------------- pass B: scoring ----------------
    say("\nPASS B: scoring (scene 3 held-out half, all of scene 4) ...")
    ST = {}
    for sc, idx in (("scene3", held_out), ("scene4", np.arange(len(files["scene4"])))):
        fl = files[sc]
        for s0 in range(0, len(idx), 4):
            sel = idx[s0:s0 + 4]; raws = [read6(fl[i]) * scale for i in sel]
            labs = [labels[Path(fl[i]).name] for i in sel]
            for a in ALPHAS:
                for b in BETAS:
                    x6 = np.stack([haze(r, b, A[sc], a) for r in raws])
                    for m in models:
                        lg = logits(m, x6)
                        for nm in READOUTS:
                            rd = R[(m["name"], a, b)][nm]
                            for k in range(len(sel)):
                                z0, z1 = lg[k, 0], lg[k, 1]; pb, pf, pn = apply(rd, z0, z1)
                                ST.setdefault((m["name"], a, sc, b, nm), []).append(patch_stats(pb, pf, pn, z0, z1, labs[k]))
        say(f"  scored {sc}")
    ST = {k: np.stack(v) for k, v in ST.items()}

    # ---------------- results ----------------
    rows, cis = [], []
    brng = np.random.default_rng(3)
    for m in models:
        for a in ALPHAS:
            for sc in ("scene3", "scene4"):
                P = ST[(m["name"], a, sc, BETAS[0], "softmax")].shape[0]
                Wt = np.stack([np.bincount(brng.integers(0, P, P), minlength=P) for _ in range(BOOT)]).astype(np.float64)
                for b in BETAS:
                    pts, bts = {}, {}
                    for nm in READOUTS:
                        M = ST[(m["name"], a, sc, b, nm)]
                        pts[nm] = {k: float(v[0]) for k, v in metrics(M.sum(0)[None]).items()}
                        bts[nm] = metrics(Wt @ M)
                        rows.append(dict(model=m["name"], alpha=a, scene=sc, beta0=b, readout=nm, **pts[nm]))
                    for ref in ("softmax", "class-cond T (mixture)"):
                        for met in ("conf Brier", "true-fire ECE", "true-bg ECE"):
                            d = bts[KEY][met] - bts[ref][met]; d = d[np.isfinite(d)]
                            if d.size == 0: continue
                            d = np.where(np.abs(d) < 1e-6, 0.0, d)              # rounding noise is not an effect
                            lo, hi = np.percentile(d, [2.5, 97.5])
                            cis.append(dict(model=m["name"], alpha=a, scene=sc, beta0=b, readout=KEY, reference=ref,
                                            metric=met, diff=pts[KEY][met] - pts[ref][met], ci_low=lo, ci_high=hi,
                                            significant=bool(hi < 0 or lo > 0)))
    for name, data in (("readout_results.csv", rows), ("readout_cis.csv", cis)):
        with open(OUT / name, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(data[0].keys())); w.writeheader(); w.writerows(data)

    show = ["softmax", "temperature (mixture)", "class-cond T (mixture)", "gate ECE-fit (clear)",
            "gate ECE-fit (mixture)", "gate Brier-fit (mixture)", "gate Brier-fit (matched)"]
    short = ["softmax", "T mix", "ccT mix", "gateECE clr", "gateECE mix", "gateBr mix", "gateBr mtch"]
    get = lambda m, a, sc, b, nm, k: next(r[k] for r in rows if r["model"] == m and r["alpha"] == a
                                          and r["scene"] == sc and r["beta0"] == b and r["readout"] == nm)
    fmt = lambda v, d=4: f"{v:.{d}f}" if np.isfinite(v) else "--"
    for a in ALPHAS:
        say(f"\n######################## ALPHA = {a} ########################")
        for sc in ("scene3", "scene4"):
            for m in models:
                say(f"\n  [{sc} | {m['name']}]")
                for met in ("conf Brier", "true-fire ECE"):
                    say(f"    {met} (lower = better)")
                    say("    " + f"{'beta0':>6}" + "".join(f"{s:>13}" for s in short))
                    for b in BETAS:
                        say("    " + f"{b:>6.1f}" + "".join(f"{fmt(get(m['name'], a, sc, b, nm, met)):>13}" for nm in show))
                say(f"    {KEY}: what it does to each kind of pixel")
                say("    " + f"{'beta0':>6}{'missed px':>11}{'conf missed':>13}{'(softmax)':>11}{'conf corr bg':>14}"
                    f"{'conf detected':>15}{'selectivity':>13}{'abstain ignored':>17}")
                for b in BETAS:
                    g = lambda k, nm=KEY: get(m["name"], a, sc, b, nm, k)
                    say("    " + f"{b:>6.1f}{int(g('missed px')):>11,}{fmt(g('conf missed'), 3):>13}"
                        f"{fmt(g('conf missed', 'softmax'), 3):>11}{fmt(g('conf correct bg')):>14}"
                        f"{fmt(g('conf detected')):>15}{fmt(g('selectivity'), 1):>13}{fmt(g('abstain ignored')):>17}")
                say(f"    {KEY} MINUS reference, 95% CI (* = excludes 0; negative = gate better)")
                for b in BETAS:
                    cs = [c for c in cis if c["model"] == m["name"] and c["alpha"] == a and c["scene"] == sc and c["beta0"] == b]
                    say("    " + f"{b:>6.1f}  " + "   ".join(
                        f"{'vs softmax' if c['reference'] == 'softmax' else 'vs ccT'} {c['metric']}: {c['diff']:+.5f}"
                        f"{'*' if c['significant'] else ''}" for c in cs if c["metric"] != "true-bg ECE"))

    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    for a in ALPHAS:
        fig, ax = plt.subplots(2, 2, figsize=(12, 8.4))
        for j, sc in enumerate(("scene3", "scene4")):
            for i, met in enumerate(("conf Brier", "true-fire ECE")):
                for nm, st in (("softmax", "-"), ("class-cond T (mixture)", "-."), ("gate ECE-fit (mixture)", ":"),
                               ("gate Brier-fit (mixture)", "-"), ("gate Brier-fit (matched)", "--")):
                    for k, m in enumerate(models):
                        ys = [get(m["name"], a, sc, b, nm, met) for b in BETAS]
                        ax[i][j].plot(BETAS, ys, ls=st, marker="o" if k == 0 else "^", ms=4, alpha=1 if k == 0 else 0.55,
                                      lw=2 if nm == KEY else 1.3, label=f"{nm}" + (f" ({m['name']})" if len(models) > 1 else ""))
                ax[i][j].set_title(f"{sc}, alpha {a}: {met}"); ax[i][j].set_xlabel("haze optical depth beta0 at 550 nm")
                ax[i][j].grid(alpha=0.3)
        ax[0][0].legend(fontsize=6, ncol=2)
        fig.tight_layout(); fig.savefig(OUT / f"readouts_alpha{a}.png", dpi=110); plt.close(fig)

    say("\nHOW TO READ THIS")
    say("  conf Brier is the primary measure: proper, with no bins to fool.")
    say("  The realistic readout is the MIXTURE fit -- the haze level is unknown in practice.")
    say("  'clear' fits should switch off: no errors at zero haze to learn from.")
    say("  A real success needs ALL of: lower conf Brier than softmax, lower confidence on")
    say("  missed fire, correct-background and detected confidence staying near 1, high")
    say("  selectivity, and low abstention on IGNORED pixels (a hidden cost otherwise).")
    say("  Compare with class-cond T: if two temperatures match the gate, abstention adds nothing.")
    (OUT / "report.txt").write_text("\n".join(LOG))
    say(f"\nWrote {OUT}/report.txt, readout_results.csv, readout_cis.csv, readouts_alpha*.png")


if __name__ == "__main__":
    main()
