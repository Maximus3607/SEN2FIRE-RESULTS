"""
FULL HAZE SWEEP: dump logits for scene4 at graded atmospheric severities.

This replaces haze_check.py. The check answered "does smoke shift this model?"
-- it does, dramatically. This produces the data the calibration study runs on.

WHAT THE CHECK FOUND (24 patches)
  beta0   IoU     acc|fire   conf|fire
  0.00    0.0376   0.038      0.9689
  0.20    0.0355   0.036      0.9696
  0.50    0.0247   0.025      0.9743
  1.00    0.0002   0.0002     0.9833
  2.00    0.0000   0.0000     0.9912

  Accuracy on fire collapses to zero while confidence RISES. Textbook
  overconfidence under covariate shift. Note that SWIR2 still transmits 72% at
  beta0=2.0 -- surviving SWIR was not enough, because corrupting the visible
  bands breaks the inter-band relationships the network learned, and per-band
  standardisation (std ~0.04-0.09) amplifies the shift before it reaches the
  first conv.

TWO CHANGES FROM THE CHECK

1. SEVERITY GRID MOVED TO 0.0-0.5.
   At beta0 >= 1.0 accuracy is zero, so the only honest confidence is "I know
   nothing" and every calibrator converges on the same uninformative answer --
   no signal to distinguish methods. The usable window is where the model still
   has predictive signal AND is degrading measurably. Two points above the
   window are kept so the collapse is visible in the figure.

2. ALL 504 PATCHES, NOT 24.
   The check reported clear-condition IoU 0.0376 against 0.1997 on the full
   test set from the same checkpoint. Metrics pool TP/FP/FN globally, so a few
   patches with large well-detected fire regions dominate, and a 24-patch draw
   can miss them. Absolute numbers from a subsample are not trustworthy.

OUTPUT
  One npz per severity: logits, labels, aerosol, haze_cue, plus the beta0 and
  alpha used. Feed them to calibrate.py exactly like the clean dumps. The haze
  cue is RECOMPUTED from the hazed reflectance, because that is what a
  deployed calibrator would see -- computing it from clean bands would leak
  information no real system has.

Kaggle: attach Sen2Fire AND the training version's output. GPU T4. ~30 min.
"""

import glob, time
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# ------------------------------------------------------------------ config
DATA_ROOT = "/kaggle/input"
OUT_DIR   = Path("/kaggle/working")
N_PATCHES = None                     # None = all 504
BAND_IDX  = [3, 2, 1, 7, 10, 11]     # R, G, B, NIR, SWIR1, SWIR2
WAVELEN   = np.array([665., 560., 490., 842., 1610., 2190.])
LAMBDA0   = 550.0
ALPHA     = 1.3                      # biomass-burning Angstrom exponent
# usable window, plus two points past the collapse for the figure
BETAS     = [0.0, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 1.00, 2.00]
BATCH     = 4
IN_CH, OUT_CH, BASE = 6, 2, 64
SEL_RED, SEL_NIR, SEL_SWIR1, SEL_SWIR2 = 0, 3, 4, 5   # within the 6-band stack

DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT_DIR.mkdir(parents=True, exist_ok=True)
print("device:", DEV)


# ------------------------------------------------------------------- model
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co*2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2)-x.size(-2); dx = skip.size(-1)-x.size(-1)
            x = F.pad(x, [dx//2, dx-dx//2, dy//2, dy-dy//2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b*2), Down(b*2, b*4)
        self.d3, self.d4 = Down(b*4, b*8), Down(b*8, b*16)
        self.u1, self.u2 = Up(b*16, b*8), Up(b*8, b*4)
        self.u3, self.u4 = Up(b*4, b*2), Up(b*2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)


# -------------------------------------------------------------------- haze
def transmission(beta0, alpha=ALPHA):
    """Angstrom turbidity -> Beer-Lambert. One value per band, shape (6,1,1).

    d = 1: a satellite views a fixed atmospheric column at near-nadir, so path
    length is constant and folds into beta0 -- which is why beta0 reads
    directly as aerosol optical depth at 550 nm.
    """
    beta = beta0 * (WAVELEN / LAMBDA0) ** (-alpha)
    return np.exp(-beta).astype(np.float32)[:, None, None]


def apply_haze(img, beta0, A, alpha=ALPHA):
    """Koschmieder scattering, per band, on RAW reflectance."""
    if beta0 == 0.0:
        return img                                   # must be bit-identical
    t = transmission(beta0, alpha)
    return img * t + A[:, None, None] * (1.0 - t)


def _nd(a, b, eps=1e-6):
    return (a - b) / (a + b + eps)


def haze_cue(img):
    """Visible-vs-SWIR divergence, from whatever reflectance is passed in.

    Smoke attenuates visible far more than SWIR, so an NDVI-based index and
    SWIR-based ones diverge exactly where the visible signal is compromised.
    Computed on the HAZED bands here: a deployed calibrator has no access to
    the clean image, and using it would leak information.
    """
    ndvi = _nd(img[SEL_NIR], img[SEL_RED])
    nbr  = _nd(img[SEL_NIR], img[SEL_SWIR2])
    nbr2 = _nd(img[SEL_SWIR1], img[SEL_SWIR2])
    cue = 0.5*np.abs(ndvi - nbr) + 0.5*np.abs(ndvi - nbr2)
    return np.nan_to_num(cue).astype(np.float32)[None]


# -------------------------------------------------------------------- data
def find_scene(root, scene):
    return [f for f in sorted(glob.glob(str(Path(root)/"**"/"*.npz"), recursive=True))
            if scene in {p.lower() for p in Path(f).parts[:-1]}]


def load_patch(path, scale):
    z = np.load(path, allow_pickle=True)
    ks = list(z.keys())
    ik = next((k for k in ("image","img","data","x") if k in ks), ks[0])
    lk = next((k for k in ("label","mask","gt","y") if k in ks), ks[-1])
    ak = next((k for k in ("aerosol","s5p","aod") if k in ks), None)
    img = np.asarray(z[ik], dtype=np.float32)
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2, 0, 1))
    lab = np.asarray(z[lk])
    if lab.ndim == 3: lab = lab[0]
    aer = np.asarray(z[ak], dtype=np.float32) if ak else np.zeros(lab.shape, np.float32)
    if aer.ndim == 2: aer = aer[None]
    return (np.nan_to_num(img[BAND_IDX]) * scale,
            (lab > 0).astype(np.uint8), np.nan_to_num(aer))


# -------------------------------------------------------------------- main
def main():
    files = find_scene(DATA_ROOT, "scene4")
    assert files, "no scene4 patches found under /kaggle/input"
    if N_PATCHES:
        files = files[:N_PATCHES]
    print(f"{len(files)} scene4 patches")

    sp = glob.glob(str(Path(DATA_ROOT)/"**"/"norm_stats.npz"), recursive=True)
    assert sp, "norm_stats.npz not found -- attach the training output"
    zs = np.load(sp[0]); MEAN, STD, SCALE = zs["mean"], zs["std"], float(zs["scale"])

    cp = glob.glob(str(Path(DATA_ROOT)/"**"/"best.pt"), recursive=True)
    assert cp, "best.pt not found -- attach the training output"
    ck = torch.load(cp[0], map_location=DEV, weights_only=False)
    model = UNet(IN_CH, OUT_CH, BASE).to(DEV)
    model.load_state_dict(ck["model"]); model.eval()
    print(f"loaded {cp[0]} (epoch {ck.get('epoch','?')})")

    print("loading patches ...", flush=True)
    imgs, labs, aers = zip(*[load_patch(f, SCALE) for f in files])
    imgs = np.stack(imgs); labs = np.stack(labs); aers = np.stack(aers)
    print(f"  {imgs.shape}, fire {100*labs.mean():.2f}% of pixels")

    # atmospheric light from the CLEAR imagery, 99th percentile per band
    A = np.percentile(imgs, 99, axis=(0, 2, 3)).astype(np.float32)
    print("atmospheric light A per band:", np.round(A, 4))

    print(f"\n{'beta0':<8}{'IoU':>9}{'prec':>8}{'rec':>8}"
          f"{'conf|fire':>11}{'acc|fire':>10}{'gap':>9}   file")
    print("-" * 74)
    lab_t = torch.from_numpy(labs.astype(np.int64)).to(DEV)

    for b in BETAS:
        hz = np.stack([apply_haze(im, b, A) for im in imgs])
        if b == 0.0:
            assert np.allclose(hz, imgs), "beta0=0 must reproduce the input exactly"
        cues = np.stack([haze_cue(h) for h in hz])       # from HAZED bands
        norm = (hz - MEAN[:, None, None]) / (STD[:, None, None] + 1e-6)

        L = []
        with torch.no_grad():
            for i in range(0, len(norm), BATCH):
                x = torch.from_numpy(norm[i:i+BATCH]).to(DEV)
                L.append(model(x).float().cpu())
        lg = torch.cat(L)

        pred = lg.argmax(1).to(DEV); prob = lg.softmax(1).to(DEV)
        tp = ((pred==1)&(lab_t==1)).sum().item()
        fp = ((pred==1)&(lab_t==0)).sum().item()
        fn = ((pred==0)&(lab_t==1)).sum().item()
        e = 1e-9
        fm = lab_t == 1
        cf = prob.max(1).values[fm].mean().item()
        af = (pred[fm] == 1).float().mean().item()

        tag = f"{b:.2f}".replace(".", "p")
        path = OUT_DIR / f"haze_{tag}_logits.npz"
        np.savez_compressed(
            path, logits=lg.numpy().astype(np.float16),
            labels=labs, aerosol=aers.astype(np.float16),
            haze_cue=cues.astype(np.float16),
            beta0=b, alpha=ALPHA, lambda0=LAMBDA0,
            transmission=transmission(b).ravel(),
            atmospheric_light=A, epoch=ck.get("epoch", -1))

        print(f"{b:<8.2f}{tp/(tp+fp+fn+e):>9.4f}{tp/(tp+fp+e):>8.3f}"
              f"{tp/(tp+fn+e):>8.3f}{cf:>11.4f}{af:>10.4f}{cf-af:>9.4f}   {path.name}",
              flush=True)

    print("\nGAP = conf|fire - acc|fire. A RISING gap with severity is the")
    print("miscalibration this project targets: the model gets more confident")
    print("as it gets less correct.")
    print("\nNEXT")
    print("  Fit calibrators on the CLEAR val dump (val_logits.npz) and evaluate")
    print("  each haze level. That mirrors deployment: you calibrate on clear-sky")
    print("  data you have, then meet weather you did not. It is also the exact")
    print("  setting where global temperature scaling is known to degrade.")
    print("  Calibration is only meaningful where the model retains signal --")
    print("  beta0 >= 1.0 has zero fire accuracy, so every method converges on")
    print("  uniform low confidence and the comparison is uninformative.")


if __name__ == "__main__":
    t0 = time.time(); main(); print(f"\ndone in {time.time()-t0:.1f}s")
