r"""
GATE DIAGNOSIS: why did the height gate stop working on scene 4?

Candidate causes, each tested separately:
  LOGITS       scene 4's errors look like confident correct answers, so no
               readout could separate them
  MAXLOGIT     the logits hold the information, but reading the predicted
               class's logit misses it
  THRESHOLDS   the signal still ranks errors, but tau, fitted on clear scene 3,
               sits in the wrong place for scene 4
  SHAPE        the gate's sharpness (gamma) or strength (k) -- borrowed from one
               trained model and never tuned -- is wrong for scene 4
  ABSTENTION   the three-outcome mechanism itself cannot fix the problem

NOTE: the gate was fitted on CLEAR scene 3, not on hazed data. Hazed scene 3
was already a transfer test, and it passed. So the comparison that matters is
scene 3 -> scene 4, not synthetic -> real.

SECTION 1  THE LOGITS
  Per pixel type (correct fire, false alarm, missed fire, correct bg): pixel
  share and the median predicted-class logit h, |gap| and sum. Plus how much
  the h distributions of errors and correct pixels overlap, per predicted class.
SECTION 2  RANKING (no thresholds involved)
  AUROC for separating errors from correct pixels within each predicted class:
  MSP, MaxLogit, energy, sum, and the cross-fitted CEILING (best possible
  function of the two logits).
SECTION 3  THE GATE AS FITTED
  Its parameters; where each fitted tau sits as a percentile of h for errors and
  for correct pixels in each condition; how far the gate actually opens on each
  pixel type; confidence per pixel type versus softmax; selectivity; and the
  ECEs that explain why it ends up no better than softmax on scene 4.
SECTION 4  COUNTERFACTUALS ON SCENE 4 (the decisive part)
  Scene 4 patches are split in half. "Oracle" variants are refitted on half A
  and every variant is scored on half B, with a paired bootstrap over half-B
  patches. Oracles PEEK at scene 4: they are diagnostics, never a method.
    V0  softmax
    V1  height gate exactly as fitted on scene 3                 (what failed)
    V1b same gate, tau refit on scene 3 with the conf-Brier objective
                                                     tests the FITTING RULE
    V2b same gate, tau refit on scene 4 with the conf-Brier objective
    V2  + tau refitted on scene 4                    tests THRESHOLDS
    V3  + tau, gamma and k refitted on scene 4       tests SHAPE
    V4  MSP signal, fitted on scene 3                tests MAXLOGIT (transfer)
    V5  MSP signal, tau refitted on scene 4          tests MAXLOGIT (oracle)
    V6  CEILING signal, learned and fitted on scene 4 half A
                                                     best any logit readout
    V7  PERFECT signal (knows which pixels are wrong), strength fitted on A
                                                     tests ABSTENTION itself
  Every gate uses the same objective as the original: true-fire ECE + true-bg
  ECE. Oracle grids span the 2nd-98th percentile; the original's spanned only
  2nd-60th.

WHICH NUMBERS TO TRUST
  conf Brier -- mean (confidence - correct)^2 -- is the PRIMARY measure here.
  It has no bins, so it always rewards less confidence on errors and more on
  correct pixels. Binned true-fire ECE does NOT: moving missed fire into the
  same bins as correct detections makes their errors cancel, so it can rank a
  worse readout above a better one (a perfect error detector can score worse).
  Read true-fire ECE only alongside missed-fire confidence and selectivity.
  V1b / V2b refit the SAME gate with the conf-Brier objective instead of the
  original binned one -- on scene 3 and on scene 4. If V1b beats V1 on scene 4,
  the original FITTING RULE was part of the problem.

HOW TO READ THE VERDICT -- two separate questions, two measures
  Q1 CAN THE GATE REACH THE ERRORS AT ALL?   -> SELECTIVITY after a refit
     V1 low, V2/V2b high       the information is there; the scene-3
                               THRESHOLDS kept the gate shut on scene 4
     V2 low, V5 or V6 high     MaxLogit misses information the logits hold
     V2, V5 AND V6 all near 1  the LOGITS are the limit -- no readout of them
                               can target scene 4's errors
     V7 high                   abstention itself works when information exists
  Q2 IS THE RESULT ACTUALLY BETTER?          -> CONF BRIER (lower = better)
     A refit can reach the errors (Q1) yet still be worse overall, if it
     abstains too broadly. The ECE-fitted variants tend to; the Brier-fitted
     ones (V1b, V2b) show the best achievable trade.
  Missed-fire confidence shows how far the gate actually moved the errors.

Usage (same model arguments as final_tests.py):
  python3 gate_diagnosis.py --boot 1000 --model A_s0 "" test_logits.npz ...
Writes results/gate_diagnosis.csv and results/gate_diagnosis_TABLES.csv.
"""

import sys, os, csv, argparse
import numpy as np
from reverse_gate import load, evidence, readout as gate_readout, fit as gate_fit, sigmoid
from final_compare import fixed, FIX_C, FIX_K, FIX_G
from final_tests import chunk_stats, metrics, diff, CHUNK, OUT, fmt, write_tables, O_N as O_N_COL
from logit_limits import auroc, ceiling, collect

CATS = ["correct fire", "false alarm", "missed fire", "correct bg"]
NB_CELL = 40


# ------------------------------------------------------------------ basics
def three(z0, z1, eta):
    m = np.maximum(np.maximum(z0, z1), eta)
    a, b, c = np.exp(z0 - m), np.exp(z1 - m), np.exp(eta - m); Z = a + b + c
    return a / Z, b / Z, c / Z, z1 > z0


def gate3(z0, z1, x, P, gam):
    """Generic gate: eta = c + k * sigmoid(gam_c * gmult * (tau - x)) per
    predicted class. x is a CONFIDENCE signal (higher = more confident).
    P: {class: (tau, gmult, k) or None}."""
    pred = z1 > z0; eta = np.full(z0.shape, -1e4, dtype=np.float64)
    for c in (False, True):
        if P[c] is None: continue
        tau, gm, k = P[c]; m = pred == c
        eta[m] = FIX_C + k * sigmoid(gam[c] * gm * (tau - x[m]))
    return three(z0, z1, eta)


def ece(conf, corr):
    if conf.size == 0: return 0.0
    b = np.clip((conf * 20).astype(int), 0, 19)
    return float(np.abs(np.bincount(b, corr, 20) - np.bincount(b, conf, 20)).sum() / conf.size)


def objective(z0, z1, x, y, P, gam, mode="ece"):
    """mode 'ece'  : true-fire ECE + true-bg ECE  (the ORIGINAL fitting rule)
       mode 'brier': mean (confidence - correct)^2 -- a proper score with no
                     bins, so it always rewards lower confidence on errors and
                     higher confidence on correct pixels. Needs a UNIFORM sample."""
    pb, pf, pn, pr = gate3(z0, z1, x, P, gam)
    conf = np.where(pr, pf, pb); corr = (pr == y).astype(np.float64)
    if mode == "brier":
        return float(np.mean((conf - corr) ** 2))
    return ece(conf[y], corr[y]) + ece(conf[~y], corr[~y])


def uniform(z0, z1, y, n=2_000_000):
    i = np.random.default_rng(4).choice(z0.size, min(n, z0.size), replace=False)
    return z0[i], z1[i], y[i]


def stratified(z0, z1, y, extra=(), n_fire=400_000, n_bg=1_600_000):
    rng = np.random.default_rng(0)
    fi, bi = np.flatnonzero(y), np.flatnonzero(~y)
    i = np.sort(np.concatenate([rng.choice(fi, min(n_fire, fi.size), replace=False),
                                rng.choice(bi, min(n_bg, bi.size), replace=False)]))
    return (z0[i], z1[i], y[i]) + tuple(e[i] for e in extra)


def rescale_gamma(z0, z1, x):
    """Same rule as the original fit: sharpness matched to the signal's spread."""
    s = 0.5 * (z0 + z1); pred = z1 > z0
    return {c: FIX_G * (s[pred == c].std() + 1e-6) / (x[pred == c].std() + 1e-6) for c in (False, True)}


def fit_gate(z0, z1, x, y, gam, q=(0.02, 0.98), nq=25, gmults=(1.0,), ks=(FIX_K,), mode="ece"):
    """Thresholds only -> joint grid (as the original). With gamma/k too ->
    coordinate descent over classes (bg, fire, bg, fire)."""
    pred = z1 > z0
    taus = {c: list(np.quantile(x[pred == c], np.linspace(*q, nq))) for c in (False, True)}
    cand = {c: [None] + [(t, g, k) for t in taus[c] for g in gmults for k in ks] for c in (False, True)}
    if len(gmults) == 1 and len(ks) == 1:
        best = None
        for a in cand[False]:
            for b in cand[True]:
                o = objective(z0, z1, x, y, {False: a, True: b}, gam, mode)
                if best is None or o < best[0]: best = (o, {False: a, True: b})
        return best[1]
    P = {False: None, True: None}
    for c in (False, True, False, True):
        P[c] = min(cand[c], key=lambda p: objective(z0, z1, x, y, {**P, c: p}, gam, mode))
    return P


class CeilingMap:
    """Error rate per (z0, z1) quantile cell, per predicted class, learned on
    one set of pixels and applied to another."""
    def __init__(self, z0, z1, y):
        pred = z1 > z0; self.t = {}
        for c in (False, True):
            m = pred == c; a0, a1, e = z0[m], z1[m], (y != c)[m]
            q0 = np.quantile(a0, np.linspace(0, 1, NB_CELL + 1)[1:-1]); q1 = np.quantile(a1, np.linspace(0, 1, NB_CELL + 1)[1:-1])
            cell = np.searchsorted(q0, a0) * NB_CELL + np.searchsorted(q1, a1)
            n = np.bincount(cell, minlength=NB_CELL ** 2); k = np.bincount(cell, e.astype(float), NB_CELL ** 2)
            self.t[c] = (q0, q1, np.where(n > 0, k / np.maximum(n, 1), e.mean()))

    def score(self, z0, z1):
        """Confidence signal = -(estimated error rate)."""
        pred = z1 > z0; out = np.empty(z0.shape)
        for c in (False, True):
            m = pred == c; q0, q1, r = self.t[c]
            out[m] = -r[np.searchsorted(q0, z0[m]) * NB_CELL + np.searchsorted(q1, z1[m])]
        return out


def signal(name, z0, z1, y=None, cmap=None):
    if name == "maxlogit": return np.maximum(z0, z1)
    if name == "msp":      return np.abs(z1 - z0)
    if name == "ceiling":  return cmap.score(z0, z1)
    if name == "perfect":  return -((z1 > z0) != y).astype(np.float64)
    raise ValueError(name)


def load_patches(path, idx):
    z = np.load(path); L, Y = z["logits"], z["labels"]
    z0, z1, yy = [], [], []
    for s in range(0, len(idx), CHUNK):
        sel = idx[s:s + CHUNK]; lg = L[sel].astype(np.float32); y = Y[sel]
        if y.ndim == 4: y = y[:, 0]
        z0.append(lg[:, 0].ravel()); z1.append(lg[:, 1].ravel()); yy.append((y == 1).ravel())
    return np.concatenate(z0), np.concatenate(z1), np.concatenate(yy)


# ----------------------------------------------------------- sections 1-3
def overlap(a, b, bins=200):
    lo, hi = np.percentile(np.concatenate([a, b]), [0.5, 99.5])
    ha, _ = np.histogram(a, bins, (lo, hi), density=True); hb, _ = np.histogram(b, bins, (lo, hi), density=True)
    return float(np.minimum(ha, hb).sum() * (hi - lo) / bins)


def sections_1_2(label, cname, path, idx, rows):
    data = collect(path, idx)
    print(f"\n  [{cname}]")
    print(f"    {'pixel type':<14}{'median h':>10}{'median |gap|':>14}{'median sum':>12}")
    for c, (err_nm, ok_nm) in ((True, ("false alarm", "correct fire")), (False, ("missed fire", "correct bg"))):
        a0, a1, e = data[c]; h = a1 if c else a0
        for nm, m in ((ok_nm, ~e), (err_nm, e)):
            r = dict(model=label, condition=cname, section="1 logits", item=nm,
                     median_h=float(np.median(h[m])), median_gap=float(np.median(np.abs(a1 - a0)[m])),
                     median_sum=float(np.median(((a0 + a1) / 2)[m])))
            rows.append(r)
            print(f"    {nm:<14}{r['median_h']:>10.2f}{r['median_gap']:>14.2f}{r['median_sum']:>12.2f}")
    print(f"    {'calls':<14}{'h overlap':>10}{'MSP':>8}{'MaxLogit':>10}{'energy':>8}{'sum':>7}{'ceiling':>9}")
    for c, nm in ((False, "background"), (True, "fire")):
        a0, a1, e = data[c]; h = a1 if c else a0
        m = np.maximum(a0, a1); lse = m + np.log(np.exp(a0 - m) + np.exp(a1 - m))
        ssum = auroc((a0 + a1) / 2, e)
        r = dict(model=label, condition=cname, section="2 ranking", item=f"{nm} calls",
                 h_overlap=overlap(h[e], h[~e]), MSP=auroc(-np.abs(a1 - a0), e), MaxLogit=auroc(-h, e),
                 energy=auroc(-lse, e), sum=max(ssum, 1 - ssum), ceiling=ceiling(a0, a1, e))
        rows.append(r)
        print(f"    {nm:<14}{r['h_overlap']:>10.3f}{r['MSP']:>8.3f}{r['MaxLogit']:>10.3f}"
              f"{r['energy']:>8.3f}{r['sum']:>7.3f}{r['ceiling']:>9.3f}", flush=True)


def section_3(label, cname, path, idx, taus, gams, rows):
    """The gate exactly as fitted: where tau falls, how far it opens, and what
    that does to each pixel type."""
    z = np.load(path); L, Y = z["logits"], z["labels"]
    acc = {k: np.zeros(6) for k in CATS}              # n, conf_sm, conf_g, abst, openness, h-below-tau
    hs = {k: [] for k in CATS}; rng = np.random.default_rng(2)
    E = {"softmax": [], "gate": []}; corr_all = []; y_all = []; pred_all = []
    for s in range(0, len(idx), CHUNK):
        sel = idx[s:s + CHUNK]; lg = L[sel].astype(np.float32); y = Y[sel]
        if y.ndim == 4: y = y[:, 0]
        z0, z1, yb = lg[:, 0].ravel(), lg[:, 1].ravel(), (y == 1).ravel()
        d = dict(z0=z0, z1=z1, y=yb.astype(np.int8), c=FIX_C, k=FIX_K, g=FIX_G)
        h = evidence(d, "height gate"); pred = z1 > z0
        cg, _, pn, _ = gate_readout(d, h, taus, gams)
        p = sigmoid(z1 - z0); cs = np.where(pred, p, 1 - p)
        open_ = np.zeros_like(h)
        for c in (False, True):
            if taus[c] is not None:
                m = pred == c; open_[m] = sigmoid(gams[c] * (taus[c] - h[m]))
        below = np.zeros_like(h, dtype=bool)
        for c in (False, True):
            if taus[c] is not None: below[pred == c] = h[pred == c] < taus[c]
        for k_, m in zip(CATS, [pred & yb, pred & ~yb, ~pred & yb, ~pred & ~yb]):
            acc[k_] += [m.sum(), cs[m].sum(), cg[m].sum(), pn[m].sum(), open_[m].sum(), below[m].sum()]
            hm = h[m]
            if hm.size: hs[k_].append(hm[rng.random(hm.size) < min(1.0, 200_000 / max(hm.size, 1))])
        corr = (pred == yb).astype(np.float64)
        E["softmax"].append(cs); E["gate"].append(cg); corr_all.append(corr); y_all.append(yb); pred_all.append(pred)
    tot = sum(v[0] for v in acc.values())
    print(f"\n  [{cname}]  gate as fitted on clear scene 3")
    print(f"    {'pixel type':<14}{'share':>7}{'conf softmax':>14}{'conf gate':>11}{'change':>9}"
          f"{'abstention':>12}{'gate open':>11}{'h < tau':>9}")
    for k_ in CATS:
        n, cs_, cg_, ab, op, bl = acc[k_]
        if n == 0: continue
        r = dict(model=label, condition=cname, section="3 gate as fitted", item=k_, share=n / tot,
                 conf_softmax=cs_ / n, conf_gate=cg_ / n, abstention=ab / n, gate_open=op / n, frac_h_below_tau=bl / n)
        rows.append(r)
        print(f"    {k_:<14}{100 * n / tot:>6.1f}%{r['conf_softmax']:>14.3f}{r['conf_gate']:>11.3f}"
              f"{r['conf_gate'] - r['conf_softmax']:>+9.3f}{r['abstention']:>12.4f}{r['gate_open']:>11.3f}{r['frac_h_below_tau']:>9.3f}")
    sel_ = (acc["missed fire"][3] / acc["missed fire"][0]) / max(acc["correct bg"][3] / acc["correct bg"][0], 1e-12)
    y_ = np.concatenate(y_all); c_ = np.concatenate(corr_all)
    es = {k: np.concatenate(v) for k, v in E.items()}
    vals = {k: (ece(es[k][y_], c_[y_]), ece(es[k][~y_], c_[~y_])) for k in es}
    print(f"    selectivity {sel_:.2f}    true-fire ECE softmax {vals['softmax'][0]:.4f} -> gate {vals['gate'][0]:.4f}"
          f"    true-bg ECE {vals['softmax'][1]:.4f} -> {vals['gate'][1]:.4f}")
    for c, err_k, ok_k in ((False, "missed fire", "correct bg"), (True, "false alarm", "correct fire")):
        if taus[c] is None:
            print(f"    tau for {'background' if not c else 'fire'} calls: OFF"); continue
        he = np.concatenate(hs[err_k]) if hs[err_k] else np.array([np.nan])
        ho = np.concatenate(hs[ok_k]) if hs[ok_k] else np.array([np.nan])
        pe, po = 100 * (he < taus[c]).mean(), 100 * (ho < taus[c]).mean()
        r = dict(model=label, condition=cname, section="3 tau position", item=f"{'background' if not c else 'fire'} calls",
                 tau=taus[c], tau_pct_of_errors=pe, tau_pct_of_correct=po)
        rows.append(r)
        print(f"    tau for {'background' if not c else 'fire'} calls = {taus[c]:+.3f}: below it lie "
              f"{pe:.1f}% of {err_k} and {po:.1f}% of {ok_k}")
    rows.append(dict(model=label, condition=cname, section="3 summary", item="gate as fitted", selectivity=sel_,
                     true_fire_ece_softmax=vals["softmax"][0], true_fire_ece_gate=vals["gate"][0],
                     true_bg_ece_softmax=vals["softmax"][1], true_bg_ece_gate=vals["gate"][1]))


# ------------------------------------------------------------- section 4
def section_4(label, s3_path, fit_idx, s4_path, taus, gams, boot, rows, blocks):
    n4 = int(np.load(s4_path)["logits"].shape[0])
    perm = np.random.default_rng(42).permutation(n4)
    A, B = np.sort(perm[:n4 // 2]), np.sort(perm[n4 // 2:])
    print(f"\n  scene 4 split: {len(A)} patches to refit oracles (half A), {len(B)} to score (half B)", flush=True)

    # scene-3 fitting sample (for transfer variants) and scene-4 half-A sample (oracles)
    full3 = load_patches(s3_path, fit_idx)
    z0_3, z1_3, y_3 = stratified(*full3); u3 = uniform(*full3); del full3
    z0_A, z1_A, y_A = load_patches(s4_path, A)
    cmap = CeilingMap(z0_A, z1_A, y_A)
    uA = uniform(z0_A, z1_A, y_A)
    z0_a, z1_a, y_a = stratified(z0_A, z1_A, y_A); del z0_A, z1_A, y_A

    V = {}
    P1 = {c: (None if taus[c] is None else (taus[c], 1.0, FIX_K)) for c in (False, True)}
    V["V1 as fitted"] = ("maxlogit", P1, gams)
    print("  refitting V2 (tau on scene 4) ...", flush=True)
    xa = signal("maxlogit", z0_a, z1_a)
    V["V2 tau refit"] = ("maxlogit", fit_gate(z0_a, z1_a, xa, y_a, gams), gams)
    print("  refitting V3 (tau, gamma, k on scene 4) ...", flush=True)
    V["V3 shape refit"] = ("maxlogit", fit_gate(z0_a, z1_a, xa, y_a, gams, nq=20,
                                                 gmults=(0.25, 0.5, 1.0, 2.0, 4.0), ks=(4.0, FIX_K, 12.0, 16.0)), gams)
    print("  fitting V1b / V2b (same gate, proper Brier objective) ...", flush=True)
    V["V1b Brier sc3"] = ("maxlogit", fit_gate(u3[0], u3[1], signal("maxlogit", u3[0], u3[1]), u3[2], gams, mode="brier"), gams)
    V["V2b Brier sc4"] = ("maxlogit", fit_gate(uA[0], uA[1], signal("maxlogit", uA[0], uA[1]), uA[2], gams, mode="brier"), gams)
    print("  fitting V4 / V5 (MSP signal) ...", flush=True)
    x3 = signal("msp", z0_3, z1_3); g_msp = rescale_gamma(z0_3, z1_3, x3)
    V["V4 MSP transfer"] = ("msp", fit_gate(z0_3, z1_3, x3, y_3, g_msp, q=(0.02, 0.60), nq=15), g_msp)
    V["V5 MSP refit"] = ("msp", fit_gate(z0_a, z1_a, signal("msp", z0_a, z1_a), y_a, g_msp), g_msp)
    print("  fitting V6 (ceiling signal) ...", flush=True)
    xc = signal("ceiling", z0_a, z1_a, cmap=cmap); g_c = rescale_gamma(z0_a, z1_a, xc)
    V["V6 ceiling"] = ("ceiling", fit_gate(z0_a, z1_a, xc, y_a, g_c), g_c)
    print("  fitting V7 (perfect signal) ...", flush=True)
    xp = signal("perfect", z0_a, z1_a, y_a); g_p = {False: 40.0, True: 40.0}
    cand = [None] + [(-0.5, 1.0, k) for k in (2.0, 4.0, FIX_K, 12.0, 16.0, 24.0)]
    best = None
    for a in cand:
        for b in cand:
            o = objective(z0_a, z1_a, xp, y_a, {False: a, True: b}, g_p)
            if best is None or o < best[0]: best = (o, {False: a, True: b})
    V["V7 perfect"] = ("perfect", best[1], g_p)
    del z0_3, z1_3, y_3, z0_a, z1_a, y_a, u3, uA

    fp = lambda P: " | ".join(f"{'bg' if not c else 'fire'}: " + ("OFF" if P[c] is None else
                              f"tau {P[c][0]:+.3f} gx{P[c][1]:.2f} k {P[c][2]:.1f}") for c in (False, True))
    for nm, (sg, P, _) in V.items():
        print(f"    {nm:<17} signal={sg:<9} {fp(P)}")

    # score every variant on half B
    z = np.load(s4_path); L, Y = z["logits"], z["labels"]; stats, brs = {}, {}
    for s in range(0, len(B), CHUNK):
        sel = B[s:s + CHUNK]; p = len(sel); lg = L[sel].astype(np.float32); y = Y[sel]
        if y.ndim == 4: y = y[:, 0]
        z0, z1, yb = lg[:, 0].ravel(), lg[:, 1].ravel(), (y == 1).ravel()
        pid = np.repeat(np.arange(p), lg.shape[2] * lg.shape[3])
        pf = sigmoid(z1 - z0)
        R = {"V0 softmax": (1 - pf, pf, np.zeros_like(pf), pf > 0.5)}
        for nm, (sg, P, gm) in V.items():
            R[nm] = gate3(z0, z1, signal(sg, z0, z1, yb, cmap), P, gm)
        for nm, (pb, pf_, pn, pr) in R.items():
            stats.setdefault(nm, []).append(chunk_stats(pb, pf_, pn, pr, yb, pid, p))
            conf = np.where(pr, pf_, pb); corr = (pr == yb).astype(np.float64)
            brs.setdefault(nm, []).append(np.bincount(pid, (conf - corr) ** 2, p))
    stats = {k: np.vstack(v) for k, v in stats.items()}
    brs = {k: np.concatenate(v) for k, v in brs.items()}
    # sanity: V1 must reproduce the original height gate exactly
    d = dict(z0=z0, z1=z1, y=yb.astype(np.int8), c=FIX_C, k=FIX_K, g=FIX_G)
    cg, _, _, _ = gate_readout(d, evidence(d, "height gate"), taus, gams)
    pb, pf_, pn, pr = R["V1 as fitted"]
    assert np.allclose(np.where(pr, pf_, pb), cg, atol=2e-5), "V1 does not reproduce the original height gate"

    rng = np.random.default_rng(3); P_ = len(B)
    Wt = np.stack([np.bincount(rng.integers(0, P_, P_), minlength=P_) for _ in range(boot)]).astype(np.float64)
    res = {}
    for nm, M in stats.items():
        pt = {k: float(v[0]) for k, v in metrics(M.sum(0)[None]).items()}
        bt = metrics(Wt @ M); N = M[:, O_N_COL]
        pt["conf_brier"] = float(brs[nm].sum() / N.sum()); bt["conf_brier"] = (Wt @ brs[nm]) / (Wt @ N)
        res[nm] = dict(point=pt, boot=bt)
    keys = [("conf Brier", "conf_brier"), ("true-fire ECE", "ece_true_fire"), ("true-bg ECE", "ece_true_bg"),
            ("pred-fire ECE", "ece_pred_fire"), ("AUROC", "auroc")]
    print(f"\n  SCENE 4 HALF B ({P_} patches) -- every variant, point estimates")
    hdr = f"    {'variant':<17}" + "".join(f"{n:>15}" for n, _ in keys) + f"{'conf missed':>13}{'conf corr bg':>14}{'selectivity':>13}"
    print(hdr)
    table = []
    for nm, r in res.items():
        pt = r["point"]
        sel = pt["abst_missed fire"] / pt["abst_correct bg"] if pt["abst_correct bg"] > 1e-9 else float("nan")
        row = [nm] + [pt[k] for _, k in keys] + [pt["conf_missed fire"], pt["conf_correct bg"], sel]
        table.append(row)
        print(f"    {nm:<17}" + "".join(f"{v:>15.4f}" for v in row[1:6]) + f"{row[6]:>13.3f}{row[7]:>14.3f}{row[8]:>13.2f}")
        rows.append(dict(model=label, condition="scene4 half B", section="4 counterfactual", item=nm,
                         **{n: pt[k] for n, k in keys}, conf_missed=pt["conf_missed fire"],
                         conf_correct_bg=pt["conf_correct bg"], selectivity=sel))
    blocks.append((f"{label} | scene 4 half B | every variant", ["variant"] + [n for n, _ in keys] +
                   ["conf missed fire", "conf correct bg", "selectivity"], [[t[0]] + [fmt(v) for v in t[1:]] for t in table]))
    print(f"\n  each variant MINUS V1 (the gate as fitted), {boot} paired replicates (negative = better; AUROC: positive)")
    print(f"    {'variant':<17}" + "".join(f"{n:>24}" for n, _ in keys[:3]))
    drows = []
    for nm in res:
        if nm == "V1 as fitted": continue
        cells = []
        for n, k in keys[:3]:
            dv = diff(res, nm, "V1 as fitted", k)
            cells.append(f"{dv[0]:+.4f} [{dv[1]:+.3f},{dv[2]:+.3f}]{'*' if dv[3] else ' '}" if dv else "--")
            rows.append(dict(model=label, condition="scene4 half B", section="4 vs V1", item=nm, metric=n,
                             diff=dv[0] if dv else None, ci_low=dv[1] if dv else None, ci_high=dv[2] if dv else None,
                             significant=bool(dv and dv[3])))
        drows.append([nm] + cells)
        print(f"    {nm:<17}" + "".join(f"{c:>24}" for c in cells))
    blocks.append((f"{label} | scene 4 half B | variant MINUS V1 with 95% CI", ["variant"] + [n for n, _ in keys[:3]], drows))
    return res


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("--model", action="append", nargs=3, default=[])
    a = ap.parse_args()
    if not a.model:
        print(__doc__); sys.exit(1)
    os.makedirs(OUT, exist_ok=True); rows, blocks = [], []
    for label, prefix, s4 in a.model:
        s3 = {b: f"{prefix}scene3_haze_{b}_logits.npz" for b in ("0p00", "0p50")}
        n = int(np.load(s3["0p00"])["logits"].shape[0])
        perm = np.random.default_rng(0).permutation(n)                  # SAME split as every run
        fit_idx, ev_idx = np.sort(perm[:n // 2]), np.sort(perm[n // 2:])
        print(f"\n################ {label} ################", flush=True)
        d = fixed(load(s3["0p00"], fit_idx)); taus, gams = gate_fit(d, "height gate")
        pred = d["z1"] > d["z0"]; h = np.maximum(d["z0"], d["z1"])
        for c in (False, True):
            if taus[c] is None: continue
            pct = 100 * (h[pred == c] < taus[c]).mean()
            print(f"  fitted tau for {'background' if not c else 'fire'} calls {taus[c]:+.3f} = {pct:.1f}th percentile "
                  f"of scene-3 h (the original search stopped at the 60th{'  <-- AT THE EDGE' if pct > 57 else ''})")
            rows.append(dict(model=label, condition="scene3 fit", section="3 parameters", item=f"{'background' if not c else 'fire'} calls",
                             tau=taus[c], tau_percentile_scene3=pct, gamma=gams[c], c=FIX_C, k=FIX_K))
        print(f"  c = {FIX_C}   k = {FIX_K}   gamma bg = {gams[False]:.3f}   gamma fire = {gams[True]:.3f}")
        del d, h, pred
        conds = [("scene3 b0=0.0", s3["0p00"], ev_idx), ("scene3 b0=0.5", s3["0p50"], ev_idx),
                 ("scene4 natural", s4, np.arange(int(np.load(s4)["logits"].shape[0])))]
        print("\n SECTIONS 1-2: the logits, and how well each signal ranks errors")
        for cname, path, idx in conds:
            if os.path.exists(path): sections_1_2(label, cname, path, idx, rows)
        print("\n SECTION 3: the gate as fitted")
        for cname, path, idx in conds:
            if os.path.exists(path): section_3(label, cname, path, idx, taus, gams, rows)
        print("\n SECTION 4: counterfactuals on scene 4")
        if os.path.exists(s4):
            section_4(label, s3["0p00"], fit_idx, s4, taus, gams, a.boot, rows, blocks)

    keys = []
    for r in rows:
        for k in r:
            if k not in keys: keys.append(k)
    with open(f"{OUT}/gate_diagnosis.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rows)
    write_tables(f"{OUT}/gate_diagnosis_TABLES.csv", blocks)
    print(f"\nWrote {OUT}/gate_diagnosis.csv and gate_diagnosis_TABLES.csv")
    print(__doc__[__doc__.find("WHICH NUMBERS TO TRUST"):__doc__.find("Usage")])


if __name__ == "__main__":
    main()
