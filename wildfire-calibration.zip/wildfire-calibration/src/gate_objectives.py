r"""
GATE OBJECTIVES: does the height gate's fitting objective decide what it does?

WHY THIS EXISTS
Model B seed 1 switched its fire-call gate OFF. The thresholds were fitted to
TRUE-fire ECE + TRUE-bg ECE, which never mentions predicted-fire ECE -- the
primary endpoint. So the fire-call gate was never optimised for it. This tests
that directly.

PRE-SPECIFIED DESIGN -- fixed before running, reported in full whatever it shows
Same height gate, same fixed c, k, gamma; ONLY the objective choosing the two
thresholds changes:

  joint             tau_bg and tau_fire together minimise true-fire ECE +
                    true-bg ECE (the original height gate)
  self-calibrated   each gate minimises the ECE of ITS OWN predictions:
                    tau_fire -> predicted-fire ECE, tau_bg -> predicted-bg ECE
  fire-first        tau_fire -> predicted-fire ECE, then tau_bg -> the joint
                    objective with that fire gate held fixed

Because thresholds are per predicted class, predicted-fire ECE depends ONLY on
tau_fire and predicted-bg ECE ONLY on tau_bg, so self-calibrated fits are
independent and exact.

SAMPLING DETAIL THAT MATTERS: predicted-class objectives are fitted on a
UNIFORM sample of that predicted class. A sample stratified by the true label
(as the joint fit uses, correctly, for true-class ECE) would distort the mix of
correct and wrong predictions within a predicted class, and bias the result.

Grid: tau over the 2nd-98th percentiles of h within the predicted class, plus
OFF. Wider than before, so a gate that wants to abstain on most fire calls can.

PREDICTION WRITTEN BEFORE RUNNING: a background gate fitted to predicted-bg
ECE will switch OFF -- background calls are already well calibrated and missed
fire is ~2% of them.

Compared on held-out patches: softmax, class-conditional temperature, and the
three gates. Paired bootstrap against softmax and class-cond T. Abstention by
pixel type, to show where each gate spends its abstention.

Usage (reverse_gate.py, final_compare.py, paired_height.py in the folder):
  python3 gate_objectives.py --boot 1000 \
    --model A_s0 scene3_haze_0p00_logits.npz scene3_haze_0p20_logits.npz scene3_haze_0p50_logits.npz \
    --model B_s0 gated_scene3_haze_0p00_logits.npz gated_scene3_haze_0p20_logits.npz gated_scene3_haze_0p50_logits.npz \
    --model A_s1 A_s1_scene3_haze_0p00_logits.npz A_s1_scene3_haze_0p20_logits.npz A_s1_scene3_haze_0p50_logits.npz \
    --model B_s1 B_s1_scene3_haze_0p00_logits.npz B_s1_scene3_haze_0p20_logits.npz B_s1_scene3_haze_0p50_logits.npz
"""

import sys, argparse
import numpy as np
from reverse_gate import load, evidence, readout as gate_readout, fit as gate_fit, sigmoid
from final_compare import fit_T, fixed
from paired_height import patch_stats, metrics

NB = 20


def ece(conf, corr):
    if conf.size == 0: return float("nan")
    b = np.clip((conf * NB).astype(int), 0, NB - 1)
    return float(np.abs(np.bincount(b, corr, NB) - np.bincount(b, conf, NB)).sum() / conf.size)


def sub(d, idx):
    return {k: (v[idx] if isinstance(v, np.ndarray) else v) for k, v in d.items()}


def fit_pred_class(d, cls, gams, grid, n=3_000_000):
    """tau for ONE predicted class, minimising that class's predicted-class ECE,
    on a UNIFORM sample of pixels predicted as that class."""
    pred = d["z1"] > d["z0"]
    idx = np.flatnonzero(pred == cls)
    if idx.size > n:
        idx = np.sort(np.random.default_rng(7).choice(idx, n, replace=False))
    ds = sub(d, idx); x = evidence(ds, "height gate")
    other = not cls
    def score(t):
        conf, corr, _, pr = gate_readout(ds, x, {cls: t, other: None}, gams)
        return ece(conf, corr)                       # all pixels here are class `cls`
    return min(grid, key=score)


def fit_joint_bg(d, tau_fire, gams, grid, n_fire=400_000, n_bg=1_600_000):
    """tau_bg minimising true-fire + true-bg ECE, fire gate fixed. Stratified by
    TRUE label -- correct for TRUE-class objectives."""
    rng = np.random.default_rng(0)
    fi = np.flatnonzero(d["y"] == 1); bi = np.flatnonzero(d["y"] == 0)
    i = np.sort(np.concatenate([rng.choice(fi, min(n_fire, fi.size), replace=False),
                                rng.choice(bi, min(n_bg, bi.size), replace=False)]))
    ds = sub(d, i); x = evidence(ds, "height gate"); f = ds["y"] == 1
    def score(t):
        conf, corr, _, _ = gate_readout(ds, x, {False: t, True: tau_fire}, gams)
        return ece(conf[f], corr[f]) + ece(conf[~f], corr[~f])
    return min(grid, key=score)


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("--model", action="append", nargs="+", default=[])
    a = ap.parse_args()
    if not a.model:
        print(__doc__); sys.exit(1)
    fmt = lambda t: "OFF" if t is None else f"{t:+.3f}"
    rows_order = ["pred fire", "TRUE fire", "TRUE bg", "pred bg", "AURC"]

    for spec in a.model:
        label, files = spec[0], spec[1:]
        n = int(np.load(files[0])["logits"].shape[0])
        perm = np.random.default_rng(0).permutation(n)       # SAME split everywhere
        fit_idx, ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])
        d = fixed(load(files[0], fit_idx))
        g = d["z1"] - d["z0"]; y = d["y"] == 1; pred = g > 0
        Tc = {c: fit_T(g[pred == c], y[pred == c]) for c in (False, True)}

        print(f"\n######## {label}: fitting on {len(fit_idx)} held-in patches", flush=True)
        J_tau, gams = gate_fit(d, "height gate")             # the original, unchanged
        h = evidence(d, "height gate")
        grid = {c: [None] + list(np.quantile(h[pred == c], np.linspace(0.02, 0.98, 25)))
                for c in (False, True)}
        tf = fit_pred_class(d, True, gams, grid[True])
        tb_self = fit_pred_class(d, False, gams, grid[False])
        tb_first = fit_joint_bg(d, tf, gams, grid[False])
        V = {"joint": J_tau, "self-calibrated": {False: tb_self, True: tf},
             "fire-first": {False: tb_first, True: tf}}
        for nm, t in V.items():
            print(f"  {nm:<16} tau pred bg {fmt(t[False]):>7}   tau pred fire {fmt(t[True]):>7}")
        print(f"  class-cond T     pred bg {Tc[False]:.4f}   pred fire {Tc[True]:.4f}")

        for path in files[1:]:
            e = fixed(load(path, ev_idx)); P = len(ev_idx); HW = e["z0"].size // P
            g = e["z1"] - e["z0"]; y = e["y"] == 1; pred = g > 0
            x = evidence(e, "height gate")
            R, AB = {}, {}
            p = sigmoid(g); R["softmax"] = (np.where(pred, p, 1 - p), (pred == y).astype(np.float64))
            pT = sigmoid(g / np.where(pred, Tc[True], Tc[False]))
            R["class-cond T"] = (np.where(pred, pT, 1 - pT), (pred == y).astype(np.float64))
            for nm, t in V.items():
                conf, corr, pn, _ = gate_readout(e, x, t, gams)
                R[nm] = (conf, corr); AB[nm] = pn
            for nm, (_, corr) in R.items():
                assert np.array_equal(corr, R["softmax"][1]), f"{nm} changed a prediction"

            S = {nm: patch_stats(c, o, y, pred, P, HW) for nm, (c, o) in R.items()}
            M = {nm: metrics(H.sum(0), Rr.sum(0)) for nm, (H, Rr) in S.items()}
            beta = float(np.load(path)["beta0"])
            print(f"\n=== {label}   beta0 = {beta}   ({P} held-out patches)")
            print(f"  {'readout':<17}" + "".join(f"{r:>11}" for r in rows_order))
            for nm in R:
                print(f"  {nm:<17}" + "".join(f"{M[nm][r]:>11.4f}" for r in rows_order))

            groups = {"detected": y & pred, "false alarm": ~y & pred,
                      "missed": y & ~pred, "correct bg": ~y & ~pred}
            print(f"\n  abstention by pixel type" + " " * 6 + "".join(f"{k:>13}" for k in groups)
                  + f"{'missed/bg':>11}")
            for nm, pn in AB.items():
                vals = [float(pn[m].mean()) for m in groups.values()]
                print(f"  {nm:<30}" + "".join(f"{v:>13.4f}" for v in vals)
                      + f"{vals[2] / max(vals[3], 1e-9):>11.2f}")

            rng = np.random.default_rng(3)
            refs, gates = ("softmax", "class-cond T"), list(V)
            D = {(gt, rf, r): [] for gt in gates for rf in refs for r in rows_order}
            for _ in range(a.boot):
                pk = rng.integers(0, P, P)
                b = {nm: metrics(H[pk].sum(0), Rr[pk].sum(0)) for nm, (H, Rr) in S.items()}
                for gt in gates:
                    for rf in refs:
                        for r in rows_order:
                            D[(gt, rf, r)].append(b[gt][r] - b[rf][r])
            print(f"\n  gate MINUS reference, {a.boot} paired replicates (negative = gate better; * = CI excludes 0)")
            for gt in gates:
                for rf in refs:
                    cells = []
                    for r in rows_order:
                        v = np.array(D[(gt, rf, r)]); v = v[np.isfinite(v)]
                        lo, hi = np.percentile(v, [2.5, 97.5])
                        cells.append(f"{np.mean(v):+.4f}{'*' if (hi < 0 or lo > 0) else ' '}")
                    print(f"    {gt:<16} vs {rf:<13}" + "".join(f"{c:>11}" for c in cells))
            print(f"    {'':<33}" + "".join(f"{r:>11}" for r in rows_order))

    print("\nHOW TO READ THIS")
    print("  Compare the three gates on the SAME model: only the fitting objective")
    print("  differs. 'pred fire' against class-cond T is the primary comparison.")
    print("  missed/bg is the selectivity ratio: how much more abstention lands on")
    print("  missed fire than on correct background. Near 1 = indiscriminate.")
    print("  Report every row for every model -- this analysis was specified before")
    print("  running, and its value depends on reporting it in full.")


if __name__ == "__main__":
    main()
