r"""
HAZE SWEEP, ALL SCENES -- memory-safe rewrite.

The previous version loaded an entire scene's imagery into RAM and then built
two more full-size float32 copies per severity. For a ~729-patch scene that is
about three arrays of 2.3 GB each, and Kaggle ran out.

This version NEVER holds a whole scene. Patches are read from disk in small
batches and released immediately. Two loop orders are used depending on what is
needed:

  metrics only (scenes 1, 2, 4)
      outer loop over patches, inner loop over the nine severities.
      Each file is read from disk exactly once, all nine severities applied
      while it is resident, then discarded. Metrics accumulate as scalars.

  dumping logits (scene 3)
      outer loop over severities, inner loop over patches.
      Only one severity's logits are held at a time -- about 530 MB at fp16 for
      504 patches -- and written before the next severity starts.

WHY SWEEP EVERY SCENE

Every haze number so far comes from scene 4, the held-out geographic split. So
the dose-response is confounded: it could be a property of the MODEL under
atmospheric degradation, or of that particular region. Sweeping scenes 1-3 gives
the atmospheric curve with geography held fixed, which is what the research
question actually asks about. Scene 4 then becomes a secondary condition under
combined atmospheric AND geographic shift.

It also tests memorisation directly. Scenes 1-2 were seen in training. If they
degrade markedly more slowly under haze, the model leans on memorised patches
and the train/val IoU gap (0.42 vs 0.29) is overfitting rather than geographic
shift. Similar slopes everywhere means it is shift.

Kaggle: attach Sen2Fire AND the training version's output. GPU T4 (single is
fine). Roughly 2-3 hours for four scenes.
"""

import glob, time, gc
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# ------------------------------------------------------------------ config
DATA_ROOT   = "/kaggle/input"
OUT_DIR     = Path("/kaggle/working")
SCENES      = ["scene1", "scene2", "scene3", "scene4"]
DUMP_SCENES = ["scene3"]              # scene4 dumps already exist; 1-2 too big
BAND_IDX    = [3, 2, 1, 7, 10, 11]
WAVELEN     = np.array([665., 560., 490., 842., 1610., 2190.])
LAMBDA0, ALPHA = 550.0, 1.3
BETAS       = [0.0, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 1.00, 2.00]
BATCH       = 4
A_SAMPLE    = 120                     # patches used to estimate atmospheric light
IN_CH, OUT_CH, BASE = 6, 2, 64

DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT_DIR.mkdir(parents=True, exist_ok=True)
print("device:", DEV, flush=True)


# ------------------------------------------------------------------- model
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co*2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2)-x.size(-2); dx = skip.size(-1)-x.size(-1)
            x = F.pad(x, [dx//2, dx-dx//2, dy//2, dy-dy//2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b*2), Down(b*2, b*4)
        self.d3, self.d4 = Down(b*4, b*8), Down(b*8, b*16)
        self.u1, self.u2 = Up(b*16, b*8), Up(b*8, b*4)
        self.u3, self.u4 = Up(b*4, b*2), Up(b*2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)


# -------------------------------------------------------------------- haze
def transmission(b0):
    return np.exp(-b0 * (WAVELEN / LAMBDA0) ** (-ALPHA)).astype(np.float32)[:, None, None]

def apply_haze(img, b0, A):
    if b0 == 0.0:
        return img
    t = transmission(b0)
    return img * t + A[:, None, None] * (1.0 - t)

def _nd(a, b, eps=1e-6):
    return (a - b) / (a + b + eps)

def haze_cue(img):
    """From the HAZED bands: a deployed calibrator never sees the clean image."""
    ndvi = _nd(img[3], img[0]); nbr = _nd(img[3], img[5]); nbr2 = _nd(img[4], img[5])
    return np.nan_to_num(0.5*np.abs(ndvi-nbr) + 0.5*np.abs(ndvi-nbr2)).astype(np.float32)


# -------------------------------------------------------------------- data
def find(root, scene):
    return [f for f in sorted(glob.glob(str(Path(root)/"**"/"*.npz"), recursive=True))
            if scene in {p.lower() for p in Path(f).parts[:-1]}]

def load_patch(path, scale):
    with np.load(path, allow_pickle=True) as z:
        ks = list(z.keys())
        ik = next((k for k in ("image","img","data","x") if k in ks), ks[0])
        lk = next((k for k in ("label","mask","gt","y") if k in ks), ks[-1])
        ak = next((k for k in ("aerosol","s5p","aod") if k in ks), None)
        img = np.asarray(z[ik], dtype=np.float32)
        lab = np.asarray(z[lk])
        aer = np.asarray(z[ak], dtype=np.float32) if ak else None
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2, 0, 1))
    if lab.ndim == 3: lab = lab[0]
    if aer is None: aer = np.zeros(lab.shape, np.float32)
    if aer.ndim == 3: aer = aer[0]
    return (np.nan_to_num(img[BAND_IDX])*scale, (lab > 0).astype(np.uint8),
            np.nan_to_num(aer))


class Acc:
    """Running TP/FP/FN and fire-pixel confidence. Scalars only."""
    def __init__(self):
        self.tp = self.fp = self.fn = 0
        self.conf = 0.0; self.hit = 0; self.n = 0
    def add(self, lg, lab):
        pred = lg.argmax(1)
        self.tp += int(((pred==1)&(lab==1)).sum())
        self.fp += int(((pred==1)&(lab==0)).sum())
        self.fn += int(((pred==0)&(lab==1)).sum())
        fm = lab == 1
        if fm.any():
            self.conf += float(lg.softmax(1).max(1).values[fm].sum())
            self.hit  += int((pred[fm]==1).sum())
            self.n    += int(fm.sum())
    def row(self):
        e = 1e-9
        cf = self.conf/max(self.n,1) if self.n else float("nan")
        af = self.hit/max(self.n,1) if self.n else float("nan")
        return (self.tp/(self.tp+self.fp+self.fn+e), self.tp/(self.tp+self.fp+e),
                self.tp/(self.tp+self.fn+e), cf, af)


# -------------------------------------------------------------------- main
def main():
    sp = glob.glob(str(Path(DATA_ROOT)/"**"/"norm_stats.npz"), recursive=True)
    assert sp, "norm_stats.npz not found"
    zs = np.load(sp[0]); MEAN, STD, SCALE = zs["mean"], zs["std"], float(zs["scale"])
    cp = glob.glob(str(Path(DATA_ROOT)/"**"/"best.pt"), recursive=True)
    assert cp, "best.pt not found"
    ck = torch.load(cp[0], map_location=DEV, weights_only=False)
    model = UNet(IN_CH, OUT_CH, BASE).to(DEV)
    model.load_state_dict(ck["model"]); model.eval()
    print(f"loaded {cp[0]} (epoch {ck.get('epoch','?')})", flush=True)

    M3, S3 = MEAN[:, None, None], STD[:, None, None]
    summary = {}

    for scene in SCENES:
        files = find(DATA_ROOT, scene)
        if not files:
            print(f"\n{scene}: no patches, skipping"); continue
        role = ("TRAIN (seen)" if scene in ("scene1","scene2")
                else "VAL" if scene == "scene3" else "TEST (held out)")
        print(f"\n=== {scene}  [{role}]  {len(files)} patches ===", flush=True)

        # atmospheric light from a SAMPLE of this scene's clear imagery --
        # the 99th percentile is stable well before all patches are seen, and
        # sampling avoids holding the scene in memory just to compute it
        step = max(1, len(files)//A_SAMPLE)
        samp = np.stack([load_patch(f, SCALE)[0] for f in files[::step]])
        A = np.percentile(samp, 99, axis=(0,2,3)).astype(np.float32)
        fire_frac = None
        del samp; gc.collect()
        print(f"  atmospheric light A = {np.round(A,4)}", flush=True)

        dump = scene in DUMP_SCENES
        accs = {b: Acc() for b in BETAS}

        if not dump:
            # ---- patches outer, severities inner: each file read ONCE ----
            nf = tot = 0
            for i in range(0, len(files), BATCH):
                raw, labs, _ = zip(*[load_patch(f, SCALE) for f in files[i:i+BATCH]])
                raw = np.stack(raw); labs = np.stack(labs)
                nf += int(labs.sum()); tot += labs.size
                lab_t = torch.from_numpy(labs.astype(np.int64)).to(DEV)
                for b in BETAS:
                    hz = np.stack([apply_haze(im, b, A) for im in raw])
                    if b == 0.0:
                        assert np.allclose(hz, raw), "beta0=0 must reproduce input"
                    with torch.no_grad():
                        lg = model(torch.from_numpy((hz - M3)/(S3 + 1e-6)).to(DEV)).float()
                    accs[b].add(lg, lab_t)
                    del hz, lg
                del raw, labs, lab_t
                if (i//BATCH) % 40 == 0:
                    print(f"    {i}/{len(files)} patches", flush=True)
            fire_frac = 100*nf/max(tot,1)
        else:
            # ---- severities outer, patches inner: hold ONE severity's logits ----
            nf = tot = 0
            for b in BETAS:
                L, C, LB, AE = [], [], [], []
                for i in range(0, len(files), BATCH):
                    raw, labs, aers = zip(*[load_patch(f, SCALE) for f in files[i:i+BATCH]])
                    raw = np.stack(raw); labs = np.stack(labs); aers = np.stack(aers)
                    if b == BETAS[0]:
                        nf += int(labs.sum()); tot += labs.size
                    hz = np.stack([apply_haze(im, b, A) for im in raw])
                    if b == 0.0:
                        assert np.allclose(hz, raw), "beta0=0 must reproduce input"
                    with torch.no_grad():
                        lg = model(torch.from_numpy((hz - M3)/(S3 + 1e-6)).to(DEV)).float()
                    accs[b].add(lg, torch.from_numpy(labs.astype(np.int64)).to(DEV))
                    L.append(lg.cpu().numpy().astype(np.float16))
                    C.append(np.stack([haze_cue(h) for h in hz])[:, None].astype(np.float16))
                    LB.append(labs); AE.append(aers[:, None].astype(np.float16))
                    del raw, labs, aers, hz, lg
                tag = f"{b:.2f}".replace(".", "p")
                np.savez_compressed(
                    OUT_DIR/f"{scene}_haze_{tag}_logits.npz",
                    logits=np.concatenate(L), labels=np.concatenate(LB),
                    aerosol=np.concatenate(AE), haze_cue=np.concatenate(C),
                    beta0=b, alpha=ALPHA, lambda0=LAMBDA0,
                    transmission=transmission(b).ravel(), atmospheric_light=A)
                print(f"    dumped beta0={b:.2f}", flush=True)
                del L, C, LB, AE; gc.collect()
            fire_frac = 100*nf/max(tot,1)

        print(f"  fire {fire_frac:.2f}% of pixels")
        print(f"  {'beta0':<8}{'IoU':>9}{'prec':>8}{'rec':>8}"
              f"{'conf|fire':>11}{'acc|fire':>10}{'gap':>9}")
        rows = []
        for b in BETAS:
            iou, pr, rc, cf, af = accs[b].row()
            rows.append((b, iou, cf, af))
            print(f"  {b:<8.2f}{iou:>9.4f}{pr:>8.3f}{rc:>8.3f}"
                  f"{cf:>11.4f}{af:>10.4f}{cf-af:>9.4f}")
        summary[scene] = rows
        gc.collect()
        if DEV == "cuda": torch.cuda.empty_cache()

    # ---------------- cross-scene comparison ----------------
    if len(summary) > 1:
        print("\n\n=== DEGRADATION SLOPE BY SCENE ===")
        print("IoU normalised to each scene's own clear baseline, so the SHAPE")
        print("of the curve is comparable across scenes of differing difficulty.\n")
        print(f"  {'beta0':<8}" + "".join(f"{s:>12}" for s in summary))
        for i, b in enumerate(BETAS):
            line = f"  {b:<8.2f}"
            for s in summary:
                base = summary[s][0][1]
                line += f"{summary[s][i][1]/max(base,1e-9):>12.3f}"
            print(line)
        print("\n  Curves coinciding means atmospheric degradation is a property")
        print("  of the MODEL and the dose-response generalises. Training scenes")
        print("  degrading markedly more slowly would mean the model leans on")
        print("  memorised patches, making the train/val IoU gap overfitting")
        print("  rather than geographic shift.")

        print("\n=== CONFIDENCE GAP BY SCENE (conf|fire - acc|fire) ===")
        print(f"  {'beta0':<8}" + "".join(f"{s:>12}" for s in summary))
        for i, b in enumerate(BETAS):
            line = f"  {b:<8.2f}"
            for s in summary:
                _, _, cf, af = summary[s][i]
                line += f"{cf-af:>12.4f}"
            print(line)
        print("\n  A gap widening with severity in EVERY scene is the central")
        print("  claim: the model does not become less confident as its input is")
        print("  destroyed, regardless of region.")


if __name__ == "__main__":
    t = time.time(); main(); print(f"\ndone in {(time.time()-t)/60:.1f}m")
