r"""
MAKE AGREEMENT LABELS -- fire where two independent sensors agree.

WHY
About 95% of Sen2Fire's MODIS-labelled fire pixels show no fire in the
Sentinel-2 image: MODIS marks whole 1 km cells, and passes at a different time.
A Sentinel-2 model is worth having only for the fine detail it adds, so these
labels train it on fire that is actually visible -- confirmed by an independent
thermal sensor (MODIS) AND by the image itself.

THE LABEL (uint8, per pixel)
    1    FIRE        MODIS says fire  AND  a STRICT fire signature is present
    0    BACKGROUND  MODIS says background  AND  no signature of any strength,
                     and nothing within 30 m of one
  255    IGNORE      everything else: labelled fire with nothing visible,
                     signatures outside MODIS cells (often burn scars), and
                     borderline pixels. Skipped by training (ignore_index=255)
                     and by scoring.
Strict for fire, permissive for background exclusion: nothing doubtful is
allowed to count as either class.

THE SIGNATURES (on reflectance; B12 = SWIR2, B8A = narrow NIR, both 20 m)
  q = B12 / B8A
  PRIMARY  seed-and-grow, HOTMAP-motivated (a recent Sentinel-2 active-fire
           benchmark): seeds  B12 >= 0.35 and q >= 4.0; candidates
           B12 >= 0.25 and q >= 2.0; seeds grow into candidates by at most
           two four-neighbour steps. Thresholds well above burn scars.
  ALTERNATIVE  Charter HOTSPOT strict: q > 2.0 and B12 - B8A > 0.15,
           B12 >= 0.04. Saved as label_charter, for a sensitivity check.
  BACKGROUND EXCLUSION  Charter candidate (q > 1.1 and B12 - B8A > 0.10,
           B12 >= 0.04), dilated by 3 pixels (30 m).

CHECKS BUILT IN
  - Band order is re-verified from native resolution: Sen2Fire enlarged
    coarse bands by copying pixels, so the share of identical neighbours is
    ~0.18 for 10 m bands, ~0.57 for 20 m, ~0.86 for 60 m. Index 8 must be
    20 m (B8A) and index 9 60 m (B9); otherwise the script stops.
  - Patches are found and ordered exactly as the training and dump scripts do.

OUTPUT  (/kaggle/working/agreement_labels/)
  agreement_scene1.npz ... scene4   files, label, label_charter, flags
      flags bits: 1 permissive, 2 Charter strict, 4 seed-and-grow,
                  8 within 30 m of a permissive pixel
  summary.csv        per scene: counts for every label class and rule
  patch_counts.csv   per patch: MODIS fire, agreement fire, ignored pixels
  figures/*.png      example patches: fire composite, MODIS outline, the new
                     label (red fire, grey ignore)
  report.txt         everything printed, including the TRAINING VIABILITY check
No GPU needed. Attach only Sen2Fire.
"""

import os, glob, csv
from pathlib import Path
import numpy as np
from scipy import ndimage

ROOT = os.environ.get("AGREE_ROOT", "/kaggle/input")
OUT = Path(os.environ.get("AGREE_OUT", "/kaggle/working/agreement_labels"))
SCENES = ["scene1", "scene2", "scene3", "scene4"]
TRAIN_SCENES = ["scene1", "scene2"]
BAND = dict(B2=1, B3=2, B4=3, B8=7, B8A=8, B9=9, B11=10, B12=11)
IGNORE = 255
SEED, CAND, GROW = (0.35, 4.0), (0.25, 2.0), 2
CHARTER_STRICT, CHARTER_CAND, WATER = (2.0, 0.15), (1.1, 0.10), 0.04
NEAR_PX, N_FIG = 3, 6
CROSS = ndimage.generate_binary_structure(2, 1)

LOG = []
def say(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); LOG.append(s)


def find(root, scene):
    """Identical to the training and dump scripts, so patch order matches."""
    return [f for f in sorted(glob.glob(str(Path(root) / "**" / "*.npz"), recursive=True))
            if scene in {p.lower() for p in Path(f).parts[:-1]}]


def load_raw(path):
    with np.load(path, allow_pickle=True) as z:
        ks = list(z.keys())
        ik = next((k for k in ("image", "img", "data", "x") if k in ks), ks[0])
        lk = next((k for k in ("label", "mask", "gt", "y") if k in ks), ks[-1])
        img = np.asarray(z[ik], dtype=np.float32); lab = np.asarray(z[lk])
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2, 0, 1))
    if lab.ndim == 3: lab = lab[0]
    return np.nan_to_num(img), lab > 0


def check_bands(files):
    """Native resolution from the share of identical horizontal neighbours."""
    img, _ = load_raw(files[len(files) // 2])
    same = [float((img[b][:, :-1] == img[b][:, 1:]).mean()) for b in range(img.shape[0])]
    res = ["10 m" if s < 0.35 else "20 m" if s < 0.75 else "60 m" for s in same]
    say("  band check (identical neighbours -> native resolution): " +
        ", ".join(f"{b}:{s:.2f}/{r}" for b, (s, r) in enumerate(zip(same, res))))
    ok = (res[BAND["B8A"]] == "20 m" and res[BAND["B12"]] == "20 m" and res[BAND["B9"]] == "60 m"
          and res[BAND["B4"]] == "10 m")
    if not ok:
        raise SystemExit("BAND ORDER DOES NOT MATCH B1 B2 B3 B4 B5 B6 B7 B8 B8A B9 B11 B12 -- stopping. "
                         "Paste this output into the chat.")
    say("  band order confirmed: index 8 = B8A (20 m), index 9 = B9 (60 m), index 11 = B12 (20 m)")


def detect_scale(files):
    v = np.concatenate([load_raw(f)[0][BAND["B12"]].ravel()[::97] for f in files[:: max(1, len(files) // 20)]])
    p99 = float(np.percentile(v, 99)); scale = 1e-4 if p99 > 5 else 1.0
    say(f"  B12 99th percentile {p99:.1f} -> {'digital numbers, x 1e-4' if scale < 1 else 'already reflectance'}")
    return scale


def signatures(img, scale):
    b12 = img[BAND["B12"]] * scale; b8a = img[BAND["B8A"]] * scale
    q = np.where(b8a > 1e-6, b12 / np.maximum(b8a, 1e-6), np.inf); d = b12 - b8a
    seed = (b12 >= SEED[0]) & (q >= SEED[1]); cand = (b12 >= CAND[0]) & (q >= CAND[1])
    grow = seed.copy()
    for _ in range(GROW):
        grow |= ndimage.binary_dilation(grow, CROSS) & cand
    ok = b12 >= WATER
    strict = ok & (q > CHARTER_STRICT[0]) & (d > CHARTER_STRICT[1])
    perm = ok & (q > CHARTER_CAND[0]) & (d > CHARTER_CAND[1])
    near = ndimage.binary_dilation(perm, iterations=NEAR_PX)
    flags = (perm * 1 | strict * 2 | grow * 4 | near * 8).astype(np.uint8)
    return grow, strict, perm, near, flags


def make_label(modis, fire_sig, near):
    lab = np.full(modis.shape, IGNORE, np.uint8)
    lab[modis & fire_sig] = 1
    lab[~modis & ~near] = 0          # near already includes every permissive pixel
    return lab


def stretch(rgb):
    out = np.empty_like(rgb)
    for c in range(3):
        lo, hi = np.percentile(rgb[c], [2, 98]); out[c] = np.clip((rgb[c] - lo) / max(hi - lo, 1e-6), 0, 1)
    return np.transpose(out, (1, 2, 0))


def draw(path, img, scale, modis, label, title):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    edge = modis & ~ndimage.binary_erosion(modis)
    fc = stretch(img[[BAND["B12"], BAND["B8A"], BAND["B4"]]] * scale)
    tc = stretch(img[[BAND["B4"], BAND["B3"], BAND["B2"]]] * scale)
    fcl = fc.copy(); fcl[edge] = [0, 1, 1]
    lv = np.zeros(modis.shape + (3,)); lv[label == 0] = [0.12, 0.12, 0.12]
    lv[label == IGNORE] = [0.55, 0.55, 0.55]; lv[label == 1] = [1.0, 0.1, 0.1]; lv[edge] = [0, 1, 1]
    fig, ax = plt.subplots(1, 4, figsize=(18, 4.9))
    for a, im, t in zip(ax, [tc, fc, fcl, lv], ["true colour (B4 B3 B2)", "fire composite (B12 B8A B4)",
                                                 "fire composite + MODIS label (cyan)",
                                                 "AGREEMENT LABEL: red fire, dark background,\ngrey ignored; cyan = MODIS"]):
        a.imshow(im); a.set_title(t, fontsize=9); a.axis("off")
    fig.suptitle(title, fontsize=11); fig.tight_layout(rect=[0, 0, 1, 0.88]); fig.savefig(path, dpi=80); plt.close(fig)


def main():
    OUT.mkdir(parents=True, exist_ok=True); (OUT / "figures").mkdir(exist_ok=True)
    say("MAKE AGREEMENT LABELS")
    summary, patch_rows, banded = [], [], False
    for sc in SCENES:
        files = find(ROOT, sc)
        if not files:
            say(f"\n{sc}: no patches found -- skipped"); continue
        say(f"\n==================== {sc}: {len(files)} patches ====================")
        if not banded:
            check_bands(files); banded = True
        scale = detect_scale(files)
        n = len(files); LAB = LCH = FLG = None
        tot = dict(pixels=0, modis_fire=0, agree_fire=0, charter_fire=0, background=0, ignore=0,
                   seedgrow_outside_modis=0, charter_outside_modis=0, permissive_outside_modis=0)
        pf = []
        for i, f in enumerate(files):
            img, modis = load_raw(f)
            if LAB is None:
                LAB = np.zeros((n,) + modis.shape, np.uint8); LCH = np.zeros_like(LAB); FLG = np.zeros_like(LAB)
            grow, strict, perm, near, flags = signatures(img, scale)
            LAB[i] = make_label(modis, grow, near); LCH[i] = make_label(modis, strict, near); FLG[i] = flags
            a = int((LAB[i] == 1).sum())
            tot["pixels"] += modis.size; tot["modis_fire"] += int(modis.sum()); tot["agree_fire"] += a
            tot["charter_fire"] += int((LCH[i] == 1).sum()); tot["background"] += int((LAB[i] == 0).sum())
            tot["ignore"] += int((LAB[i] == IGNORE).sum())
            tot["seedgrow_outside_modis"] += int((grow & ~modis).sum())
            tot["charter_outside_modis"] += int((strict & ~modis).sum())
            tot["permissive_outside_modis"] += int((perm & ~modis).sum())
            patch_rows.append(dict(scene=sc, index=i, file=Path(f).name, modis_fire=int(modis.sum()),
                                   agreement_fire=a, charter_fire=int((LCH[i] == 1).sum()),
                                   ignored=int((LAB[i] == IGNORE).sum())))
            pf.append(a)
            if (i + 1) % 100 == 0: print(f"    {i + 1}/{n}", flush=True)
        pf = np.array(pf)
        P = tot["pixels"]; mf = max(tot["modis_fire"], 1)
        say(f"  MODIS fire pixels               {tot['modis_fire']:>13,}  ({100 * tot['modis_fire'] / P:.2f}% of the scene)")
        say(f"  AGREEMENT fire (primary rule)   {tot['agree_fire']:>13,}  ({100 * tot['agree_fire'] / mf:.2f}% of MODIS fire)")
        say(f"  agreement fire (Charter strict) {tot['charter_fire']:>13,}  ({100 * tot['charter_fire'] / mf:.2f}% of MODIS fire)")
        say(f"  clean background                {tot['background']:>13,}  ({100 * tot['background'] / P:.1f}% of the scene)")
        say(f"  ignored                         {tot['ignore']:>13,}  ({100 * tot['ignore'] / P:.1f}% of the scene)")
        say(f"  patches with any agreement fire {int((pf > 0).sum()):>5} / {n}    with >= 100 fire pixels "
            f"{int((pf >= 100).sum()):>5}")
        say("  signature pixels OUTSIDE MODIS cells (burn scars, or fire MODIS missed):")
        say(f"    primary {tot['seedgrow_outside_modis']:,}   Charter strict {tot['charter_outside_modis']:,}   "
            f"permissive {tot['permissive_outside_modis']:,}")
        summary.append(dict(scene=sc, patches=n, **tot, patches_with_fire=int((pf > 0).sum()),
                            patches_with_100_fire=int((pf >= 100).sum())))
        np.savez_compressed(OUT / f"agreement_{sc}.npz", files=np.array([Path(f).name for f in files]),
                            label=LAB, label_charter=LCH, flags=FLG,
                            legend=np.array(["label: 0 background, 1 fire, 255 ignore",
                                             "flags bits: 1 permissive, 2 Charter strict, 4 seed-and-grow, 8 within 30 m"]))
        say(f"  saved agreement_{sc}.npz")
        order = np.argsort(-pf)
        picks = [int(i) for i in order[: N_FIG // 2]]
        mf_pp = np.array([r["modis_fire"] for r in patch_rows if r["scene"] == sc])
        picks += [int(i) for i in np.argsort(-(mf_pp * (pf == 0)))[: N_FIG - len(picks)] if mf_pp[i] > 0]
        for i in picks:
            img, modis = load_raw(files[i])
            draw(OUT / "figures" / f"{sc}_patch{i:03d}.png", img, scale, modis, LAB[i],
                 f"{sc} patch {i} ({Path(files[i]).name}) | MODIS fire {int(modis.sum()):,} px | "
                 f"agreement fire {int((LAB[i] == 1).sum()):,} px")
        del LAB, LCH, FLG

    for name, rows in (("summary.csv", summary), ("patch_counts.csv", patch_rows)):
        if rows:
            with open(OUT / name, "w", newline="") as fh:
                w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

    tr = [s for s in summary if s["scene"] in TRAIN_SCENES]
    if tr:
        fire = sum(s["agree_fire"] for s in tr); pt = sum(s["patches_with_100_fire"] for s in tr)
        ch = sum(s["charter_fire"] for s in tr)
        say("\n==================== TRAINING VIABILITY (scenes 1 + 2) ====================")
        say(f"  agreement fire pixels: {fire:,} (primary)   {ch:,} (Charter strict)")
        say(f"  patches with at least 100 agreement fire pixels: {pt}")
        if fire >= 100_000 and pt >= 50:
            v = "VIABLE -- enough fire, spread over enough patches, to train on."
        elif fire >= 20_000 and pt >= 15:
            v = ("MARGINAL -- trainable, but expect noisier results; consider the Charter-strict "
                 "version if it has clearly more fire.")
        else:
            v = "NOT VIABLE as it stands -- too little fire to learn from. Stop and rethink before retraining."
        say(f"  verdict: {v}")
        say("  (Rough guide only: about 100,000 fire pixels across 50+ patches is comfortable for a U-Net.)")
    (OUT / "report.txt").write_text("\n".join(LOG))
    say(f"\nWrote everything to {OUT}")


if __name__ == "__main__":
    main()
