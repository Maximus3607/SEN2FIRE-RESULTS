r"""
CLASS-CONDITIONAL GATE: can the logit sum carry error information WITHIN each
predicted class, once the class split is taken out of its hands?

WHAT WENT WRONG
The trained gate abstained by PREDICTED CLASS, not by correctness:
    detected fire   pred fire   s -0.655   p(abst) 0.68
    false alarm     pred fire   s -0.678   p(abst) 0.72
    missed fire     pred bg     s -0.111   p(abst) 0.22
    correct bg      pred bg     s +0.235   p(abst) 0.05
Precision was ~45%, so ~55% of predicted-fire pixels are errors, while missed
fire is a sliver of the 62M predicted-background pixels. BCE therefore learned
the easy per-class error rate. The learned tau (~ -0.21) sits BETWEEN the two
predicted classes, making the gate a detector for "the model said fire".

On true fire pixels that is backwards: detected fire shares a predicted class
with false alarms (abstain), missed fire shares one with correct background
(don't). ECE(fire) only sees those two groups, so it got worse.

WHAT THIS TESTS
PART 1 -- is there signal to recover? AUROC of s for errors WITHIN each
predicted class. If both are near 0.5, no gate built on s can help and the
honest conclusion is that the sum re-encodes the prediction.

PART 2 -- a separate threshold per predicted class, fitted on the held-in half,
scored on the held-out half. c, k and gamma are kept from training; only
tau_bg and tau_fire are chosen, each from a quantile grid of s within that
class, plus an OFF option (gate shut, eta = c). The objective is
ECE(fire) + ECE(bg), equally weighted, because optimising ECE(fire) alone lets
the gate abstain on all predicted-background pixels and wreck background
calibration -- exactly the SAEA failure. Post-hoc, no retraining, accuracy
preserved because the null term is still shared by both class denominators.

Usage:  python3 classcond_gate.py gated_scene3_haze_0p00_logits.npz \
            gated_scene3_haze_0p20_logits.npz gated_scene3_haze_0p50_logits.npz
"""

import sys
import numpy as np

_trapz = getattr(np, "trapezoid", None) or getattr(np, "trapz")


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


def load(path, idx):
    z = np.load(path)
    for k in ("null_logit", "gate_c", "gate_k", "gate_gamma", "gate_tau"):
        assert k in z.files, f"{path} lacks {k}: needs model B's gated dumps"
    lg = z["logits"][idx].astype(np.float32); y = z["labels"][idx]
    if y.ndim == 4: y = y[:, 0]
    return dict(z0=lg[:, 0].ravel(), z1=lg[:, 1].ravel(), y=y.ravel().astype(np.int8),
                c=float(z["gate_c"]), k=float(z["gate_k"]),
                gamma=float(z["gate_gamma"]), tau=float(z["gate_tau"]),
                beta=float(z["beta0"]) if "beta0" in z.files else float("nan"))


def auroc(score, target):
    """AUROC for LOW score predicting target (errors should have low s)."""
    s = -score.astype(np.float64); t = target.astype(np.float64)
    npos, nneg = t.sum(), (1 - t).sum()
    if npos == 0 or nneg == 0: return float("nan")
    if s.size > 2_000_000:
        i = np.random.default_rng(0).choice(s.size, 2_000_000, replace=False)
        s, t = s[i], t[i]; npos, nneg = t.sum(), (1 - t).sum()
    o = np.argsort(s); r = np.empty(s.size); r[o] = np.arange(1, s.size + 1)
    return float((r[t == 1].sum() - npos*(npos+1)/2) / (npos*nneg))


def readout(d, tau_bg, tau_fire):
    """Gate with a separate threshold per PREDICTED class. None = gate shut."""
    s = 0.5 * (d["z0"] + d["z1"]); pred = d["z1"] > d["z0"]
    gate = np.zeros_like(s)
    for mask, tau in ((~pred, tau_bg), (pred, tau_fire)):
        if tau is not None:
            gate[mask] = sigmoid(d["gamma"] * (tau - s[mask]))
    eta = d["c"] + d["k"] * gate
    m = np.maximum(np.maximum(d["z0"], d["z1"]), eta)
    lse = m + np.log(np.exp(d["z0"]-m) + np.exp(d["z1"]-m) + np.exp(eta-m))
    pb, pf, pn = np.exp(d["z0"]-lse), np.exp(d["z1"]-lse), np.exp(eta-lse)
    conf = np.where(pred, pf, pb)                 # NOT renormalised
    corr = (pred == (d["y"] == 1)).astype(np.float32)
    return conf, corr, pn


def ece(conf, corr, nb=20):
    e = np.linspace(0, 1, nb + 1); n = conf.size; t = 0.0
    if n == 0: return float("nan")
    for i in range(nb):
        sel = (conf > e[i]) & (conf <= e[i+1]); k = int(sel.sum())
        if k: t += (k/n) * abs(corr[sel].mean() - conf[sel].mean())
    return float(t)


def aurc(conf, corr, nb=2000):
    e = np.linspace(0, 1, nb + 1)
    b = np.clip(np.searchsorted(e, conf, side="right") - 1, 0, nb - 1)
    n = np.bincount(b, minlength=nb)[::-1].astype(float)
    er = np.bincount(b, weights=1 - corr, minlength=nb)[::-1]
    cn, ce = np.cumsum(n), np.cumsum(er); k = cn > 0
    return float(_trapz(ce[k]/cn[k], cn[k]/cn[-1]))


def score_fast(d, tb, tf):
    """Only ECE(fire) and ECE(bg) -- the two terms the objective uses.
    Skipping AURC and aggregate ECE roughly halves the cost of every grid cell."""
    conf, corr, _ = readout(d, tb, tf)
    f, b = d["y"] == 1, d["y"] == 0
    return ece(conf[f], corr[f]) + ece(conf[b], corr[b])


def subsample(d, n_fire, n_bg, seed=0):
    """Stratified pixel subsample for the threshold search.

    Choosing TWO thresholds does not need 66 million pixels. Fire and
    background are sampled separately so the rare fire class keeps enough
    pixels for a stable ECE(fire) estimate -- a plain uniform sample would
    leave only ~3.5% fire.
    """
    rng = np.random.default_rng(seed)
    fi = np.flatnonzero(d["y"] == 1); bi = np.flatnonzero(d["y"] == 0)
    fi = rng.choice(fi, min(n_fire, fi.size), replace=False)
    bi = rng.choice(bi, min(n_bg, bi.size), replace=False)
    i = np.sort(np.concatenate([fi, bi]))
    return {k: (v[i] if isinstance(v, np.ndarray) else v) for k, v in d.items()}


def score(d, tb, tf):
    conf, corr, pn = readout(d, tb, tf)
    f, b = d["y"] == 1, d["y"] == 0
    return dict(ef=ece(conf[f], corr[f]), eb=ece(conf[b], corr[b]),
                e=ece(conf, corr), aurc=aurc(conf, corr),
                cf=float(conf[f].mean()), af=float(corr[f].mean()))


def main(paths):
    n = int(np.load(paths[0])["logits"].shape[0])
    perm = np.random.default_rng(0).permutation(n)      # SAME split as before
    fit_idx, ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])

    # ---------------- PART 1: within-class signal ----------------
    print("PART 1 -- does s separate errors WITHIN each predicted class?\n")
    print(f"  {'file':<30}{'pred-bg: missed vs correct':>28}{'pred-fire: FA vs detected':>28}")
    for p in paths:
        d = load(p, ev_idx)
        s = 0.5*(d["z0"]+d["z1"]); pred = d["z1"] > d["z0"]; y = d["y"] == 1
        wrong = pred != y
        a_bg = auroc(s[~pred], wrong[~pred]); a_f = auroc(s[pred], wrong[pred])
        print(f"  {p.split('/')[-1][:29]:<30}{max(a_bg,1-a_bg):>28.4f}{max(a_f,1-a_f):>28.4f}")
    print("  (usable AUROC; 0.5 = no signal. Model A's best hand-designed signal")
    print("   reached ~0.60-0.63; the evidence head 0.54-0.62 on the hard subset.)")

    # ---------------- PART 2: class-conditional gate ----------------
    df_full = load(paths[0], fit_idx)
    df = subsample(df_full, n_fire=400_000, n_bg=1_600_000)
    print(f"\n  threshold search on a stratified subsample: "
          f"{int((df['y']==1).sum()):,} fire + {int((df['y']==0).sum()):,} "
          f"background pixels (of {df_full['y'].size:,})", flush=True)
    s_f = 0.5*(df["z0"]+df["z1"]); pr = df["z1"] > df["z0"]
    q = np.linspace(0.02, 0.60, 15)
    grid_bg = [None] + list(np.quantile(s_f[~pr], q))
    grid_fi = [None] + list(np.quantile(s_f[pr], q))
    best = None; total = len(grid_bg) * len(grid_fi); done = 0
    for tb in grid_bg:
        for tf in grid_fi:
            obj = score_fast(df, tb, tf)
            if best is None or obj < best[0]:
                best = (obj, tb, tf)
            done += 1
        print(f"    searched {done}/{total}", flush=True)
    _, TB, TF = best
    fmt = lambda t: "OFF" if t is None else f"{t:+.3f}"
    print(f"\nPART 2 -- class-conditional gate, fitted on {len(fit_idx)} held-in patches")
    print(f"  tau_bg = {fmt(TB)}   tau_fire = {fmt(TF)}   "
          f"(trained single tau was {df['tau']:+.3f})")
    print(f"  objective: ECE(fire) + ECE(bg), so fire cannot be bought with background\n")

    for p in paths[1:]:
        d = load(p, ev_idx)
        rows = [("identity", None, None, True), ("trained gate", d["tau"], d["tau"], False),
                ("class-cond gate", TB, TF, False)]
        print(f"  {p.split('/')[-1]}   beta0 = {d['beta']}   ({len(ev_idx)} held-out patches)")
        print(f"    {'readout':<17}{'ECE':>9}{'ECE(fire)':>11}{'ECE(bg)':>10}{'AURC':>9}"
              f"{'conf|fire':>11}{'acc|fire':>10}")
        for nm, tb, tf, ident in rows:
            if ident:
                dd = dict(d); dd["c"] = -1e4       # eta -> -inf: exactly identity
                r = score(dd, None, None)
            else:
                r = score(d, tb, tf)
            print(f"    {nm:<17}{r['e']:>9.5f}{r['ef']:>11.5f}{r['eb']:>10.5f}"
                  f"{r['aurc']:>9.5f}{r['cf']:>11.4f}{r['af']:>10.4f}")
        print()

    print("HOW TO READ THIS")
    print("  PART 1 decides everything. If the pred-bg AUROC is well above 0.5,")
    print("  s carries real error information about MISSED fire, and a")
    print("  class-conditional gate has something to use. If both columns are")
    print("  near 0.5, s re-encodes the prediction and no gate on s can help.")
    print("  PART 2: the class-conditional gate should beat identity on ECE(fire)")
    print("  WITHOUT a large rise in ECE(bg). If it only helps by turning the gate")
    print("  OFF, the honest answer is that s adds nothing usable.")
    print("  acc|fire is identical in every row -- predictions never change.")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    main(sys.argv[1:])
