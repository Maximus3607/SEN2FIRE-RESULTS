r"""
HEIGHT CHECK: does the HEIGHT of a class's own logit carry error information?

The idea being tested. Two pixels can share a gap and a probability yet differ
in what backs that probability:
    pixel A   z_bg = 0.5, z_fire = -3.0   gap 3.5   p(bg) 0.971
    pixel B   z_bg = 5.0, z_fire =  1.5   gap 3.5   p(bg) 0.971
A is confident only because fire is REJECTED -- its background logit is barely
positive. B is confident because background is ASSERTED. The hypothesis: a
confident prediction not backed by a tall logit of its own class is more likely
to be wrong. Softmax cannot see this; it reads only the gap. Model A could not
even express it (z1 = -z0 forces the heights), but model B's logits can.

SIGNALS, each scored within one predicted class
    gap        z1 - z0                      what plain softmax already reads
    sum        (z0 + z1) / 2                what the trained gate read
    z_bg       height of the background logit
    z_fire     height of the fire logit
    winner     height of the PREDICTED class's logit   <- the core idea
    loser      height of the REJECTED class's logit
    backing    winner / |gap|  -- how much of the confidence is asserted
               rather than won by rejection. NON-linear, so it is not already
               covered by the earlier linear sum+gap test.

THE CEILING
Any "magnitude" built from these logits is some function of the two numbers
(z0, z1). So the last row is the best possible such function: the (z0, z1)
plane is cut into a 40x40 grid of quantile cells, the error rate of each cell
is measured on the HELD-IN half, and that rate is used as the score on the
HELD-OUT half. No definition of magnitude computed from the two logits -- linear
or not, threshold or not -- can meaningfully beat this row. If the ceiling ties
the gap, no new identity for magnitude can help; if it clearly beats the gap,
some identity can, and the winner/backing rows show which.

Usage:
  python3 height_check.py gated_scene3_haze_0p20_logits.npz scene3_haze_0p20_logits.npz
"""

import sys
import numpy as np


def auroc(score, target, n=2_000_000, seed=0):
    s = np.asarray(score, np.float64).ravel(); t = np.asarray(target, np.float64).ravel()
    if s.size > n:
        i = np.random.default_rng(seed).choice(s.size, n, replace=False)
        s, t = s[i], t[i]
    npos, nneg = t.sum(), (1 - t).sum()
    if npos == 0 or nneg == 0: return float("nan")
    o = np.argsort(s, kind="stable"); r = np.empty(s.size); r[o] = np.arange(1, s.size + 1)
    a = float((r[t == 1].sum() - npos*(npos+1)/2) / (npos*nneg))
    return max(a, 1 - a)                       # usable: invert if it ranks backwards


def signals(z0, z1, pred):
    g = z1 - z0
    win = np.where(pred, z1, z0); lose = np.where(pred, z0, z1)
    return {"gap": g, "sum": 0.5*(z0 + z1), "z_bg": z0, "z_fire": z1,
            "winner": win, "loser": lose,
            "backing": win / (np.abs(g) + 1e-3)}


def ceiling(z0f, z1f, ef, z0e, z1e, nb=40, alpha=20.0):
    """Best possible function of (z0, z1): per-cell error rate from the held-in
    half, smoothed toward the overall rate, applied to the held-out half."""
    qa = np.unique(np.quantile(z0f, np.linspace(0, 1, nb + 1)))
    qb = np.unique(np.quantile(z1f, np.linspace(0, 1, nb + 1)))
    ia = np.clip(np.searchsorted(qa, z0f, "right") - 1, 0, len(qa) - 2)
    ib = np.clip(np.searchsorted(qb, z1f, "right") - 1, 0, len(qb) - 2)
    K = (len(qa) - 1) * (len(qb) - 1); cell = ia * (len(qb) - 1) + ib
    cnt = np.bincount(cell, minlength=K).astype(float)
    err = np.bincount(cell, weights=ef, minlength=K)
    p0 = ef.mean(); rate = (err + alpha*p0) / (cnt + alpha)
    ja = np.clip(np.searchsorted(qa, z0e, "right") - 1, 0, len(qa) - 2)
    jb = np.clip(np.searchsorted(qb, z1e, "right") - 1, 0, len(qb) - 2)
    return rate[ja * (len(qb) - 1) + jb]


def main(paths):
    for path in paths:
        z = np.load(path)
        lg = z["logits"].astype(np.float32); y = z["labels"]
        if y.ndim == 4: y = y[:, 0]
        n = lg.shape[0]
        perm = np.random.default_rng(0).permutation(n)       # SAME split as before
        fit, evl = np.sort(perm[:n//2]), np.sort(perm[n//2:])
        tag = "MODEL B" if "null_logit" in z.files else "MODEL A"
        beta = float(z["beta0"]) if "beta0" in z.files else float("nan")

        def flat(idx):
            a, b = lg[idx, 0].ravel(), lg[idx, 1].ravel()
            p = b > a
            return a, b, p, (p != (y[idx].ravel() == 1)).astype(np.float64)
        z0f, z1f, pf, ef = flat(fit); z0e, z1e, pe, ee = flat(evl)

        print(f"\n=== {path.split('/')[-1]}   {tag}   beta0 = {beta}   "
              f"({len(evl)} held-out patches)")
        print(f"  usable AUROC for errors, within each predicted class")
        print(f"  {'signal':<12}{'pred BACKGROUND':>18}{'pred FIRE':>12}"
              f"      (bg: missed fire vs correct bg | fire: false alarm vs detected)")
        res = {}
        for want, col in ((False, "bg"), (True, "fire")):
            me = pe == want; mf = pf == want
            S = signals(z0e[me], z1e[me], pe[me])
            for k, v in S.items():
                res.setdefault(k, {})[col] = auroc(v, ee[me])
            rng = np.random.default_rng(1); fi = np.flatnonzero(mf)
            if fi.size > 3_000_000: fi = rng.choice(fi, 3_000_000, replace=False)
            res.setdefault("CEILING", {})[col] = auroc(
                ceiling(z0f[fi], z1f[fi], ef[fi], z0e[me], z1e[me]), ee[me])
        for k in ("gap", "sum", "z_bg", "z_fire", "winner", "loser", "backing"):
            print(f"  {k:<12}{res[k]['bg']:>18.4f}{res[k]['fire']:>12.4f}")
        print(f"  {'-'*42}")
        print(f"  {'CEILING':<12}{res['CEILING']['bg']:>18.4f}{res['CEILING']['fire']:>12.4f}"
              f"      best possible function of (z0, z1)")
        gain = res["CEILING"]["bg"] - res["gap"]["bg"]
        print(f"  ceiling minus gap, predicted background: {gain:+.4f}")

    print("\nHOW TO READ THIS")
    print("  'winner' is your idea: the height of the predicted class's own logit.")
    print("  'backing' asks how much of the confidence is asserted rather than won")
    print("  by rejecting the other class.")
    print("  The CEILING row is the most any definition of magnitude built from")
    print("  these two logits could achieve. Compare it with 'gap':")
    print("    ceiling ~ gap        -> no identity for magnitude can help; the two")
    print("                            logits hold no more error information than the")
    print("                            gap alone.")
    print("    ceiling clearly > gap -> some identity can, and whichever single row")
    print("                            comes closest to the ceiling is the one to use.")
    print("  On MODEL A every height is fixed by the gap, so those rows should")
    print("  match the gap -- a built-in sanity check.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    main(sys.argv[1:])
