"""
TEN-MINUTE CHECK: does physically-correct smoke haze actually shift this model?

Run this BEFORE building the full sweep. It answers one question: when smoke is
simulated with the correct WAVELENGTH DEPENDENCE, does the model degrade at all?

Why it might not. The Sen2Fire authors found SWIR1 and SWIR2 are the critical
bands for fire detection, with NIR helping to penetrate smoke and cloud. Smoke
particles are ~0.3 um, so they scatter light of comparable wavelength strongly
and longer wavelengths weakly. At severe haze (optical depth 2.0 at 550 nm)
SWIR2 still transmits ~72% of the ground signal while blue transmits ~10%.

So the bands carrying most of the fire information are the ones smoke barely
touches. If IoU does not move, smoke is the WRONG shift axis for this model,
and the honest response is to switch to thin cloud (which does attenuate SWIR)
rather than to build a sweep that measures nothing.

THE MODEL
  Angstrom turbidity:      beta(L) = beta0 * (L/L0)^(-alpha)
  Beer-Lambert extinction: t(L)    = exp(-beta(L) * d),  d = 1 for nadir view
  Koschmieder scattering:  I(L)    = J(L)*t(L) + A(L)*(1 - t(L))

  beta0 is the ONLY thing swept. It equals aerosol optical depth at 550 nm
  because d = 1, which makes it directly comparable to satellite AOD products.
  alpha = 1.3 places this in the biomass-burning regime (AERONET smoke
  retrievals run ~1.2-2.0; dust is ~0-0.5).

  A(L), the atmospheric light, is estimated from the 99th percentile of the
  CLEAR imagery per band -- the standard estimator from the dehazing
  literature -- rather than guessed.

IMPORTANT ORDER OF OPERATIONS
  Haze is applied to RAW REFLECTANCE, before standardisation. Applying it after
  would be physically meaningless: the per-band mean subtraction destroys the
  reflectance scale the scattering model operates on.

Kaggle:  attach the Sen2Fire dataset AND the training version's output
         (for best.pt). GPU T4. A few minutes.
"""

import glob, time
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# ------------------------------------------------------------------ config
DATA_ROOT = "/kaggle/input"
CKPT_GLOB = "/kaggle/input/**/best.pt"
N_PATCHES = 24                       # enough to see a real effect
BAND_IDX  = [3, 2, 1, 7, 10, 11]     # R, G, B, NIR, SWIR1, SWIR2
WAVELEN   = np.array([665., 560., 490., 842., 1610., 2190.])   # nm, same order
LAMBDA0   = 550.0                    # conventional AOD reference
ALPHA     = 1.3                      # biomass-burning Angstrom exponent
BETAS     = [0.0, 0.2, 0.5, 1.0, 2.0]            # clear -> extreme
IN_CH, OUT_CH, BASE = 6, 2, 64

DEV = "cuda" if torch.cuda.is_available() else "cpu"
print("device:", DEV)


# ------------------------------------------------------------------- model
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co*2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2)-x.size(-2); dx = skip.size(-1)-x.size(-1)
            x = F.pad(x, [dx//2, dx-dx//2, dy//2, dy-dy//2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b*2), Down(b*2, b*4)
        self.d3, self.d4 = Down(b*4, b*8), Down(b*8, b*16)
        self.u1, self.u2 = Up(b*16, b*8), Up(b*8, b*4)
        self.u3, self.u4 = Up(b*4, b*2), Up(b*2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)


# -------------------------------------------------------------------- haze
def transmission(beta0, alpha=ALPHA, wl=WAVELEN, l0=LAMBDA0):
    """Angstrom -> Beer-Lambert. Returns one transmission per band, shape (6,1,1).

    d = 1: a satellite views a fixed atmospheric column at near-nadir, so path
    length is constant across the scene and folds into beta0. That is why beta0
    reads directly as optical depth.
    """
    beta = beta0 * (wl / l0) ** (-alpha)
    return np.exp(-beta).astype(np.float32)[:, None, None]


def apply_haze(img, beta0, A):
    """Koschmieder, per band, on RAW reflectance. img (6,H,W)."""
    if beta0 == 0.0:
        return img                                   # must be bit-identical
    t = transmission(beta0)
    return img * t + A[:, None, None] * (1.0 - t)


# -------------------------------------------------------------------- data
def find_test_files(root):
    out = []
    for f in sorted(glob.glob(str(Path(root) / "**" / "*.npz"), recursive=True)):
        if "scene4" in {p.lower() for p in Path(f).parts[:-1]}:
            out.append(f)
    return out


def load_patch(path, scale):
    z = np.load(path, allow_pickle=True)
    ks = list(z.keys())
    ik = next((k for k in ("image","img","data","x") if k in ks), ks[0])
    lk = next((k for k in ("label","mask","gt","y") if k in ks), ks[-1])
    img = np.asarray(z[ik], dtype=np.float32)
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2, 0, 1))
    lab = np.asarray(z[lk])
    if lab.ndim == 3: lab = lab[0]
    return np.nan_to_num(img[BAND_IDX]) * scale, (lab > 0).astype(np.int64)


# -------------------------------------------------------------------- main
def main():
    files = find_test_files(DATA_ROOT)
    assert files, "no scene4 patches found under /kaggle/input"
    rng = np.random.default_rng(0)
    pick = [files[i] for i in rng.choice(len(files), min(N_PATCHES, len(files)),
                                         replace=False)]
    print(f"{len(files)} scene4 patches found, using {len(pick)}")

    stats = glob.glob(str(Path(DATA_ROOT) / "**" / "norm_stats.npz"), recursive=True)
    assert stats, "norm_stats.npz not found -- attach the training output"
    zs = np.load(stats[0]); MEAN, STD, SCALE = zs["mean"], zs["std"], float(zs["scale"])
    print(f"norm stats loaded: scale {SCALE:g}")

    imgs, labs = zip(*[load_patch(f, SCALE) for f in pick])
    imgs = np.stack(imgs); labs = np.stack(labs)
    print(f"patches {imgs.shape}, fire {100*labs.mean():.2f}% of pixels")

    # atmospheric light: 99th percentile per band of the CLEAR imagery
    A = np.percentile(imgs, 99, axis=(0, 2, 3)).astype(np.float32)
    print("atmospheric light A per band:", np.round(A, 4))

    print("\ntransmission by band and severity (fraction of ground signal kept):")
    names = ["Red", "Green", "Blue", "NIR", "SWIR1", "SWIR2"]
    print(f"  {'beta0':<8}" + "".join(f"{n:>9}" for n in names))
    for b in BETAS:
        t = transmission(b).ravel()
        print(f"  {b:<8.2f}" + "".join(f"{v:>9.3f}" for v in t))
    print("  Note how little SWIR2 moves. Those are the fire-carrying bands.")

    ck_paths = glob.glob(CKPT_GLOB, recursive=True)
    assert ck_paths, "best.pt not found -- attach the training version's output"
    ck = torch.load(ck_paths[0], map_location=DEV, weights_only=False)
    model = UNet(IN_CH, OUT_CH, BASE).to(DEV)
    model.load_state_dict(ck["model"]); model.eval()
    print(f"\nloaded {ck_paths[0]} (epoch {ck.get('epoch','?')})")

    lab_t = torch.from_numpy(labs).to(DEV)
    print(f"\n{'beta0':<8}{'IoU':>9}{'prec':>8}{'rec':>8}"
          f"{'mean conf':>11}{'conf|fire':>11}{'acc|fire':>10}")
    print("-" * 65)
    base_iou = None
    for b in BETAS:
        hz = np.stack([apply_haze(im, b, A) for im in imgs])
        norm = (hz - MEAN[:, None, None]) / (STD[:, None, None] + 1e-6)
        x = torch.from_numpy(norm).to(DEV)
        with torch.no_grad():
            lg = torch.cat([model(x[i:i+4]) for i in range(0, len(x), 4)]).float()
        prob = lg.softmax(1); pred = lg.argmax(1)
        tp = ((pred==1)&(lab_t==1)).sum().item()
        fp = ((pred==1)&(lab_t==0)).sum().item()
        fn = ((pred==0)&(lab_t==1)).sum().item()
        e = 1e-9
        iou = tp/(tp+fp+fn+e)
        conf = prob.max(1).values
        fm = lab_t == 1
        cf = conf[fm].mean().item() if fm.any() else float("nan")
        af = (pred[fm]==1).float().mean().item() if fm.any() else float("nan")
        if base_iou is None: base_iou = iou
        print(f"{b:<8.2f}{iou:>9.4f}{tp/(tp+fp+e):>8.3f}{tp/(tp+fn+e):>8.3f}"
              f"{conf.mean().item():>11.4f}{cf:>11.4f}{af:>10.4f}")

        if b == 0.0:
            # clear condition MUST reproduce the originals exactly
            assert np.allclose(hz, imgs), "beta0=0 did not reproduce the input"

    print("\nVERDICT")
    print("  If IoU falls substantially by beta0=2.0, smoke is a usable shift")
    print("  axis: build the full sweep with 5 severities and several spatial")
    print("  realisations per level.")
    print("  If IoU is nearly flat, the model is robust to smoke because SWIR")
    print("  carries the fire signal through it. That is a REAL finding, but it")
    print("  means smoke cannot be the shift variable -- switch to thin cloud,")
    print("  which attenuates SWIR too, and re-run this check.")
    print("  Watch 'conf|fire' against 'acc|fire': confidence staying high while")
    print("  accuracy falls IS the miscalibration the project targets.")


if __name__ == "__main__":
    t0 = time.time(); main(); print(f"\ndone in {time.time()-t0:.1f}s")
