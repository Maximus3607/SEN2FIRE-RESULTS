r"""
EVERY PIXEL -- do the results hold when nothing is ignored?

Every earlier score skipped the agreement labels' IGNORED pixels (about 13-18% of
each scene, concentrated around fires). This script scores the same networks and
readouts on EVERY pixel, under three label versions:

  agreement  as before: ignored pixels skipped. SANITY CHECK -- must reproduce
             haze_readouts.py (compared automatically if its readout_results.csv
             is attached as an input).
  visible    fire wherever the strict seed-and-grow SWIR signature appears in the
             CLEAR image -- inside or outside MODIS cells; background everywhere
             else, including the rings around fires and burn scars. Nothing ignored.
  modis      the original Sen2Fire MODIS labels. Nothing ignored. Shows how the
             networks treat fire the sensor cannot see (~95% of MODIS fire).

It also breaks the ignored pixels into what they are, and reports how the network
treats each kind:
  MODIS fire, nothing visible          the 1 km cells' unburnt ground
  strict signature outside MODIS       probably real fire MODIS missed
  near a weak signature                rings around fires, burn scars, borderline

READOUTS -- fitted EXACTLY as in haze_readouts.py (same samples, same seeds, same
haze levels, agreement labels), so the readout being judged is the same one:
  softmax, temperature (mixture), class-cond T (mixture), gate Brier-fit (mixture),
plus the standard post-hoc calibrators, fitted on the same weighted samples:
  Platt (mixture)     sigmoid(a + b * gap), weighted logistic regression
  beta (mixture)      sigmoid(c + a ln p - b ln(1 - p)), p = softmax  (Kull et al. 2017)
  isotonic (mixture)  monotone map of the gap, weighted pool-adjacent-violators
These three can MOVE the decision boundary, so every readout's prediction is taken
from its own probabilities, and IoU is reported for each.

For each label version, haze type (alpha 1.3 and 0), scene and haze level:
IoU, precision, recall; confidence on missed fire (softmax -> gate) and correct
background; selectivity; MaxLogit AUROC for missed fire vs correct background;
true-fire ECE and confidence Brier, gate vs softmax with paired-bootstrap 95% CIs;
and fire Brier (Brier on true-fire pixels only), whose values are not drowned by
background, so relative changes are readable.
PROPER SCORES for every readout: NLL and three-outcome Brier of the full class
probabilities (these penalise abstention by construction), and confidence NLL /
confidence Brier -- log and squared scores of confidence as a forecast of being
correct, the bin-free test of calibration -- overall and on true-fire pixels.

KAGGLE SETUP -- inputs as haze_readouts.py:
  Sen2Fire; the agreement-label notebook's output; both training outputs.
  Optional: the haze_readouts notebook's output (for the automatic sanity check).
  Accelerator GPU T4.  Save Version -> Save & Run All.  Roughly 1.5 hours.
OUTPUT (/kaggle/working/every_pixel/): report.txt, every_pixel_results.csv,
  every_pixel_cis.csv, ignored_pixels.csv
"""

import os, glob, csv
from pathlib import Path
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F

ROOT = os.environ.get("EP_ROOT", "/kaggle/input")
OUT = Path(os.environ.get("EP_OUT", "/kaggle/working/every_pixel"))
FIT_BETAS = [0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0]          # identical to haze_readouts.py: identical fits
SCORE_BETAS = [float(b) for b in os.environ.get("EP_BETAS", "0,1,2,3,4").split(",")]
ALPHAS = [float(a) for a in os.environ.get("EP_ALPHAS", "1.3,0.0").split(",")]
BOOT = int(os.environ.get("EP_BOOT", 300))
MAXP = int(os.environ.get("EP_MAXP", 0))
DEV = "cuda" if torch.cuda.is_available() else "cpu"
BAND_IDX = [3, 2, 1, 7, 10, 11]
WL6 = np.array([665., 560., 490., 842., 1610., 2190.])
LAMBDA0, A_SAMPLE, IGNORE, NB = 550.0, 120, 255, 20
FIX_C, FIX_K, FIX_G = -5.658, 8.486, 2.751
BG_RATE = 0.004
READOUTS = ["softmax", "temperature (mixture)", "class-cond T (mixture)", "Platt (mixture)", "beta (mixture)",
            "isotonic (mixture)", "gate Brier-fit (mixture)"]
CALIBRATORS = ["Platt (mixture)", "beta (mixture)", "isotonic (mixture)"]     # can move the decision boundary
SLOPE_MAX = float(np.exp(4))      # same range as the temperature search: T in [e^-4, e^4]
KEY = "gate Brier-fit (mixture)"
VERSIONS = ["agreement", "visible", "modis"]
MISS_KEEP = {"agreement": 1.0, "visible": 1.0, "modis": 0.02}     # AUROC samples
CBG_KEEP = 0.002
CATS = ["MODIS fire, nothing visible", "strict signature outside MODIS", "near a weak signature"]
SEEDGROW_BIT = 4

LOG = []
def say(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); LOG.append(s)


# ------------------------------------------------------------- network
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co * 2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2) - x.size(-2); dx = skip.size(-1) - x.size(-1)
            x = F.pad(x, [dx // 2, dx - dx // 2, dy // 2, dy - dy // 2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b * 2), Down(b * 2, b * 4)
        self.d3, self.d4 = Down(b * 4, b * 8), Down(b * 8, b * 16)
        self.u1, self.u2 = Up(b * 16, b * 8), Up(b * 8, b * 4)
        self.u3, self.u4 = Up(b * 4, b * 2), Up(b * 2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)


# ---------------------------------------------------------------- data
def find(root, scene):
    return [f for f in sorted(glob.glob(str(Path(root) / "**" / "*.npz"), recursive=True))
            if scene in {p.lower() for p in Path(f).parts[:-1]}]


def read_patch(path):
    """-> (six input bands, MODIS label as bool)."""
    with np.load(path, allow_pickle=True) as z:
        ks = list(z.keys())
        ik = next((k for k in ("image", "img", "data", "x") if k in ks), ks[0])
        lk = next((k for k in ("label", "mask", "gt", "y") if k in ks), ks[-1])
        img = np.asarray(z[ik], dtype=np.float32); lab = np.asarray(z[lk])
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2, 0, 1))
    if lab.ndim == 3: lab = lab[0]
    return np.nan_to_num(img[BAND_IDX]), lab > 0


def haze(x, b0, A, alpha):
    if b0 == 0.0: return x
    t = np.exp(-b0 * (WL6 / LAMBDA0) ** (-alpha)).astype(np.float32)[:, None, None]
    return x * t + A[:, None, None] * (1.0 - t)


def load_models():
    out = []
    found = sorted(glob.glob(str(Path(ROOT) / "**" / "best.pt"), recursive=True))
    if not found:
        raise SystemExit("No best.pt anywhere under " + ROOT + " -- the training notebooks are not attached. "
                         "Add Input -> Notebook Output -> add ag-seed-1 and ag-seed-2, then run again.")
    for ck in found:
        d = torch.load(ck, map_location=DEV, weights_only=False)
        if "agreement" not in str(d.get("labels", "")):
            say(f"  skipping {ck}: not an agreement-label checkpoint (labels = {d.get('labels', 'not recorded')})"); continue
        ns = Path(ck).parent / "norm_stats.npz"
        if not ns.exists():
            say(f"  skipping {ck}: no norm_stats.npz in the same folder"); continue
        z = np.load(ns); base = d["model"]["inc.block.0.weight"].shape[0]
        m = UNet(6, 2, base).to(DEV); m.load_state_dict(d["model"]); m.eval()
        name = f"seed {d['seed']}"
        if any(x["name"] == name for x in out):
            name += f" (run {sum(x['name'].startswith(name) for x in out) + 1})"
            say(f"  WARNING: two checkpoints share seed {d['seed']} -- same-seed runs show only GPU randomness")
        out.append(dict(name=name, model=m, mean=z["mean"], std=z["std"], scale=float(z["scale"])))
        say(f"  loaded network {name} (best epoch {d['epoch']}) from {ck}")
    if not out: raise SystemExit("No agreement-label best.pt found -- attach the training outputs.")
    return out


@torch.no_grad()
def logits(m, x6):
    xn = (x6 - m["mean"][:, None, None]) / (m["std"][:, None, None] + 1e-6)
    return m["model"](torch.from_numpy(xn).float().to(DEV)).float().cpu().numpy()


# ------------------------------------------------- readouts (as haze_readouts.py)
def sig(x): return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


def three(z0, z1, eta):
    m = np.maximum(np.maximum(z0, z1), eta)
    a, b, c = np.exp(z0 - m), np.exp(z1 - m), np.exp(eta - m); Z = a + b + c
    return a / Z, b / Z, c / Z


def apply(rd, z0, z1):
    g = z1 - z0; pred = g > 0
    if rd["kind"] == "softmax":
        pf = sig(g); return 1 - pf, pf, np.zeros_like(pf)
    if rd["kind"] == "T":
        pf = sig(g / rd["T"]); return 1 - pf, pf, np.zeros_like(pf)
    if rd["kind"] == "ccT":
        pf = sig(g / np.where(pred, rd["T"][1], rd["T"][0])); return 1 - pf, pf, np.zeros_like(pf)
    if rd["kind"] == "platt":
        pf = sig(rd["w"][0] + rd["w"][1] * g); return 1 - pf, pf, np.zeros_like(pf)
    if rd["kind"] == "beta":
        p = np.clip(sig(g), 1e-7, 1 - 1e-7)
        pf = sig(rd["w"][0] + rd["w"][1] * np.log(p) - rd["w"][2] * np.log(1 - p)); return 1 - pf, pf, np.zeros_like(pf)
    if rd["kind"] == "iso":
        edges, table = rd["model"]
        pf = table[np.clip(np.searchsorted(edges, g, "right") - 1, 0, len(table) - 1)].astype(np.float64)
        return 1 - pf, pf, np.zeros_like(pf)
    if all(t is None for t in rd["tau"]):
        pf = sig(g); return 1 - pf, pf, np.zeros_like(pf)
    h = np.maximum(z0, z1); eta = np.full(z0.shape, -1e4)
    for c in (0, 1):
        t = rd["tau"][c]
        if t is None: continue
        m = pred == bool(c); eta[m] = FIX_C + FIX_K * sig(rd["gam"][c] * (t - h[m]))
    return three(z0, z1, eta)


def _logistic(X, y, w, w0, lo, hi, iters=60):
    """Weighted logistic regression by damped Newton steps; coefficients clipped to [lo, hi]."""
    w = w / w.mean(); b = np.array(w0, np.float64)
    def nll(c):
        q = np.clip(sig(X @ c), 1e-12, 1 - 1e-12)
        return -(w * (y * np.log(q) + (1 - y) * np.log(1 - q))).mean()
    cur = nll(b)
    for _ in range(iters):
        q = sig(X @ b); H = (X * (w * q * (1 - q))[:, None]).T @ X / len(y) + 1e-6 * np.eye(len(b))
        step = np.linalg.solve(H, X.T @ (w * (q - y)) / len(y)); t = 1.0
        while t > 1e-4:                                     # backtracking: never increase the loss
            cand = np.clip(b - t * step, lo, hi); new = nll(cand)
            if new <= cur: break
            t *= 0.5
        if t <= 1e-4 or abs(cur - new) < 1e-12: break
        b, cur = cand, new
    return b


def fit_platt(g, y, w):
    X = np.column_stack([np.ones_like(g), g]).astype(np.float64)
    return _logistic(X, y.astype(np.float64), w, [0.0, 1.0], [-1e3, 1 / SLOPE_MAX], [1e3, SLOPE_MAX])


def fit_beta(g, y, w):
    p = np.clip(sig(g.astype(np.float64)), 1e-7, 1 - 1e-7)
    X = np.column_stack([np.ones_like(p), np.log(p), -np.log(1 - p)])
    return _logistic(X, y.astype(np.float64), w, [0.0, 1.0, 1.0], [-1e3, -SLOPE_MAX, -SLOPE_MAX],
                     [1e3, SLOPE_MAX, SLOPE_MAX])


def fit_isotonic(g, y, w, nb=2000):
    """Weighted pool-adjacent-violators on quantile bins of the gap -> monotone P(fire | gap)."""
    edges = np.unique(np.quantile(g, np.linspace(0, 1, nb + 1)))
    b = np.clip(np.searchsorted(edges, g, "right") - 1, 0, len(edges) - 2)
    n = np.bincount(b, w, len(edges) - 1); s = np.bincount(b, w * y.astype(float), len(edges) - 1)
    keep = np.flatnonzero(n > 0); val, wt, blocks = [], [], []
    for idx in keep:
        val.append(s[idx] / n[idx]); wt.append(n[idx]); blocks.append([idx])
        while len(val) > 1 and val[-2] > val[-1]:
            v2, w2, b2 = val.pop(), wt.pop(), blocks.pop()
            val[-1] = (val[-1] * wt[-1] + v2 * w2) / (wt[-1] + w2); wt[-1] += w2; blocks[-1] += b2
    table = np.full(len(edges) - 1, np.nan)
    for v, bl in zip(val, blocks): table[bl] = v
    filled = np.flatnonzero(np.isfinite(table))                # empty bins take their neighbours' value
    table = np.interp(np.arange(len(table)), filled, table[filled])
    return edges, table, len(val)


def fit(kind, S):
    z0, z1, y, w = S["z0"], S["z1"], S["y"].astype(bool), S["w"]
    g = z1 - z0; pred = g > 0; corr = (pred == y).astype(np.float64)
    def nll(T, m):
        p = np.clip(sig(g[m] / T), 1e-12, 1 - 1e-12); yy = y[m]
        return -(w[m] * np.where(yy, np.log(p), np.log(1 - p))).sum() / max(w[m].sum(), 1e-12)
    if kind == "platt": return dict(kind="platt", w=fit_platt(g, y, w))
    if kind == "beta": return dict(kind="beta", w=fit_beta(g, y, w))
    if kind == "iso":
        e, t, nblk = fit_isotonic(g, y, w); return dict(kind="iso", model=(e, t), blocks=nblk)
    Ts = np.exp(np.linspace(-4, 4, 161))
    if kind == "T":
        return dict(kind="T", T=float(min(Ts, key=lambda T: nll(T, np.ones_like(y)))))
    if kind == "ccT":
        return dict(kind="ccT", T=[float(min(Ts, key=lambda T: nll(T, pred == bool(c)))) if (pred == bool(c)).any() else 1.0
                                   for c in (0, 1)])
    h = np.maximum(z0, z1); s = 0.5 * (z0 + z1)
    gam = [FIX_G * (s[pred == bool(c)].std() + 1e-6) / (h[pred == bool(c)].std() + 1e-6) if (pred == bool(c)).sum() > 1 else FIX_G
           for c in (0, 1)]
    grid = [[None] + (list(np.quantile(h[pred == bool(c)], np.linspace(0.02, 0.98, 25))) if (pred == bool(c)).any() else [])
            for c in (0, 1)]
    def score(tau):
        pb, pf, pn = apply(dict(kind="gate", tau=tau, gam=gam), z0, z1)
        conf = np.where(pred, pf, pb)
        return float((w * (conf - corr) ** 2).sum() / w.sum())
    best = min(((a, b) for a in grid[0] for b in grid[1]), key=lambda t: score(list(t)))
    return dict(kind="gate", tau=list(best), gam=gam)


def describe(rd):
    if rd["kind"] == "softmax": return "--"
    if rd["kind"] == "T": return f"T={rd['T']:.3f}"
    if rd["kind"] == "ccT": return f"T bg={rd['T'][0]:.3f} fire={rd['T'][1]:.3f}"
    if rd["kind"] == "platt": return f"sigmoid({rd['w'][0]:+.2f} {rd['w'][1]:+.3f}*gap)"
    if rd["kind"] == "beta": return f"a={rd['w'][1]:.3f} b={rd['w'][2]:.3f} c={rd['w'][0]:+.2f}"
    if rd["kind"] == "iso": return f"{rd['blocks']} monotone steps"
    f = lambda t: "OFF" if t is None else f"{t:+.2f}"
    return f"tau bg={f(rd['tau'][0])} fire={f(rd['tau'][1])}"


# --------------------------------------------------------- statistics
F_BIN = 3 * NB
O_B = 3 * F_BIN
O_P = O_B + 4 + 10                                   # proper scores
F_TOT = O_P + 4
EPS = 1e-12                                          # probability floor for log scores: -log(1e-12) = 27.6

def patch_stats(pb, pf, pn, z0, z1, lab):
    """Sufficient statistics for one patch; lab may contain IGNORE (255).
    The prediction is the readout's OWN: p(fire) > p(bg). For softmax, temperature
    scaling and the gate this equals argmax(z0, z1); Platt, beta and isotonic can
    move it, which shows up as a change in IoU."""
    pred = pf > pb; v = lab != IGNORE; y = lab == 1
    conf = np.where(pred, pf, pb); corr = (pred == y).astype(np.float64)
    row = np.zeros(F_TOT); o = 0
    for m in (v & y, v & ~y, v & pred):                    # true fire, true bg, predicted fire
        c, k = conf[m], corr[m]; b = np.clip((c * NB).astype(int), 0, NB - 1)
        row[o:o + NB] = np.bincount(b, minlength=NB); row[o + NB:o + 2 * NB] = np.bincount(b, c, NB)
        row[o + 2 * NB:o + 3 * NB] = np.bincount(b, k, NB); o += F_BIN
    e2 = (conf - corr) ** 2
    row[o] = e2[v].sum(); row[o + 1] = v.sum(); row[o + 2] = e2[v & y].sum(); row[o + 3] = (v & y).sum(); o += 4
    for m in (v & pred & y, v & pred & ~y):                 # detected, false alarm
        row[o] = m.sum(); row[o + 1] = conf[m].sum(); o += 2
    for m in (v & ~pred & y, v & ~pred & ~y):               # missed, correct background
        row[o] = m.sum(); row[o + 1] = conf[m].sum(); row[o + 2] = pn[m].sum(); o += 3
    # proper scores of the FULL distribution -- abstention is never the true class, so these penalise it
    pt = np.where(y, pf, pb)
    row[o] = -np.log(np.maximum(pt, EPS))[v].sum()                                       # NLL
    row[o + 1] = ((pb - (~y)) ** 2 + (pf - y) ** 2 + pn ** 2)[v].sum()                   # three-outcome Brier
    # proper scores of CONFIDENCE as a forecast of being correct -- what calibration measures
    cl = -(corr * np.log(np.maximum(conf, EPS)) + (1 - corr) * np.log(np.maximum(1 - conf, EPS)))
    row[o + 2] = cl[v].sum(); row[o + 3] = cl[v & y].sum()
    return row


def metrics(V):
    out = {}
    def ece(o):
        n, c, k = V[:, o:o + NB], V[:, o + NB:o + 2 * NB], V[:, o + 2 * NB:o + 3 * NB]
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.abs(k - c).sum(1) / n.sum(1)
    out["true-fire ECE"], out["true-bg ECE"], out["pred-fire ECE"] = ece(0), ece(F_BIN), ece(2 * F_BIN)
    o = O_B
    with np.errstate(invalid="ignore", divide="ignore"):
        out["conf Brier"] = V[:, o] / V[:, o + 1]; out["fire Brier"] = V[:, o + 2] / V[:, o + 3]; o += 4
        tp = V[:, o]; out["conf detected"] = V[:, o + 1] / tp; o += 2
        fp = V[:, o]; out["conf false alarm"] = V[:, o + 1] / fp; o += 2
        fn = V[:, o]; out["missed px"] = fn; out["conf missed"] = V[:, o + 1] / fn; am = V[:, o + 2] / fn; o += 3
        out["conf correct bg"] = V[:, o + 1] / V[:, o]; ab = V[:, o + 2] / V[:, o]
        out["selectivity"] = am / ab
        out["IoU"] = tp / (tp + fp + fn); out["precision"] = tp / (tp + fp); out["recall"] = tp / (tp + fn)
        out["fire px"] = tp + fn
        n_all, n_fire = V[:, O_B + 1], V[:, O_B + 3]
        out["NLL"] = V[:, O_P] / n_all; out["Brier"] = V[:, O_P + 1] / n_all
        out["conf NLL"] = V[:, O_P + 2] / n_all; out["fire NLL"] = V[:, O_P + 3] / n_fire
    return out


def auroc(score, pos):
    s = np.asarray(score, np.float64); p = np.asarray(pos, bool)
    if p.sum() == 0 or (~p).sum() == 0: return float("nan")
    u, inv = np.unique(s, return_inverse=True)
    P = np.bincount(inv, p.astype(float), len(u)); N = np.bincount(inv, (~p).astype(float), len(u))
    return float((P * (np.cumsum(N) - N + 0.5 * N)).sum() / (P.sum() * N.sum()))


# ------------------------------------------------------------------ main
def main():
    OUT.mkdir(parents=True, exist_ok=True)
    say(f"EVERY PIXEL   device {DEV}   scored beta0 = {SCORE_BETAS}   alpha = {ALPHAS}   bootstrap {BOOT}")
    models = load_models()
    agree, flags = {}, {}
    for sc in ("scene3", "scene4"):
        f = next(iter(glob.glob(str(Path(ROOT) / "**" / f"agreement_{sc}.npz"), recursive=True)), None)
        if f is None: raise SystemExit(f"agreement_{sc}.npz not found -- attach the label notebook's output.")
        z = np.load(f, allow_pickle=True); L = z["label"]; Fl = z["flags"]      # decompress ONCE
        for i, nm in enumerate(z["files"]): agree[str(nm)] = L[i]; flags[str(nm)] = Fl[i]
        say(f"  agreement labels and signature flags loaded: {Path(f).name}")
    files = {sc: find(ROOT, sc) for sc in ("scene3", "scene4")}
    if MAXP: files = {k: v[:MAXP] for k, v in files.items()}
    n3 = len(files["scene3"]); perm = np.random.default_rng(0).permutation(n3)     # SAME split as every run
    held_in, held_out = np.sort(perm[:n3 // 2]), np.sort(perm[n3 // 2:])
    scale = models[0]["scale"]
    A = {}
    for sc, fl in files.items():
        step = max(1, len(fl) // A_SAMPLE)
        A[sc] = np.percentile(np.stack([read_patch(f)[0] * scale for f in fl[::step]]), 99, axis=(0, 2, 3))
        say(f"  {sc}: {len(fl)} patches   atmospheric light {np.round(A[sc], 4)}")

    # ---------------- pass A: fitting samples -- identical to haze_readouts.py ----------------
    say("\nPASS A: fitting samples (scene 3, held-in half, agreement labels, as haze_readouts.py) ...")
    rng = np.random.default_rng(5)
    S = {(m["name"], a, b): {k: [] for k in ("z0", "z1", "y", "w")} for m in models for a in ALPHAS for b in FIT_BETAS}
    fl = files["scene3"]
    for s0 in range(0, len(held_in), 4):
        sel = held_in[s0:s0 + 4]; raws = [read_patch(fl[i])[0] * scale for i in sel]
        lab = np.stack([agree[Path(fl[i]).name] for i in sel]); v = lab != IGNORE
        keep = v & ((lab == 1) | (rng.random(lab.shape) < BG_RATE))
        wt = np.where(lab == 1, 1.0, 1.0 / BG_RATE)[keep]
        for a in ALPHAS:
            for b in FIT_BETAS:
                if a != ALPHAS[0] and b == 0.0: continue
                x6 = np.stack([haze(r, b, A["scene3"], a) for r in raws])
                for m in models:
                    lg = logits(m, x6); d = S[(m["name"], a, b)]
                    d["z0"].append(lg[:, 0][keep]); d["z1"].append(lg[:, 1][keep])
                    d["y"].append((lab == 1)[keep]); d["w"].append(wt)
    S = {k: {kk: np.concatenate(vv) for kk, vv in d.items()} for k, d in S.items() if d["z0"]}
    for m in models:
        for a in ALPHAS[1:]:
            S[(m["name"], a, 0.0)] = S[(m["name"], ALPHAS[0], 0.0)]
    say("\nFITTING (should match the FITTING section of haze_readouts' report)")
    R = {}
    for m in models:
        for a in ALPHAS:
            mix = {k: np.concatenate([S[(m["name"], a, b)][k] for b in FIT_BETAS]) for k in ("z0", "z1", "y", "w")}
            R[(m["name"], a)] = {"softmax": dict(kind="softmax"), "temperature (mixture)": fit("T", mix),
                                 "class-cond T (mixture)": fit("ccT", mix), "Platt (mixture)": fit("platt", mix),
                                 "beta (mixture)": fit("beta", mix), "isotonic (mixture)": fit("iso", mix),
                                 KEY: fit("gate", mix)}
            say(f"  {m['name']}, alpha {a}:   " + "   ".join(f"{nm}: {describe(rd)}" for nm, rd in R[(m['name'], a)].items()
                                                         if nm != "softmax"))
    del S

    # ---------------- pass B: scoring every pixel ----------------
    say("\nPASS B: scoring every pixel (scene 3 held-out half, all of scene 4) ...")
    ST, CAT, SMP = {}, {}, {}
    srng = np.random.default_rng(17)
    for sc, idx in (("scene3", held_out), ("scene4", np.arange(len(files["scene4"])))):
        fl = files[sc]
        for s0 in range(0, len(idx), 4):
            sel = idx[s0:s0 + 4]; P = [read_patch(fl[i]) for i in sel]
            raws = [p[0] * scale for p in P]
            names = [Path(fl[i]).name for i in sel]
            labs = []
            for (_, modis), nm in zip(P, names):
                ag = agree[nm]; vis = (flags[nm] & SEEDGROW_BIT) > 0
                cat = np.full(ag.shape, -1, np.int8); ig = ag == IGNORE
                cat[ig & modis & ~vis] = 0; cat[ig & ~modis & vis] = 1; cat[ig & ~modis & ~vis] = 2
                labs.append(dict(agreement=ag, visible=vis.astype(np.uint8), modis=modis.astype(np.uint8), cat=cat))
            for a in ALPHAS:
                for b in SCORE_BETAS:
                    x6 = np.stack([haze(r, b, A[sc], a) for r in raws])
                    for m in models:
                        lg = logits(m, x6)
                        for k in range(len(sel)):
                            z0, z1 = lg[k, 0], lg[k, 1]; pred = z1 > z0; h = np.maximum(z0, z1)
                            outs = {nm: apply(R[(m["name"], a)][nm], z0, z1) for nm in READOUTS}
                            for ver in VERSIONS:
                                L = labs[k][ver]
                                for nm in READOUTS:
                                    ST.setdefault((m["name"], a, sc, b, ver, nm), []).append(patch_stats(*outs[nm], z0, z1, L))
                                v = L != IGNORE; y = L == 1
                                miss = v & ~pred & y; cbg = v & ~pred & ~y
                                km = miss & (srng.random(miss.shape) < MISS_KEEP[ver]); kc = cbg & (srng.random(cbg.shape) < CBG_KEEP)
                                d = SMP.setdefault((m["name"], a, sc, b, ver), {"miss": [], "cbg": []})
                                d["miss"].append(h[km].astype(np.float32)); d["cbg"].append(h[kc].astype(np.float32))
                            sm, gt = outs["softmax"], outs[KEY]
                            pfire = sm[1]; confsm = np.where(pred, sm[1], sm[0])
                            for c in range(len(CATS)):
                                mc = labs[k]["cat"] == c
                                acc = CAT.setdefault((m["name"], a, sc, b, c), np.zeros(5))
                                acc += [mc.sum(), (pred & mc).sum(), pfire[mc].sum(), confsm[mc].sum(), gt[2][mc].sum()]
        say(f"  scored {sc}")
    ST = {k: np.stack(v) for k, v in ST.items()}

    # ---------------- results ----------------
    rows, cis, catrows = [], [], []
    brng = np.random.default_rng(3)
    for m in models:
        for a in ALPHAS:
            for sc in ("scene3", "scene4"):
                P = ST[(m["name"], a, sc, SCORE_BETAS[0], "agreement", "softmax")].shape[0]
                Wt = np.stack([np.bincount(brng.integers(0, P, P), minlength=P) for _ in range(BOOT)]).astype(np.float64)
                for b in SCORE_BETAS:
                    for ver in VERSIONS:
                        pts, bts = {}, {}
                        smp = SMP[(m["name"], a, sc, b, ver)]
                        hm = np.concatenate(smp["miss"]); hc = np.concatenate(smp["cbg"])
                        au = auroc(-np.r_[hm, hc], np.r_[np.ones(hm.size, bool), np.zeros(hc.size, bool)])
                        for nm in READOUTS:
                            M = ST[(m["name"], a, sc, b, ver, nm)]
                            pts[nm] = {k: float(v[0]) for k, v in metrics(M.sum(0)[None]).items()}
                            bts[nm] = metrics(Wt @ M)
                            rows.append(dict(model=m["name"], alpha=a, scene=sc, beta0=b, labels=ver, readout=nm,
                                             maxlogit_auroc=au, **pts[nm]))
                        for ref in ["softmax"] + CALIBRATORS:
                            for met in ("true-fire ECE", "conf Brier", "fire Brier", "conf NLL", "fire NLL", "NLL", "Brier"):
                                d = bts[KEY][met] - bts[ref][met]; d = d[np.isfinite(d)]
                                if d.size == 0: continue
                                d = np.where(np.abs(d) < 1e-7, 0.0, d)
                                lo, hi = np.percentile(d, [2.5, 97.5])
                                cis.append(dict(model=m["name"], alpha=a, scene=sc, beta0=b, labels=ver, reference=ref,
                                                metric=met, softmax=pts[ref][met], gate=pts[KEY][met],
                                                diff=pts[KEY][met] - pts[ref][met], ci_low=lo, ci_high=hi,
                                                significant=bool(hi < 0 or lo > 0)))
                    for c, cn in enumerate(CATS):
                        n, nf, spf, sconf, sab = CAT[(m["name"], a, sc, b, c)]
                        catrows.append(dict(model=m["name"], alpha=a, scene=sc, beta0=b, category=cn, pixels=int(n),
                                            called_fire=nf / max(n, 1), mean_p_fire=spf / max(n, 1),
                                            conf_softmax=sconf / max(n, 1), gate_abstention=sab / max(n, 1)))
    for name, data in (("every_pixel_results.csv", rows), ("every_pixel_cis.csv", cis), ("ignored_pixels.csv", catrows)):
        with open(OUT / name, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(data[0].keys())); w.writeheader(); w.writerows(data)

    get = lambda mm, a, sc, b, ver, nm, k: next(r[k] for r in rows if r["model"] == mm and r["alpha"] == a and r["scene"] == sc
                                                 and r["beta0"] == b and r["labels"] == ver and r["readout"] == nm)
    ci = lambda mm, a, sc, b, ver, met, ref="softmax": next(c for c in cis if c["model"] == mm and c["alpha"] == a
                                             and c["scene"] == sc and c["beta0"] == b and c["labels"] == ver
                                             and c["metric"] == met and c["reference"] == ref)
    fmt = lambda v, d=3: f"{v:.{d}f}" if np.isfinite(v) else "--"

    # sanity check against haze_readouts
    prev = next(iter(glob.glob(str(Path(ROOT) / "**" / "readout_results.csv"), recursive=True)), None)
    say("\nSANITY CHECK -- agreement labels must reproduce haze_readouts.py")
    if prev:
        P_ = [r for r in csv.DictReader(open(prev))]
        diffs = []
        for r in rows:
            if r["labels"] != "agreement": continue
            q = [p for p in P_ if p["model"] == r["model"] and float(p["alpha"]) == r["alpha"] and p["scene"] == r["scene"]
                 and float(p["beta0"]) == r["beta0"] and p["readout"] == r["readout"]]
            for met in ("true-fire ECE", "conf Brier"):
                if q and q[0][met] not in ("", "nan") and np.isfinite(r[met]):
                    diffs.append(abs(float(q[0][met]) - r[met]))
        mx = max(diffs) if diffs else float("nan")
        say(f"  compared {len(diffs)} values with {prev}: largest difference {mx:.2e}  "
            f"{'-> MATCH' if mx < 2e-3 else '-> MISMATCH: paste this report into the chat before using the results'}")
    else:
        say("  haze_readouts' readout_results.csv not attached -- compare by eye: under 'agreement' below, the gate's")
        say("  true-fire ECE should equal haze_readouts' 'gateBr mix' column at the same alpha, scene, seed and beta0.")

    say("\nWHAT THE IGNORED PIXELS ARE, AND HOW THE NETWORK TREATS THEM")
    say("  share = share of the scored scene; called fire = share the network calls fire; P(fire) = softmax mean")
    for a in ALPHAS:
        for sc in ("scene3", "scene4"):
            for m in models:
                say(f"\n  [alpha {a} | {sc} | {m['name']}]")
                say(f"    {'beta0':>6}  " + "".join(f"{cn:>40}" for cn in CATS))
                say(f"    {'':>6}  " + "".join(f"{'share  called fire  P(fire)  gate abst':>40}" for _ in CATS))
                for b in SCORE_BETAS:
                    cells = []
                    npx = float(ST[(m["name"], a, sc, b, "modis", "softmax")][:, O_B + 1].sum())   # every pixel scored
                    for cn in CATS:
                        r = next(x for x in catrows if x["model"] == m["name"] and x["alpha"] == a and x["scene"] == sc
                                 and x["beta0"] == b and x["category"] == cn)
                        cells.append(f"{100 * r['pixels'] / max(npx, 1):>6.2f}%{100 * r['called_fire']:>12.1f}%"
                                     f"{r['mean_p_fire']:>9.3f}{r['gate_abstention']:>11.4f}")
                    say(f"    {b:>6.1f}  " + "".join(f"{c:>40}" for c in cells))

    titles = {"agreement": "AGREEMENT LABELS, ignored pixels skipped (sanity check)",
              "visible": "EVERY PIXEL, VISIBLE-FIRE TRUTH (strict SWIR signature anywhere = fire)",
              "modis": "EVERY PIXEL, MODIS TRUTH (original labels; ~95% not visible to the sensor)"}
    for ver in VERSIONS:
        say(f"\n######################## {titles[ver]} ########################")
        for a in ALPHAS:
            for sc in ("scene3", "scene4"):
                for m in models:
                    say(f"\n  [alpha {a} | {sc} | {m['name']}]")
                    say("    " + f"{'beta0':>6}{'IoU':>7}{'prec':>7}{'recall':>8}{'missed px':>12}"
                        f"{'conf missed sm->gate':>22}{'corr bg gate':>13}{'select.':>9}{'MaxLogit':>9}"
                        f"{'true-fire ECE sm -> gate':>28}{'fire Brier sm -> gate':>27}{'conf Brier diff':>17}")
                    for b in SCORE_BETAS:
                        g = lambda k, nm="softmax": get(m["name"], a, sc, b, ver, nm, k)
                        e, fb, cb = (ci(m["name"], a, sc, b, ver, x) for x in ("true-fire ECE", "fire Brier", "conf Brier"))
                        star = lambda c: "*" if c["significant"] else " "
                        say("    " + f"{b:>6.1f}{fmt(g('IoU')):>7}{fmt(g('precision')):>7}{fmt(g('recall')):>8}"
                            f"{int(g('missed px')):>12,}"
                            f"{fmt(g('conf missed')) + ' -> ' + fmt(g('conf missed', KEY)):>22}"
                            f"{fmt(g('conf correct bg', KEY), 4):>13}{fmt(g('selectivity', KEY), 1):>9}{fmt(g('maxlogit_auroc')):>9}"
                            f"{fmt(e['softmax'], 4) + ' -> ' + fmt(e['gate'], 4) + star(e):>28}"
                            f"{fmt(fb['softmax'], 4) + ' -> ' + fmt(fb['gate'], 4) + star(fb):>27}"
                            f"{cb['diff']:>+16.6f}{star(cb)}")

    short = {"softmax": "softmax", "temperature (mixture)": "T", "class-cond T (mixture)": "ccT", "Platt (mixture)": "Platt",
             "beta (mixture)": "beta", "isotonic (mixture)": "isotonic", KEY: "gate"}
    for ver in ("visible", "agreement"):
        say(f"\n######################## EVERY READOUT -- {titles[ver]} ########################")
        say("  Every readout fitted on hazed scene 3 (held-in half, mixture of haze levels), predictions from each")
        say("  readout's own probabilities: an IoU below softmax's means the calibrator moved the decision boundary.")
        for a in ALPHAS:
            for sc in ("scene3", "scene4"):
                for m in models:
                    say(f"\n  [alpha {a} | {sc} | {m['name']}]")
                    for met, d in (("IoU", 3), ("true-fire ECE", 4), ("fire Brier", 4), ("conf missed", 3)):
                        say(f"    {met}" + ("  (higher = better)" if met == "IoU" else "  (lower = better)"))
                        say("    " + f"{'beta0':>6}" + "".join(f"{short[nm]:>10}" for nm in READOUTS))
                        for b in SCORE_BETAS:
                            say("    " + f"{b:>6.1f}" + "".join(f"{fmt(get(m['name'], a, sc, b, ver, nm, met), d):>10}"
                                                            for nm in READOUTS))
                    say("    PROPER SCORES (lower = better).  Calibration -- fair to abstention: conf Brier, conf NLL,")
                    say("    fire Brier, fire NLL.  Full distribution -- penalise abstention by design: NLL, Brier.")
                    for met, d in (("conf Brier", 6), ("conf NLL", 5), ("fire Brier", 4), ("fire NLL", 4), ("NLL", 5), ("Brier", 6)):
                        say(f"    {met}")
                        say("    " + f"{'beta0':>6}" + "".join(f"{short[nm]:>11}" for nm in READOUTS))
                        for b in SCORE_BETAS:
                            say("    " + f"{b:>6.1f}" + "".join(f"{fmt(get(m['name'], a, sc, b, ver, nm, met), d):>11}"
                                                            for nm in READOUTS))
                    say("    gate MINUS softmax on the proper scores (* = 95% CI excludes 0; negative = gate better)")
                    for b in SCORE_BETAS:
                        cs = [ci(m["name"], a, sc, b, ver, met) for met in ("conf Brier", "conf NLL", "fire Brier", "fire NLL",
                                                                           "NLL", "Brier")]
                        say("    " + f"{b:>6.1f}  " + "   ".join(f"{c['metric']}: {c['diff']:+.5f}{'*' if c['significant'] else ' '}"
                                                             for c in cs))
                    say("    gate MINUS each calibrator, true-fire ECE / fire Brier (* = 95% CI excludes 0; negative = gate better)")
                    for b in SCORE_BETAS:
                        cells = []
                        for ref in CALIBRATORS:
                            e, f = ci(m["name"], a, sc, b, ver, "true-fire ECE", ref), ci(m["name"], a, sc, b, ver, "fire Brier", ref)
                            cells.append(f"vs {short[ref]}: {e['diff']:+.4f}{'*' if e['significant'] else ' '} / "
                                         f"{f['diff']:+.4f}{'*' if f['significant'] else ' '}")
                        say("    " + f"{b:>6.1f}  " + "   ".join(cells))

    say("\nHOW TO READ THIS")
    say("  * = paired-bootstrap 95% CI of (gate - softmax) excludes 0; negative = gate better.")
    say("  1. SANITY CHECK must say MATCH (or the agreement tables must equal haze_readouts').")
    say("  2. VISIBLE truth is the honest version of the main result: background now includes the rings")
    say("     around fires and burn scars. If IoU, selectivity and MaxLogit AUROC stay high and the gate")
    say("     still lowers missed-fire confidence and fire Brier at heavy haze, the result does not depend")
    say("     on the ignore rule. Expect lower values than under agreement labels.")
    say("  3. IGNORED PIXELS: 'strict signature outside MODIS' called fire = the network finding fire")
    say("     MODIS missed. 'Near a weak signature' called fire = false alarms at fire edges or scars.")
    say("  4. MODIS truth: low recall is EXPECTED -- most MODIS fire is invisible. A MaxLogit AUROC near")
    say("     0.5 there means no readout can find those pixels: the information limit, not a flaw.")
    say("  5. EVERY READOUT: Platt, beta and isotonic can lower ECE by moving the decision boundary -- check")
    say("     their IoU against softmax's before crediting them. The gate never moves it. fire Brier (Brier on")
    say("     true-fire pixels only) is the clean head-to-head: proper, no bins, not drowned by background.")
    say("  6. PROPER SCORES: conf Brier / conf NLL score confidence as a forecast of being correct -- the fair")
    say("     test of calibration, with no bins. fire Brier / fire NLL are the same on true-fire pixels only.")
    say("     NLL and Brier score the full class probabilities: abstention is never the true class, so they")
    say("     penalise any abstention by construction -- a gate losing there is expected, not a contradiction.")
    say(f"     Log scores floor probabilities at {EPS:g} (a confidently wrong pixel costs at most {-np.log(EPS):.1f}).")
    (OUT / "report.txt").write_text("\n".join(LOG))
    say(f"\nWrote {OUT}/report.txt, every_pixel_results.csv, every_pixel_cis.csv, ignored_pixels.csv")


if __name__ == "__main__":
    main()
