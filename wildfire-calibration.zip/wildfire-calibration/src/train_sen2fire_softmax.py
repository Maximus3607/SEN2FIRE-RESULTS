"""
Wildfire segmentation - U-Net on Sen2Fire.  SOFTMAX version.
Stage 1 of a two-stage calibration study: train the segmenter, then dump logits
for offline temperature scaling and MSP-variant research.

Kaggle:  Session options > Accelerator > GPU T4    <- DO THIS FIRST
         NOT P100: it is sm_60, and Kaggle's torch 2.10+cu128 build supports
         only sm_70..sm_120. It dies with AcceleratorError on first forward.
         Add Data > Sen2Fire
         Save Version > Save & Run All (Commit)      <- not plain Run

Dataset: https://zenodo.org/records/10881058  (CC-BY-4.0)

==============================================================================
CHANGE 1: SIGMOID -> SOFTMAX
==============================================================================
out_ch is now 2, not 1. The head emits a real 2-vector of logits per pixel,
the loss is CrossEntropyLoss, and probabilities come from softmax.

Mathematically a 1-logit sigmoid equals a 2-logit softmax with one logit
pinned to zero, so ordinary MSP and temperature scaling give identical numbers
either way. The reason to use 2 logits anyway is that MSP VARIANTS need the
extra degree of freedom: energy scores (logsumexp over logits), logit norms,
and logit-margin methods all read absolute logit magnitude, which a single
logit does not carry. Since the research goal is new scores under the MSP
umbrella, the output has to be able to express them.

Labels are now int64 class indices of shape (B,H,W) -- 0 background, 1 fire --
because that is what CrossEntropyLoss expects. Not (B,1,H,W) floats.

==============================================================================
CHANGE 2: WHY THE LAST RUN COLLAPSED, AND WHAT NOW PREVENTS IT
==============================================================================
Last run: val loss went NaN at epoch 5, train loss at epoch 19, IoU hit 0.0000
by epoch 26 and stayed there. best.pt was last written at EPOCH 4. 160 minutes
of GPU time produced a model trained for 12 minutes.

Mechanism. Under AMP, when a forward pass overflows fp16, GradScaler detects
the bad gradients and SKIPS the optimizer step, so the weights are protected.
But BatchNorm's running_mean/running_var are buffers, not parameters: they are
updated during the FORWARD pass and the scaler never sees them. One overflowing
forward permanently poisons them. Training mode keeps working because it uses
batch statistics; eval mode reads the poisoned buffers and returns NaN
immediately. That is exactly the val-breaks-first-then-train signature.

Five guards, at every level where it failed:

  G1  amp = False. fp32 has ~1e38 headroom against fp16's 65504, which removes
      the overflow at its source. Costs roughly 2x wall-clock. Worth it.
  G2  lr 1e-3 -> 3e-4 plus 300 steps of linear warmup. The overflow happened in
      the first epochs, when AdamW's early updates are largest.
  G3  Per-batch: if the loss is non-finite, skip the step and count it. If a
      whole epoch is bad, stop rather than grind out 40 dead epochs.
  G4  Per-epoch: verify every BatchNorm buffer is finite. If any is poisoned,
      roll back to the last known-good state and halve the LR instead of
      continuing into guaranteed collapse.
  G5  Checkpointing: a NaN validation loss can never be recorded as "best", and
      a separate good.pt snapshot is kept from the last epoch that passed every
      health check.
==============================================================================
"""

import os, glob, json, time, collections, copy
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler

# ================================ CONFIG ================================
class CFG:
    data_root   = "/kaggle/input"
    out_dir     = "/kaggle/working"
    band_idx    = [3, 2, 1, 7, 10, 11]   # R, G, B, NIR, SWIR1, SWIR2
    # Aerosol lives under its OWN npz key ('aerosol'), NOT a 13th image channel.
    sel_red, sel_nir, sel_swir1, sel_swir2 = 0, 3, 4, 5   # within the 6-stack

    splits      = {"train": ["scene1", "scene2"], "val": ["scene3"], "test": ["scene4"]}
    in_ch       = 6
    out_ch      = 2        # SOFTMAX: 0 = background, 1 = fire
    base        = 64
    batch_size  = 4        # drop to 2 if fp32 OOMs on the T4
    epochs      = 65       # ~7 min/epoch fp32 -> ~7.6h, fits one session
    lr          = 3e-4     # G2
    warmup_steps= 300      # G2
    weight_decay= 1e-4

    # CLASS WEIGHT: [background, fire]. Deliberately NOT 1.0 any more.
    # The unweighted run reached only 0.19 recall on fire, which makes the
    # confidence signal degenerate: there is almost nothing correct to be
    # confident ABOUT, so any calibrator collapses toward uniform low
    # confidence. A weight of 5 raises recall enough for calibration to mean
    # something. The cost is that weighted CE is no longer a proper scoring
    # rule and adds a roughly constant logit OFFSET, which a pure scale (global
    # temperature) cannot undo -- so Platt scaling, which fits scale AND
    # offset, must be reported alongside global T as a fair baseline.
    class_weight  = [1.0, 5.0]
    fire_sampling = True     # sampling stays: it does not distort the loss
    fire_ratio    = 0.3

    amp         = False    # G1 -- the direct cause of the last collapse
    workers     = 2
    stats_n     = 300
    max_hours   = 8.0
    fresh_start = True     # last run's checkpoints are poisoned; ignore them

torch.manual_seed(0); np.random.seed(0)
torch.backends.cudnn.benchmark = True
DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT = Path(CFG.out_dir); OUT.mkdir(parents=True, exist_ok=True)
print("torch", torch.__version__, "| device:", DEV, "| amp:", CFG.amp)
if DEV == "cuda":
    print("GPU:", torch.cuda.get_device_name(0))
else:
    print("!! NO GPU -> Session options > Accelerator > GPU T4, then re-run")

# ================================ MODEL ================================
class DoubleConv(nn.Module):
    """(conv3x3 -> BN -> ReLU) x2.  padding=1 keeps H,W unchanged."""
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(inplace=True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(inplace=True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    """maxpool 2x2 (halve H,W) then DoubleConv (double channels)."""
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    """convT 2x2 stride 2 (double H,W), concat skip, DoubleConv."""
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2)
        self.conv = DoubleConv(co * 2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2) - x.size(-2); dx = skip.size(-1) - x.size(-1)
            x = F.pad(x, [dx//2, dx-dx//2, dy//2, dy-dy//2])
        return self.conv(torch.cat([skip, x], dim=1))

class UNet(nn.Module):
    """Architecture UNCHANGED from the sigmoid version except the final conv,
    which now emits 2 channels instead of 1. Parameter count moves by 65."""
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b*2), Down(b*2, b*4)
        self.d3, self.d4 = Down(b*4, b*8), Down(b*8, b*16)
        self.u1, self.u2 = Up(b*16, b*8), Up(b*8, b*4)
        self.u3, self.u4 = Up(b*4, b*2), Up(b*2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)                       # (B,2,H,W) logits, NO softmax

_m = UNet(CFG.in_ch, CFG.out_ch, CFG.base)
_c = collections.Counter(type(x).__name__ for x in _m.modules() if not list(x.children()))
print("\narchitecture:")
for k, v in {"Conv2d":19,"BatchNorm2d":18,"ReLU":18,"MaxPool2d":4,"ConvTranspose2d":4}.items():
    assert _c[k] == v, f"{k}: got {_c[k]}, expected {v}"
    print(f"  {k:16s} {_c[k]:3d}  OK")
print("  parameters:", f"{sum(p.numel() for p in _m.parameters()):,}")
print(f"  output channels: {CFG.out_ch}  (softmax over 2 classes)")
del _m

# ================================ DATA ================================
def find_files(root, tags):
    """A file belongs to a split if one of its PARENT DIRECTORIES is exactly a
    tag (not a substring), so 'scene1-backup' cannot pollute a split."""
    out = []
    for f in sorted(glob.glob(str(Path(root) / "**" / "*.npz"), recursive=True)):
        parts = {p.lower() for p in Path(f).parts[:-1]}
        if any(t.lower() in parts for t in tags):
            out.append(f)
    return out

print("\ndata:")
files = {s: find_files(CFG.data_root, t) for s, t in CFG.splits.items()}
for s, f in files.items():
    print(f"  {s:6s} {len(f):5d} files" + (f"   e.g. {f[0]}" if f else ""))
n_total = sum(len(f) for f in files.values())
assert n_total > 0, (
    "No .npz matched. Check Add Data attached the dataset and that the "
    "scene1..scene4 folders exist. Debug with:\n"
    "  import glob; print(glob.glob('/kaggle/input/**/*.npz', recursive=True)[:5])")
print(f"  total {n_total} (expected 2466: 1458 train / 504 val / 504 test)")


def _nd(a, b, eps=1e-6):
    return (a - b) / (a + b + eps)


def haze_cue_from_raw(img_raw):
    """Per-pixel smoke indicator, from RAW REFLECTANCE (not standardised bands:
    these are ratio indices and subtracting a per-band mean destroys the ratio).

    Smoke attenuates visible far more than SWIR, so a visible-dependent index
    (NDVI) diverges from SWIR-dependent ones (NBR, NBR2) exactly where the
    visible signal is compromised. An ATTENUATION signal, not a fire signal.
    """
    red, nir = img_raw[CFG.sel_red], img_raw[CFG.sel_nir]
    swir1, swir2 = img_raw[CFG.sel_swir1], img_raw[CFG.sel_swir2]
    ndvi, nbr, nbr2 = _nd(nir, red), _nd(nir, swir2), _nd(swir1, swir2)
    cue = 0.5*np.abs(ndvi - nbr) + 0.5*np.abs(ndvi - nbr2)
    return np.nan_to_num(cue).astype(np.float32)[None]


class Sen2Fire(Dataset):
    """return_aux=True also yields aerosol and haze cue for the calibration
    stage. The segmenter itself never receives either."""

    def __init__(self, files, mean=None, std=None, augment=False,
                 scale=1.0, return_aux=False, seed=0):
        self.files = files
        self.mean, self.std = mean, std
        self.augment, self.scale, self.return_aux = augment, scale, return_aux
        self.rng = np.random.default_rng(seed)     # built ONCE, not per item
        self.ik = self.lk = self.ak = None

    def __len__(self): return len(self.files)

    def _keys(self, z):
        if self.ik is None:
            ks = list(z.keys())
            self.ik = next((k for k in ("image","img","data","x") if k in ks), ks[0])
            self.lk = next((k for k in ("label","mask","gt","y") if k in ks), ks[-1])
            self.ak = next((k for k in ("aerosol","s5p","aod") if k in ks), None)
            assert self.ik != self.lk, f"image/label key collision in npz: {ks}"
            assert self.ak is not None, f"no aerosol key in npz: {ks}"
        return self.ik, self.lk

    def _load(self, i):
        """Returns (bands, label2d, aerosol). No normalisation, no selection."""
        z = np.load(self.files[i], allow_pickle=True)
        ik, lk = self._keys(z)
        img = np.asarray(z[ik], dtype=np.float32)
        if img.ndim == 3 and img.shape[2] < img.shape[0]:
            img = np.transpose(img, (2, 0, 1))                 # (H,W,C)->(C,H,W)
        lab = np.asarray(z[lk])
        if lab.ndim == 3: lab = lab[0]
        lab = (lab > 0).astype(np.int64)                       # (H,W) class idx
        aer = np.asarray(z[self.ak], dtype=np.float32)
        if aer.ndim == 2: aer = aer[None]
        return np.nan_to_num(img), lab, np.nan_to_num(aer)

    def raw(self, i):
        allb, lab, aer = self._load(i)
        assert allb.shape[0] == 12, f"expected 12 bands, got {allb.shape[0]}"
        return allb[CFG.band_idx] * self.scale, lab, aer       # GLOBAL scale

    def __getitem__(self, i):
        img, lab, aer = self.raw(i)
        cue = haze_cue_from_raw(img)                           # from RAW bands

        if self.mean is not None:
            img = (img - self.mean[:,None,None]) / (self.std[:,None,None] + 1e-6)

        if self.augment:                                       # GEOMETRIC ONLY:
            r = self.rng                                       # photometric edits
            if r.random() < .5:                                # would alter the
                img, lab = img[:,:,::-1], lab[:,::-1]          # test variable
                aer, cue = aer[:,:,::-1], cue[:,:,::-1]
            if r.random() < .5:
                img, lab = img[:,::-1], lab[::-1]
                aer, cue = aer[:,::-1], cue[:,::-1]
            k = int(r.integers(4))
            if k:
                img, lab = np.rot90(img,k,(1,2)), np.rot90(lab,k,(0,1))
                aer, cue = np.rot90(aer,k,(1,2)), np.rot90(cue,k,(1,2))

        t = lambda a: torch.from_numpy(np.ascontiguousarray(a))
        if self.return_aux:
            return t(img), t(lab), t(aer), t(cue)
        return t(img), t(lab)                    # lab is (H,W) int64


# ---- global reflectance scale + norm stats, decided ONCE ----
STATS = OUT / "norm_stats.npz"
probe = Sen2Fire(files["train"])
if STATS.exists() and not CFG.fresh_start:
    z = np.load(STATS); MEAN, STD, SCALE = z["mean"], z["std"], float(z["scale"])
    print("\n  loaded cached norm stats")
else:
    rng = np.random.default_rng(0)
    idx = rng.choice(len(probe), size=min(CFG.stats_n, len(probe)), replace=False)
    maxes = [float(np.nanmax(probe._load(int(i))[0][CFG.band_idx])) for i in idx[:50]]
    SCALE = 1e-4 if float(np.median(maxes)) > 100 else 1.0
    print(f"\n  reflectance probe: median max {np.median(maxes):.1f} -> scale {SCALE:g}")
    probe.scale = SCALE
    print(f"  computing norm stats from {len(idx)} RANDOM train patches ...")
    n = 0; s1 = np.zeros(CFG.in_ch); s2 = np.zeros(CFG.in_ch)
    for i in idx:
        im = probe.raw(int(i))[0]; v = im.reshape(CFG.in_ch, -1)
        s1 += v.sum(1); s2 += (v**2).sum(1); n += v.shape[1]
    MEAN = (s1/n).astype(np.float32)
    STD  = np.sqrt(np.maximum(s2/n - MEAN**2, 1e-8)).astype(np.float32)
    np.savez(STATS, mean=MEAN, std=STD, scale=SCALE)
probe.scale = SCALE
print("  scale", SCALE); print("  mean", np.round(MEAN,4)); print("  std ", np.round(STD,4))

print("\nsanity check (one training patch):")
_allb = probe._load(0)[0]
print(f"  npz image channels: {_allb.shape[0]} (band_idx assumes 12, B10 dropped)")
_i, _l, _a = probe.raw(0)
_cue = haze_cue_from_raw(_i)
print(f"  image {_i.shape} range [{_i.min():.4f}, {_i.max():.4f}]")
print(f"  label {_l.shape} dtype {_l.dtype} classes {np.unique(_l)} "
      f"fire = {(_l>0).mean()*100:.2f}% of pixels")
print(f"  aerosol {_a.shape} range [{_a.min():.4f}, {_a.max():.4f}] std {_a.std():.6f}")
print(f"  haze cue {_cue.shape} range [{_cue.min():.4f}, {_cue.max():.4f}]")
assert _i.shape[0] == CFG.in_ch, f"expected {CFG.in_ch} bands, got {_i.shape[0]}"
assert _i.shape[1:] == _l.shape, "image/label size mismatch"
assert _l.dtype == np.int64, "CrossEntropyLoss needs int64 class indices"
if _a.min() < 0:
    print("  NOTE aerosol has NEGATIVE values -> it is log-transformed or")
    print("       pre-standardised, NOT raw optical depth. Physical claims in")
    print("       the writeup must account for this.")
if _a.std() < 1e-6:
    print("  NOTE aerosol is flat within this patch -> scene-level term only")

FIREIDX = OUT / "fire_index.json"
if CFG.fire_sampling:
    if FIREIDX.exists() and not CFG.fresh_start:
        has_fire = np.array(json.loads(FIREIDX.read_text()), dtype=bool)
        print("\n  loaded cached fire index")
    else:
        print("\n  scanning train labels for fire content (one pass) ...")
        has_fire = np.array([probe._load(i)[1].sum() > 0 for i in range(len(probe))])
        FIREIDX.write_text(json.dumps(has_fire.tolist()))
    nf = int(has_fire.sum())
    print(f"  {nf}/{len(has_fire)} train patches contain fire ({100*nf/len(has_fire):.1f}%)")
    if nf == 0 or nf == len(has_fire):
        print("  -> degenerate, disabling fire sampling"); CFG.fire_sampling = False
del probe

# ============================ LOSS / METRICS ============================
CW = None if CFG.class_weight is None else torch.tensor(CFG.class_weight, device=DEV)

def criterion(lg, y):
    """Plain cross-entropy over 2 classes. No class weights, no dice: both
    distort the probabilities the downstream calibration study measures."""
    return F.cross_entropy(lg, y, weight=CW)

@torch.no_grad()
def plain_nll(lg, y):
    """UNWEIGHTED cross-entropy. The training loss is class-weighted and is
    therefore not a proper scoring rule; this is the number that is comparable
    to the downstream calibration metrics."""
    return F.cross_entropy(lg, y).item()

@torch.no_grad()
def counts(lg, y):
    """TP/FP/FN for the fire class (index 1) via argmax."""
    p = lg.argmax(1)
    return ((p==1)&(y==1)).sum().item(), ((p==1)&(y==0)).sum().item(), \
           ((p==0)&(y==1)).sum().item()

def bn_buffers_finite(model):
    """G4. BatchNorm running stats are updated in the FORWARD pass and are
    invisible to the optimizer, so they can be poisoned while weights survive.
    This is the exact failure that killed the previous run."""
    for m in model.modules():
        if isinstance(m, nn.BatchNorm2d):
            if not (torch.isfinite(m.running_mean).all()
                    and torch.isfinite(m.running_var).all()):
                return False
    return True

# ================================ TRAIN ================================
def mk(split, aug, aux=False):
    return Sen2Fire(files[split], MEAN, STD, aug, scale=SCALE, return_aux=aux)

dl_kw = dict(num_workers=CFG.workers, pin_memory=(DEV == "cuda"))
train_ds = mk("train", True)
if CFG.fire_sampling:
    w = np.where(has_fire, CFG.fire_ratio/max(has_fire.sum(),1),
                           (1-CFG.fire_ratio)/max((~has_fire).sum(),1))
    sampler = WeightedRandomSampler(torch.as_tensor(w, dtype=torch.double),
                                    num_samples=len(train_ds), replacement=True)
    train_dl = DataLoader(train_ds, batch_size=CFG.batch_size,
                          sampler=sampler, drop_last=True, **dl_kw)
    print("  using fire-balanced sampling")
else:
    train_dl = DataLoader(train_ds, batch_size=CFG.batch_size,
                          shuffle=True, drop_last=True, **dl_kw)
val_dl = DataLoader(mk("val", False), batch_size=CFG.batch_size, **dl_kw)

model = UNet(CFG.in_ch, CFG.out_ch, CFG.base).to(DEV)
opt   = torch.optim.AdamW(model.parameters(), lr=CFG.lr, weight_decay=CFG.weight_decay)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=CFG.epochs)
scaler = torch.amp.GradScaler("cuda", enabled=(CFG.amp and DEV == "cuda"))

LAST, BEST, GOOD = OUT/"last.pt", OUT/"best.pt", OUT/"good.pt"
if CFG.fresh_start:
    for p in (LAST, BEST, GOOD):
        if p.exists(): p.unlink()
    print("\nfresh_start: cleared old checkpoints (previous run's were poisoned)")

ep0, best, hist, gstep = 1, -1.0, [], 0
if LAST.exists():
    ck = torch.load(LAST, map_location=DEV, weights_only=False)
    model.load_state_dict(ck["model"]); opt.load_state_dict(ck["opt"])
    sched.load_state_dict(ck["sched"]); scaler.load_state_dict(ck["scaler"])
    ep0, best, hist, gstep = ck["epoch"]+1, ck["best"], ck["hist"], ck.get("gstep",0)
    print(f"\nRESUMED from epoch {ck['epoch']} (best IoU {best:.4f})")
else:
    print("\nstarting fresh")


def run(dl, train):
    """G3: a non-finite loss skips the step and is counted rather than being
    backpropagated. Returns (loss, iou, prec, rec, n_bad, plain_nll)."""
    global gstep
    model.train(train); tp = fp = fn = tot = nb = bad = pnll = 0.0
    with torch.enable_grad() if train else torch.no_grad():
        for img, lab in dl:
            img = img.to(DEV, non_blocking=True)
            lab = lab.to(DEV, non_blocking=True)
            with torch.amp.autocast("cuda", enabled=(CFG.amp and DEV == "cuda")):
                lg = model(img)
            lg = lg.float()
            loss = criterion(lg, lab)

            if not torch.isfinite(loss):
                bad += 1
                if train: opt.zero_grad(set_to_none=True)
                continue

            if train:
                gstep += 1
                if gstep <= CFG.warmup_steps:            # G2 linear warmup
                    for g in opt.param_groups:
                        g["lr"] = CFG.lr * gstep / CFG.warmup_steps
                opt.zero_grad(set_to_none=True)
                scaler.scale(loss).backward()
                scaler.unscale_(opt)                     # MUST precede clipping
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                scaler.step(opt); scaler.update()

            a, b, c = counts(lg, lab); tp += a; fp += b; fn += c
            tot += loss.item(); pnll += plain_nll(lg, lab); nb += 1
    e = 1e-9                                  # global TP/FP/FN, not per-image
    return (tot/max(nb,1), tp/(tp+fp+fn+e), tp/(tp+fp+e), tp/(tp+fn+e),
            int(bad), pnll/max(nb,1))


print(f"\ntraining {len(files['train'])} patches, {len(train_dl)} steps/epoch")
print(f"  lr {CFG.lr} warmup {CFG.warmup_steps} steps | amp {CFG.amp} | "
      f"{CFG.epochs} epochs\n")

good_state = copy.deepcopy(model.state_dict())     # G4 rollback target
t0, dead = time.time(), 0
for ep in range(ep0, CFG.epochs + 1):
    trl, tri, _, _, trbad, _     = run(train_dl, True)
    vl,  vi, vp, vr, vbad, vnll  = run(val_dl, False)
    sched.step()

    healthy = bn_buffers_finite(model) and np.isfinite(vl) and np.isfinite(trl)
    flag = "" if healthy else "  <-- UNHEALTHY"
    if trbad or vbad: flag += f"  [skipped {trbad} train / {vbad} val batches]"
    print(f"ep {ep:3d} | train {trl:.4f} IoU {tri:.4f} | val {vl:.4f} "
          f"IoU {vi:.4f} P {vp:.3f} R {vr:.3f} | nll {vnll:.4f} | "
          f"{(time.time()-t0)/60:.1f}m{flag}", flush=True)

    if not healthy:
        # G4: roll back rather than continue into guaranteed collapse.
        dead += 1
        print(f"    rolling back to last healthy state, halving lr "
              f"({dead}/3 strikes)")
        model.load_state_dict(good_state)
        for g in opt.param_groups: g["lr"] *= 0.5
        if dead >= 3:
            print("\nABORTING: 3 unhealthy epochs. The last healthy weights are "
                  "in good.pt and the dump below uses best.pt.")
            break
        continue

    dead = 0
    good_state = copy.deepcopy(model.state_dict())
    torch.save(dict(model=good_state, epoch=ep), GOOD)          # G5

    hist.append(dict(epoch=ep, train_loss=trl, train_iou=tri, val_loss=vl,
                     val_iou=vi, val_prec=vp, val_rec=vr, val_nll=vnll))
    ck = dict(model=model.state_dict(), opt=opt.state_dict(), sched=sched.state_dict(),
              scaler=scaler.state_dict(), epoch=ep, best=best, hist=hist, gstep=gstep)
    torch.save(ck, LAST)

    # G5: a NaN val loss can never win "best" -- the healthy check above
    # already guarantees vl is finite at this point.
    if vi > best:
        best = vi; ck["best"] = best; torch.save(ck, BEST)
        print(f"    new best {best:.4f}")
    (OUT/"history.json").write_text(json.dumps(hist, indent=2))

    if (time.time()-t0)/3600 > CFG.max_hours:
        print(f"\nstopping at {CFG.max_hours}h - re-commit (set fresh_start=False) "
              f"to resume from epoch {ep+1}")
        break

print(f"\ndone. best val IoU {best:.4f}  ->  {BEST}")

# ================= LOGIT DUMP: VAL (fit) + TEST (evaluate) =================
# Both splits required: temperature is FIT on val (scene3) and EVALUATED on
# test (scene4). Dumping only test would force fitting and reporting on the
# same data. BOTH logit channels are saved -- MSP variants that read absolute
# logit magnitude (energy, logit norm) need the full vector, not a probability.
@torch.no_grad()
def dump(split, ckpt):
    dl = DataLoader(mk(split, False, aux=True), batch_size=CFG.batch_size, **dl_kw)
    L, Y, A, C = [], [], [], []; tp = fp = fn = 0.0
    for img, lab, aer, cue in dl:
        img = img.to(DEV, non_blocking=True)
        lg = model(img).float().cpu()
        a, b, c = counts(lg, lab); tp += a; fp += b; fn += c
        L.append(lg.numpy().astype(np.float16))          # (B,2,H,W)  # noqa
        Y.append(lab.numpy().astype(np.uint8))           # (B,H,W)
        A.append(aer.numpy().astype(np.float16))
        C.append(cue.numpy().astype(np.float16))
    e = 1e-9
    L, Y, A, C = (np.concatenate(x) for x in (L, Y, A, C))
    assert np.isfinite(L).all(), f"{split}: non-finite logits in the dump"
    path = OUT/f"{split}_logits.npz"
    np.savez_compressed(path, logits=L, labels=Y, aerosol=A, haze_cue=C,
                        epoch=ckpt["epoch"], val_iou=ckpt.get("best", np.nan),
                        band_idx=np.array(CFG.band_idx), scale=SCALE,
                        n_classes=CFG.out_ch)
    print(f"  {split:5s} IoU {tp/(tp+fp+fn+e):.4f}  P {tp/(tp+fp+e):.3f}  "
          f"R {tp/(tp+fn+e):.3f}  -> {path.name}  ({L.nbytes/1e6:.0f} MB raw)")

src = BEST if BEST.exists() else (GOOD if GOOD.exists() else None)
if src is not None:
    print(f"\ndumping logits from {src.name} ...")
    ck = torch.load(src, map_location=DEV, weights_only=False)
    model.load_state_dict(ck["model"]); model.eval()
    assert bn_buffers_finite(model), "loaded checkpoint has poisoned BN buffers"
    for split in ("val", "test"):
        if files[split]: dump(split, ck)
    print("\n  -> logits are (N,2,H,W); labels are (N,H,W) int class indices")
    print("  -> fit temperature on val_logits.npz, report on test_logits.npz")
else:
    print("\nNO CHECKPOINT TO DUMP -- training never produced a healthy epoch.")
