r"""
HAZE SWEEP, ALL SCENES. Replaces haze_sweep.py, which covered scene 4 only.

WHY THIS MATTERS

Every haze number so far comes from scene 4 -- the held-out geographic split,
and the hardest one. So the dose-response curve (gap 0.658 -> 0.911 across nine
severities) is currently confounded: it could be a property of the MODEL under
atmospheric degradation, or a property of SCENE 4 specifically.

Sweeping every scene separates them. If the curve has the same shape on the
training scenes, on validation and on test, it is the model. If scene 4 is
distinct, atmospheric degradation interacts with geographic shift, and that is
itself a finding.

It also gives a direct test of the memorisation hypothesis. Scenes 1-2 were seen
during training. If the model degrades markedly LESS under haze there than on
unseen regions, it is leaning on memorised patches rather than transferable
features. If the degradation slope is similar everywhere, memorisation is not
the explanation and the train/val IoU gap (0.42 vs 0.29) is geographic shift.

STORAGE

Scenes 1-2 are 1458 patches; nine severities of full logit dumps would be about
14 GB, over Kaggle's 20 GB working limit once scene 3 is added. So metrics are
computed for every scene, and logits are dumped only where they are needed for
fitting calibrators -- controlled by DUMP_SCENES.

Kaggle: attach Sen2Fire AND the training version's output. GPU T4. ~2-3 hours
for all scenes.
"""

import glob, time
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# ------------------------------------------------------------------ config
DATA_ROOT = "/kaggle/input"
OUT_DIR   = Path("/kaggle/working")
SCENES    = ["scene1", "scene2", "scene3", "scene4"]
DUMP_SCENES = ["scene3"]              # scene4 dumps already exist; 1-2 too big
BAND_IDX  = [3, 2, 1, 7, 10, 11]
WAVELEN   = np.array([665., 560., 490., 842., 1610., 2190.])
LAMBDA0   = 550.0
ALPHA     = 1.3
BETAS     = [0.0, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 1.00, 2.00]
BATCH     = 4          # also the haze/normalise chunk size, see main()
IN_CH, OUT_CH, BASE = 6, 2, 64

DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT_DIR.mkdir(parents=True, exist_ok=True)
print("device:", DEV)


# ------------------------------------------------------------------- model
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co*2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2)-x.size(-2); dx = skip.size(-1)-x.size(-1)
            x = F.pad(x, [dx//2, dx-dx//2, dy//2, dy-dy//2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b*2), Down(b*2, b*4)
        self.d3, self.d4 = Down(b*4, b*8), Down(b*8, b*16)
        self.u1, self.u2 = Up(b*16, b*8), Up(b*8, b*4)
        self.u3, self.u4 = Up(b*4, b*2), Up(b*2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)


# -------------------------------------------------------------------- haze
def transmission(b0):
    return np.exp(-b0 * (WAVELEN / LAMBDA0) ** (-ALPHA)).astype(np.float32)[:, None, None]

def apply_haze(img, b0, A):
    if b0 == 0.0:
        return img
    t = transmission(b0)
    return img * t + A[:, None, None] * (1.0 - t)

def _nd(a, b, eps=1e-6):
    return (a - b) / (a + b + eps)

def haze_cue(img):
    """Computed on the HAZED bands: a deployed calibrator never sees the clean
    image, so using clean bands would leak information it cannot have."""
    ndvi = _nd(img[3], img[0]); nbr = _nd(img[3], img[5]); nbr2 = _nd(img[4], img[5])
    return np.nan_to_num(0.5*np.abs(ndvi-nbr) + 0.5*np.abs(ndvi-nbr2)).astype(np.float32)[None]


# -------------------------------------------------------------------- data
def find(root, scene):
    return [f for f in sorted(glob.glob(str(Path(root)/"**"/"*.npz"), recursive=True))
            if scene in {p.lower() for p in Path(f).parts[:-1]}]

def load_patch(path, scale):
    z = np.load(path, allow_pickle=True)
    ks = list(z.keys())
    ik = next((k for k in ("image","img","data","x") if k in ks), ks[0])
    lk = next((k for k in ("label","mask","gt","y") if k in ks), ks[-1])
    ak = next((k for k in ("aerosol","s5p","aod") if k in ks), None)
    img = np.asarray(z[ik], dtype=np.float32)
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2, 0, 1))
    lab = np.asarray(z[lk])
    if lab.ndim == 3: lab = lab[0]
    aer = np.asarray(z[ak], dtype=np.float32) if ak else np.zeros(lab.shape, np.float32)
    if aer.ndim == 2: aer = aer[None]
    return (np.nan_to_num(img[BAND_IDX])*scale, (lab > 0).astype(np.uint8),
            np.nan_to_num(aer))


# -------------------------------------------------------------------- main
def main():
    sp = glob.glob(str(Path(DATA_ROOT)/"**"/"norm_stats.npz"), recursive=True)
    zs = np.load(sp[0]); MEAN, STD, SCALE = zs["mean"], zs["std"], float(zs["scale"])
    cp = glob.glob(str(Path(DATA_ROOT)/"**"/"best.pt"), recursive=True)
    ck = torch.load(cp[0], map_location=DEV, weights_only=False)
    model = UNet(IN_CH, OUT_CH, BASE).to(DEV)
    model.load_state_dict(ck["model"]); model.eval()
    print(f"loaded {cp[0]} (epoch {ck.get('epoch','?')})\n")

    summary = {}
    for scene in SCENES:
        files = find(DATA_ROOT, scene)
        if not files:
            print(f"{scene}: no patches, skipping"); continue
        role = ("TRAIN (seen)" if scene in ("scene1", "scene2")
                else "VAL" if scene == "scene3" else "TEST (held out)")
        print(f"\n=== {scene}  [{role}]  {len(files)} patches ===")
        imgs, labs, aers = zip(*[load_patch(f, SCALE) for f in files])
        imgs = np.stack(imgs); labs = np.stack(labs); aers = np.stack(aers)
        print(f"  fire {100*labs.mean():.2f}% of pixels")

        # atmospheric light from THIS scene's clear imagery
        A = np.percentile(imgs, 99, axis=(0, 2, 3)).astype(np.float32)
        lab_t = torch.from_numpy(labs.astype(np.int64)).to(DEV)

        print(f"  {'beta0':<8}{'IoU':>9}{'prec':>8}{'rec':>8}"
              f"{'conf|fire':>11}{'acc|fire':>10}{'gap':>9}")
        rows = []
        dump = scene in DUMP_SCENES
        for b in BETAS:
            # STREAMED. The earlier version built two more full-scene float32
            # arrays per severity (hazed + normalised) on top of the imagery
            # already resident -- roughly 3 x 2.3 GB for a 729-patch scene,
            # which exhausted Kaggle's RAM on scene1. Hazing and normalising
            # one batch at a time keeps peak memory at a few hundred MB, and
            # metrics accumulate as scalars instead of holding every logit.
            tp = fp = fn = 0
            conf_sum = 0.0; hit = 0; n_fire = 0
            L = [] if dump else None
            C = [] if dump else None
            for i in range(0, len(imgs), BATCH):
                raw = imgs[i:i+BATCH]
                hz = np.stack([apply_haze(im, b, A) for im in raw])
                if b == 0.0:
                    assert np.allclose(hz, raw), "beta0=0 must reproduce input"
                nm = (hz - MEAN[:, None, None]) / (STD[:, None, None] + 1e-6)
                with torch.no_grad():
                    lg_b = model(torch.from_numpy(nm).to(DEV)).float()
                pred_b = lg_b.argmax(1)
                lab_b = lab_t[i:i+BATCH]
                tp += int(((pred_b==1)&(lab_b==1)).sum())
                fp += int(((pred_b==1)&(lab_b==0)).sum())
                fn += int(((pred_b==0)&(lab_b==1)).sum())
                fm = lab_b == 1
                if fm.any():
                    conf_sum += float(lg_b.softmax(1).max(1).values[fm].sum())
                    hit += int((pred_b[fm]==1).sum())
                    n_fire += int(fm.sum())
                if dump:
                    L.append(lg_b.cpu().numpy().astype(np.float16))
                    C.append(np.stack([haze_cue(h) for h in hz]).astype(np.float16))
                del hz, nm, lg_b
            e = 1e-9
            cf = conf_sum/max(n_fire,1) if n_fire else float("nan")
            af = hit/max(n_fire,1) if n_fire else float("nan")
            iou = tp/(tp+fp+fn+e)
            rows.append((b, iou, cf, af))
            print(f"  {b:<8.2f}{iou:>9.4f}{tp/(tp+fp+e):>8.3f}{tp/(tp+fn+e):>8.3f}"
                  f"{cf:>11.4f}{af:>10.4f}{cf-af:>9.4f}", flush=True)

            if dump:
                tag = f"{b:.2f}".replace(".", "p")
                np.savez_compressed(
                    OUT_DIR/f"{scene}_haze_{tag}_logits.npz",
                    logits=np.concatenate(L), labels=labs,
                    aerosol=aers.astype(np.float16),
                    haze_cue=np.concatenate(C),
                    beta0=b, alpha=ALPHA, lambda0=LAMBDA0,
                    transmission=transmission(b).ravel(), atmospheric_light=A)
                del L, C
                L = [] if dump else None; C = [] if dump else None
        summary[scene] = rows
        del imgs, labs, aers, lab_t
        import gc; gc.collect()
        if DEV == "cuda":
            torch.cuda.empty_cache()

    # ---------------- cross-scene comparison ----------------
    print("\n\n=== DEGRADATION SLOPE BY SCENE ===")
    print("Relative IoU (normalised to each scene's own clear baseline) so the")
    print("SHAPE of the curve is comparable across scenes of differing difficulty.\n")
    print(f"  {'beta0':<8}" + "".join(f"{s:>12}" for s in summary))
    for i, b in enumerate(BETAS):
        line = f"  {b:<8.2f}"
        for s in summary:
            base = summary[s][0][1]
            line += f"{summary[s][i][1]/max(base,1e-9):>12.3f}"
        print(line)

    print("\n  If the curves coincide, atmospheric degradation is a property of")
    print("  the MODEL and the dose-response generalises. If the training scenes")
    print("  degrade markedly more slowly, the model is leaning on memorised")
    print("  patches, and the train/val IoU gap (0.42 vs 0.29) is overfitting")
    print("  rather than geographic shift.")

    print("\n=== CONFIDENCE GAP BY SCENE (conf|fire - acc|fire) ===")
    print(f"  {'beta0':<8}" + "".join(f"{s:>12}" for s in summary))
    for i, b in enumerate(BETAS):
        line = f"  {b:<8.2f}"
        for s in summary:
            _, _, cf, af = summary[s][i]
            line += f"{cf-af:>12.4f}"
        print(line)
    print("\n  A gap that widens with severity in EVERY scene is the central")
    print("  claim: the model does not become less confident as its input is")
    print("  destroyed, regardless of region.")


if __name__ == "__main__":
    t = time.time(); main(); print(f"\ndone in {(time.time()-t)/60:.1f}m")
