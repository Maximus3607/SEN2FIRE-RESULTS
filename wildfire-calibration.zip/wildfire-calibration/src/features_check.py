r"""
FEATURES CHECK: do the decoder features know anything about missed fire that
the logit gap does not?

This decides whether a class-conditional FN gate is worth training. That gate
would read the 64-channel decoder features. But a head reading those exact
features already exists -- the evidence head, trained on scenes 1-2 to predict
"is the frozen model wrong here" -- and its scores on scene 3 are sitting in
evidence_val_0p00.npz. So the question can be answered for free.

The reference to beat: within pixels PREDICTED BACKGROUND on scene 3, model A's
own gap separated missed fire from correct background at usable AUROC ~0.75.
Plain softmax reads the gap, so that is what a readout gets for nothing.

WHAT IT REPORTS, within each predicted class
  AUROC(gap)        what plain softmax already sees
  AUROC(evidence)   what the decoder features add, via the evidence head
  corr              how redundant they are
  AUROC(both)       two-feature logistic model, FITTED ON THE HELD-IN HALF,
                    scored on the held-out half -- same split as every other
                    scene-3 analysis, so nothing is flattered

HOW TO READ IT
  evidence clearly > gap, or both > gap   -> the features carry information the
                                              gap discards. An FN gate trained
                                              ONLY on predicted-background pixels
                                              (removing the class shortcut) has
                                              something to learn. Worth the GPU.
  evidence ~ gap, both ~ gap              -> the features hold nothing more about
                                              missed fire than the gap. An FN gate
                                              would hit the same ceiling. Skip it.

CAVEATS, stated rather than hidden
  - The evidence head was trained on ALL pixels, so it could learn the class
    shortcut. A dedicated FN gate might do better than this on predicted
    background. So "evidence ~ gap" is strong evidence against, not proof.
  - Scene 3 at beta0 = 0 only: the head only dumped clean scene 3.
  - Model A's features. Model B's may differ.
  - The head was saved every epoch, not selected on scene 3, so these numbers
    are not selection-biased.

Usage:
  python3 features_check.py val_logits.npz evidence_val_0p00.npz
  (or scene3_haze_0p00_logits.npz in place of val_logits.npz)
"""

import sys
import numpy as np


def auroc(score, target, n=2_000_000, seed=0):
    """Returns (usable, raw). raw > 0.5 means HIGH score marks the target."""
    s = score.astype(np.float64).ravel(); t = target.astype(np.float64).ravel()
    if s.size > n:
        i = np.random.default_rng(seed).choice(s.size, n, replace=False)
        s, t = s[i], t[i]
    npos, nneg = t.sum(), (1 - t).sum()
    if npos == 0 or nneg == 0: return float("nan"), float("nan")
    o = np.argsort(s); r = np.empty(s.size); r[o] = np.arange(1, s.size + 1)
    a = float((r[t == 1].sum() - npos*(npos+1)/2) / (npos*nneg))
    return max(a, 1 - a), a


def fit_logistic(X, y, iters=25):
    """Class-balanced logistic regression, Newton's method. 3 parameters."""
    mu, sd = X.mean(0), X.std(0) + 1e-9
    Z = np.column_stack([np.ones(len(X)), (X - mu) / sd])
    w = np.where(y == 1, 0.5/max(y.mean(), 1e-9), 0.5/max(1-y.mean(), 1e-9))
    b = np.zeros(Z.shape[1])
    for _ in range(iters):
        p = 1/(1 + np.exp(-np.clip(Z @ b, -30, 30)))
        g = Z.T @ (w*(p - y))
        H = (Z * (w*p*(1-p))[:, None]).T @ Z + 1e-6*np.eye(Z.shape[1])
        step = np.linalg.solve(H, g); b -= step
        if np.abs(step).max() < 1e-7: break
    return mu, sd, b


def score_logistic(m, X):
    mu, sd, b = m
    return np.column_stack([np.ones(len(X)), (X - mu) / sd]) @ b


def main(lg_path, ev_path):
    z = np.load(lg_path)
    lg = z["logits"].astype(np.float32); y = z["labels"]
    if y.ndim == 4: y = y[:, 0]
    ev = np.load(ev_path)["evidence"].astype(np.float32)
    if ev.ndim == 4: ev = ev[:, 0]
    assert ev.shape == y.shape, (
        f"shape mismatch: evidence {ev.shape} vs labels {y.shape} -- the two "
        "files must cover the same patches")

    z0, z1 = lg[:, 0], lg[:, 1]
    gap = z1 - z0
    pred = z1 > z0
    wrong = pred != (y == 1)

    # --- pairing check: must reproduce the evidence head's ~0.85 on scene 3 ---
    _, raw_all = auroc(ev, wrong)
    print(f"{lg_path}  +  {ev_path}")
    print(f"  pairing check: evidence error-AUROC over ALL pixels = {raw_all:.4f}")
    print("  (the head scored ~0.85 on scene 3; near 0.5 would mean the two")
    print("   files are not aligned patch-for-patch, and nothing below is valid)")
    if not (raw_all > 0.7):
        print("  WARNING: pairing looks wrong -- stop and check the files.")

    n = lg.shape[0]
    perm = np.random.default_rng(0).permutation(n)       # SAME split as before
    fit, evl = np.sort(perm[:n//2]), np.sort(perm[n//2:])

    print(f"\n  held-out half: {len(evl)} patches")
    print(f"  {'population':<34}{'AUROC(gap)':>11}{'AUROC(evid)':>12}"
          f"{'corr':>8}{'AUROC(both)':>13}")
    for nm, want in [("pred BACKGROUND: missed vs correct", False),
                     ("pred FIRE: false alarm vs detected", True)]:
        mf = pred[fit] == want; me = pred[evl] == want
        gf, ef, wf = gap[fit][mf], ev[fit][mf], wrong[fit][mf].astype(float)
        ge, ee, we = gap[evl][me], ev[evl][me], wrong[evl][me].astype(float)
        if we.sum() == 0 or wf.sum() == 0:
            print(f"  {nm:<34}  no errors here"); continue
        a_g, _ = auroc(ge, we)
        a_e, raw_e = auroc(ee, we)
        c = float(np.corrcoef(ge, ee)[0, 1]) if ge.std() > 1e-6 and ee.std() > 1e-6 else float("nan")
        if gf.size > 2_000_000:
            k = np.random.default_rng(1).choice(gf.size, 2_000_000, replace=False)
            gf, ef, wf = gf[k], ef[k], wf[k]
        m = fit_logistic(np.column_stack([gf, ef]), wf)
        a_b, _ = auroc(score_logistic(m, np.column_stack([ge, ee])), we)
        flag = "" if raw_e > 0.5 else "   (evidence runs BACKWARDS here)"
        print(f"  {nm:<34}{a_g:>11.4f}{a_e:>12.4f}{c:>8.3f}{a_b:>13.4f}{flag}")

    print("\nHOW TO READ THIS")
    print("  Predicted-BACKGROUND is the row that matters: missed fire lives there.")
    print("  If AUROC(evid) or AUROC(both) clearly beats AUROC(gap), the decoder")
    print("  features know something about missed fire that the gap throws away,")
    print("  and a class-conditional FN gate is worth training.")
    print("  If all three are close, the features hold nothing more than the gap,")
    print("  and an FN gate would most likely hit the same ceiling.")
    print("  'Clearly' means a few hundredths, not a few thousandths -- with this")
    print("  many pixels, tiny differences are real but not worth a GPU run.")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__); sys.exit(1)
    main(sys.argv[1], sys.argv[2])
