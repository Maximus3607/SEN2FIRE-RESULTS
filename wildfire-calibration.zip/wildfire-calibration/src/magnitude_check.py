"""
STAGE 1: does total logit magnitude carry any signal?

Answer this BEFORE building the null-term softmax. The proposed readout is

    p(fire) = exp(z1) / ( exp(z1) + exp(z0) + lambda * exp(-gamma * M) )

where M is total evidence at a pixel. The null term only does useful work if M
is LOW exactly where the model is WRONG. If M is flat, gamma fits to zero, the
term never activates, and the formula reduces to ordinary softmax.

Two questions, in order of importance.

  Q1  Does M DISCRIMINATE? On true fire pixels, is M lower where the model is
      wrong than where it is right? This is decisive. A large drop in mean M
      under haze is useless if correct and incorrect pixels move together: a
      null term firing on everything is uniform softening, which is exactly
      what temperature scaling does, and that already failed
      (ECE(fire) 0.691 -> 0.686).

  Q2  Does M DECLINE with severity? If mean M falls as haze thickens, the
      readout can also express scene-level degradation. Secondary to Q1.

Three candidate definitions, because which notion of "evidence" tracks failure
is empirical, not a matter of taste:

  abs    |z0| + |z1|            total signal strength, either direction
  relu   ReLU(z0) + ReLU(z1)    positive evidence only. Two strongly NEGATIVE
                                logits mean the network is rejecting both
                                classes -- abs would wrongly call that strong
                                evidence, relu correctly calls it weak.
  lse    logsumexp(z0, z1)      smooth maximum. This is the energy score,
                                which already degraded 25% more slowly than
                                MSP under haze (-0.0395 vs -0.0526), the one
                                empirical hint that magnitude carries signal.

AUROC asks how well LOW M ranks the errors: 0.5 is useless. The gap column
says the same thing in the units of M.

numpy only, no torch. Runs in seconds.

Usage:  python3 magnitude_check.py haze_0p00_logits.npz haze_0p20_logits.npz ...
"""

import sys
import numpy as np


def load(path):
    z = np.load(path)
    lg = z["logits"].astype(np.float32)          # (N,2,H,W)
    lb = z["labels"]
    if lb.ndim == 4:
        lb = lb[:, 0]
    beta = float(z["beta0"]) if "beta0" in z.files else float("nan")
    return lg, lb.astype(np.int64), beta


def magnitudes(lg):
    z0, z1 = lg[:, 0], lg[:, 1]
    m = np.maximum(z0, z1)
    lse = m + np.log(np.exp(z0 - m) + np.exp(z1 - m))   # stable logsumexp
    return {"abs":  np.abs(z0) + np.abs(z1),
            "relu": np.maximum(z0, 0) + np.maximum(z1, 0),
            "lse":  lse}


def auroc_low(score, is_error, n=1_000_000, seed=0):
    """AUROC for LOW score predicting is_error. Rank-based, subsampled."""
    s = score.ravel().astype(np.float64)
    t = is_error.ravel().astype(np.float64)
    if s.size > n:
        rng = np.random.default_rng(seed)
        idx = rng.choice(s.size, n, replace=False)
        s, t = s[idx], t[idx]
    npos, nneg = t.sum(), (1 - t).sum()
    if npos == 0 or nneg == 0:
        return float("nan")
    order = np.argsort(-s)                  # low score first -> flags errors
    ranks = np.empty(s.size, dtype=np.float64)
    ranks[order] = np.arange(1, s.size + 1)
    return (ranks[t == 1].sum() - npos * (npos + 1) / 2) / (npos * nneg)


def main(paths):
    rows = []
    for p in paths:
        lg, lb, beta = load(p)
        pred = lg.argmax(1)
        fire = lb == 1
        rows.append(dict(path=p, beta=beta, M=magnitudes(lg), pred=pred,
                         lb=lb, fire=fire,
                         right=fire & (pred == lb), wrong=fire & (pred != lb)))
    rows.sort(key=lambda r: (np.isnan(r["beta"]), r["beta"]))

    print("Q1  Does M separate CORRECT from INCORRECT fire pixels?")
    print("    The decisive test. A null term that fires everywhere is just")
    print("    uniform softening, which temperature scaling already is.\n")
    for name in ("abs", "relu", "lse"):
        print(f"  M = {name}")
        print(f"    {'beta0':<8}{'M | right':>11}{'M | wrong':>11}"
              f"{'gap':>9}{'AUROC':>9}")
        for r in rows:
            m = r["M"][name]
            if r["right"].sum() == 0 or r["wrong"].sum() == 0:
                print(f"    {r['beta']:<8.2f}{'n/a':>11}")
                continue
            mr = m[r["right"]].mean()
            mw = m[r["wrong"]].mean()
            a = auroc_low(m[r["fire"]], (r["pred"][r["fire"]] != 1))
            print(f"    {r['beta']:<8.2f}{mr:>11.4f}{mw:>11.4f}"
                  f"{mr-mw:>9.4f}{a:>9.4f}")
        print()

    print("Q2  Does mean M decline as haze thickens?\n")
    print(f"  {'beta0':<8}{'abs':>10}{'relu':>10}{'lse':>10}"
          f"{'abs|fire':>11}{'acc|fire':>10}")
    for r in rows:
        f = r["fire"]
        af = r["M"]["abs"][f].mean() if f.any() else float("nan")
        ac = (r["pred"][f] == 1).mean() if f.any() else float("nan")
        print(f"  {r['beta']:<8.2f}{r['M']['abs'].mean():>10.4f}"
              f"{r['M']['relu'].mean():>10.4f}{r['M']['lse'].mean():>10.4f}"
              f"{af:>11.4f}{ac:>10.4f}")

    print("\nHOW TO READ THIS")
    print("  Q1 AUROC near 0.5, or a gap near zero, means M cannot tell correct")
    print("  from incorrect. gamma would fit to ~0, the formula reduces to plain")
    print("  softmax, and there is no point building it -- pick another signal.")
    print("  AUROC comfortably above 0.5 means low evidence really does mark the")
    print("  errors, and the null term has something to act on.")
    print("  Whichever of abs/relu/lse separates best is the M to use, and that")
    print("  choice is itself a reportable result.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    main(sys.argv[1:])
