r"""
EVIDENCE-SCALED NULL LOGIT: no gate at all. The null logit slides smoothly with
the evidence for the predicted class.

    h   = logit of the PREDICTED class (the height of the model's own claim)
    eta = h - s * (h - t)
    p(abstain) = e^eta / (e^z0 + e^z1 + e^eta)  ~=  sigmoid( -s * (h - t) )

  t   the evidence level where abstention is about half-strength
  s   how fast abstention fades as the claim gets taller (s > 0, so it always
      falls with evidence -- never the reversed direction)

Fitted separately for each predicted class on the HELD-IN half, with the SAME
objective as the height gate (true-fire ECE + true-bg ECE), so the two are
directly comparable. "OFF" is allowed for either class and means plain softmax
there.

HOW IT DIFFERS FROM THE HEIGHT GATE
The height gate is eta = c + k * sigmoid(gamma*(tau - h)): the same idea
squeezed into a capped switch, with a floor (c ~ -5.7) and a ceiling (c + k).
Here there is neither. Very weak claims can be pushed almost entirely into
abstention; very strong ones lose it smoothly. If the cap was what held the
height gate back, this should beat it. If the limit is the information in h --
the ~0.76 separability of missed fire from correct background -- it will land
in the same place.

Reuses reverse_gate.py (loading, the height gate) and paired_height.py (the
paired bootstrap), so every number is computed exactly as before.

Usage (reverse_gate.py and paired_height.py in the same folder):
  python3 evidence_null.py --boot 1000 gated_scene3_haze_0p00_logits.npz \
      gated_scene3_haze_0p20_logits.npz gated_scene3_haze_0p50_logits.npz
"""

import sys, argparse
import numpy as np
from reverse_gate import load, evidence, readout as gate_readout, fit as gate_fit, sigmoid, ece, aurc
from paired_height import patch_stats, metrics

S_GRID = (0.5, 1.0, 2.0, 3.0, 5.0)


def readout(d, params):
    """params: {predicted class: (t, s) or None}. None = OFF = plain softmax there."""
    pred = d["z1"] > d["z0"]
    h = np.where(pred, d["z1"], d["z0"])
    eta = np.full_like(h, -1e4)
    for c in (False, True):
        if params[c] is not None:
            t, s = params[c]; m = pred == c
            eta[m] = h[m] - s * (h[m] - t)
    mx = np.maximum(np.maximum(d["z0"], d["z1"]), eta)
    lse = mx + np.log(np.exp(d["z0"]-mx) + np.exp(d["z1"]-mx) + np.exp(eta-mx))
    pb, pf, pn = np.exp(d["z0"]-lse), np.exp(d["z1"]-lse), np.exp(eta-lse)
    conf = np.where(pred, pf, pb)                         # NOT renormalised
    corr = (pred == (d["y"] == 1)).astype(np.float64)
    return conf, corr, pn


def objective(d, params):
    conf, corr, _ = readout(d, params)
    f = d["y"] == 1
    return ece(conf[f], corr[f]) + ece(conf[~f], corr[~f])


def fit(d, n_fire=400_000, n_bg=1_600_000):
    rng = np.random.default_rng(0)
    fi = np.flatnonzero(d["y"] == 1); bi = np.flatnonzero(d["y"] == 0)
    i = np.sort(np.concatenate([rng.choice(fi, min(n_fire, fi.size), replace=False),
                                rng.choice(bi, min(n_bg, bi.size), replace=False)]))
    ds = {k: (v[i] if isinstance(v, np.ndarray) else v) for k, v in d.items()}
    pred = ds["z1"] > ds["z0"]; h = np.where(pred, ds["z1"], ds["z0"])
    cands = {}
    for c in (False, True):
        qs = np.quantile(h[pred == c], np.linspace(0.02, 0.60, 15))
        cands[c] = [None] + [(t, s) for t in qs for s in S_GRID]
    # coordinate descent: background given fire OFF, fire given background, background again
    P = {False: None, True: None}
    for c in (False, True, False):
        best = min(cands[c], key=lambda p: objective(ds, {**P, c: p}))
        P[c] = best
        print(f"    fitted {'pred bg  ' if not c else 'pred fire'}: "
              f"{'OFF' if best is None else f't={best[0]:+.3f} s={best[1]:.1f}'}", flush=True)
    return P


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("files", nargs="*")
    a = ap.parse_args()
    if len(a.files) < 2:
        print(__doc__); sys.exit(1)

    n = int(np.load(a.files[0])["logits"].shape[0])
    perm = np.random.default_rng(0).permutation(n)          # SAME split as before
    fit_idx, ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])
    df = load(a.files[0], fit_idx)
    print("fitting the evidence-scaled null on the held-in half ...", flush=True)
    P = fit(df)
    print("fitting the height gate for comparison ...", flush=True)
    G = gate_fit(df, "height gate")

    for path in a.files[1:]:
        d = load(path, ev_idx)
        Pn = len(ev_idx); HW = d["z0"].size // Pn
        pred = d["z1"] > d["z0"]; y = d["y"] == 1
        p = sigmoid(d["z1"] - d["z0"])
        R = {"identity": (np.where(pred, p, 1 - p), (pred == y).astype(np.float64),
                          np.zeros_like(p))}
        cg, og, ng, _ = gate_readout(d, evidence(d, "height gate"), *G)
        R["height gate"] = (cg, og, ng)
        R["evidence null"] = readout(d, P)
        for k, (_, corr, _) in R.items():
            assert np.array_equal(corr, R["identity"][1]), f"{k} changed a prediction"

        groups = {"detected fire": y & pred, "false alarm": ~y & pred,
                  "missed fire": y & ~pred, "correct bg": ~y & ~pred}
        print(f"\n=== {path.split('/')[-1]}   beta0 = {d['beta']}   ({Pn} held-out patches)")
        print("\n  WHAT EACH ABSTAINS ON  (mean p(abstain))")
        print(f"  {'readout':<15}" + "".join(f"{g:>15}" for g in groups))
        for k in ("height gate", "evidence null"):
            print(f"  {k:<15}" + "".join(f"{R[k][2][m].mean():>15.4f}" for m in groups.values()))

        S = {k: patch_stats(c, o, y, pred, Pn, HW) for k, (c, o, _) in R.items()}
        M = {k: metrics(H.sum(0), Rr.sum(0)) for k, (H, Rr) in S.items()}
        rows = ["TRUE fire", "TRUE bg", "pred fire", "pred bg", "all", "AURC"]
        print(f"\n  {'readout':<15}" + "".join(f"{r:>11}" for r in rows))
        for k in R:
            print(f"  {k:<15}" + "".join(f"{M[k][r]:>11.4f}" for r in rows))

        rng = np.random.default_rng(3)
        D = {(ref, r): [] for ref in ("identity", "height gate") for r in rows}
        for _ in range(a.boot):
            pk = rng.integers(0, Pn, Pn)
            b = {k: metrics(H[pk].sum(0), Rr[pk].sum(0)) for k, (H, Rr) in S.items()}
            for ref in ("identity", "height gate"):
                for r in rows:
                    D[(ref, r)].append(b["evidence null"][r] - b[ref][r])
        print(f"\n  paired bootstrap, {a.boot} replicates: evidence null MINUS reference"
              "  (negative = evidence null better)")
        for ref in ("identity", "height gate"):
            print(f"    vs {ref}")
            for r in rows:
                v = np.array(D[(ref, r)]); v = v[np.isfinite(v)]
                lo, hi = np.percentile(v, [2.5, 97.5])
                sig = "  *" if (hi < 0 or lo > 0) else ""
                print(f"      {r:<11}{np.mean(v):>+9.4f}   [{lo:+.4f}, {hi:+.4f}]{sig}")

    print("\nHOW TO READ THIS")
    print("  The abstention table first: it should look like the height gate's --")
    print("  most on missed fire, least on detected fire and correct background.")
    print("  'vs height gate' asks whether removing the cap helped. Differences")
    print("  near zero mean the cap was not the limit -- the information in the")
    print("  predicted class's logit was.")
    print("  'vs identity' repeats the trade-off test: expect fire better, background")
    print("  and AURC worse. A readout that improves BOTH would be new.")


if __name__ == "__main__":
    main()
