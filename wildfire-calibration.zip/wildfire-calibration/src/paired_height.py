r"""
PAIRED BOOTSTRAP: is the height gate genuinely better than plain softmax?

The height gate abstains when the logit of the PREDICTED class is short -- a
weakly supported prediction. On model B it put most of its abstention on missed
fire (0.30) and little on detected fire (0.09), and lowered TRUE-fire ECE from
0.396 to 0.326 at beta0 = 0.20 and from 0.426 to 0.299 at 0.50. This tests
whether those gains survive resampling.

DESIGN
  - The height gate is imported from reverse_gate.py, so it is EXACTLY the
    readout that produced the table above -- no reimplementation drift.
  - Thresholds are fitted ONCE on the held-in half (clear scene 3) and then
    HELD FIXED. The bootstrap resamples only held-out patches. This measures
    evaluation uncertainty -- is the gain patch-sampling luck -- not the
    uncertainty in choosing the thresholds.
  - PAIRED: every replicate scores both readouts on the SAME resampled patches,
    so patch difficulty cancels in the difference.
  - Per-patch sufficient statistics make 1000 replicates take seconds.

WHAT IS TESTED (difference = height gate minus identity; negative = better)
  PRIMARY    TRUE-fire ECE      the research question
  SECONDARY  TRUE-bg ECE        the expected cost
             fire + bg          the objective the thresholds were fitted to
             pred-fire ECE, pred-bg ECE, standard ECE, AURC

CAVEATS TO STATE
  - Sen2Fire patches overlap spatially, so resampled patches are not fully
    independent and these intervals are somewhat too narrow. A spatially
    blocked bootstrap would need patch coordinates, which the dumps lack.
  - Several metrics at two severities: treat TRUE-fire ECE as the single
    pre-specified primary endpoint rather than hunting across the rest.
  - One training run of model B.

Usage (reverse_gate.py must be in the same folder):
  python3 paired_height.py --boot 1000 gated_scene3_haze_0p00_logits.npz \
      gated_scene3_haze_0p20_logits.npz gated_scene3_haze_0p50_logits.npz
"""

import sys, argparse
import numpy as np
from reverse_gate import load, evidence, readout, fit, sigmoid

NB, NR = 20, 2000
POPS = ("TRUE fire", "TRUE bg", "pred fire", "pred bg", "all")


def patch_stats(conf, corr, y, pred, P, HW):
    """Per-patch bin sums: H[p, pop, {count, sum conf, sum corr}, bin] and a
    fine confidence histogram R[p, {count, errors}, bin] for AURC."""
    H = np.zeros((P, len(POPS), 3, NB)); R = np.zeros((P, 2, NR))
    b = np.clip((conf * NB).astype(int), 0, NB - 1)
    r = np.clip((conf * NR).astype(int), 0, NR - 1)
    masks = (y, ~y, pred, ~pred, np.ones_like(y))
    for p in range(P):
        s = slice(p * HW, (p + 1) * HW)
        bb, cc, oo = b[s], conf[s], corr[s]
        for k, m in enumerate(masks):
            mm = m[s]
            H[p, k, 0] = np.bincount(bb[mm], minlength=NB)
            H[p, k, 1] = np.bincount(bb[mm], cc[mm], NB)
            H[p, k, 2] = np.bincount(bb[mm], oo[mm], NB)
        R[p, 0] = np.bincount(r[s], minlength=NR)
        R[p, 1] = np.bincount(r[s], 1 - oo, NR)
    return H, R


def ece_h(h):
    n = h[0].sum()
    return float(np.abs(h[2] - h[1]).sum() / n) if n else float("nan")


_trapz = getattr(np, "trapezoid", None) or getattr(np, "trapz")


def aurc_h(R):
    n, e = R[0][::-1], R[1][::-1]
    cn, ce = np.cumsum(n), np.cumsum(e); k = cn > 0
    return float(_trapz(ce[k] / cn[k], cn[k] / cn[-1]))


def metrics(H, R):
    m = {pop: ece_h(H[i]) for i, pop in enumerate(POPS)}
    m["fire + bg"] = m["TRUE fire"] + m["TRUE bg"]
    m["AURC"] = aurc_h(R)
    return m


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("files", nargs="*")
    a = ap.parse_args()
    if len(a.files) < 2:
        print(__doc__); sys.exit(1)

    n = int(np.load(a.files[0])["logits"].shape[0])
    perm = np.random.default_rng(0).permutation(n)          # SAME split as before
    fit_idx, ev_idx = np.sort(perm[:n//2]), np.sort(perm[n//2:])
    print("fitting the height gate on the held-in half ...", flush=True)
    taus, gams = fit(load(a.files[0], fit_idx), "height gate")
    fmt = lambda t: "OFF" if t is None else f"{t:+.3f}"
    print(f"  tau (pred bg) {fmt(taus[False])}   tau (pred fire) {fmt(taus[True])}   "
          "-- held fixed from here on")

    order = ["TRUE fire", "TRUE bg", "fire + bg", "pred fire", "pred bg", "all", "AURC"]
    for path in a.files[1:]:
        d = load(path, ev_idx)
        P = len(ev_idx); HW = d["z0"].size // P
        pred = d["z1"] > d["z0"]; y = d["y"] == 1
        p = sigmoid(d["z1"] - d["z0"])
        conf_id = np.where(pred, p, 1 - p); corr = (pred == y).astype(np.float64)
        conf_h, corr_h, _, _ = readout(d, evidence(d, "height gate"), taus, gams)
        assert np.array_equal(corr, corr_h), "height gate changed a prediction"

        Hi, Ri = patch_stats(conf_id, corr, y, pred, P, HW)
        Hh, Rh = patch_stats(conf_h, corr, y, pred, P, HW)
        mi, mh = metrics(Hi.sum(0), Ri.sum(0)), metrics(Hh.sum(0), Rh.sum(0))

        rng = np.random.default_rng(3)
        D = {k: [] for k in order}
        for _ in range(a.boot):
            pk = rng.integers(0, P, P)
            bi = metrics(Hi[pk].sum(0), Ri[pk].sum(0))
            bh = metrics(Hh[pk].sum(0), Rh[pk].sum(0))
            for k in order:
                D[k].append(bh[k] - bi[k])

        print(f"\n=== {path.split('/')[-1]}   beta0 = {d['beta']}   ({P} held-out patches, "
              f"{a.boot} paired replicates)")
        print(f"  {'metric':<12}{'identity':>10}{'height':>10}{'diff':>10}"
              f"{'95% CI of diff':>24}{'height better':>15}")
        for k in order:
            v = np.array(D[k]); v = v[np.isfinite(v)]
            lo, hi = np.percentile(v, [2.5, 97.5])
            sig = "  *" if (hi < 0 or lo > 0) else ""
            tag = "  <- PRIMARY" if k == "TRUE fire" else ""
            print(f"  {k:<12}{mi[k]:>10.4f}{mh[k]:>10.4f}{mh[k]-mi[k]:>+10.4f}"
                  f"    [{lo:+.4f}, {hi:+.4f}]{(v < 0).mean():>13.1%}{sig}{tag}")

    print("\nHOW TO READ THIS")
    print("  Negative diff = the height gate is better (every metric is lower-is-better).")
    print("  * = the 95% interval excludes zero.")
    print("  The PRIMARY row is the claim. If its interval excludes zero at both")
    print("  severities, the height gate reliably improves fire calibration -- not luck.")
    print("  Expect TRUE-bg to be significantly WORSE: that is the known cost, and it")
    print("  must be reported alongside, not hidden.")
    print("  'fire + bg' is what the thresholds were fitted to, so it shows whether the")
    print("  trade is a net gain.")
    print("  Intervals are somewhat optimistic because Sen2Fire patches overlap.")


if __name__ == "__main__":
    main()
