"""
Diagnostics: how much of the calibration failure is NOT the softmax readout?

Runs on the dumps. No GPU, no autograd, so it finishes in about a minute.

The point: before blaming softmax for a bad ECE, subtract the parts caused by
things softmax cannot control. What survives is the honest baseline, and the
number a modified activation would have to beat.

Covers BOTH classes. The earlier version only inspected fire pixels, which was
right for an unweighted model that under-predicted fire. With class weighting
the model over-predicts fire instead, so the failure moves to background --
confident false alarms rather than confident misses. Both directions are
reported so the failure mode is identified rather than assumed.

Usage:  python3 diagnose.py val_logits.npz test_logits.npz
"""

import sys
import numpy as np
import torch
import torch.nn.functional as F


def load(path):
    z = np.load(path)
    lg = torch.from_numpy(z["logits"].astype(np.float32))
    lb = torch.from_numpy(z["labels"].astype(np.int64))
    if lb.dim() == 4:
        lb = lb[:, 0]
    assert lg.dim() == 4 and lg.shape[1] == 2, \
        f"expected (N,2,H,W) softmax logits, got {tuple(lg.shape)}"
    print(f"{path}: {lg.shape[0]} patches, fire {100*(lb==1).float().mean():.2f}%")
    return lg, lb


def ece(prob2, lab, n_bins=15, mask=None):
    conf, pred = prob2.max(1).values.flatten(), prob2.argmax(1).flatten()
    y = lab.flatten()
    if mask is not None:
        m = mask.flatten().bool()
        conf, pred, y = conf[m], pred[m], y[m]
    if conf.numel() == 0:
        return float("nan"), 0
    correct = (pred == y).float()
    edges = torch.linspace(0.5, 1.0, n_bins + 1)
    tot = 0.0
    for i in range(n_bins):
        sel = (conf > edges[i]) & (conf <= edges[i+1])
        if sel.sum() == 0:
            continue
        tot += (sel.float().mean()
                * (correct[sel].mean() - conf[sel].mean()).abs()).item()
    return tot, conf.numel()


def interior_mask(lab, cls, dist):
    """Pixels of class `cls` at least `dist` from any label boundary.

    Sen2Fire labels come from MODIS at 1 km resampled to 10 m, so fire edges in
    the ground truth are interpolation artifacts. Eroding the mask keeps only
    pixels deep inside a region, where the label is most likely genuine.
    """
    f = (lab == cls).float().unsqueeze(1)
    k = 2*dist + 1
    return (-F.max_pool2d(-f, k, stride=1, padding=dist)).squeeze(1) > 0.5


def direction(prob2, lab, mask, name):
    """Which way the confidence is wrong, on a given pixel population."""
    conf = prob2.max(1).values[mask]
    correct = (prob2.argmax(1)[mask] == lab[mask]).float()
    if conf.numel() == 0:
        print(f"  {name}: no pixels"); return
    over  = ((correct == 0) & (conf > 0.9)).float().mean().item()
    under = ((correct == 1) & (conf < 0.7)).float().mean().item()
    print(f"  {name}  ({conf.numel():,} pixels)")
    print(f"    mean confidence          {conf.mean():.4f}")
    print(f"    actual accuracy          {correct.mean():.4f}")
    print(f"    gap (conf - accuracy)    {conf.mean()-correct.mean():+.4f}")
    print(f"    confident AND WRONG      {100*over:.2f}%   (conf>0.9, incorrect)")
    print(f"    unconfident AND RIGHT    {100*under:.2f}%   (conf<0.7, correct)")


def main(val_path, test_path):
    lg_v, lb_v = load(val_path)
    lg_t, lb_t = load(test_path)
    prob = lg_t.softmax(1)
    fire, back = lb_t == 1, lb_t == 0

    agg, n_all = ece(prob, lb_t)
    e_fire, n_f = ece(prob, lb_t, mask=fire)
    e_back, n_b = ece(prob, lb_t, mask=back)
    print(f"\nECE  aggregate {agg:.5f}  over {n_all:,} pixels")
    print(f"ECE  fire      {e_fire:.5f}  over {n_f:,} pixels")
    print(f"ECE  background{e_back:.5f}  over {n_b:,} pixels")
    print("  The aggregate is dominated by background. A large fire/background")
    print("  split means a SINGLE temperature cannot fix both -- the required")
    print("  correction has opposite signs in the two populations.")

    # ---------------- 1. label noise ----------------
    print("\n1. LABEL NOISE -- ECE away from label edges (MODIS 1km -> 10m)")
    print(f"   {'erosion':<9}{'ECE(fire)':>12}{'ECE(back)':>12}{'fire kept':>13}")
    print(f"   {'none':<9}{e_fire:>12.5f}{e_back:>12.5f}{n_f:>13,}")
    for d in (2, 4, 8):
        ef, kf = ece(prob, lb_t, mask=interior_mask(lb_t, 1, d))
        eb, _  = ece(prob, lb_t, mask=interior_mask(lb_t, 0, d))
        print(f"   {d:<9}{ef:>12.5f}{eb:>12.5f}{kf:>13,}")
    print("   A sharp drop would mean resampling artifacts, not the model.")

    # ---------------- 2. base-rate shift ----------------
    pi_v = (lb_v == 1).float().mean().item()
    pi_t = (lb_t == 1).float().mean().item()
    shift = float(np.log(pi_t / pi_v))
    print(f"\n2. BASE-RATE SHIFT -- val {100*pi_v:.2f}% fire, test {100*pi_t:.2f}%")
    print(f"   log prior ratio {shift:+.4f} added to the fire logit")
    lg_c = lg_t.clone(); lg_c[:, 1] += shift
    pc = lg_c.softmax(1)
    ef_c, _ = ece(pc, lb_t, mask=fire)
    eb_c, _ = ece(pc, lb_t, mask=back)
    print(f"   {'':<18}{'fire':>12}{'background':>13}")
    print(f"   {'uncorrected':<18}{e_fire:>12.5f}{e_back:>13.5f}")
    print(f"   {'prior-corrected':<18}{ef_c:>12.5f}{eb_c:>13.5f}")
    print("   No activation can fix a prior shift: the model reports p(fire|x)")
    print("   under the prior it was trained on.")

    # ---------------- 3. residual ----------------
    m4 = interior_mask(lb_t, 1, 4)
    resid, _ = ece(pc, lb_t, mask=m4)
    frac = 100*(1 - resid/e_fire) if e_fire > 0 else float("nan")
    print(f"\n3. RESIDUAL ECE(fire) = {resid:.5f}  vs raw {e_fire:.5f}")
    print(f"   {frac:.1f}% of the apparent miscalibration comes from label noise")
    print("   and prior shift. The rest belongs to the readout.")

    # ---------------- 4. failure direction ----------------
    print("\n4. FAILURE DIRECTION -- which way is the confidence wrong?")
    direction(prob, lb_t, fire, "on TRUE FIRE pixels")
    direction(prob, lb_t, back, "on TRUE BACKGROUND pixels")
    pred_fire = prob.argmax(1) == 1
    direction(prob, lb_t, pred_fire, "on PREDICTED FIRE pixels (false alarms)")
    print("   A POSITIVE gap means overconfident: it claims more than it delivers.")
    print("   A NEGATIVE gap means underconfident. Opposite signs across the two")
    print("   populations is exactly what a single global temperature cannot fix.")

    # ---------------- 5. where the confidence mass sits ----------------
    print("\n5. CONFIDENCE DISTRIBUTION on test")
    conf = prob.max(1).values.flatten()
    corr = (prob.argmax(1) == lb_t).float().flatten()
    print(f"   {'conf bin':<14}{'pixels':>14}{'accuracy':>11}{'mean conf':>12}")
    for lo, hi in ((0.5,0.7),(0.7,0.9),(0.9,0.99),(0.99,1.01)):
        s = (conf >= lo) & (conf < hi)
        if s.sum() == 0:
            continue
        print(f"   [{lo:.2f}, {hi:.2f}){'':<3}{int(s.sum()):>14,}"
              f"{corr[s].mean():>11.4f}{conf[s].mean():>12.4f}")
    print("   A well-calibrated model has accuracy ~ mean conf in every row.")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__); sys.exit(1)
    main(sys.argv[1], sys.argv[2])
