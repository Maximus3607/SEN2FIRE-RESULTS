#!/bin/bash
# run_all.sh -- every seed-1 analysis, then the full ledger, in order.
# Usage, from ~/Downloads/Calibration:   bash run_all.sh
# Every output is shown on screen AND saved to a .txt file.
set -e -o pipefail
cd "$(dirname "$0")"
[ -f venv/bin/activate ] && source venv/bin/activate
BOOT=${BOOT:-1000}          # keep 1000: the seed-0 results used 1000
T0=$SECONDS
step() { echo; echo "======================== $1 ========================"; }
took() { echo "  -> took $(( (SECONDS-$1)/60 )) min $(( (SECONDS-$1)%60 )) s"; }

step "1/5  checking scripts and files before anything slow starts"
for f in final_compare.py reverse_gate.py compile_results.py paired_compare.py \
         paired_height.py evidence_null.py height_check.py; do
  [ -f "$f" ] || { echo "MISSING SCRIPT: $f"; exit 1; }
done
[ "$(grep -c 'MODEL A (matched)' final_compare.py || true)" = "1" ] || \
  { echo "final_compare.py is an OLD version -- re-download it"; exit 1; }
[ "$(grep -c 'fire_hist' paired_compare.py || true)" -ge 1 ] || \
  echo "  note: paired_compare.py is the old, slow version -- it will still work, just slowly"
for p in A_s1_ B_s1_ "" gated_; do
  for b in 0p00 0p20 0p50; do
    f="${p}scene3_haze_${b}_logits.npz"
    [ -f "$f" ] || { echo "MISSING DATA: $f"; exit 1; }
  done
done
echo "  all 7 scripts and all 12 data files present"

step "2/5  height gate vs every baseline -- model B, seed 1"
s=$SECONDS
python3 -u -W ignore final_compare.py --boot $BOOT \
  B_s1_scene3_haze_0p00_logits.npz B_s1_scene3_haze_0p20_logits.npz B_s1_scene3_haze_0p50_logits.npz \
  | tee results_B_s1.txt
took $s

step "3/5  height gate vs every baseline -- model A matched, seed 1"
s=$SECONDS
python3 -u -W ignore final_compare.py --boot $BOOT \
  A_s1_scene3_haze_0p00_logits.npz A_s1_scene3_haze_0p20_logits.npz A_s1_scene3_haze_0p50_logits.npz \
  | tee results_A_s1.txt
took $s

step "4/5  model A vs model B on identical patches -- the loss, nothing else"
s=$SECONDS
python3 -u -W ignore paired_compare.py --boot $BOOT \
  A_s1_scene3_haze_0p20_logits.npz B_s1_scene3_haze_0p20_logits.npz \
  A_s1_scene3_haze_0p50_logits.npz B_s1_scene3_haze_0p50_logits.npz \
  | tee results_pair_s1.txt
took $s

step "5/5  full ledger: every readout, every model, every score (slowest step)"
s=$SECONDS
python3 -u -W ignore compile_results.py \
  --model A_s0 scene3_haze_0p00_logits.npz scene3_haze_0p20_logits.npz scene3_haze_0p50_logits.npz \
  --model B_s0 gated_scene3_haze_0p00_logits.npz gated_scene3_haze_0p20_logits.npz gated_scene3_haze_0p50_logits.npz \
  --model A_s1 A_s1_scene3_haze_0p00_logits.npz A_s1_scene3_haze_0p20_logits.npz A_s1_scene3_haze_0p50_logits.npz \
  --model B_s1 B_s1_scene3_haze_0p00_logits.npz B_s1_scene3_haze_0p20_logits.npz B_s1_scene3_haze_0p50_logits.npz \
  | tee compile_output.txt
took $s

echo
echo "ALL DONE in $(( (SECONDS-T0)/60 )) min."
echo "Saved: results_B_s1.txt  results_A_s1.txt  results_pair_s1.txt  compile_output.txt"
echo "       all_results.csv  antisymmetry.csv"
echo "Paste the four .txt files into the chat."
