r"""
EVIDENCE CHECK: does the learned signal hold on the HELD-OUT region?

The evidence head reached val error-AUROC 0.8650 at epoch 1 and 0.8545 at epoch
25, never leaving the 0.839-0.865 band. Training loss fell from 0.50 to 0.32
over the same span, so the head found the signal immediately and did not drift
as it kept fitting -- that stability argues against memorisation.

But all of those numbers are SCENE 3, and the head trained on scenes 1-2. Same
broad region, shared landscape. Scene 4 is the held-out geographic split, and it
is the only number that decides whether this is a transferable signal or a
regional artifact.

WHAT IS BEING TESTED

Among pixels the frozen model PREDICTS as background, can the evidence value
separate genuine background from missed fire? That is the population ECE(fire)
is computed over -- roughly three quarters of true fire pixels sit there.

Every hand-designed signal measured on this population topped out at:

    gap / abs / lse   0.65 -> 0.57   (all identical; one degree of freedom)
    nbr_fire          0.60 -> 0.63   best of the hand-designed set
    haze_cue          0.52 -> 0.58
    aerosol           0.61           but 99.7% overlap, between-patch only

If evidence lands near 0.85 on scene 4, the readout was the bottleneck: the
information existed in the decoder features and the 2-channel projection threw
it away.

If it falls toward 0.65, the head learned scene-1-2 error patterns that do not
transfer, and the honest reading is that the signal is regional rather than
general.

Nothing here fits or calibrates anything. It is one measurement.

Usage:
  python3 evidence_check.py test_logits.npz evidence_test_0p00.npz \
                            haze_0p20_logits.npz evidence_test_0p20.npz \
                            haze_0p50_logits.npz evidence_test_0p50.npz
"""

import sys
import numpy as np

W_SPATIAL = 201


def box_mean(x, k):
    p = k // 2
    xp = np.pad(x.astype(np.float32), ((0, 0), (p, p), (p, p)), mode="edge")
    c = np.pad(xp.cumsum(1).cumsum(2), ((0, 0), (1, 0), (1, 0)))
    H, W = x.shape[1], x.shape[2]
    return (c[:, k:k+H, k:k+W] - c[:, 0:H, k:k+W]
            - c[:, k:k+H, 0:W] + c[:, 0:H, 0:W]) / (k * k)


def auroc(score, target, n=800_000, seed=0):
    s = score.ravel().astype(np.float64)
    t = target.ravel().astype(np.float64)
    if s.size > n:
        rng = np.random.default_rng(seed)
        i = rng.choice(s.size, n, replace=False)
        s, t = s[i], t[i]
    npos, nneg = t.sum(), (1 - t).sum()
    if npos == 0 or nneg == 0:
        return float("nan")
    o = np.argsort(s)
    r = np.empty(s.size); r[o] = np.arange(1, s.size + 1)
    return (r[t == 1].sum() - npos * (npos + 1) / 2) / (npos * nneg)


def main(pairs):
    print(f"{'file':<24}{'beta0':>7}{'signal':<12}{'corr bg':>10}"
          f"{'missed':>10}{'AUROC':>8}{'usable':>8}{'overlap':>9}")
    print("-" * 88)
    for lg_path, ev_path in pairs:
        z = np.load(lg_path)
        lg = z["logits"].astype(np.float32)
        lb = z["labels"]
        if lb.ndim == 4:
            lb = lb[:, 0]
        lb = lb.astype(np.int64)
        beta = float(z["beta0"]) if "beta0" in z.files else float("nan")

        ev = np.load(ev_path)["evidence"].astype(np.float32)
        if ev.ndim == 4:
            ev = ev[:, 0]
        assert ev.shape == lb.shape, (
            f"shape mismatch: evidence {ev.shape} vs labels {lb.shape}. "
            "The evidence file must come from the SAME haze level as the "
            "logits file it is paired with.")

        pred = lg.argmax(1)
        z0, z1 = lg[:, 0], lg[:, 1]
        sig = {"gap": z0 - z1,
               "nbr_fire": box_mean((pred == 1).astype(np.float32), W_SPATIAL),
               "evidence": ev}

        pb = pred == 0
        miss, corr = pb & (lb == 1), pb & (lb == 0)
        if miss.sum() == 0 or corr.sum() == 0:
            continue
        short = lg_path.split("/")[-1][:22]
        for j, (name, s) in enumerate(sig.items()):
            sc, sm = s[corr], s[miss]
            lo, hi = np.percentile(sc, [5, 95])
            ov = float(((sm >= lo) & (sm <= hi)).mean())
            a = auroc(np.concatenate([sc, sm]),
                      np.concatenate([np.zeros(sc.size), np.ones(sm.size)]))
            lead = f"{short:<24}{beta:>7.2f}" if j == 0 else " " * 31
            print(f"{lead}{name:<12}{sc.mean():>10.4f}{sm.mean():>10.4f}"
                  f"{a:>8.4f}{max(a, 1-a):>8.4f}{ov:>9.2%}")
        print()

    print("HOW TO READ THIS")
    print("  'usable' is max(AUROC, 1-AUROC) -- a signal that ranks missed fire")
    print("  LOWER is equally useful, you invert it.")
    print("  gap and nbr_fire are the reference points, already measured at")
    print("  0.57-0.65 and 0.60-0.63 on these same files.")
    print("  evidence at ~0.85 with much lower overlap means the decoder")
    print("  features carried a separable failure signal that the 2-channel")
    print("  projection discarded -- the readout was the bottleneck.")
    print("  evidence near 0.65 means it matched the hand-designed ceiling and")
    print("  the scene-3 result did not transfer across regions.")
    print("  Overlap matters as much as AUROC: a high AUROC with 95% overlap")
    print("  still leaves no threshold that acts selectively.")


if __name__ == "__main__":
    args = sys.argv[1:]
    if len(args) < 2 or len(args) % 2 != 0:
        print(__doc__); sys.exit(1)
    main(list(zip(args[0::2], args[1::2])))
