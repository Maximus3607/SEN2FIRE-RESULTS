r"""
FULL CALIBRATION BASELINES with bootstrap confidence intervals.

Replaces calibrate.py. Adds the established binary calibrators that were
missing -- isotonic regression and beta calibration -- plus patch-level
bootstrap intervals and proper scoring rules alongside ECE.

WHY ISOTONIC MATTERS MOST

This model learned antisymmetric logits (z1 = -z0), so the output carries ONE
number per pixel: the gap. Any confidence score that is a function of the logits
alone is therefore a function of the gap. Among all MONOTONE functions of the
gap, isotonic regression is the one that minimises calibration error -- it is
the unconstrained optimum of that family.

So isotonic is not just another baseline. It is an UPPER BOUND on what any
monotone logit-only readout can achieve. Temperature scaling is the linear
special case; Platt adds an offset; beta calibration adds a shape parameter. If
isotonic gains little over temperature scaling, then no readout of the logits
can gain much either, and the four custom readouts that failed were failing
against a ceiling rather than through poor design. That converts an enumeration
("we tried four things") into a bound ("nothing in this family can work").

THE CALIBRATORS

  identity      no change. The baseline everything is measured against.
  temperature   p = sigmoid(gap / T). One parameter. Accuracy-preserving:
                dividing by a positive scalar cannot reorder the logits.
  Platt         p = sigmoid(a*gap + b). Scale AND offset. NOT accuracy-
                preserving -- b moves the decision boundary. Included because
                class-weighted training adds a roughly constant logit offset
                that a pure scale structurally cannot undo.
  beta          p = sigmoid(a*log(q) - b*log(1-q) + c), q = sigmoid(gap).
                Three parameters, more flexible than Platt, standard for
                binary calibration (Kull et al.).
  isotonic      the optimal monotone map, fitted by pool-adjacent-violators.
                The ceiling for this family.

CLASS WEIGHTING CAVEAT

The model was trained with class weights [1, 5], which changes the population-
optimal prediction from q to 5q/(1+4q) -- roughly a +log(5) shift in log-odds.
The probabilities are therefore not calibrated to the true posterior BY DESIGN.
Note the direction: up-weighting fire inflates p(fire), which makes background
predictions LESS confident, while the failure measured here is background
predictions being overconfident on true fire pixels. The weighting works against
the observed effect rather than producing it. The unweighted model should still
be reported as a control.

BOOTSTRAP

Resampling is at the PATCH level, not the pixel level. Pixels within a patch are
spatially correlated, so treating them as independent observations would give
intervals that are far too narrow. Paired differences between methods are
computed on the same resampled patches, which cancels patch-to-patch variation
and gives much tighter intervals on the comparison than on either method alone.

Usage:
  python3 calibrate_full.py val_logits.npz test_logits.npz haze_0p20_logits.npz ...
  python3 calibrate_full.py --boot 1000 val_logits.npz test_logits.npz
"""

import sys, argparse, time
import numpy as np

N_FIT_PATCHES = 96
FIT_PIX = 4_000_000          # pixels subsampled for fitting the 1-D calibrators


# ------------------------------------------------------------------ loading
def load(path, idx=None):
    """idx selects PATCHES. All files from one scene share a patch ordering, so
    index i means the same ground location in every severity file."""
    z = np.load(path)
    lg, lb = z["logits"], z["labels"]
    if idx is not None:
        lg, lb = lg[idx], lb[idx]
    lg = lg.astype(np.float32)
    if lb.ndim == 4:
        lb = lb[:, 0]
    beta = float(z["beta0"]) if "beta0" in z.files else float("nan")
    return lg[:, 1] - lg[:, 0], lb.astype(np.int8), beta      # gap, label


# -------------------------------------------------------------- calibrators
def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


def fit_temperature(gap, y, iters=60):
    """One parameter, minimising NLL. Golden-section on log T."""
    lo, hi = -3.0, 3.0
    f = lambda lt: nll(sigmoid(gap / np.exp(lt)), y)
    gr = (np.sqrt(5) - 1) / 2
    a, b = lo, hi
    c, d = b - gr * (b - a), a + gr * (b - a)
    for _ in range(iters):
        if f(c) < f(d):
            b, d = d, c; c = b - gr * (b - a)
        else:
            a, c = c, d; d = a + gr * (b - a)
    return float(np.exp((a + b) / 2))


def fit_platt(gap, y, iters=200, lr=0.5):
    """Newton-free gradient descent on a, b for sigmoid(a*gap + b)."""
    a, b = 1.0, 0.0
    n = gap.size
    for _ in range(iters):
        p = sigmoid(a * gap + b)
        r = p - y
        ga, gb = float((r * gap).sum() / n), float(r.sum() / n)
        a -= lr * ga; b -= lr * gb
    return a, b


def fit_beta(gap, y, iters=300, lr=0.3):
    """Beta calibration: sigmoid(a*log q - b*log(1-q) + c), q = sigmoid(gap)."""
    q = np.clip(sigmoid(gap), 1e-6, 1 - 1e-6)
    lq, l1q = np.log(q), np.log(1 - q)
    a, b, c = 1.0, 1.0, 0.0
    n = q.size
    for _ in range(iters):
        p = sigmoid(a * lq - b * l1q + c)
        r = p - y
        a -= lr * float((r * lq).sum() / n)
        b -= lr * float((r * -l1q).sum() / n)
        c -= lr * float(r.sum() / n)
    return a, b, c


def fit_isotonic(gap, y, n_bins=2000):
    """Pool-adjacent-violators on binned gaps. Returns (edges, values).

    Binning first keeps this O(n log n) instead of O(n^2) on 130M pixels, and
    2000 bins is far finer than the 20 used for ECE, so the discretisation is
    not the limiting factor.
    """
    order = np.argsort(gap)
    g, t = gap[order], y[order].astype(np.float64)
    edges = np.quantile(g, np.linspace(0, 1, n_bins + 1))
    edges = np.unique(edges)
    idx = np.clip(np.searchsorted(edges, g, side="right") - 1, 0, len(edges) - 2)
    cnt = np.bincount(idx, minlength=len(edges) - 1).astype(np.float64)
    s = np.bincount(idx, weights=t, minlength=len(edges) - 1)
    keep = cnt > 0
    cnt, s = cnt[keep], s[keep]
    bin_lo = edges[:-1][keep]
    v = s / cnt
    # PAVA
    vals, wts, starts = [], [], []
    for i in range(v.size):
        vals.append(v[i]); wts.append(cnt[i]); starts.append(bin_lo[i])
        while len(vals) > 1 and vals[-2] > vals[-1]:
            w = wts[-1] + wts[-2]
            m = (vals[-1] * wts[-1] + vals[-2] * wts[-2]) / w
            vals.pop(); wts.pop(); s0 = starts.pop()
            vals[-1] = m; wts[-1] = w; starts[-1] = min(starts[-1], s0)
    return np.array(starts), np.array(vals)


def apply_isotonic(gap, model, eps=1e-4):
    """Clipped away from 0 and 1.

    PAVA can return exactly 0 or 1 for a pooled block that happens to be pure,
    which makes NLL infinite for a single misclassified pixel in that block.
    Clipping is standard practice and does not change the ranking, so ECE and
    Brier are unaffected while NLL becomes finite and comparable.
    """
    starts, vals = model
    i = np.clip(np.searchsorted(starts, gap, side="right") - 1, 0, vals.size - 1)
    return np.clip(vals[i], eps, 1.0 - eps)


# ------------------------------------------------------------------ metrics
def nll(p, y, eps=1e-9):
    p = np.clip(p, eps, 1 - eps)
    return float(-(y * np.log(p) + (1 - y) * np.log(1 - p)).mean())


def ece_from(conf, correct, n_bins=20):
    e = np.linspace(0.0, 1.0, n_bins + 1); tot = 0.0; n = conf.size
    for i in range(n_bins):
        s = (conf > e[i]) & (conf <= e[i + 1]); k = int(s.sum())
        if k:
            tot += (k / n) * abs(correct[s].mean() - conf[s].mean())
    return float(tot)


def metrics(p, y):
    """p = p(fire) after calibration. y in {0,1}."""
    pred = (p > 0.5).astype(np.int8)
    conf = np.maximum(p, 1 - p)
    corr = (pred == y).astype(np.float32)
    fire, bg = y == 1, y == 0
    e = 1e-9
    tp = float(((pred == 1) & fire).sum())
    fp = float(((pred == 1) & bg).sum())
    fn = float(((pred == 0) & fire).sum())
    return dict(ece=ece_from(conf, corr),
                ece_fire=ece_from(conf[fire], corr[fire]),
                ece_bg=ece_from(conf[bg], corr[bg]),
                brier=float(((p - y) ** 2).mean()),
                nll=nll(p, y),
                iou=tp / (tp + fp + fn + e))


# ---------------------------------------------------------------- bootstrap
def bootstrap_ece_fire(p_by_method, y, patch_id, n_boot, seed=0):
    """Patch-level resampling. Returns {method: (lo, hi)} and paired diffs."""
    rng = np.random.default_rng(seed)
    n_patch = int(patch_id.max()) + 1
    names = list(p_by_method)
    # index pixels by patch once
    order = np.argsort(patch_id, kind="stable")
    bounds = np.searchsorted(patch_id[order], np.arange(n_patch + 1))
    out = {k: [] for k in names}
    for _ in range(n_boot):
        pick = rng.integers(0, n_patch, n_patch)
        sel = np.concatenate([order[bounds[i]:bounds[i + 1]] for i in pick])
        yy = y[sel]; fire = yy == 1
        if fire.sum() == 0:
            continue
        for k in names:
            pk = p_by_method[k][sel]
            conf = np.maximum(pk, 1 - pk)
            corr = ((pk > 0.5).astype(np.int8) == yy).astype(np.float32)
            out[k].append(ece_from(conf[fire], corr[fire]))
    ci = {k: (float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5)))
          for k, v in out.items() if v}
    base = np.array(out["identity"])
    diffs = {k: (float(np.percentile(np.array(v) - base, 2.5)),
                 float(np.percentile(np.array(v) - base, 97.5)))
             for k, v in out.items() if k != "identity" and v}
    return ci, diffs


# --------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--boot", type=int, default=0,
                    help="bootstrap replicates for ECE(fire) CIs; 0 = skip")
    ap.add_argument("--split", action="store_true",
                    help="WITHIN-SCENE split: fit on a random half of the "
                         "patches, evaluate on the other half. Use this when "
                         "the fit file and the evaluation files come from the "
                         "SAME scene -- otherwise the calibrator is fitted and "
                         "scored on identical ground, and a reader will ask "
                         "about it. Not needed when fitting on scene 3 and "
                         "evaluating on scene 4, which are disjoint regions.")
    ap.add_argument("files", nargs="*")
    a = ap.parse_args()
    if len(a.files) < 2:
        print(__doc__); sys.exit(1)

    n = int(np.load(a.files[0])["logits"].shape[0])
    rng = np.random.default_rng(0)
    if a.split:
        perm = rng.permutation(n)
        fit_pool, eval_pool = np.sort(perm[:n//2]), np.sort(perm[n//2:])
        idx = fit_pool[:min(N_FIT_PATCHES, fit_pool.size)]
        print(f"WITHIN-SCENE SPLIT: {fit_pool.size} patches reserved for "
              f"fitting, {eval_pool.size} held out for evaluation")
    else:
        eval_pool = None
        idx = np.sort(rng.choice(n, min(N_FIT_PATCHES, n), replace=False))
    gv, yv, _ = load(a.files[0], idx)
    gvf, yvf = gv.ravel(), yv.ravel().astype(np.float64)
    if gvf.size > FIT_PIX:
        s = np.random.default_rng(1).choice(gvf.size, FIT_PIX, replace=False)
        gvf, yvf = gvf[s], yvf[s]
    print(f"fitting on {len(idx)} CLEAR val patches, {gvf.size:,} pixels\n")

    T = fit_temperature(gvf, yvf)
    pa, pb = fit_platt(gvf, yvf)
    ba, bb, bc = fit_beta(gvf, yvf)
    iso = fit_isotonic(gvf, yvf)
    print(f"  temperature  T = {T:.4f}")
    print(f"  Platt        a = {pa:.4f}, b = {pb:+.4f}")
    print(f"  beta         a = {ba:.4f}, b = {bb:.4f}, c = {bc:+.4f}")
    print(f"  isotonic     {iso[1].size} monotone segments")

    cal = {
        "identity":    lambda g: sigmoid(g),
        "temperature": lambda g: sigmoid(g / T),
        "Platt":       lambda g: sigmoid(pa * g + pb),
        "beta":        lambda g: sigmoid(
            ba * np.log(np.clip(sigmoid(g), 1e-6, 1 - 1e-6))
            - bb * np.log(1 - np.clip(sigmoid(g), 1e-6, 1 - 1e-6)) + bc),
        "isotonic":    lambda g: apply_isotonic(g, iso),
    }

    for path in a.files[1:]:
        g, y, beta = load(path, eval_pool)
        gf, yf = g.ravel(), y.ravel()
        pid = np.repeat(np.arange(g.shape[0]), g.shape[1] * g.shape[2])
        print(f"\n{path.split('/')[-1]}   beta0 = {beta}")
        hdr = (f"  {'method':<13}{'ECE':>9}{'ECE(fire)':>11}{'ECE(bg)':>10}"
               f"{'Brier':>10}{'NLL':>9}{'IoU':>8}")
        print(hdr); print("  " + "-" * (len(hdr) - 2))
        P = {}
        for name, f in cal.items():
            p = f(gf).astype(np.float32)
            P[name] = p
            m = metrics(p, yf)
            print(f"  {name:<13}{m['ece']:>9.5f}{m['ece_fire']:>11.5f}"
                  f"{m['ece_bg']:>10.5f}{m['brier']:>10.5f}{m['nll']:>9.5f}"
                  f"{m['iou']:>8.4f}")
        if a.boot:
            print(f"\n  bootstrap, {a.boot} patch-level replicates:")
            ci, diffs = bootstrap_ece_fire(P, yf, pid, a.boot)
            print(f"  {'method':<13}{'ECE(fire) 95% CI':>26}"
                  f"{'diff vs identity 95% CI':>30}")
            for k in cal:
                lo, hi = ci.get(k, (float('nan'),) * 2)
                if k == "identity":
                    print(f"  {k:<13}[{lo:.5f}, {hi:.5f}]{'':>26}")
                else:
                    d = diffs.get(k, (float('nan'),) * 2)
                    star = "" if d[0] < 0 < d[1] else "  *"
                    print(f"  {k:<13}[{lo:.5f}, {hi:.5f}]"
                          f"    [{d[0]:+.5f}, {d[1]:+.5f}]{star}")
            print("  * = interval excludes zero, i.e. a statistically")
            print("    distinguishable change from uncalibrated.")

    print("\nHOW TO READ THIS")
    print("  ISOTONIC IS THE CEILING for logit-only calibration on this model.")
    print("  With antisymmetric logits there is one number per pixel, and")
    print("  isotonic is the optimal monotone map of it. If isotonic gains")
    print("  little over temperature scaling, no readout of these logits can")
    print("  gain much -- which bounds the whole family rather than just the")
    print("  four forms already tested.")
    print("  Platt, beta and isotonic are NOT accuracy-preserving; watch the")
    print("  IoU column. Temperature scaling provably is.")
    print("  Brier and NLL are proper scoring rules. ECE is not, so a method")
    print("  that improves ECE while worsening Brier and NLL is flattening")
    print("  confidence rather than making it honest.")


if __name__ == "__main__":
    t = time.time(); main(); print(f"\ndone in {time.time()-t:.0f}s")
