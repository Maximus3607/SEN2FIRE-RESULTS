r"""
FIT SAEA: the Spatial-Aerosol Energy Abstention readout.

Fits on the CLEAR validation split, evaluates on every haze level without
refitting. That mirrors deployment -- calibrate on the clear-sky data you have,
then meet weather you did not -- and is the setting where temperature scaling is
documented to degrade.

THE READOUT

    E_i = z_0,i - C + lambda * S_i(W) * omega(A_i)

    p(fire)_i = exp(z_1,i) / Z_i
    p(bg)_i   = exp(z_0,i) / Z_i
    p(empty)_i= exp(E_i/tau) / Z_i        Z_i = exp(z_0)+exp(z_1)+exp(E_i/tau)

    omega(A) = beta / (1 + exp(-gamma*(A - A_thresh)))

Six learnable parameters: C, lambda, tau, beta, gamma, A_thresh.

  S_i(W)  fraction of a W x W neighbourhood the frozen model predicted as fire.
          Computed from the PREDICTION MAP, not the logits. Fire is contiguous
          and MODIS label cells are 1 km, so a missed fire pixel tends to sit
          near a detected one.
  A_i     Sentinel-5P aerosol. Flat within a patch (km-scale instrument), so it
          modulates whole scenes rather than individual pixels.

The PLUS sign matters: opening the gates must push E UP toward z_0 so the
abstention term expands.

WHY NOT THE LOGITS THEMSELVES

This model learned antisymmetric logits (z_1 = -z_0), so gap and |z_0|+|z_1|
agree to four significant figures -- one degree of freedom, which MSP already
reads. Three separate functional forms (null term, exponential soft-cap, linear
hinge) were tested at fixed flag budget and every one lost to the spatial gate
alone. S and A are external to the logit vector, which is exactly why they
escape that bottleneck.

TRAINING TARGET: learning-to-reject

    T_i = y_i  if the frozen model is right, else 2 (abstain)

Plain 3-class cross-entropy on this target rewards abstention exactly where the
model errs, and penalises it where the model is correct. Without it the loss has
no term that ever rewards abstaining, so the optimiser drives C -> infinity and
the method collapses to ordinary softmax.

    w_i = C_FN/C_FA on missed fire flagged for review, 1 elsewhere.

Set the cost ratio from operational reasoning about what a missed wildfire costs
versus a wasted review, NOT from the observed false-flag rate -- that would be
circular. Default 5.0. Sweep it to trace the frontier.

ACCURACY IS PRESERVED BY CONSTRUCTION: the abstention term is identical in both
class denominators, so argmax over {fire, background} cannot move. Abstention is
a downstream FLAG, never a prediction. The script asserts this.

Usage:
  python3 fit_saea.py val_logits.npz test_logits.npz haze_0p20_logits.npz ...
  python3 fit_saea.py --w 201 --cost 5 val_logits.npz test_logits.npz ...
"""

import sys, argparse
import numpy as np

W_DEFAULT = 201
N_FIT_PATCHES = 64
ITERS = 400
LR = 0.05


# ------------------------------------------------------------------ helpers
def load(path, idx=None):
    z = np.load(path)
    lg = z["logits"]
    lb = z["labels"]
    ae = z["aerosol"]
    if idx is not None:
        lg, lb, ae = lg[idx], lb[idx], ae[idx]
    lg = lg.astype(np.float32)
    if lb.ndim == 4:
        lb = lb[:, 0]
    ae = ae.astype(np.float32)
    if ae.ndim == 4:
        ae = ae[:, 0]
    beta = float(z["beta0"]) if "beta0" in z.files else float("nan")
    return lg, lb.astype(np.int64), ae, beta


def n_patches(path):
    return int(np.load(path)["logits"].shape[0])


def box_mean(x, k):
    """k x k neighbourhood mean via summed-area table. x is (N,H,W) float32."""
    p = k // 2
    xp = np.pad(x, ((0, 0), (p, p), (p, p)), mode="edge")
    c = np.pad(xp.cumsum(1).cumsum(2), ((0, 0), (1, 0), (1, 0)))
    H, W = x.shape[1], x.shape[2]
    return (c[:, k:k+H, k:k+W] - c[:, 0:H, k:k+W]
            - c[:, k:k+H, 0:W] + c[:, 0:H, 0:W]) / (k * k)


def prepare(path, W, idx=None):
    """Everything the fit and the evaluation need, precomputed."""
    lg, lb, ae, beta = load(path, idx)
    pred = lg.argmax(1)
    S = box_mean((pred == 1).astype(np.float32), W)
    A = ae.reshape(ae.shape[0], -1).mean(1)          # scene-level aerosol
    A = np.repeat(A[:, None, None], lb.shape[1], 1)
    A = np.repeat(A, lb.shape[2], 2)
    T = np.where(pred == lb, lb, 2)                  # learning-to-reject target
    return dict(z0=lg[:, 0], z1=lg[:, 1], lb=lb, pred=pred,
                S=S, A=A, T=T, beta=beta)


# --------------------------------------------------------------- the model
TAU_MIN, TAU_MAX = 0.3, 3.0

def unpack(theta):
    """Positivity where required, via softplus. tau is additionally BOUNDED.

    Why tau is capped. In the first run it fitted to 30.0010 -- exactly the top
    of its range. With tau that large, E/tau is nearly constant across pixels
    (z_0 is about 2 and the gate term rarely exceeds a few units), so the
    abstention term degenerates into a near-uniform mass added everywhere. The
    selectivity columns confirmed it: abstention 0.1325 on missed fire against
    0.0975 on correct pixels, a ratio of only 1.36:1.

    The optimiser preferred that because the spatial gate reaches just ~25% of
    missed fire. Under a loss weighting misses 5x, flat mass captures ALL
    misses including the 75% the gate cannot see, while selective mass captures
    a quarter. Flat therefore wins the weighted cross-entropy -- and wrecks ECE,
    which punishes exactly that kind of indiscriminate softening. The objective
    and the metric were pulling in opposite directions.

    Bounding tau forces the abstention term to actually track E rather than
    flattening. If the gate then collapses to zero, that is the honest answer:
    uniform softening was genuinely optimal and selective abstention is not
    achievable at this coverage.
    """
    C, log_lam, log_tau, log_beta, log_gam, a_thr = theta
    sp = lambda v: np.log1p(np.exp(np.clip(v, -30, 30)))
    tau = TAU_MIN + (TAU_MAX - TAU_MIN) / (1.0 + np.exp(-np.clip(log_tau, -30, 30)))
    return C, sp(log_lam), tau, sp(log_beta), sp(log_gam), a_thr


def probs(d, theta):
    C, lam, tau, beta, gam, a_thr = unpack(theta)
    omega = beta / (1.0 + np.exp(-np.clip(gam * (d["A"] - a_thr), -30, 30)))
    E = d["z0"] - C + lam * d["S"] * omega
    m = np.maximum(np.maximum(d["z0"], d["z1"]), E / tau)
    e0 = np.exp(d["z0"] - m); e1 = np.exp(d["z1"] - m); ea = np.exp(E / tau - m)
    Z = e0 + e1 + ea
    return e1 / Z, e0 / Z, ea / Z                     # fire, background, empty


def loss(d, theta, cost):
    pf, pb, pe = probs(d, theta)
    eps = 1e-9
    T, lb = d["T"], d["lb"]
    p_t = np.where(T == 1, pf, np.where(T == 0, pb, pe))
    w = np.where((T == 2) & (lb == 1), cost, 1.0)
    return float(-(w * np.log(p_t + eps)).sum() / w.sum())


def fit(d, cost, iters=ITERS, lr=LR, seed=0):
    """Nelder-Mead-ish coordinate search. Six parameters, no gradients needed:
    the logits and S are frozen constants, so a derivative-free search is both
    simpler and immune to the non-smoothness of the hard argmax in S."""
    rng = np.random.default_rng(seed)
    theta = np.array([4.0, 0.0, 0.0, 0.0, 0.0, float(np.median(d["A"]))])
    best = loss(d, theta, cost)
    step = np.array([1.0, 0.5, 0.5, 0.5, 0.5, float(np.std(d["A"]) + 1e-3)])
    for it in range(iters):
        improved = False
        for k in range(len(theta)):
            for s in (+1, -1):
                cand = theta.copy(); cand[k] += s * step[k]
                v = loss(d, cand, cost)
                if v < best - 1e-9:
                    best, theta, improved = v, cand, True
        if not improved:
            step *= 0.5
            if step.max() < 1e-4:
                break
        if (it + 1) % 50 == 0:
            print(f"    iter {it+1:>4}  loss {best:.6f}", flush=True)
    return theta, best


# --------------------------------------------------------------- metrics
def ece(conf, correct, n_bins=20):
    # bins span [0,1], NOT [0.5,1]: with an abstention class the confidence in
    # the two real classes can fall below 0.5, which is exactly the intended
    # behaviour and must not be binned away.
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    tot = 0.0
    for i in range(n_bins):
        s = (conf > edges[i]) & (conf <= edges[i + 1])
        k = int(s.sum())
        if k:
            tot += (k / conf.size) * abs(correct[s].mean() - conf[s].mean())
    return float(tot)


def evaluate(d, theta, name):
    pf, pb, pe = probs(d, theta)
    # Confidence is taken from the 3-class distribution WITHOUT renormalising.
    # Renormalising over {fire, background} would cancel the abstention term
    # exactly -- p_f/(p_f+p_b) = e^z1/(e^z0+e^z1) -- making the method a no-op
    # for every calibration metric. Abstention mass is supposed to REDUCE the
    # confidence attached to the surviving prediction; that is the mechanism.
    conf = np.maximum(pf, pb)
    pred = d["pred"]
    correct = (pred == d["lb"]).astype(np.float32)
    fire = d["lb"] == 1
    bg = d["lb"] == 0
    return dict(
        name=name,
        ece=ece(conf.ravel(), correct.ravel()),
        ece_fire=ece(conf[fire], correct[fire]),
        ece_bg=ece(conf[bg], correct[bg]),
        abstain=float(pe.mean()),
        abst_on_miss=float(pe[fire & (pred == 0)].mean()),
        abst_on_ok=float(pe[correct.astype(bool)].mean()))


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--w", type=int, default=W_DEFAULT)
    ap.add_argument("--cost", type=float, default=5.0)
    ap.add_argument("files", nargs="*")
    a = ap.parse_args()
    if len(a.files) < 2:
        print(__doc__); sys.exit(1)
    val_path, test_paths = a.files[0], a.files[1:]

    print(f"window W = {a.w} ({a.w*10} m)   cost ratio C_FN/C_FA = {a.cost}")
    rng = np.random.default_rng(0)
    npat = n_patches(val_path)
    idx = np.sort(rng.choice(npat, min(N_FIT_PATCHES, npat), replace=False))
    print(f"fitting on {len(idx)} of {npat} CLEAR validation patches\n")

    dv = prepare(val_path, a.w, idx)
    theta, best = fit(dv, a.cost)
    C, lam, tau, beta, gam, a_thr = unpack(theta)
    print(f"\n  fitted: C={C:.4f}  lambda={lam:.4f}  tau={tau:.4f}")
    print(f"          beta={beta:.4f}  gamma={gam:.4f}  A_thresh={a_thr:.4f}")
    print(f"          final loss {best:.6f}")
    if lam < 1e-3 or beta < 1e-3:
        print("  WARNING gate collapsed to zero -- the optimiser found no")
        print("  configuration where abstaining beats not abstaining.")
    if tau > TAU_MAX - 1e-2:
        print(f"  NOTE tau is at its ceiling ({TAU_MAX}); the abstention term is")
        print("  flattening again. Selective abstention may not be reachable.")

    hdr = (f"\n{'file':<26}{'beta0':>7}{'ECE':>9}{'ECE(fire)':>11}"
           f"{'ECE(bg)':>10}{'abstain':>9}{'on miss':>9}{'on ok':>8}")
    print(hdr); print("-" * len(hdr.strip()) )
    for p in test_paths:
        d = prepare(p, a.w)
        base = evaluate(d, np.array([1e6, -30., 0., -30., 0., 0.]), "uncal")
        r = evaluate(d, theta, "saea")
        short = p.split("/")[-1][:24]
        print(f"{short:<26}{d['beta']:>7.2f}{base['ece']:>9.5f}"
              f"{base['ece_fire']:>11.5f}{base['ece_bg']:>10.5f}"
              f"{'--':>9}{'--':>9}{'--':>8}   uncalibrated")
        print(f"{'':<26}{'':>7}{r['ece']:>9.5f}{r['ece_fire']:>11.5f}"
              f"{r['ece_bg']:>10.5f}{r['abstain']:>9.4f}"
              f"{r['abst_on_miss']:>9.4f}{r['abst_on_ok']:>8.4f}   SAEA")
        d_fire = r["ece_fire"] - base["ece_fire"]
        d_bg = r["ece_bg"] - base["ece_bg"]
        print(f"{'':<26}{'delta':>7}{'':>9}{d_fire:>+11.5f}{d_bg:>+10.5f}")
        # accuracy preservation is structural, but verify it
        assert np.array_equal(d["pred"], np.stack([d["z0"], d["z1"]]).argmax(0)), \
            "argmax changed -- accuracy is NOT preserved"
        print()

    print("HOW TO READ THIS")
    print("  ECE(fire) delta NEGATIVE is the win. ECE(bg) delta POSITIVE is the")
    print("  cost. Both must be reported: the method buys fire calibration by")
    print("  spending background calibration, and hiding the second would be")
    print("  misleading.")
    print("  'on miss' vs 'on ok' is the selectivity: abstention mass placed on")
    print("  missed fire versus on pixels the model got right. If they are")
    print("  similar, the gate is firing indiscriminately and the method is")
    print("  uniform softening -- temperature scaling, renamed.")
    print("  Accuracy is identical in every row by construction and asserted.")
    print("  For scale: adaptive T beat uncalibrated by 0.0070 on ECE(fire).")


if __name__ == "__main__":
    main()
