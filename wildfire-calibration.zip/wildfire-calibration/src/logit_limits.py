r"""
LOGIT LIMITS: why does MaxLogit stop telling errors apart on scene 4?

Three candidate causes:
  1. THE LOGITS   scene 4's errors look like confident correct answers, so no
                  readout of the logits could separate them
  2. MAXLOGIT     the logits still hold the information, but MaxLogit's way of
                  reading it misses it
  3. THRESHOLDS   MaxLogit still RANKS errors correctly; thresholds fitted on
                  scene 3 are simply misplaced on scene 4
AUROC needs no threshold, so it removes cause 3. The CEILING -- the best
possible score from ANY function of the two logits -- separates 1 from 2:
  MaxLogit falls but the ceiling holds          -> MaxLogit is the problem
  MaxLogit and the ceiling fall together        -> the logits are the problem
  AUROCs hold but selectivity collapsed         -> the thresholds are

Scores, each oriented so higher = "more likely wrong", within each predicted
class:
  MSP        -|z1 - z0|            maximum softmax probability
  MaxLogit   -(predicted class's logit)            Hendrycks et al. 2022
  energy     -logsumexp(z0, z1)                    Liu et al. 2020
  sum        (z0 + z1)/2, direction-free (max of AUROC, 1 - AUROC)
  ceiling    best function of (z0, z1): P(error | cell) on a 40 x 40 grid of
             logit quantiles, CROSS-FITTED (learned on one half of the pixels,
             scored on the other) so it cannot memorise noise. It estimates
             what the best possible readout of these logits could achieve.
Background calls: positive = missed fire.  Fire calls: positive = false alarm.

Conditions: scene 3 held-out half at beta0 0.0 and 0.5, and scene 4 natural.
Usage (same model arguments as final_tests.py):
  python3 logit_limits.py --model A_s0 "" test_logits.npz --model B_s0 gated_ ...
Writes results/logit_limits.csv
"""
import sys, os, csv, argparse
import numpy as np
from final_tests import CHUNK, OUT

N_MAX = 3_000_000


def auroc(score, pos):
    s = np.asarray(score, np.float64); p = np.asarray(pos, bool)
    u, inv = np.unique(s, return_inverse=True)
    P = np.bincount(inv, p.astype(float), len(u)); N = np.bincount(inv, (~p).astype(float), len(u))
    below = np.cumsum(N) - N
    return float((P * (below + 0.5 * N)).sum() / (P.sum() * N.sum()))


def ceiling(z0, z1, pos, nb=None):
    """CROSS-FITTED: error rates per cell are learned on one random half and
    scored on the other (and vice versa), so the ceiling cannot memorise noise.
    Cells unseen in the learning half get that half's overall error rate.
    Grid size adapts to the data: up to 40 x 40, coarser when errors are few,
    so each cell holds enough pixels for a stable rate."""
    if nb is None:
        nb = int(np.clip(np.sqrt(min(pos.sum(), (~pos).sum()) / 20), 6, 40))
    q0 = np.quantile(z0, np.linspace(0, 1, nb + 1)[1:-1]); q1 = np.quantile(z1, np.linspace(0, 1, nb + 1)[1:-1])
    cell = np.searchsorted(q0, z0) * nb + np.searchsorted(q1, z1)
    half = np.random.default_rng(7).random(cell.size) < 0.5
    score = np.empty(cell.size)
    for learn in (half, ~half):
        k = np.bincount(cell[learn], pos[learn].astype(float), nb * nb); n = np.bincount(cell[learn], minlength=nb * nb)
        rate = np.where(n > 0, k / np.maximum(n, 1), pos[learn].mean())
        score[~learn] = rate[cell[~learn]]
    return auroc(score, pos)


def collect(path, idx):
    z = np.load(path); L, Y = z["logits"], z["labels"]
    idx = np.arange(L.shape[0]) if idx is None else idx
    rng = np.random.default_rng(1); keep = {False: [], True: []}
    for s in range(0, len(idx), CHUNK):
        sel = idx[s:s + CHUNK]; lg = L[sel].astype(np.float32); y = Y[sel]
        if y.ndim == 4: y = y[:, 0]
        z0, z1, y = lg[:, 0].ravel(), lg[:, 1].ravel(), (y == 1).ravel()
        pred = z1 > z0
        for c in (False, True):
            m = pred == c; err = (y != c)[m]
            a0, a1 = z0[m], z1[m]
            # keep every error, subsample the (abundant) correct pixels
            k = err | (rng.random(err.size) < 0.08)
            keep[c].append((a0[k], a1[k], err[k]))
    out = {}
    for c in (False, True):
        a0 = np.concatenate([x[0] for x in keep[c]]); a1 = np.concatenate([x[1] for x in keep[c]])
        e = np.concatenate([x[2] for x in keep[c]])
        if a0.size > N_MAX:
            i = rng.choice(a0.size, N_MAX, replace=False); a0, a1, e = a0[i], a1[i], e[i]
        out[c] = (a0, a1, e)
    return out


def scores(a0, a1, e, cls):
    h = a1 if cls else a0
    m = np.maximum(a0, a1); lse = m + np.log(np.exp(a0 - m) + np.exp(a1 - m))
    s_sum = auroc((a0 + a1) / 2, e)
    return {"MSP": auroc(-np.abs(a1 - a0), e), "MaxLogit": auroc(-h, e), "energy": auroc(-lse, e),
            "sum": max(s_sum, 1 - s_sum), "ceiling": ceiling(a0, a1, e),
            "errors": int(e.sum()), "error_logit_median": float(np.median(h[e])),
            "correct_logit_median": float(np.median(h[~e]))}


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--model", action="append", nargs=3, default=[])
    a = ap.parse_args()
    if not a.model:
        print(__doc__); sys.exit(1)
    os.makedirs(OUT, exist_ok=True); rows = []
    cols = ["MSP", "MaxLogit", "energy", "sum", "ceiling"]
    for label, prefix, s4 in a.model:
        f0 = f"{prefix}scene3_haze_0p00_logits.npz"
        n = int(np.load(f0)["logits"].shape[0])
        ev = np.sort(np.random.default_rng(0).permutation(n)[n // 2:])     # SAME held-out half
        conds = [("scene3 b0=0.0", f0, ev), ("scene3 b0=0.5", f"{prefix}scene3_haze_0p50_logits.npz", ev),
                 ("scene4 natural", s4, None)]
        print(f"\n######## {label}")
        print(f"  {'condition':<16}{'calls':<12}" + "".join(f"{c:>10}" for c in cols)
              + f"{'error h':>10}{'correct h':>11}")
        for cname, path, idx in conds:
            if not os.path.exists(path):
                print(f"  {cname}: {path} missing -- skipped"); continue
            data = collect(path, idx)
            for c, nm in ((False, "background"), (True, "fire")):
                r = scores(*data[c], c)
                rows.append(dict(model=label, condition=cname, calls=nm, **r))
                print(f"  {cname:<16}{nm:<12}" + "".join(f"{r[k]:>10.3f}" for k in cols)
                      + f"{r['error_logit_median']:>10.2f}{r['correct_logit_median']:>11.2f}", flush=True)
    with open(f"{OUT}/logit_limits.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print(f"\nWrote {OUT}/logit_limits.csv")
    print("\nHOW TO READ THIS -- compare each row to the same model's scene 3 rows:")
    print("  MaxLogit falls, ceiling holds        -> MaxLogit's construction is the problem")
    print("  MaxLogit AND ceiling fall together   -> the logits are the problem: no readout")
    print("                                          of them could separate scene 4's errors")
    print("  everything holds, but selectivity collapsed in final_tests -> thresholds")
    print("  The ceiling is an ESTIMATE (cross-fitted, so slightly conservative): within")
    print("  about 0.01 of MSP, read the two as equal -- the logits hold nothing more.")
    print("  'error h' vs 'correct h': median predicted-class logit of errors vs correct")
    print("  pixels. If scene 4's errors sit as high as its correct pixels, they look")
    print("  confident to every logit-based method.")


if __name__ == "__main__":
    main()
