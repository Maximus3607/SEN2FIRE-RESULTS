r"""
TRAIN ON AGREEMENT LABELS, THEN DUMP LOGITS -- one Kaggle run.

WHAT CHANGES FROM MODEL A, AND WHAT DOES NOT
  CHANGES  the labels: agreement labels (fire only where MODIS AND a strict
           Sentinel-2 fire signature agree; 255 = ignore), and the loss skips
           ignored pixels (cross-entropy with ignore_index = 255). Validation
           IoU, used to pick the checkpoint, is also computed on agreement
           labels with ignored pixels skipped.
  SAME     the U-Net (31M parameters), the six bands, normalisation, flips,
           AdamW, learning rate, warm-up + cosine schedule, batch size, class
           weights [1, 5], fire-balanced sampling (30%), the fixed 10%
           within-scene holdout, fp32 throughout (no mixed precision: it
           corrupted BatchNorm in an early run).
  So any difference from model A comes from the labels.

AFTER TRAINING it reloads the best checkpoint and writes logit dumps in the
format every analysis script already reads:
  AG_s<seed>_scene3_haze_0p00_logits.npz ... 0p50   (beta0 0.0-0.5, step 0.1)
  AG_s<seed>_scene4_haze_0p00_logits.npz           (natural, no synthetic haze)
Each holds logits (float16), labels = AGREEMENT labels (0 / 1 / 255),
labels_modis = the original MODIS labels, aerosol, beta0, seed. The haze
model is identical to every earlier dump: Angstrom alpha 1.3, lambda0 550 nm,
atmospheric light from the 99th percentile of 120 sampled clear patches.

KAGGLE SETUP
  Inputs: Sen2Fire, AND the output of the agreement-label notebook
          (agreement_scene1.npz ... agreement_scene4.npz).
  Accelerator: GPU T4.  Save Version -> Save & Run All.
  Set SEED below: 0 for the first run, 1 for the second.
  Time: about 7-8 minutes per epoch on a T4, so ~5 h for 40 epochs, plus
  ~35 min of dumping.
"""

import os, glob, json, math, time
from pathlib import Path
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler

SEED = int(os.environ.get("AG_SEED", 0))           # <-- 0 for run one, 1 for run two
EPOCHS = int(os.environ.get("AG_EPOCHS", 40))


class CFG:
    data_root = os.environ.get("AG_ROOT", "/kaggle/input")
    out_dir   = os.environ.get("AG_OUT", "/kaggle/working")
    splits    = {"train": ["scene1", "scene2"], "val": ["scene3"], "test": ["scene4"]}
    band_idx  = [3, 2, 1, 7, 10, 11]
    in_ch, out_ch, base = 6, 2, int(os.environ.get("AG_BASE", 64))
    epochs, seed = EPOCHS, SEED
    batch, lr, weight_decay = int(os.environ.get("AG_BATCH", 4)), 3e-4, 1e-4
    warmup_steps = int(os.environ.get("AG_WARMUP", 300))   # 300 as model A; lower only for tiny tests
    class_weight = [1.0, 5.0]
    fire_ratio   = 0.3
    holdout_frac = 0.10
    workers      = int(os.environ.get("AG_WORKERS", 2))
    label_key    = "label"            # "label_charter" = the Charter-strict version
    ignore       = 255
    # dumping -- identical to dump_gated.py
    wavelen = np.array([665., 560., 490., 842., 1610., 2190.]); lambda0, alpha = 550.0, 1.3
    betas3  = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]
    a_sample = 120
    max_dump = int(os.environ.get("AG_MAXDUMP", 0))   # 0 = every patch (testing only)


DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT = Path(CFG.out_dir); OUT.mkdir(parents=True, exist_ok=True)
torch.manual_seed(CFG.seed); np.random.seed(CFG.seed)
TAG = f"AG_s{CFG.seed}_"


# ------------------------------------------------------------------- model (identical to model A)
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co * 2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2) - x.size(-2); dx = skip.size(-1) - x.size(-1)
            x = F.pad(x, [dx // 2, dx - dx // 2, dy // 2, dy - dy // 2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b * 2), Down(b * 2, b * 4)
        self.d3, self.d4 = Down(b * 4, b * 8), Down(b * 8, b * 16)
        self.u1, self.u2 = Up(b * 16, b * 8), Up(b * 8, b * 4)
        self.u3, self.u4 = Up(b * 4, b * 2), Up(b * 2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)


# -------------------------------------------------------------------- data
def find(root, tags):
    """Identical to every earlier script, so patch order matches."""
    return [f for f in sorted(glob.glob(str(Path(root) / "**" / "*.npz"), recursive=True))
            if {p.lower() for p in Path(f).parts[:-1]} & set(tags)]


def load_agreement():
    """name -> agreement label array, from the label notebook's output."""
    lab = {}
    for f in sorted(glob.glob(str(Path(CFG.data_root) / "**" / "agreement_scene*.npz"), recursive=True)):
        z = np.load(f, allow_pickle=True); L = z[CFG.label_key]
        for i, nm in enumerate(z["files"]):
            lab[str(nm)] = L[i]
        print(f"  agreement labels: {Path(f).name}  {len(z['files'])} patches  key '{CFG.label_key}'", flush=True)
    if not lab:
        raise SystemExit("No agreement_scene*.npz found -- attach the agreement-label notebook's output.")
    return lab


def read_patch(path):
    with np.load(path, allow_pickle=True) as z:
        ks = list(z.keys())
        ik = next((k for k in ("image", "img", "data", "x") if k in ks), ks[0])
        lk = next((k for k in ("label", "mask", "gt", "y") if k in ks), ks[-1])
        ak = next((k for k in ("aerosol", "s5p", "aod") if k in ks), None)
        img = np.asarray(z[ik], dtype=np.float32); lab = np.asarray(z[lk])
        aer = np.asarray(z[ak], dtype=np.float32) if ak else None
    if img.ndim == 3 and img.shape[2] < img.shape[0]:
        img = np.transpose(img, (2, 0, 1))
    if lab.ndim == 3: lab = lab[0]
    if aer is None: aer = np.zeros(lab.shape, np.float32)
    if aer.ndim == 3: aer = aer[0]
    return np.nan_to_num(img[CFG.band_idx]), (lab > 0).astype(np.uint8), np.nan_to_num(aer)


class Patches(Dataset):
    def __init__(self, files, labels, mean, std, scale, augment=False, seed=0):
        self.files, self.labels, self.mean, self.std, self.scale = files, labels, mean, std, scale
        self.augment, self.rng = augment, np.random.default_rng(seed)
    def __len__(self): return len(self.files)
    def raw(self, i):
        img, _, _ = read_patch(self.files[i])
        return img * self.scale, self.labels[Path(self.files[i]).name].astype(np.int64)
    def __getitem__(self, i):
        img, lab = self.raw(i)
        if self.augment:
            r = self.rng
            if r.random() < .5: img, lab = img[:, :, ::-1], lab[:, ::-1]
            if r.random() < .5: img, lab = img[:, ::-1], lab[::-1]
        x = (img - self.mean[:, None, None]) / (self.std[:, None, None] + 1e-6)
        t = lambda a: torch.from_numpy(np.ascontiguousarray(a))
        return t(x), t(lab)


def norm_stats(files, scale, n=300):
    """Identical to model A: same 300 patches (seed 0), same statistics."""
    idx = np.random.default_rng(0).choice(len(files), min(n, len(files)), replace=False)
    S = np.stack([read_patch(files[i])[0] * scale for i in idx])
    return S.mean((0, 2, 3)).astype(np.float32), S.std((0, 2, 3)).astype(np.float32)


@torch.no_grad()
def evaluate(model, dl):
    model.eval(); tp = fp = fn = 0.0; nfire = 0
    for x, y in dl:
        x, y = x.to(DEV), y.to(DEV)
        p = model(x).argmax(1); v = y != CFG.ignore
        tp += float(((p == 1) & (y == 1) & v).sum()); fp += float(((p == 1) & (y == 0) & v).sum())
        fn += float(((p == 0) & (y == 1) & v).sum()); nfire += int(((y == 1) & v).sum())
    e = 1e-9
    return dict(iou=tp / (tp + fp + fn + e), prec=tp / (tp + fp + e), rec=tp / (tp + fn + e), fire_px=nfire)


# -------------------------------------------------------------------- dump
def transmission(b0):
    return np.exp(-b0 * (CFG.wavelen / CFG.lambda0) ** (-CFG.alpha)).astype(np.float32)[:, None, None]


def apply_haze(img, b0, A):
    if b0 == 0.0: return img
    t = transmission(b0); return img * t + A[:, None, None] * (1.0 - t)


@torch.no_grad()
def dump(model, scene, betas, labels, MEAN, STD, SCALE):
    files = find(CFG.data_root, [scene])
    if CFG.max_dump: files = files[:CFG.max_dump]
    step = max(1, len(files) // CFG.a_sample)
    samp = np.stack([read_patch(f)[0] * SCALE for f in files[::step]])
    A = np.percentile(samp, 99, axis=(0, 2, 3)).astype(np.float32); del samp
    print(f"\n  {scene}: {len(files)} patches   atmospheric light A = {np.round(A, 4)}", flush=True)
    M3, S3 = MEAN[:, None, None], STD[:, None, None]
    model.eval()
    for b in betas:
        L, LB, LM, AE = [], [], [], []
        tp = fp = fn = 0
        for i in range(0, len(files), 4):
            chunk = files[i:i + 4]
            raws = [read_patch(f) for f in chunk]
            hz = np.stack([apply_haze(r[0] * SCALE, b, A) for r in raws])
            if b == 0.0: assert np.allclose(hz, np.stack([r[0] * SCALE for r in raws]))
            x = torch.from_numpy((hz - M3) / (S3 + 1e-6)).float().to(DEV)
            lg = model(x).float().cpu().numpy()
            ag = np.stack([labels[Path(f).name] for f in chunk])
            pred = lg.argmax(1); v = ag != CFG.ignore
            tp += int(((pred == 1) & (ag == 1) & v).sum()); fp += int(((pred == 1) & (ag == 0) & v).sum())
            fn += int(((pred == 0) & (ag == 1) & v).sum())
            L.append(lg.astype(np.float16)); LB.append(ag); LM.append(np.stack([r[1] for r in raws]))
            AE.append(np.stack([r[2] for r in raws]).astype(np.float16))
        tag = f"{b:.2f}".replace(".", "p")
        path = OUT / f"{TAG}{scene}_haze_{tag}_logits.npz"
        np.savez_compressed(path, logits=np.concatenate(L), labels=np.concatenate(LB),
                            labels_modis=np.concatenate(LM), aerosol=np.concatenate(AE),
                            beta0=b, alpha=CFG.alpha, lambda0=CFG.lambda0, seed=CFG.seed,
                            nu_target=0.0, label_source="agreement:" + CFG.label_key,
                            files=np.array([Path(f).name for f in files]))
        iou = tp / max(tp + fp + fn, 1)
        print(f"    beta0 {b:.2f}  agreement IoU {iou:.4f}  recall {tp / max(tp + fn, 1):.4f}  -> {path.name}", flush=True)


# -------------------------------------------------------------------- main
def main():
    print(f"RUN: AGREEMENT-LABEL MODEL A   seed {CFG.seed}   epochs {CFG.epochs}   device {DEV}", flush=True)
    files = {s: find(CFG.data_root, t) for s, t in CFG.splits.items()}
    assert files["train"], "no training patches found -- is Sen2Fire attached?"
    labels = load_agreement()
    for s, fl in files.items():
        missing = [Path(f).name for f in fl if Path(f).name not in labels]
        if missing:
            raise SystemExit(f"{len(missing)} {s} patches have no agreement label (e.g. {missing[0]}). "
                             "Attach the complete agreement-label output.")
    rng = np.random.default_rng(0)                      # FIXED across seeds, as model A
    perm = rng.permutation(len(files["train"])); n_hold = int(CFG.holdout_frac * len(perm))
    hold = [files["train"][i] for i in perm[:n_hold]]; train = [files["train"][i] for i in perm[n_hold:]]
    fire_px = np.array([int((labels[Path(f).name] == 1).sum()) for f in train])
    print(f"train {len(train)} | holdout {len(hold)} | val {len(files['val'])} | test {len(files['test'])}")
    print(f"agreement fire in the training patches: {int(fire_px.sum()):,} pixels in "
          f"{int((fire_px > 0).sum())} patches", flush=True)
    if fire_px.sum() == 0:
        raise SystemExit("No agreement fire in the training data -- nothing to learn. Stopping.")

    raw0, _, _ = read_patch(train[0]); SCALE = 1e-4 if raw0.max() > 100 else 1.0
    MEAN, STD = norm_stats(train, SCALE)
    np.savez(OUT / "norm_stats.npz", mean=MEAN, std=STD, scale=SCALE)
    print(f"scale {SCALE:g}  mean {np.round(MEAN, 4)}", flush=True)

    has = fire_px > 0
    w = np.where(has, CFG.fire_ratio / max(has.sum(), 1), (1 - CFG.fire_ratio) / max((~has).sum(), 1))
    sampler = WeightedRandomSampler(torch.as_tensor(w, dtype=torch.double), num_samples=len(train),
                                    replacement=True, generator=torch.Generator().manual_seed(CFG.seed))
    ds = lambda f, aug=False: Patches(f, labels, MEAN, STD, SCALE, augment=aug, seed=CFG.seed)
    train_dl = DataLoader(ds(train, True), batch_size=CFG.batch, sampler=sampler, drop_last=True,
                          num_workers=CFG.workers, pin_memory=(DEV == "cuda"))
    mk = lambda f: DataLoader(ds(f), batch_size=CFG.batch, num_workers=CFG.workers, pin_memory=(DEV == "cuda"))
    hold_dl, val_dl = mk(hold), mk(files["val"])

    model = UNet(CFG.in_ch, CFG.out_ch, CFG.base).to(DEV)
    crit = nn.CrossEntropyLoss(weight=torch.tensor(CFG.class_weight, device=DEV), ignore_index=CFG.ignore)
    opt = torch.optim.AdamW(model.parameters(), lr=CFG.lr, weight_decay=CFG.weight_decay)
    steps = CFG.epochs * len(train_dl)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1.0, (s + 1) / CFG.warmup_steps) * 0.5 * (1 + math.cos(math.pi * min(s / steps, 1.0))))
    print(f"params {sum(p.numel() for p in model.parameters()):,}   steps/epoch {len(train_dl)}\n", flush=True)

    hist, best = [], -1.0
    for ep in range(1, CFG.epochs + 1):
        t0 = time.time(); model.train(); tl = 0.0; nb = 0; skipped = 0
        for x, y in train_dl:
            x, y = x.to(DEV), y.to(DEV)
            if not (y != CFG.ignore).any():
                skipped += 1; continue                 # a batch with nothing to learn from
            loss = crit(model(x), y)
            if not torch.isfinite(loss):
                skipped += 1; continue
            opt.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step(); sched.step(); tl += float(loss.detach()); nb += 1
        v = evaluate(model, val_dl); h = evaluate(model, hold_dl) if hold else None
        flag = ""
        if v["iou"] > best:
            best, flag = v["iou"], "  * best"
            torch.save(dict(model=model.state_dict(), epoch=ep, best=best, seed=CFG.seed, nu_target=0.0,
                            labels="agreement:" + CFG.label_key), OUT / "best.pt")
        rec = dict(epoch=ep, loss=tl / max(nb, 1), val_iou=v["iou"], val_prec=v["prec"], val_rec=v["rec"],
                   hold_iou=h["iou"] if h else None, skipped_batches=skipped, minutes=(time.time() - t0) / 60)
        hist.append(rec); (OUT / "history.json").write_text(json.dumps(hist, indent=2))
        print(f"epoch {ep:3d}  loss {rec['loss']:.4f}  val IoU {v['iou']:.4f} (P {v['prec']:.3f} R {v['rec']:.3f})"
              f"  holdout IoU {rec['hold_iou'] if h else float('nan'):.4f}  {rec['minutes']:.1f} min{flag}", flush=True)

    ck = torch.load(OUT / "best.pt", map_location=DEV, weights_only=False)
    model.load_state_dict(ck["model"])
    print(f"\nbest checkpoint: epoch {ck['epoch']}  val IoU {ck['best']:.4f}   -- dumping logits", flush=True)
    dump(model, "scene3", CFG.betas3, labels, MEAN, STD, SCALE)
    dump(model, "scene4", [0.0], labels, MEAN, STD, SCALE)
    print("\nDONE. Download the AG_s*_logits.npz files, best.pt, norm_stats.npz and history.json.", flush=True)


if __name__ == "__main__":
    main()
