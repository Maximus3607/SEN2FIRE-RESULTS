"""
Stage 2: offline calibration analysis, SOFTMAX version. CPU only.

Reads val_logits.npz / test_logits.npz from train_sen2fire_softmax.py:
logits (N,2,H,W), labels (N,H,W) int class indices.
FITS on val (scene3), EVALUATES on test (scene4). Never the reverse.

Rewritten for speed and memory. The previous version held every patch in fp32
with autograd live across 400 iterations, which peaked near 14 GB and swapped.
Now: calibrators are FITTED on a random subsample of patches (three or four
scalar parameters do not need 264 million pixels), and metrics are ACCUMULATED
in chunks so full-resolution arrays are never all resident at once. Minutes,
not an hour.

FOUR methods are compared:
  1. uncalibrated       T = 1
  2. global T           one scalar. Guo et al. Accuracy-preserving.
  3. Platt              scale AND offset. NOT accuracy-preserving.
  4. adaptive T         softplus(scene aerosol + pixel haze + bias).
                        Accuracy-preserving.

WHY PLATT IS NOW REQUIRED: the model was trained with class_weight [1, 5],
which adds a roughly constant OFFSET to the logits. Global temperature DIVIDES,
and a scale cannot undo a shift -- so global T is a handicapped baseline here.
Platt fits scale and offset together and can correct it. Any new method must
beat Platt, not just global T, or a reviewer will point out that a two-parameter
classical method would have done the same job.

ACCURACY PRESERVATION: dividing both logits by one positive scalar cannot
reorder them, so IoU/P/R are provably unchanged for methods 2 and 4. Platt adds
an offset and CAN flip pixels near the boundary; its accuracy is reported
separately so the difference is visible rather than assumed.

Usage:  python3 calibrate.py val_logits.npz test_logits.npz [n_fit_patches]
"""

import sys, time
import numpy as np
import torch
import torch.nn.functional as F

torch.manual_seed(0)
CHUNK = 24          # patches per evaluation chunk
N_FIT = 96          # patches used to fit the calibrators


# ------------------------------------------------------------------ loading
class Dump:
    """Holds fp16 arrays and hands out fp32 chunks on demand."""

    def __init__(self, path):
        z = np.load(path)
        self.lg = z["logits"]                       # (N,2,H,W) fp16
        self.lb = z["labels"]                       # (N,H,W)   uint8
        self.ae = z["aerosol"]
        self.hz = z["haze_cue"]
        assert self.lg.ndim == 4 and self.lg.shape[1] == 2, \
            f"expected (N,2,H,W) softmax logits, got {self.lg.shape}"
        if self.lb.ndim == 4:
            self.lb = self.lb[:, 0]
        self.n = self.lg.shape[0]
        print(f"{path}: {self.n} patches, {self.lg.shape[-2]}x{self.lg.shape[-1]}, "
              f"fire {100*self.lb.mean():.2f}% of pixels")

    def take(self, idx):
        """fp32 tensors for the given patch indices."""
        t = lambda a: torch.from_numpy(np.asarray(a, dtype=np.float32))
        return (t(self.lg[idx]), torch.from_numpy(self.lb[idx].astype(np.int64)),
                t(self.ae[idx]), t(self.hz[idx]))

    def chunks(self):
        for s in range(0, self.n, CHUNK):
            yield self.take(slice(s, min(s + CHUNK, self.n)))


# ------------------------------------------------------------------ metrics
class Metrics:
    """Streaming ECE / Brier / NLL / IoU so nothing large stays resident."""

    def __init__(self, n_bins=15):
        self.e = torch.linspace(0.5, 1.0, n_bins + 1)
        self.nb = n_bins
        z = lambda: torch.zeros(n_bins, dtype=torch.float64)
        self.cnt, self.cs, self.rs = z(), z(), z()          # all pixels
        self.fcnt, self.fcs, self.frs = z(), z(), z()       # true-fire pixels
        self.brier = self.nll = self.npx = 0.0
        self.tp = self.fp = self.fn = 0

    def _bin(self, conf, corr, cnt, cs, rs):
        for i in range(self.nb):
            s = (conf > self.e[i]) & (conf <= self.e[i + 1])
            k = int(s.sum())
            if k:
                cnt[i] += k; cs[i] += conf[s].sum().item(); rs[i] += corr[s].sum().item()

    def update(self, logits, lab):
        prob = logits.softmax(1)
        pred = prob.argmax(1)
        conf = prob.max(1).values.flatten()
        corr = (pred == lab).float().flatten()
        self._bin(conf, corr, self.cnt, self.cs, self.rs)
        fm = (lab == 1).flatten()
        if fm.any():
            self._bin(conf[fm], corr[fm], self.fcnt, self.fcs, self.frs)
        p1 = prob[:, 1].flatten()
        y = (lab == 1).float().flatten()
        self.brier += ((p1 - y) ** 2).sum().item()
        self.nll += F.cross_entropy(logits, lab, reduction="sum").item()
        self.npx += y.numel()
        self.tp += int(((pred == 1) & (lab == 1)).sum())
        self.fp += int(((pred == 1) & (lab == 0)).sum())
        self.fn += int(((pred == 0) & (lab == 1)).sum())

    @staticmethod
    def _ece(cnt, cs, rs):
        tot = cnt.sum()
        if tot == 0:
            return float("nan")
        return float(((cnt / tot) * ((rs / cnt.clamp(min=1))
                                     - (cs / cnt.clamp(min=1))).abs()
                      ).nansum())

    def result(self):
        e = 1e-9
        return dict(ece=self._ece(self.cnt, self.cs, self.rs),
                    ece_fire=self._ece(self.fcnt, self.fcs, self.frs),
                    brier=self.brier / self.npx, nll=self.nll / self.npx,
                    iou=self.tp / (self.tp + self.fp + self.fn + e),
                    prec=self.tp / (self.tp + self.fp + e),
                    rec=self.tp / (self.tp + self.fn + e))


# ------------------------------------------------------------ calibrators
class GlobalT(torch.nn.Module):
    """One scalar. Accuracy-preserving."""
    def __init__(self):
        super().__init__(); self.logT = torch.nn.Parameter(torch.zeros(1))
    def apply(self, lg, ae=None, hz=None):
        return lg / self.logT.exp()
    def describe(self):
        return f"T = {float(self.logT.detach().exp()):.4f}"


class Platt(torch.nn.Module):
    """Scale AND offset on the logit difference: z' = a*(z1-z0) + b.

    Can correct the constant offset that class-weighted training introduces,
    which global temperature structurally cannot. NOT accuracy-preserving: b
    moves the decision boundary.
    """
    def __init__(self):
        super().__init__()
        self.a = torch.nn.Parameter(torch.ones(1))
        self.b = torch.nn.Parameter(torch.zeros(1))
    def apply(self, lg, ae=None, hz=None):
        d = lg[:, 1] - lg[:, 0]
        return torch.stack([torch.zeros_like(d), self.a * d + self.b], 1)
    def describe(self):
        return f"a = {float(self.a.detach()):.4f}, b = {float(self.b.detach()):+.4f}"


class AdaptiveT(torch.nn.Module):
    """T(x,y) = softplus(a*scene_aerosol + b*haze + c). Accuracy-preserving.

    Three parameters deliberately: a high-capacity calibrator on 504 patches
    would overfit. The claim is that a physically-motivated signal carries the
    information, not that a network can memorise scene3.
    """
    def __init__(self):
        super().__init__()
        self.a = torch.nn.Parameter(torch.zeros(1))
        self.b = torch.nn.Parameter(torch.zeros(1))
        self.c = torch.nn.Parameter(torch.full((1,), 0.5413))   # softplus ~ 1
    def temp(self, ae, hz):
        scene = ae.flatten(1).mean(1).view(-1, 1, 1, 1)
        return F.softplus(self.a * scene + self.b * hz + self.c).clamp(0.05, 10.)
    def apply(self, lg, ae=None, hz=None):
        return lg / self.temp(ae, hz)
    def describe(self):
        d = lambda p: float(p.detach())
        return (f"a(aerosol) = {d(self.a):+.4f}, b(haze) = {d(self.b):+.4f}, "
                f"c = {d(self.c):+.4f}")


def smooth(t):
    """Atmospheric conditions are spatially coherent, so T should be too."""
    return ((t[:, :, 1:, :] - t[:, :, :-1, :]).abs().mean()
            + (t[:, :, :, 1:] - t[:, :, :, :-1]).abs().mean())


def fit(model, data, iters=250, lam=0.1, lr=0.05):
    lg, lb, ae, hz = data
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    for i in range(iters):
        opt.zero_grad()
        loss = F.cross_entropy(model.apply(lg, ae, hz), lb)
        if isinstance(model, AdaptiveT):
            loss = loss + lam * smooth(model.temp(ae, hz))
        loss.backward(); opt.step()
        if (i + 1) % 50 == 0:
            print(f"    iter {i+1}/{iters}  loss {loss.item():.5f}", flush=True)
    return model


def evaluate(dump, model=None):
    m = Metrics()
    tmin, tmax, tsum, tn = 1e9, -1e9, 0.0, 0
    with torch.no_grad():
        for lg, lb, ae, hz in dump.chunks():
            if model is None:
                out = lg
            else:
                out = model.apply(lg, ae, hz)
                if isinstance(model, AdaptiveT):
                    t = model.temp(ae, hz)
                    tmin = min(tmin, float(t.min())); tmax = max(tmax, float(t.max()))
                    tsum += float(t.sum()); tn += t.numel()
            m.update(out, lb)
    r = m.result()
    if tn:
        r.update(t_min=tmin, t_max=tmax, t_mean=tsum / tn)
    return r


def main(val_path, test_path, n_fit=N_FIT):
    t0 = time.time()
    val, test = Dump(val_path), Dump(test_path)

    idx = np.sort(np.random.default_rng(0).choice(
        val.n, size=min(n_fit, val.n), replace=False))
    fit_data = val.take(idx)
    print(f"\nfitting on {len(idx)} of {val.n} val patches "
          f"({fit_data[0].shape[-1]}x{fit_data[0].shape[-2]} each)")
    print("  a handful of scalar parameters does not need every pixel; this is")
    print("  what made the previous version take an hour and 14 GB.\n")

    models = {}
    for name, cls in (("global T", GlobalT), ("Platt", Platt),
                      ("adaptive T", AdaptiveT)):
        print(f"  {name} ...", flush=True)
        models[name] = fit(cls(), fit_data)
        print(f"    -> {models[name].describe()}\n")
    del fit_data

    print("evaluating on TEST (scene4, the geographic shift split)", flush=True)
    rows = [("uncalibrated", evaluate(test, None))]
    for name, mdl in models.items():
        rows.append((name, evaluate(test, mdl)))

    hdr = (f"{'method':<14}{'ECE':>9}{'ECE(fire)':>11}{'Brier':>10}{'NLL':>9}"
           f"{'IoU':>8}{'prec':>7}{'rec':>7}")
    print("\n" + hdr); print("-" * len(hdr))
    for name, r in rows:
        print(f"{name:<14}{r['ece']:>9.5f}{r['ece_fire']:>11.5f}"
              f"{r['brier']:>10.5f}{r['nll']:>9.5f}{r['iou']:>8.4f}"
              f"{r['prec']:>7.3f}{r['rec']:>7.3f}")

    base_iou = rows[0][1]["iou"]
    print()
    for name, r in rows[1:]:
        same = abs(r["iou"] - base_iou) < 1e-9
        note = "accuracy preserved" if same else \
               f"accuracy CHANGED ({r['iou']-base_iou:+.5f} IoU) -- expected for Platt"
        print(f"  {name:<14}{note}")

    ad = rows[-1][1]
    if "t_min" in ad:
        print(f"\nadaptive T on test: [{ad['t_min']:.4f}, {ad['t_max']:.4f}] "
              f"mean {ad['t_mean']:.4f}")
        if ad["t_max"] - ad["t_min"] < 1e-3:
            print("  WARNING T is effectively constant -> adaptivity did nothing.")

    print("\nerror-detection AUROC on test (higher is better):")
    # RANDOM patches, not the first N. Taking a contiguous slice samples one
    # corner of the study area and can badly misrepresent the split.
    apick = np.sort(np.random.default_rng(1).choice(
        test.n, size=min(64, test.n), replace=False))
    lg, lb, _, _ = test.take(apick)
    prob = lg.softmax(1)
    err = (prob.argmax(1) != lb).float().flatten()
    scores = {"1 - MSP": (1 - prob.max(1).values).flatten(),
              "entropy": (-(prob * prob.clamp_min(1e-9).log()).sum(1)).flatten(),
              "-energy": (-torch.logsumexp(lg, 1)).flatten(),
              "-|margin|": (-(lg[:, 1] - lg[:, 0]).abs()).flatten()}
    g = torch.Generator().manual_seed(0)
    sub = torch.randperm(err.numel(), generator=g)[:1_500_000]
    e_s, t_s = err[sub].double(), None
    for k, v in scores.items():
        s = v[sub].double()
        npos, nneg = e_s.sum().item(), (1 - e_s).sum().item()
        if npos == 0 or nneg == 0:
            print(f"  {k:<12}n/a"); continue
        order = torch.argsort(s)
        ranks = torch.empty_like(s); ranks[order] = torch.arange(1, s.numel()+1,
                                                                dtype=torch.double)
        auc = (ranks[e_s == 1].sum().item() - npos*(npos+1)/2) / (npos*nneg)
        print(f"  {k:<12}{auc:.4f}")
    print("  MSP, entropy and margin tie by necessity: with two classes each is")
    print("  a monotone function of the same logit gap, and monotone transforms")
    print("  cannot change a ranking. Energy differs because it reads absolute")
    print("  logit magnitude -- the channel a single sigmoid logit lacks.")
    print(f"\ndone in {time.time()-t0:.1f}s")


if __name__ == "__main__":
    if len(sys.argv) not in (3, 4):
        print(__doc__); sys.exit(1)
    main(sys.argv[1], sys.argv[2],
         int(sys.argv[3]) if len(sys.argv) == 4 else N_FIT)
