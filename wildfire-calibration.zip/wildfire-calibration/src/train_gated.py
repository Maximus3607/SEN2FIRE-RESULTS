r"""
MODEL B: U-Net trained with the gated-null readout.

Identical to train_sen2fire_softmax.py in every respect -- architecture, data,
split, optimiser, augmentation, schedule -- except for the readout and the
second loss term. That is what makes the two-model comparison causal: the only
manipulated variable is whether the training objective supervises the logit sum.

WHAT MODEL A ESTABLISHED

  ECE(fire) 0.691 vs ECE(background) 0.023, opposite signs, so one global
  temperature is structurally disqualified. Label noise explains ~0%, prior
  shift 5%, the readout 95%.

  gap and |z0|+|z1| agreed to four significant figures -> z1 = -z0. Cause:
  softmax is invariant to adding a constant to both logits, so cross-entropy
  gives EXACTLY zero gradient along (z0+z1); weight decay is the only force
  there and pulls it to zero. Two logits, one number.

  Four post-hoc readouts failed identically because they were four rescalings
  of that number. Isotonic -- the optimal monotone map of it -- also failed,
  making ECE(fire) worse (0.765 vs 0.686) while improving the aggregate.

  Six signals topped out near AUROC 0.63 on the population that drives
  ECE(fire). A supervised error head reached 0.85 within-region but 0.71
  across, and 0.54-0.62 on that population.

WHAT THIS RUN TESTS

  Whether breaking the antisymmetry at TRAINING time gives the readout a second
  degree of freedom it can use. Verified in autograd: the sum-direction
  gradient goes from 5.7e-11 (plain CE, numerically zero) to 2.4e-03.

REQUIRED SETUP, all of which the audits showed is load-bearing:
  - gate params in their own optimiser group: weight_decay=0 (decaying them is
    the same trap that collapsed the logit sum) and lr=1e-2 (four scalars among
    31M parameters barely move at 3e-4)
  - set_tau_from_data() after the CE-only warmup, at the 25th LSE percentile
  - refresh_bounds() every few epochs; a stale clamp strands tau
  - IoU watched against model A's 0.1997: CE and BCE are in tension, and one
    way to predict errors well is to make more of them

Kaggle: attach Sen2Fire. GPU T4. ~8h for 65 epochs.
"""

import glob, json, math, os, time
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from readout_core import GatedNullReadout, GatedNullLoss


class CFG:
    data_root = "/kaggle/input"
    out_dir   = "/kaggle/working"
    splits    = {"train": ["scene1", "scene2"], "val": ["scene3"], "test": ["scene4"]}
    band_idx  = [3, 2, 1, 7, 10, 11]
    in_ch, out_ch, base = 6, 2, 64
    # --- identical to model A ---
    epochs      = 55      # matched to the completed model-B run
    # ---- the two settings to change between runs ----
    seed        = 1       # training randomness: init, batch order, augmentation.
                          # The holdout split and normalisation stats stay FIXED
                          # (seeded separately below), so every run trains on the
                          # identical 1,313 patches.
    # nu_target below: 0.5 = MODEL B.  0.0 = MODEL A, MATCHED -- plain
    # cross-entropy through this exact pipeline, so A and B differ in the
    # auxiliary loss term and nothing else.
    batch       = 4
    lr          = 3e-4
    weight_decay= 1e-4
    warmup_steps= 300
    class_weight= [1.0, 5.0]
    fire_ratio  = 0.3
    workers     = 2
    # --- new ---
    gate_lr     = 1e-2      # four scalars need their own, larger step
    nu_target   = 0.5       # weight on the BCE term
    warmup_ep   = 3         # epochs of CE only, before the gate switches on
    ramp_ep     = 3         # epochs to ramp nu from 0 to nu_target
    w_miss      = 12.0      # a missed fire is the failure that matters
    w_fa        = 3.0       # a false alarm is wrong but cheaper
    refresh_ev  = 4         # re-measure the LSE range every N epochs
    holdout_frac= 0.10      # within-scene holdout: separates MEMORISATION from
                            # geographic shift, which the scene1-3 gap cannot

DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT = Path(CFG.out_dir); OUT.mkdir(parents=True, exist_ok=True)
torch.manual_seed(CFG.seed); np.random.seed(CFG.seed)
print("device:", DEV, flush=True)
print(f"RUN: {'MODEL B (auxiliary loss on)' if CFG.nu_target > 0 else 'MODEL A, MATCHED (plain cross-entropy)'}"
      f"   seed {CFG.seed}   nu_target {CFG.nu_target}   epochs {CFG.epochs}", flush=True)


# ------------------------------------------------------------------- model
class DoubleConv(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ci, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True),
            nn.Conv2d(co, co, 3, padding=1, bias=False), nn.BatchNorm2d(co), nn.ReLU(True))
    def forward(self, x): return self.block(x)

class Down(nn.Module):
    def __init__(self, ci, co):
        super().__init__(); self.pool = nn.MaxPool2d(2); self.conv = DoubleConv(ci, co)
    def forward(self, x): return self.conv(self.pool(x))

class Up(nn.Module):
    def __init__(self, ci, co):
        super().__init__()
        self.up = nn.ConvTranspose2d(ci, co, 2, stride=2); self.conv = DoubleConv(co*2, co)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            dy = skip.size(-2)-x.size(-2); dx = skip.size(-1)-x.size(-1)
            x = F.pad(x, [dx//2, dx-dx//2, dy//2, dy-dy//2])
        return self.conv(torch.cat([skip, x], 1))

class UNet(nn.Module):
    def __init__(self, in_ch=6, out_ch=2, base=64):
        super().__init__(); b = base
        self.inc = DoubleConv(in_ch, b)
        self.d1, self.d2 = Down(b, b*2), Down(b*2, b*4)
        self.d3, self.d4 = Down(b*4, b*8), Down(b*8, b*16)
        self.u1, self.u2 = Up(b*16, b*8), Up(b*8, b*4)
        self.u3, self.u4 = Up(b*4, b*2), Up(b*2, b)
        self.out = nn.Conv2d(b, out_ch, 1)
    def forward(self, x):
        s1 = self.inc(x); s2 = self.d1(s1); s3 = self.d2(s2); s4 = self.d3(s3)
        x = self.d4(s4)
        x = self.u1(x, s4); x = self.u2(x, s3); x = self.u3(x, s2); x = self.u4(x, s1)
        return self.out(x)


# -------------------------------------------------------------------- data
def find(root, tags):
    return [f for f in sorted(glob.glob(str(Path(root)/"**"/"*.npz"), recursive=True))
            if {p.lower() for p in Path(f).parts[:-1]} & set(tags)]

class Patches(Dataset):
    def __init__(self, files, mean, std, scale, augment=False, seed=0):
        self.files, self.mean, self.std, self.scale = files, mean, std, scale
        self.augment, self.rng = augment, np.random.default_rng(seed)
    def __len__(self): return len(self.files)
    def raw(self, i):
        with np.load(self.files[i], allow_pickle=True) as z:
            ks = list(z.keys())
            ik = next((k for k in ("image","img","data","x") if k in ks), ks[0])
            lk = next((k for k in ("label","mask","gt","y") if k in ks), ks[-1])
            img = np.asarray(z[ik], dtype=np.float32); lab = np.asarray(z[lk])
        if img.ndim == 3 and img.shape[2] < img.shape[0]:
            img = np.transpose(img, (2,0,1))
        if lab.ndim == 3: lab = lab[0]
        return np.nan_to_num(img[CFG.band_idx])*self.scale, (lab>0).astype(np.int64)
    def __getitem__(self, i):
        img, lab = self.raw(i)
        if self.augment:
            r = self.rng
            if r.random() < .5: img, lab = img[:,:,::-1], lab[:,::-1]
            if r.random() < .5: img, lab = img[:,::-1], lab[::-1]
        x = (img - self.mean[:,None,None]) / (self.std[:,None,None] + 1e-6)
        t = lambda a: torch.from_numpy(np.ascontiguousarray(a))
        return t(x), t(lab)


def norm_stats(files, scale, n=300):
    idx = np.random.default_rng(0).choice(len(files), min(n,len(files)), replace=False)
    ds = Patches([files[i] for i in idx], np.zeros(6,np.float32),
                 np.ones(6,np.float32), scale)
    S = np.stack([ds.raw(i)[0] for i in range(len(ds))])
    return S.mean((0,2,3)).astype(np.float32), S.std((0,2,3)).astype(np.float32)


@torch.no_grad()
def counts(lg, y):
    p = lg.argmax(1)
    return (float(((p==1)&(y==1)).sum()), float(((p==1)&(y==0)).sum()),
            float(((p==0)&(y==1)).sum()))


@torch.no_grad()
def evaluate(model, readout, dl):
    """IoU / P / R, plus the diagnostics that tell you the gate is alive."""
    model.eval()
    tp=fp=fn=0.0; nll=0.0; nb=0
    pe_sum=pe_err=n_err=0.0; npx=0
    sum_abs=gap_s=0.0
    for x, y in dl:
        x, y = x.to(DEV), y.to(DEV)
        lg = model(x)
        a,b,c = counts(lg,y); tp+=a; fp+=b; fn+=c
        nll += F.cross_entropy(lg, y).item(); nb += 1
        _,_,pe = readout(lg)
        wrong = (lg.argmax(1) != y)
        pe_sum += float(pe.sum()); npx += pe.numel()
        if wrong.any():
            pe_err += float(pe[wrong].sum()); n_err += float(wrong.sum())
        # mean |z0+z1| is ZERO under antisymmetry regardless of the gap, so it
        # is a clean test. The earlier |gap - 2 LSE| was not: it equals
        # 2 log(1 + e^-gap) even for perfectly antisymmetric logits, which is
        # 1.39 at gap 0, so near-boundary pixels inflated it spuriously.
        sum_abs += float((lg[:,0]+lg[:,1]).abs().mean())
        gap_s += float((lg[:,1]-lg[:,0]).abs().mean())
    e = 1e-9
    return dict(iou=tp/(tp+fp+fn+e), prec=tp/(tp+fp+e), rec=tp/(tp+fn+e),
                nll=nll/max(nb,1), pe_all=pe_sum/max(npx,1),
                pe_err=pe_err/max(n_err,1) if n_err else float("nan"),
                gap=gap_s/max(nb,1), sum_abs=sum_abs/max(nb,1))


def main():
    files = {s: find(CFG.data_root, t) for s, t in CFG.splits.items()}
    assert files["train"], "no training patches found"

    # within-scene holdout: model A could not separate memorisation from
    # geographic shift, because train and val were different REGIONS
    rng = np.random.default_rng(0)      # FIXED across seeds: same holdout every run
    perm = rng.permutation(len(files["train"]))
    n_hold = int(CFG.holdout_frac * len(perm))
    hold = [files["train"][i] for i in perm[:n_hold]]
    train = [files["train"][i] for i in perm[n_hold:]]
    print(f"train {len(train)} | within-scene holdout {len(hold)} | "
          f"val {len(files['val'])} | test {len(files['test'])}")

    probe = Patches(train[:1], np.zeros(6,np.float32), np.ones(6,np.float32), 1.0)
    raw,_ = probe.raw(0)
    SCALE = 1e-4 if raw.max() > 100 else 1.0
    MEAN, STD = norm_stats(train, SCALE)
    np.savez(OUT/"norm_stats.npz", mean=MEAN, std=STD, scale=SCALE)
    print(f"scale {SCALE:g}  mean {np.round(MEAN,4)}")

    mk = lambda f, aug=False, sh=False: DataLoader(
        Patches(f, MEAN, STD, SCALE, augment=aug, seed=CFG.seed), batch_size=CFG.batch,
        shuffle=sh, drop_last=sh, num_workers=CFG.workers,
        pin_memory=(DEV=="cuda"))
    train_dl = mk(train, aug=True, sh=True)
    hold_dl, val_dl = mk(hold), mk(files["val"])

    model   = UNet(CFG.in_ch, CFG.out_ch, CFG.base).to(DEV)
    readout = GatedNullReadout().to(DEV)
    crit    = GatedNullLoss(CFG.class_weight, CFG.w_miss, CFG.w_fa,
                            CFG.nu_target, CFG.warmup_ep, CFG.ramp_ep).to(DEV)

    # TWO PARAMETER GROUPS. The gate scalars get no weight decay -- decaying
    # them toward zero is precisely the mechanism that collapsed the logit sum
    # in model A -- and a much larger lr, since four scalars among 31M
    # parameters would otherwise barely move.
    opt = torch.optim.AdamW([
        {"params": model.parameters(), "lr": CFG.lr, "weight_decay": CFG.weight_decay},
        {"params": readout.gate_params(), "lr": CFG.gate_lr, "weight_decay": 0.0},
    ])
    steps = CFG.epochs * len(train_dl)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1.0, (s+1)/CFG.warmup_steps)
                       * 0.5*(1+math.cos(math.pi*min(s/steps,1.0))))

    print(f"params: unet {sum(p.numel() for p in model.parameters()):,} "
          f"+ gate {sum(p.numel() for p in readout.gate_params())}")
    print(f"nu: 0 for epochs 1-{CFG.warmup_ep}, ramping to {CFG.nu_target} "
          f"by epoch {CFG.warmup_ep+CFG.ramp_ep}\n", flush=True)

    hist, best = [], -1.0
    for ep in range(1, CFG.epochs+1):
        t0 = time.time(); model.train()
        tl = tce = tb = 0.0; nb = 0
        for x, y in train_dl:
            x, y = x.to(DEV), y.to(DEV)
            lg = model(x)
            L, ce, b, nu = crit(lg, y, readout, ep)
            if not torch.isfinite(L):
                continue
            opt.zero_grad(set_to_none=True); L.backward()
            torch.nn.utils.clip_grad_norm_(
                list(model.parameters())+readout.gate_params(), 1.0)
            opt.step(); sched.step()
            tl += float(L.detach()); tce += ce; tb += b; nb += 1

        # tau cannot be placed before logits exist, and the LSE distribution
        # here differs from model A's (median ~2.1) because the loss differs
        if ep == CFG.warmup_ep:
            model.eval()
            with torch.no_grad():
                probe_lg = [model(x.to(DEV)) for i,(x,_) in enumerate(val_dl) if i < 8]
            lo, t0_, hi = readout.set_tau_from_data(probe_lg)
            print(f"  tau placed: 5% {lo:.3f}  25% {t0_:.3f}  95% {hi:.3f}", flush=True)

        # a stale clamp strands tau: LSE drifts during training (that is the
        # point), and if the bounds do not follow, the gate can be pinned shut
        if ep > CFG.warmup_ep and ep % CFG.refresh_ev == 0:
            model.eval()
            with torch.no_grad():
                probe_lg = [model(x.to(DEV)) for i,(x,_) in enumerate(val_dl) if i < 8]
            lo, md, hi, edge = readout.refresh_bounds(probe_lg)
            if edge:
                print(f"  WARNING tau at its clamp edge [{lo:.2f},{hi:.2f}] -- "
                      f"the optimiser wants to go further and cannot", flush=True)

        v = evaluate(model, readout, val_dl)
        h = evaluate(model, readout, hold_dl) if hold else None
        flag = ""
        if v["iou"] > best:
            best, flag = v["iou"], "  *"
            torch.save(dict(model=model.state_dict(), readout=readout.state_dict(),
                            epoch=ep, best=best, seed=CFG.seed,
                            nu_target=CFG.nu_target), OUT/"best.pt")
        rec = dict(epoch=ep, loss=tl/max(nb,1), ce=tce/max(nb,1), bce=tb/max(nb,1),
                   nu=crit.nu(ep), val_iou=v["iou"], val_rec=v["rec"],
                   val_nll=v["nll"], pe_all=v["pe_all"], pe_err=v["pe_err"],
                   gap=v["gap"], sum_abs=v["sum_abs"],
                   hold_iou=h["iou"] if h else None)
        hist.append(rec)
        (OUT/"history.json").write_text(json.dumps(hist, indent=2))

        # |z0+z1| is the antisymmetry test: exactly 0 when z1 = -z0
        print(f"ep {ep:3d} | L {tl/max(nb,1):.4f} ce {tce/max(nb,1):.4f} "
              f"bce {tb/max(nb,1):.4f} nu {crit.nu(ep):.2f} | "
              f"val IoU {v['iou']:.4f} R {v['rec']:.3f} nll {v['nll']:.4f}"
              + (f" | hold IoU {h['iou']:.4f}" if h else "")
              + f" | p(0) all {v['pe_all']:.4f} err {v['pe_err']:.4f}"
              f" | |z0+z1| {v['sum_abs']:.3f} gap {v['gap']:.3f}"
              f" | {(time.time()-t0)/60:.1f}m{flag}",
              flush=True)
        if ep % 5 == 0:
            print(f"      {readout.describe()}", flush=True)

    print(f"\ndone. best val IoU {best:.4f}")
    print("\nWHAT TO CHECK")
    print("  |z0+z1| near 0 means the logits are still antisymmetric and the")
    print("  intervention failed. Growing means the second degree of freedom")
    print("  exists. Model A sat at 0 by construction.")
    print("  p(0) err should exceed p(0) all -- abstention landing on errors")
    print("  rather than everywhere. Equal means uniform softening, which is")
    print("  temperature scaling renamed, and is how SAEA failed (1.36:1).")
    print("  val IoU vs hold IoU separates MEMORISATION from geographic shift;")
    print("  model A could not, because its train and val were different regions.")
    print("  val IoU below model A's 0.2864 means nu is too high: CE and BCE")
    print("  are in tension, and predicting errors well is easier if you make")
    print("  more of them.")


if __name__ == "__main__":
    t = time.time(); main(); print(f"\ntotal {(time.time()-t)/60:.1f}m")
