r"""
Plot the paper's 8 figures and render its 4 tables (PNG, 300 dpi) from paper_figures/*.csv
and csv/tidy/. Nothing is computed here except table layout: every value is read from the files.

    python scripts/plot_paper_figures.py      -> paper_figures/plots/
"""
import csv
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator

ROOT = Path(__file__).resolve().parent.parent
PF, TIDY = ROOT / "paper_figures", ROOT / "csv" / "tidy"
OUT = PF / "plots"; OUT.mkdir(exist_ok=True)

# validated categorical palette (light), fixed order; text never wears series colour
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
MK = ["o", "s", "^", "D", "v", "P", "X"]
READOUTS = ["Softmax", "Temperature scaling", "Class-conditional temperature", "Platt scaling",
            "Beta calibration", "Isotonic regression", "Height gate"]
RC = {r: (C[i], MK[i]) for i, r in enumerate(READOUTS)}          # colour follows the readout in every figure

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.titlesize": 10.5, "axes.titleweight": "bold",
                     "axes.titlecolor": INK, "legend.frameon": False, "savefig.dpi": 300, "figure.dpi": 100})
B = "Haze strength β₀"


def rd(name):
    f = next(PF.glob(name + "*.csv"))
    rows = list(csv.reader(open(f)))
    return rows[0], rows[1:]


def ax_style(ax, grid="both"):
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    ax.grid(True, axis=grid, color=GRID, lw=0.6); ax.set_axisbelow(True)


def save(fig, name):
    fig.savefig(OUT / f"{name}.png", bbox_inches="tight", facecolor="white"); plt.close(fig); print("  ", name)


def lines_vs_haze(name, title, xlabel, header, body, colours, markers, betas_ticks, xlim=None, legend_title=None):
    """x = metric, y = beta0 (as requested): one line per column."""
    fig, ax = plt.subplots(figsize=(6.6, 4.2))
    ys = [float(r[0]) for r in body]
    for j, lab in enumerate(header[1:], 1):
        pts = [(float(r[j]), y) for r, y in zip(body, ys) if r[j] != ""]
        ax.plot([p[0] for p in pts], [p[1] for p in pts], color=colours[j - 1], marker=markers[j - 1], ms=5, lw=1.6,
                label=lab, mec="white", mew=0.6)
    ax.set_xlabel(xlabel); ax.set_ylabel(B); ax.set_title(title, loc="left")
    ax.yaxis.set_major_locator(FixedLocator(betas_ticks))
    if xlim: ax.set_xlim(*xlim)
    ax_style(ax)
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), title=legend_title, fontsize=8.5, title_fontsize=8.5)
    save(fig, name)


def table_png(name, title, header, rows, col_w=None, note=None):
    n = len(rows)
    W = 1.2 + 1.05 * len(header)
    if col_w:  # widths are relative: scale the figure to them and normalise so the table fills the axes exactly
        W *= sum(col_w) / (len(header) / len(header)) if sum(col_w) > 1 else 1
        col_w = [w / sum(col_w) for w in col_w]
    fig, ax = plt.subplots(figsize=(W, 0.45 + 0.26 * (n + 1)))
    ax.set_position([0.0, 0.0, 1.0, 0.92]); ax.axis("off")
    t = ax.table(cellText=rows, colLabels=header, loc="upper left", cellLoc="center", colLoc="center",
                 colWidths=col_w)
    t.auto_set_font_size(False); t.set_fontsize(8.5); t.scale(1, 1.35)
    for (r, c), cell in t.get_celld().items():
        cell.set_edgecolor(GRID); cell.set_linewidth(0.6)
        if r == 0:
            cell.set_text_props(weight="bold", color=INK, wrap=True); cell.set_facecolor("#f1f0ec"); cell.set_height(cell.get_height() * 1.9)
        else:
            cell.set_facecolor("white" if r % 2 else "#fafaf8")
        if c == 0 and r > 0: cell.set_text_props(ha="left"); cell._loc = "left"
    ax.set_title(title, loc="left", pad=6)
    if note: fig.text(0.01, 0.0, note, fontsize=7.5, color=INK2, va="top", wrap=True)
    save(fig, name)


def f3(v):
    return "" if v in ("", None) else f"{float(v):.3f}"


def main():
    # ---------------- Figure 1
    h, b = rd("Figure_1")
    fig, ax = plt.subplots(figsize=(6.6, 4.0))
    x = [float(r[0]) for r in b]
    for j, (lab, col, mk) in enumerate([(h[1], C[0], "o"), (h[2], C[1], "s")], 1):
        y = [float(r[j]) for r in b]
        ax.plot(x, y, color=col, marker=mk, ms=5, lw=1.6, label=lab, mec="white", mew=0.6)
    ax.set_xlabel(B); ax.set_ylabel("Probability (0–1)"); ax.set_ylim(0, 1.02); ax.set_xlim(-0.05, 2.0)
    ax.set_title("Fig 1. Confidence vs accuracy on fire pixels under haze (model A, MODIS labels, scene 4)", loc="left")
    ax_style(ax); ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), fontsize=8.5, frameon=False)
    save(fig, "Figure_1_confidence_vs_accuracy")

    # ---------------- Figure 2  (x = true-fire ECE, y = beta0)
    h, b = rd("Figure_2")
    drop = h.index("SAEA v1")  # paper reports only the final SAEA (v2)
    h = ["SAEA" if c == "SAEA v2" else c for i, c in enumerate(h) if i != drop]
    b = [[v for i, v in enumerate(r) if i != drop] for r in b]
    lines_vs_haze("Figure_2_true_fire_ECE_calibrators_and_SAEA",
                  "Fig 2. True-fire ECE of standard calibrators and SAEA under haze (model A, MODIS labels, scene 4)",
                  "True-fire ECE (lower = better)", h, b, C[:4] + [C[5]], MK[:4] + [MK[5]], [0, 0.2, 0.5], legend_title="Readout")

    # ---------------- Figure 3
    h, b = rd("Figure_3")
    fig, ax = plt.subplots(figsize=(6.6, 4.0))
    cats = [r[0] for r in b]; w = 0.36
    for j, col in ((1, C[0]), (2, C[1])):
        xs = [i + (j - 1.5) * (w + 0.02) for i in range(len(cats))]
        ax.bar(xs, [float(r[j]) for r in b], width=w, color=col, label=h[j], edgecolor="white", linewidth=1)
    ax.set_xticks(range(len(cats)), cats); ax.set_xlabel("Pixel type"); ax.set_ylabel("Mean P(abstain)")
    ax.set_ylim(0, 1); ax.set_title("Fig 3. Where model B's trained gate abstains (scene 3, clear)", loc="left")
    ax_style(ax, "y"); ax.legend(loc="upper right", fontsize=8.5)
    save(fig, "Figure_3_trained_gate_abstention")

    # ---------------- Figure 4
    h, b = rd("Figure_4")
    fig, ax = plt.subplots(figsize=(7.4, 4.3))
    cats = [r[0].replace(" (learned from decoder features)", "") for r in b]; w = 0.38
    for j, col in ((1, C[0]), (2, C[1])):
        xs = [i + (j - 1.5) * (w + 0.02) for i in range(len(cats))]
        ax.bar(xs, [float(r[j]) for r in b], width=w, color=col, label=h[j], edgecolor="white", linewidth=1)
    ax.set_xticks(range(len(cats)), cats, rotation=35, ha="right"); ax.set_ylim(0, 1)
    ax.set_xlabel("Readout"); ax.set_ylabel("Error-detection AUROC (0.5 = chance)")
    ax.set_title("Fig 4. Error-detection AUROC: every readout vs the evidence head (model A, MODIS labels)", loc="left")
    ax_style(ax, "y"); ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=8.5)
    save(fig, "Figure_4_error_detection_AUROC")

    # ---------------- Figure 5a / 5b  (x = IoU, y = beta0)
    h, b = rd("Figure_5")
    for tag, alpha, idx in (("a", "aerosol haze (α = 1.3)", (2, 3, 1)), ("b", "grey haze (α = 0)", (5, 6, 4))):
        hh = [h[0]] + [h[i].replace(", aerosol haze", "").replace(", grey haze", "") for i in idx]
        bb = [[r[0]] + [r[i] for i in idx] for r in b]
        lines_vs_haze(f"Figure_5{tag}_IoU_network_vs_SWIR_rule_{'aerosol' if tag == 'a' else 'grey'}",
                      f"Fig 5{tag}. IoU of agreement-label networks vs their SWIR rule, {alpha}, scene 4",
                      "IoU (higher = better)", hh, bb, [C[0], C[1], C[2]], ["o", "s", "^"], [0, 0.5, 1, 1.5, 2, 3, 4],
                      xlim=(-0.02, 1.02))

    # ---------------- Figure 6  (x = confidence on missed fire, y = beta0)
    h, b = rd("Figure_6")
    lines_vs_haze("Figure_7_confidence_on_missed_fire",
                  "Fig 7. Confidence on missed fire, every readout (aerosol haze, scene 4, seed 1)",
                  "Mean confidence on missed fire (lower = better)", h, b,
                  [RC[r][0] for r in h[1:]], [RC[r][1] for r in h[1:]], [1, 2, 3, 4], xlim=(0, 1), legend_title="Readout")

    # ---------------- Figure 7  (log y, bars per network, scene 3 vs scene 4)
    h, b = rd("Figure_7")
    nets = ["Model A seed 1", "Model A seed 2", "Model B seed 1", "Model B seed 2", "Agreement seed 1", "Agreement seed 2"]
    def key(lbl):
        s = lbl.replace("MODIS labels: ", "").replace("Agreement labels: seed", "Agreement seed")
        net = s.split(",")[0].strip(); sc = "Scene 3" if "scene 3" in lbl else "Scene 4"
        return net, sc
    V = {key(r[0]): float(r[1]) for r in b}
    fig, ax = plt.subplots(figsize=(7.4, 4.3)); w = 0.38
    for j, (sc, col) in enumerate((("Scene 3", C[0]), ("Scene 4", C[1]))):
        xs = [i + (j - 0.5) * (w + 0.02) for i in range(len(nets))]
        vals = [V[(n, sc)] for n in nets]
        ax.bar(xs, vals, width=w, color=col, label=sc + (" (clear)" if sc == "Scene 3" else " (new region)"),
               edgecolor="white", linewidth=1)
        for x_, v in zip(xs, vals):
            ax.annotate(f"{v:,.1f}" if v < 100 else f"{v:,.0f}", (x_, v), xytext=(0, 2), textcoords="offset points",
                        ha="center", va="bottom", fontsize=7, color=INK2)
    ax.set_yscale("log"); ax.set_ylim(0.8, 30000)
    ax.set_xticks(range(len(nets)), ["Model A\nseed 1", "Model A\nseed 2", "Model B\nseed 1", "Model B\nseed 2",
                                     "Agreement\nseed 1", "Agreement\nseed 2"])
    ax.axvline(3.5, color=GRID, lw=1)
    ax.text(1.5, 14000, "MODIS-label models", ha="center", color=INK2, fontsize=8.5)
    ax.text(4.5, 14000, "Agreement-label models (β₀ = 4)", ha="center", color=INK2, fontsize=8.5)
    ax.set_ylabel("Height-gate selectivity (log scale)")
    ax.set_title("Fig 6. Height-gate selectivity: MODIS-label vs agreement-label models", loc="left")
    ax_style(ax, "y"); ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=8.5)
    save(fig, "Figure_6_height_gate_selectivity")

    # ---------------- Figure 8  (x = true-fire ECE, y = beta0 0..4)
    h, b = rd("Figure_8")
    lines_vs_haze("Figure_8_true_fire_ECE_vs_haze_every_readout",
                  "Fig 8. Haze dose response of every readout (aerosol haze, scene 4, seed 1)",
                  "True-fire ECE (lower = better)", h, b, [RC[r][0] for r in h[1:]], [RC[r][1] for r in h[1:]],
                  [0, 1, 2, 3, 4], legend_title="Readout")

    # ---------------- Table 1: every readout, scene 3 and scene 4 (TF-ECE, PF-ECE, IoU)
    L = {}
    for r in csv.DictReader(open(ROOT / "results/final_tests/1a_readouts_all_metrics.csv")):
        if r["model"] == "A_s0": L[(r["condition"], r["readout"], r["metric"])] = r["value"]
    order = [("softmax", "Softmax"), ("temperature", "Temperature scaling"), ("class-cond T", "Class-conditional temperature"),
             ("Platt", "Platt scaling"), ("beta", "Beta calibration"), ("isotonic", "Isotonic regression"),
             ("SAEA", "SAEA"), ("evidence null", "Evidence null"), ("height gate", "Height gate")]
    hdr = ["Readout", "True-fire\nECE (scene 3)", "Predicted-fire\nECE (scene 3)", "IoU\n(scene 3)",
           "True-fire\nECE (scene 4)", "Predicted-fire\nECE (scene 4)", "IoU\n(scene 4)"]
    rows = [[lab] + [f3(L[(c, k, m)]) for c in ("scene3 b0=0.0", "scene4 natural")
                     for m in ("ECE fire (true)", "ECE fire (pred)", "IoU")] for k, lab in order]
    with open(PF / "Table_1_every_readout_scene3_scene4.csv", "w", newline="") as fh:
        w_ = csv.writer(fh); w_.writerow([x.replace("\n", " ") for x in hdr]); w_.writerows(rows)
    table_png("Table_1_every_readout_MODIS_labels", "Table 1. Every readout on model A (seed 1, MODIS labels)", hdr, rows,
              col_w=[0.30] + [0.13] * 6, note="Scene 3: clear, held-out half. Scene 4: new region, natural conditions.")

    # ---------------- Table 2: IoU / precision / recall, MODIS-label model vs agreement-label models (clear, beta0 = 0)
    sw = {r["scene"]: r for r in csv.DictReader(open(TIDY / "haze_sweep_all_scenes_modelA.csv")) if float(r["beta0"]) == 0}
    ep = {(r["labels"], r["scene"], r["seed"]): r for r in csv.DictReader(open(TIDY / "every_pixel_summary_by_label_version.csv"))
          if float(r["beta0"]) == 0 and r["alpha"] == "1.3"}
    hdr2 = ["Model (trained on)", "Scored against", "IoU\n(scene 3)", "Precision\n(scene 3)", "Recall\n(scene 3)",
            "IoU\n(scene 4)", "Precision\n(scene 4)", "Recall\n(scene 4)"]
    rows2 = [["Model A seed 1 (MODIS labels)", "MODIS labels"] + [f3(sw[s][k]) for s in ("scene3", "scene4") for k in ("iou", "precision", "recall")]]
    for lab, truth in (("agreement", "Agreement labels"), ("visible", "Visible fire (every pixel)"), ("modis", "MODIS labels")):
        for sd in ("0", "1"):
            rows2.append([f"Agreement seed {int(sd) + 1} (agreement labels)", truth] +
                         [f3(ep[(lab, s, sd)][k]) for s in ("scene3", "scene4") for k in ("iou", "precision", "recall")])
    with open(PF / "Table_2_IoU_precision_recall_MODIS_vs_agreement.csv", "w", newline="") as fh:
        w_ = csv.writer(fh); w_.writerow([x.replace("\n", " ") for x in hdr2]); w_.writerows(rows2)
    table_png("Table_2_IoU_precision_recall_MODIS_vs_agreement",
              "Table 2. IoU, precision and recall: MODIS-label model vs agreement-label models (no haze)", hdr2, rows2,
              col_w=[0.36, 0.25] + [0.10] * 6,
              note="Precision and recall were recorded for model A seed 1 only among the MODIS-label models.")

    # ---------------- Table 3: pixel-by-pixel test, every readout at aerosol beta0 = 4, scene 4, both seeds
    h3, b3 = rd("Table_3_pixel_by_pixel_test_beta4_scene4")
    keep = ["Readout", "Seed", "True-fire ECE", "Fire Brier", "Fire NLL", "Confidence Brier", "IoU", "Confidence on missed fire"]
    hdr3 = ["Readout", "Seed", "True-fire\nECE", "Fire\nBrier", "Fire\nNLL", "Confidence\nBrier", "IoU", "Confidence on\nmissed fire"]
    rows3 = []
    for i, r in enumerate(b3):
        v = dict(zip(h3, r))
        rows3.append([v["Readout"] if i % 2 == 0 else "", v["Seed"]] +
                     [f"{float(v[k]):.6f}" if k == "Confidence Brier" else f3(v[k]) for k in keep[2:]])
    table_png("Table_3_every_readout_aerosol_beta4_scene4",
              "Table 3. Every readout under heavy aerosol haze (β₀ = 4, α = 1.3), scene 4, agreement-label networks", hdr3, rows3,
              col_w=[0.30, 0.07, 0.10, 0.09, 0.09, 0.13, 0.08, 0.14],
              note="Every pixel scored against visible fire. Seeds 1 and 2 are the two agreement-label networks.")

    # ---------------- Table 4: grey haze (alpha = 0), beta0 = 0, 1, 2, every readout, seed 1
    E = {(r["scene"], float(r["beta0"]), r["metric"], r["readout"]): r["value"]
         for r in csv.DictReader(open(TIDY / "every_pixel_scores.csv"))
         if r["labels"] == "visible" and r["alpha"] == "0.0" and r["seed"] == "0"}
    tidy_name = {"Softmax": "softmax", "Temperature scaling": "temperature", "Class-conditional temperature": "class-cond T",
                 "Platt scaling": "Platt", "Beta calibration": "beta", "Isotonic regression": "isotonic", "Height gate": "height gate"}
    hdr4 = ["Readout", "β₀", "IoU\n(scene 3)", "True-fire ECE\n(scene 3)", "IoU\n(scene 4)", "True-fire ECE\n(scene 4)"]
    rows4 = []
    for lab in READOUTS:
        for bb in (0.0, 1.0, 2.0):
            rows4.append([lab if bb == 0 else "", f"{bb:g}"] +
                         [f3(E[(s, bb, m, tidy_name[lab])]) for s in ("scene3", "scene4") for m in ("IoU", "true-fire ECE")])
    with open(PF / "Table_4_grey_haze_beta0_0_1_2.csv", "w", newline="") as fh:
        w_ = csv.writer(fh); w_.writerow([x.replace("\n", " ") for x in hdr4])
        w_.writerows([[r[0] or prev, *r[1:]] for r, prev in zip(rows4, [x[0] for x in rows4 for _ in (0,)] and
                      [rows4[i - i % 3][0] for i in range(len(rows4))])])
    table_png("Table_4_grey_haze_every_readout", "Table 4. Grey haze (α = 0), every readout (seed 1, every pixel scored against visible fire)",
              hdr4, rows4, col_w=[0.38, 0.07, 0.13, 0.15, 0.13, 0.15],
              note="Predicted-fire ECE was not recorded in the grey-haze run, so it is not shown.")


if __name__ == "__main__":
    main()
