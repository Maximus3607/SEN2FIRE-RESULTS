r"""
BUILD CSVs -- every result of the study as tidy and graph-ready CSV files. No graphs.

    python scripts/build_csvs.py --check   # is every result file in place and parseable?
    python scripts/build_csvs.py           # check, then write csv/

OUTPUT
  csv/graph_ready/E1 ... E5/   one file per graph: the first column is the x axis
                               (or the categories), every other column is one series,
                               every column name carries its unit. Open in Excel or
                               Google Sheets, select all, insert a chart.
  csv/tidy/                    long-format tables of everything parsed from the
                               text reports (one row per value) -- for your own pivots
  csv/raw/                     the CSVs the Kaggle runs wrote, copied unchanged
  csv/INDEX.csv                every graph-ready file: experiment, suggested chart,
                               x axis, y axis, what it shows, which run produced it

THE FIVE EXPERIMENTS (as in the paper)
  E1  Haze dose response on MODIS labels, the standard calibrators, the first custom readouts (SAEA)
  E2  Fixing antisymmetry: gap vs magnitude, model B's trained gated-null readout
  E3  Limits of post-hoc calibration: signals, the evidence head, the logit ceiling
  E4  Coarse MODIS labels, agreement labels, the retrained networks under haze
  E5  The height gate: readouts fitted on haze, and the every-pixel (pixel-by-pixel) test

Needs only the Python standard library.
"""
import argparse, csv, re, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RES, OUT = ROOT / "results", ROOT / "csv"

INPUTS = {   # key: (path under results/, produced by)
    "dose":      ("transcribed/dose_response_modelA_scene4.csv", "haze_sweep.py (transcribed)"),
    "sweepall":  ("haze_sweep/report_all_scenes_modelA.txt", "haze_sweep_v2.py"),
    "reliab":    ("transcribed/reliability_modelA_scene4.csv", "diagnose.py (transcribed)"),
    "split":     ("transcribed/class_split_modelA_scene4.csv", "diagnose.py (transcribed)"),
    "erosion":   ("transcribed/label_noise_erosion_modelA_scene4.csv", "diagnose.py (transcribed)"),
    "calib":     ("transcribed/standard_calibrators_modelA_scene4.csv", "calibrate.py (transcribed)"),
    "early":     ("transcribed/early_custom_readouts_modelA_scene4.csv", "fit_saea.py / fit_saea2.py / fit_evidence_readout.py (transcribed)"),
    "window":    ("transcribed/spatial_gate_window_sweep.csv", "window_sweep.py (transcribed)"),
    "softcap":   ("gate_sweep/softcap_by_window.txt", "gate_sweep.py"),
    "hinge":     ("gate_sweep/softcap_hinge_variants.txt", "gate_sweep.py"),
    "allres":    ("compile_results/all_results.csv", "compile_results.py"),
    "antisym":   ("compile_results/antisymmetry.csv", "compile_results.py"),
    "gapmag":    ("transcribed/gap_vs_magnitude_modelA.csv", "separation_check.py (transcribed)"),
    "nullterm":  ("transcribed/null_term_magnitude_modelA.csv", "magnitude_check.py (transcribed)"),
    "trainlog":  ("training_logs/modelB_seed0_train_log.txt", "train_gated.py (Kaggle log)"),
    "pair":      ("paired_compare/seed1_A_vs_B.txt", "paired_compare.py"),
    "ft1a":      ("final_tests/1a_readouts_all_metrics.csv", "final_tests.py"),
    "ft1b":      ("final_tests/1b_fire_ece_mce.csv", "final_tests.py"),
    "ft2":       ("final_tests/2_height_gate_vs_baselines.csv", "final_tests.py"),
    "ft3":       ("final_tests/3_confidence_by_category.csv", "final_tests.py"),
    "aerosol":   ("final_tests/scene_aerosol.csv", "final_tests.py"),
    "combined":  ("combined_readouts/report.txt", "combined_readouts.py"),
    "objectives":("gate_objectives/report.txt", "gate_objectives.py"),
    "env_A_s0":  ("evidence_null/en_vs_gate_A_s0.txt", "evidence_null.py"),
    "env_B_s0":  ("evidence_null/en_vs_gate_B_s0.txt", "evidence_null.py"),
    "env_A_s1":  ("evidence_null/en_vs_gate_A_s1.txt", "evidence_null.py"),
    "env_B_s1":  ("evidence_null/en_vs_gate_B_s1.txt", "evidence_null.py"),
    "anatomy":   ("ece_anatomy/report.txt", "ece_anatomy.py"),
    "signals":   ("transcribed/signal_auroc_predbg.csv", "separation_check.py (transcribed)"),
    "evhead":    ("transcribed/evidence_head_transfer.csv", "train_evidence_head.py / verify_evidence.py (transcribed)"),
    "evtrain":   ("transcribed/evidence_head_training.csv", "train_evidence_head.py (transcribed)"),
    "gatediag":  ("gate_diagnosis/report.txt", "gate_diagnosis.py"),
    "labelchk":  ("label_check/report.txt", "label_check.py"),
    "agcounts":  ("transcribed/agreement_label_counts.csv", "make_agreement_labels.py (transcribed)"),
    "stress":    ("haze_stress/report.txt", "haze_stress.py"),
    "hazero":    ("haze_readouts/report.txt", "haze_readouts.py"),
    "everypx":   ("every_pixel/report.txt", "every_pixel.py"),
}
RENAME = {"softmax": "softmax", "T": "temperature", "ccT": "class-cond T", "Platt": "Platt", "beta": "beta",
          "isotonic": "isotonic", "gate": "height gate", "T mix": "temperature (mixture)", "ccT mix": "class-cond T (mixture)",
          "gateECE clr": "gate ECE-fit (clear)", "gateECE mix": "gate ECE-fit (mixture)", "gateBr mix": "height gate (Brier, mixture)",
          "gateBr mtch": "gate Brier-fit (matched)"}

def num(s):
    s = s.replace(",", "").strip()
    return float("nan") if s in ("--", "nan", "") else float(s)


def parse_gate_diag():
    sig, var = [], []
    model = cond = None
    for l in (RES / INPUTS["gatediag"][0]).read_text().splitlines():
        m = re.match(r"^#+ (\w+) #+$", l)
        if m: model = m.group(1); continue
        m = re.match(r"^\s+\[(scene\d (?:b0=[\d.]+|natural))\]\s*$", l)
        if m: cond = m.group(1); continue
        m = re.match(r"^\s+(background|fire)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*$", l)
        if m and cond:
            sig.append(dict(model=model, condition=cond, calls=m.group(1), h_overlap=num(m.group(2)), MSP=num(m.group(3)),
                            MaxLogit=num(m.group(4)), energy=num(m.group(5)), sum=num(m.group(6)), ceiling=num(m.group(7))))
            continue
        m = re.match(r"^\s+(V\d+b?) (.+?)\s{2,}([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+|nan)\s*$", l)
        if m:
            var.append(dict(model=model, variant=f"{m.group(1)} {m.group(2).strip()}", conf_brier=num(m.group(3)),
                            true_fire_ece=num(m.group(4)), true_bg_ece=num(m.group(5)), pred_fire_ece=num(m.group(6)),
                            auroc=num(m.group(7)), conf_missed=num(m.group(8)), conf_corr_bg=num(m.group(9)),
                            selectivity=num(m.group(10))))
    return sig, var


def parse_label_check():
    shares, models = [], []
    scene = model = None
    for l in (RES / INPUTS["labelchk"][0]).read_text().splitlines():
        m = re.match(r"^=+ (scene\d):", l)
        if m: scene = m.group(1); shares.append(dict(scene=scene)); continue
        for key, pat in (("strict", r"with a STRICT signature\s+([\d.]+)%"), ("permissive", r"with a PERMISSIVE signature\s+([\d.]+)%"),
                         ("within_30m", r"within 30 m of one\s+([\d.]+)%"), ("none", r"NO visible fire at all\s+([\d.]+)%")):
            m = re.search(pat, l)
            if m and scene: shares[-1][key] = float(m.group(1)) / 100
        m = re.match(r"^\s+\[(\w_s\d)\]", l)
        if m: model = m.group(1); models.append(dict(scene=scene, model=model)); continue
        m = re.search(r"recall: all labels ([\d.]+)\s+on VISIBLE fire ([\d.]+)\s+on fire with NO visible signature ([\d.]+)", l)
        if m: models[-1].update(recall_all=float(m.group(1)), recall_visible=float(m.group(2)), recall_invisible=float(m.group(3)))
        m = re.search(r"confidence on missed fire: visible ([\d.]+)\s+none ([\d.]+)", l)
        if m: models[-1].update(conf_missed_visible=float(m.group(1)), conf_missed_invisible=float(m.group(2)))
        m = re.search(r"MaxLogit AUROC vs correct bg: missed-VISIBLE ([\d.]+)\s+missed-NONE ([\d.]+)", l)
        if m: models[-1].update(maxlogit_auroc_visible=float(m.group(1)), maxlogit_auroc_invisible=float(m.group(2)))
    return shares, models


def parse_haze_stress():
    perf, find = [], []
    alpha = scene = None
    for l in (RES / INPUTS["stress"][0]).read_text().splitlines():
        m = re.search(r"ALPHA = ([\d.]+)", l)
        if m: alpha = float(m.group(1)); continue
        m = re.match(r"^=+ (scene\d):", l)
        if m: scene = m.group(1); continue
        m = re.match(r"^\s+([\d.]+)\s+(rule|network seed \d)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*([\d.]+|--)?\s*([\d.]+|--)?\s*$", l)
        if m:
            perf.append(dict(alpha=alpha, scene=scene, beta0=float(m.group(1)), method=m.group(2), iou=num(m.group(3)),
                             precision=num(m.group(4)), recall=num(m.group(5)),
                             conf_detected=num(m.group(6) or "--"), conf_missed=num(m.group(7) or "--")))
            continue
        m = re.match(r"^\s+([\d.]+)\s+network seed (\d)\s+([\d,]+)\s+(\d+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+|--)\s*$", l)
        if m:
            find.append(dict(alpha=alpha, scene=scene, beta0=float(m.group(1)), seed=int(m.group(2)), missed_px=num(m.group(3)),
                             conf_missed=num(m.group(5)), conf_corr_bg=num(m.group(6)), h_missed=num(m.group(7)),
                             h_corr_bg=num(m.group(8)), maxlogit_auroc=num(m.group(9)), msp_auroc=num(m.group(10)),
                             ceiling=num(m.group(11))))
    return perf, find


def parse_haze_readouts():
    vals, gate = [], []
    alpha = scene = seed = metric = cols = None; ingate = False
    for l in (RES / INPUTS["hazero"][0]).read_text().splitlines():
        m = re.search(r"ALPHA = ([\d.]+) #", l)
        if m: alpha = float(m.group(1)); continue
        m = re.match(r"^\s+\[(scene\d) \| seed (\d)\]", l)
        if m: scene, seed = m.group(1), int(m.group(2)); metric = None; ingate = False; continue
        s = l.strip()
        if s.startswith("conf Brier (") or s.startswith("true-fire ECE ("):
            metric = s.split(" (")[0]; ingate = False; continue
        if s.startswith("gate Brier-fit (mixture): what it does"):
            metric = None; ingate = True; continue
        if s.startswith("gate Brier-fit (mixture) MINUS"):
            ingate = False; continue
        if s.startswith("beta0") and metric:
            cols = re.split(r"\s{2,}", s)[1:]; continue
        if metric and cols and alpha is not None:
            p = s.split()
            if len(p) == len(cols) + 1 and re.match(r"^[\d.]+$", p[0]):
                for c, v in zip(cols, p[1:]):
                    vals.append(dict(alpha=alpha, scene=scene, seed=seed, beta0=float(p[0]), metric=metric, readout=c, value=num(v)))
        if ingate and alpha is not None:
            p = s.split()
            if len(p) == 8 and re.match(r"^[\d.]+$", p[0]):
                gate.append(dict(alpha=alpha, scene=scene, seed=seed, beta0=float(p[0]), missed_px=num(p[1]),
                                 conf_missed_gate=num(p[2]), conf_missed_softmax=num(p[3]), conf_corr_bg=num(p[4]),
                                 conf_detected=num(p[5]), selectivity=num(p[6]), abstain_ignored=num(p[7])))
    return vals, gate


def parse_every_pixel():
    long, summ = [], []
    ver = cond = met = cols = None; section = None
    for l in (RES / INPUTS["everypx"][0]).read_text().splitlines():
        if l.startswith("########"):
            if "EVERY READOUT" in l:
                section = "readout"; ver = "visible" if "VISIBLE" in l else "agreement"
            else:
                section = "summary"; ver = "agreement" if "AGREEMENT" in l else ("visible" if "VISIBLE" in l else "modis")
            continue
        m = re.match(r"\s+\[alpha ([\d.]+) \| (scene\d) \| seed (\d)\]", l)
        if m: cond = (float(m.group(1)), m.group(2), int(m.group(3))); met = None; continue
        s = l.strip()
        if section == "summary" and cond:
            m = re.match(r"^([\d.]+)\s+([\d.]+|--)\s+([\d.]+|--)\s+([\d.]+|--)\s+([\d,]+)\s+([\d.]+|--) -> ([\d.]+|--)\s+([\d.]+|--)\s+([\d.]+|--)\s+([\d.]+|--)", s)
            if m:
                summ.append(dict(labels=ver, alpha=cond[0], scene=cond[1], seed=cond[2], beta0=float(m.group(1)), iou=num(m.group(2)),
                                 precision=num(m.group(3)), recall=num(m.group(4)), missed_px=num(m.group(5)),
                                 conf_missed_softmax=num(m.group(6)), conf_missed_gate=num(m.group(7)),
                                 conf_corr_bg_gate=num(m.group(8)), selectivity=num(m.group(9)), maxlogit_auroc=num(m.group(10))))
            continue
        if section != "readout" or not cond: continue
        m = re.match(r"^(IoU|true-fire ECE|fire Brier|conf missed|conf Brier|conf NLL|fire NLL|NLL|Brier)(\s{2}\(|$)", s)
        if m: met = m.group(1); continue
        if s.startswith("PROPER SCORES") or s.startswith("gate MINUS") or s.startswith("fire Brier, fire NLL"): met = None; continue
        if s.startswith("beta0") and met: cols = s.split()[1:]; continue
        p = s.split()
        if met and cols and len(p) == len(cols) + 1 and re.match(r"^[\d.]+$", p[0]):
            for c, v in zip(cols, p[1:]):
                long.append(dict(labels=ver, alpha=cond[0], scene=cond[1], seed=cond[2], beta0=float(p[0]), metric=met,
                                 readout=RENAME.get(c, c), value=num(v)))
    # the same fire Brier table is printed twice per block; keep one copy
    seen, out = set(), []
    for r in long:
        k = (r["labels"], r["alpha"], r["scene"], r["seed"], r["beta0"], r["metric"], r["readout"])
        if k not in seen: seen.add(k); out.append(r)
    return out, summ



# ------------------------------------------------------------------ new parsers
def text(key):
    return (RES / INPUTS[key][0]).read_text().splitlines()


def read_csv(key):
    lines = [l for l in (RES / INPUTS[key][0]).read_text().splitlines() if not l.startswith("#")]
    return list(csv.DictReader(lines))


def parse_sweep_all():
    """haze_sweep_v2.py: per scene, beta0 -> IoU, precision, recall, conf|fire, acc|fire, gap."""
    out, scene = [], None
    for l in text("sweepall"):
        l = re.sub(r"^[\d.]+s\t\d+\t", "", l)
        m = re.match(r"^=== (scene\d)", l)
        if m: scene = m.group(1); continue
        m = re.match(r"^\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*$", l)
        if m and scene:
            v = [float(x) for x in m.groups()]
            out.append(dict(scene=scene, beta0=v[0], iou=v[1], precision=v[2], recall=v[3], conf_fire=v[4], acc_fire=v[5], gap=v[6]))
    seen, uniq = set(), []                      # some scenes print the table twice (metrics pass, dump pass)
    for r in out:
        k = (r["scene"], r["beta0"])
        if k not in seen: seen.add(k); uniq.append(r)
    return uniq


def parse_trainlog():
    eps, gates, last = [], [], 0
    pat = (r"ep\s+(\d+) \| L ([\d.]+) ce ([\d.]+) bce ([\d.]+) nu ([\d.]+) \| val IoU ([\d.]+) R ([\d.]+) nll ([\d.]+) \| "
           r"hold IoU ([\d.]+) \| p\(0\) all ([\d.]+) err ([\d.]+) \| \|z0\+z1\| ([\d.]+) gap ([\d.]+)")
    for l in text("trainlog"):
        m = re.search(pat, l)
        if m:
            v = m.groups(); last = int(v[0])
            eps.append(dict(epoch=int(v[0]), loss=float(v[1]), ce=float(v[2]), bce=float(v[3]), nu=float(v[4]),
                            val_iou=float(v[5]), val_recall=float(v[6]), val_nll=float(v[7]), holdout_iou=float(v[8]),
                            mean_p_abstain_all=float(v[9]), mean_p_abstain_errors=float(v[10]),
                            mean_abs_logit_sum=float(v[11]), mean_abs_gap=float(v[12]), best_so_far="*" in l[m.end():]))
            continue
        m = re.search(r"c=([-\d.]+) k=([-\d.]+) gamma=([-\d.]+) tau=([-\d.]+)", l)
        if m:
            gates.append(dict(after_epoch=last, c=float(m.group(1)), k=float(m.group(2)), gamma=float(m.group(3)), tau=float(m.group(4))))
    seen, ue = set(), []
    for r in eps:
        if r["epoch"] not in seen: seen.add(r["epoch"]); ue.append(r)
    seen, ug = set(), []
    for r in gates:
        k = (r["after_epoch"], r["c"])
        if k not in seen: seen.add(k); ug.append(r)
    return ue, ug


def parse_gate_sweeps():
    rows, W = [], None
    for key in ("softcap", "hinge"):
        for l in text(key):
            m = re.match(r"^\s+W = (\d+)", l)
            if m: W = int(m.group(1)); continue
            m = re.match(r"^\s+(.+?)\s+(\d+)%\s+([\d.]+)%\s+([\d.]+)%\s+([\d.]+)", l)
            if m and W:
                v = m.group(1).strip()
                variant = v if not re.match(r"^[\d.]+$", v) else f"soft a{v}"
                rows.append(dict(window_px=W, variant=variant, budget=int(m.group(2)) / 100, coverage=float(m.group(3)) / 100,
                                 precision=float(m.group(4)) / 100, ece_bound=float(m.group(5))))
    seen, out = set(), []
    for r in rows:
        k = (r["window_px"], r["variant"], r["budget"])
        if k not in seen: seen.add(k); out.append(r)
    return out


def parse_pair():
    rows, b = [], None
    for l in text("pair"):
        m = re.search(r"beta0 = ([\d.]+)", l)
        if m: b = float(m.group(1)); continue
        m = re.match(r"^\s+model (A|B)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)", l)
        if m: rows.append(dict(beta0=b, model=f"model {m.group(1)} seed 1", true_fire_ece=float(m.group(2)),
                               conf_fire=float(m.group(3)), acc_fire=float(m.group(4)), conf_minus_acc=float(m.group(5))))
        m = re.search(r"ECE\(fire\) B - A\s+95% CI \[([-+\d.]+), ([-+\d.]+)\]", l)
        if m and rows: rows[-1].update(diff_ci_low=float(m.group(1)), diff_ci_high=float(m.group(2)))
    return rows


def parse_tables(key, model_hint=None):
    """Generic: '=== <model> beta0 = x' blocks containing 'readout ...' score tables and
    'abstention by pixel type' / 'WHAT EACH ABSTAINS ON' tables."""
    scores, abst = [], []
    model, beta, mode, cols = model_hint, None, None, None
    for l in text(key):
        m = re.match(r"^#+ (\w_s\d):", l)
        if m: model = m.group(1); continue
        m = re.match(r"^=== (\S+)\s+beta0 = ([\d.]+)", l)
        if m:
            beta = float(m.group(2)); mode = None
            mm = re.match(r"^(\w_s\d)", m.group(1)); model = mm.group(1) if mm else model
            continue
        s = l.strip()
        if not s: mode = None; continue
        if s.startswith("readout") and "fire" in s and "abst" not in s.lower() and "detected" not in s:
            mode, cols = "score", re.split(r"\s{2,}", s)[1:]; continue
        if s.startswith("abstention by pixel type") or (s.startswith("readout") and "detected" in s):
            mode, cols = "abst", re.split(r"\s{2,}", s)[1:]; continue
        if s.startswith("WHAT EACH ABSTAINS"): continue
        if mode and beta is not None:
            p = re.split(r"\s{2,}", s)
            if len(p) == len(cols) + 1 and all(re.match(r"^[-+]?[\d.]+$", x) for x in p[1:]):
                d = dict(model=model, beta0=beta, readout=p[0])
                d.update({c: float(x) for c, x in zip(cols, p[1:])})
                (scores if mode == "score" else abst).append(d)
            else:
                mode = None
    return scores, abst


def parse_anatomy():
    blocks, cur, part, front, perfect = [], "B_s0 beta0=0.2", None, [], []
    for l in text("anatomy"):
        m = re.match(r"^=== (\S+)\s+beta0 = ([\d.]+)", l)
        if m: cur = f"{'B_s0' if m.group(1).startswith('gated') else m.group(1)} beta0={m.group(2)}"; continue
        m = re.match(r"^PART (\d)", l)
        if m: part = int(m.group(1)); continue
        s = l.strip(); p = s.split()
        if part == 3 and len(p) == 4 and all(re.match(r"^[\d.]+$", x) for x in p):
            front.append(dict(condition=cur, true_fire_ece=float(p[0]), true_bg_ece=float(p[1]),
                              squash_pred_bg=float(p[2]), squash_pred_fire=float(p[3])))
        if part == 4:
            m = re.match(r"^(.+?)\s{2,}([\d.]+)\s+([\d.]+)$", s)
            if m: perfect.append(dict(condition=cur, scenario=m.group(1), true_fire_ece=float(m.group(2)), true_bg_ece=float(m.group(3))))
    return front, perfect


def parse_ignored():
    rows, cond, on = [], None, False
    for l in text("everypx"):
        if l.startswith("WHAT THE IGNORED PIXELS"): on = True; continue
        if l.startswith("########"): on = False
        if not on: continue
        m = re.match(r"\s+\[alpha ([\d.]+) \| (scene\d) \| seed (\d)\]", l)
        if m: cond = (float(m.group(1)), m.group(2), int(m.group(3))); continue
        nums = re.findall(r"[\d.]+%?", l)
        if cond and len(nums) == 13:
            b = float(nums[0])
            for i, cat in enumerate(["MODIS fire, nothing visible", "strict signature outside MODIS", "near a weak signature"]):
                g = nums[1 + 4 * i: 5 + 4 * i]
                rows.append(dict(alpha=cond[0], scene=cond[1], seed=cond[2], beta0=b, category=cat,
                                 share_of_scene=float(g[0].rstrip("%")) / 100, called_fire=float(g[1].rstrip("%")) / 100,
                                 mean_p_fire_softmax=float(g[2]), gate_abstention=float(g[3])))
    return rows


PARSERS = {k: (lambda k=k: read_csv(k)) for k, (p, _) in INPUTS.items() if p.endswith(".csv")}
PARSERS.update(sweepall=parse_sweep_all, trainlog=parse_trainlog, softcap=lambda: parse_gate_sweeps(), hinge=lambda: parse_gate_sweeps(),
               pair=parse_pair, combined=lambda: parse_tables("combined"), objectives=lambda: parse_tables("objectives"),
               env_A_s0=lambda: parse_tables("env_A_s0", "A_s0"), env_B_s0=lambda: parse_tables("env_B_s0", "B_s0"),
               env_A_s1=lambda: parse_tables("env_A_s1", "A_s1"), env_B_s1=lambda: parse_tables("env_B_s1", "B_s1"),
               anatomy=parse_anatomy, gatediag=parse_gate_diag, labelchk=parse_label_check, stress=parse_haze_stress,
               hazero=parse_haze_readouts, everypx=lambda: (parse_every_pixel(), parse_ignored()))


# ------------------------------------------------------------------ writers
EXPDIR = {"E1": "E1_haze_dose_response_MODIS", "E2": "E2_antisymmetry_and_model_B", "E3": "E3_limits_of_post_hoc",
          "E4": "E4_MODIS_labels_and_agreement_labels", "E5": "E5_height_gate_and_every_pixel"}
INDEX = []
KEY = {   # the ~30 files that tell the story; INDEX.csv marks them paper_figure = yes
    "fire_confidence_vs_accuracy_scene4", "detection_vs_haze_scene4", "ece_by_population_scene4", "standard_calibrators_fire_ece_vs_haze",
    "softmax_true_fire_ece_vs_haze_4_models_scene3", "early_custom_readouts_fire_ece_change", "early_custom_readouts_selectivity",
    "gap_vs_magnitude_modelA", "antisymmetry_4_models", "modelB_gate_parameters", "trained_gate_abstention_by_pixel_type", "modelA_vs_modelB_seed1",
    "signal_auroc_finding_missed_fire", "evidence_head_vs_readouts_auroc", "evidence_head_transfer", "logit_ceiling_vs_haze_4_models",
    "scene4_gate_counterfactuals", "every_readout_predicted_fire_ece_scene3_clear", "every_readout_true_fire_ece_scene3_clear",
    "change_vs_softmax_pred_fire_ece_scene3_clear", "abstention_by_pixel_type_height_gate_MODIS",
    "MODIS_fire_visibility", "recall_MODIS_vs_visible_fire", "agreement_label_counts", "iou_rule_vs_network_aerosol_haze", "iou_rule_vs_network_grey_haze",
    "conf_missed_vs_haze_agreement_networks", "haze_readouts_true_fire_ece_aerosol_scene4", "confidence_on_missed_fire_gate_vs_softmax_aerosol",
    "height_gate_selectivity_vs_haze", "every_pixel_b4_aerosol_true_fire_ece", "every_pixel_b4_aerosol_fire_brier", "every_pixel_b4_aerosol_conf_missed",
    "every_pixel_b4_aerosol_iou", "every_pixel_b2_grey_true_fire_ece", "grey_haze_calibrators_on_clear_images_iou", "iou_by_label_version_seed0",
    "selectivity_MODIS_vs_agreement_labels"}


def clean(v):
    if isinstance(v, float):
        if v != v: return ""
        return f"{v:.6g}" if abs(v) < 1e-3 and v != 0 else f"{round(v, 6)}"
    return v


def graph(exp, name, chart, x, y, shows, source, header, rows):
    """One graph-ready CSV: first column = x axis / categories, other columns = series."""
    if chart.startswith("line") and x == B: chart = chart.replace("line", "line (XY scatter with lines: beta0 steps are uneven)", 1)
    d = OUT / "graph_ready" / EXPDIR[exp]; d.mkdir(parents=True, exist_ok=True)
    with open(d / f"{name}.csv", "w", newline="") as fh:
        w = csv.writer(fh); w.writerow(header); w.writerows([[clean(v) for v in r] for r in rows])
    INDEX.append(dict(file=f"graph_ready/{EXPDIR[exp]}/{name}.csv", experiment=exp,
                      paper_figure="yes" if name.split("_", 1)[1] in KEY else "", chart=chart, x_axis=x, y_axis=y,
                      shows=shows, source=source, rows=len(rows)))


def tidy(name, rows):
    if not rows: return
    d = OUT / "tidy"; d.mkdir(parents=True, exist_ok=True)
    keys = []
    for r in rows:
        for k in r:
            if k not in keys: keys.append(k)
    with open(d / f"{name}.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows([{k: clean(v) for k, v in r.items()} for r in rows])


def pivot(rows, xk, sk, vk, xs=None, ss=None):
    xs = xs if xs is not None else sorted({r[xk] for r in rows})
    if ss is None:
        ss = []
        for r in rows:
            if r[sk] not in ss: ss.append(r[sk])
    t = {(r[xk], r[sk]): r[vk] for r in rows}
    return ss, [[x] + [t.get((x, s), "") for s in ss] for x in xs]


F = lambda r, k: float(r[k]) if r.get(k, "") not in ("", None) else float("nan")
MODELS = ["A_s0", "A_s1", "B_s0", "B_s1"]
MNAME = {"A_s0": "model A seed 0", "A_s1": "model A seed 1", "B_s0": "model B seed 0", "B_s1": "model B seed 1"}
B = "beta0 (haze optical depth at 550 nm)"


# ------------------------------------------------------------------ E1
def build_E1(P):
    d = P["dose"]
    graph("E1", "E1-01_fire_confidence_vs_accuracy_scene4", "line", B, "probability (0-1)",
          "Model A: mean confidence on fire pixels stays ~0.92 while accuracy on fire falls 0.27 -> 0.02",
          INPUTS["dose"][1], [B, "mean confidence on fire pixels", "accuracy on fire pixels", "gap (confidence - accuracy)"],
          [[F(r, "beta0"), F(r, "conf_fire"), F(r, "acc_fire"), F(r, "gap")] for r in d])
    graph("E1", "E1-02_detection_vs_haze_scene4", "line", B, "score (0-1)", "Recall collapses while precision rises",
          INPUTS["dose"][1], [B, "IoU", "precision", "recall"], [[F(r, "beta0"), F(r, "iou"), F(r, "precision"), F(r, "recall")] for r in d])
    S = P["sweepall"]
    for k, lab, n in (("acc_fire", "accuracy on fire pixels", "03"), ("conf_fire", "mean confidence on fire pixels", "04"),
                      ("gap", "confidence minus accuracy on fire", "05"), ("iou", "IoU", "06")):
        ss, rows = pivot(S, "beta0", "scene", k)
        graph("E1", f"E1-{n}_{k}_vs_haze_all_scenes", "line", B, lab, f"Model A seed 0, all four scenes: {lab} as haze rises",
              INPUTS["sweepall"][1], [B] + [f"{s} ({lab})" for s in ss], rows)
    R = P["reliab"]
    graph("E1", "E1-07_reliability_scene4", "bar (or line vs diagonal)", "confidence bin", "probability (0-1)",
          "Reliability: accuracy vs mean confidence per confidence bin, all pixels", INPUTS["reliab"][1],
          ["confidence bin", "accuracy", "mean confidence", "pixels"], [[r["bin"], F(r, "accuracy"), F(r, "mean_confidence"), int(r["pixels"])] for r in R])
    Sp = P["split"]
    graph("E1", "E1-08_ece_by_population_scene4", "bar", "population", "ECE",
          "Overall ECE 0.031 hides true-fire ECE 0.691", INPUTS["split"][1], ["population", "ECE", "mean confidence", "accuracy"],
          [[r["population"], F(r, "ece"), F(r, "mean_confidence"), F(r, "accuracy")] for r in Sp])
    E = P["erosion"]
    graph("E1", "E1-09_label_noise_control", "line", "fire-mask erosion (pixels)", "true-fire ECE",
          "Eroding label edges does not reduce fire ECE: edge noise is not the cause", INPUTS["erosion"][1],
          ["fire-mask erosion (pixels)", "true-fire ECE"], [[int(r["erosion_px"]), F(r, "true_fire_ece")] for r in E])
    C = P["calib"]
    graph("E1", "E1-10_standard_calibrators_clean_scene4", "bar", "calibrator", "score",
          "Temperature, adaptive T and Platt: overall ECE improves, fire ECE does not; Platt costs IoU", INPUTS["calib"][1],
          ["calibrator", "overall ECE", "true-fire ECE", "Brier", "NLL", "IoU"],
          [[r["method"], F(r, "ece"), F(r, "true_fire_ece"), F(r, "brier"), F(r, "nll"), F(r, "iou")] for r in C if F(r, "beta0") == 0])
    ss, rows = pivot(C, "beta0", "method", "true_fire_ece")
    graph("E1", "E1-11_standard_calibrators_fire_ece_vs_haze", "line", B, "true-fire ECE",
          "No standard calibrator fixes fire calibration as haze rises", INPUTS["calib"][1], [B] + ss, [[float(r[0])] + [float(x) for x in r[1:]] for r in rows])
    A = [r for r in P["allres"] if r["readout"] == "softmax"]
    for k, lab, n in (("acc_fire", "accuracy on fire pixels", "12"), ("conf_fire", "mean confidence on fire pixels", "13"),
                      ("true_fire_ece", "true-fire ECE", "14"), ("true_bg_ece", "true-background ECE", "15"), ("standard_ece", "overall ECE", "16")):
        rr = [dict(beta0=F(r, "beta0"), model=MNAME[r["model"]], v=F(r, k)) for r in A]
        ss, rows = pivot(rr, "beta0", "model", "v")
        graph("E1", f"E1-{n}_softmax_{k}_vs_haze_4_models_scene3", "line", B, lab,
              f"All four MODIS-label models, scene 3 held-out half: {lab} under haze (softmax)", INPUTS["allres"][1], [B] + ss, rows)
    Ea = P["early"]
    ss, rows = pivot([dict(b=F(r, "beta0"), s=r["readout"], v=F(r, "delta_true_fire_ece")) for r in Ea], "b", "s", "v")
    graph("E1", "E1-17_early_custom_readouts_fire_ece_change", "bar (grouped by haze)", B, "change in true-fire ECE vs softmax (+ = worse)",
          "SAEA v1, SAEA v2 and the evidence-gated readout all made fire calibration worse", INPUTS["early"][1], [B] + ss, rows)
    ss, rows = pivot([dict(b=F(r, "beta0"), s=r["readout"], v=F(r, "selectivity")) for r in Ea], "b", "s", "v")
    graph("E1", "E1-18_early_custom_readouts_selectivity", "bar", B, "selectivity (abstention on missed fire / on correct pixels)",
          "SAEA abstained almost everywhere (selectivity ~1.35)", INPUTS["early"][1], [B] + ss, rows)
    W = P["window"]
    graph("E1", "E1-19_spatial_gate_window_sweep", "line", "window size (pixels)", "share (0-1)",
          "Spatial gate: coverage of missed fire rises with window size but precision falls", INPUTS["window"][1],
          ["window size (pixels)", "coverage of missed fire", "precision", "AUROC"],
          [[int(r["window_px"]), F(r, "coverage"), F(r, "precision"), F(r, "auroc")] for r in W])
    G = [r for r in P["softcap"] if r["window_px"] == 101]
    ss, rows = pivot(G, "variant", "budget", "precision")
    graph("E1", "E1-20_softcap_hinge_precision_W101", "bar", "readout variant", "precision of flagged pixels",
          "Every soft-cap and hinge variant lost to the plain spatial gate (window 101 px)", INPUTS["softcap"][1],
          ["readout variant"] + [f"precision at {int(b * 100)}% flag budget" for b in ss], rows)


# ------------------------------------------------------------------ E2
def build_E2(P):
    G = P["gapmag"]
    graph("E2", "E2-01_gap_vs_magnitude_modelA", "bar", "pixel group", "logit value",
          "Gap and magnitude agree to within 0.1% (4.1889 vs 4.1897 on correct background): the logits are antisymmetric", INPUTS["gapmag"][1],
          ["pixel group", "mean gap z0 - z1", "mean magnitude |z0| + |z1|"],
          [[f"{r['pixel_group']} (beta0 {r['beta0']})", F(r, "mean_gap"), F(r, "mean_magnitude")] for r in G])
    N = P["nullterm"]
    graph("E2", "E2-02_null_term_magnitude_by_pixel_type", "bar", "pixel type", "mean magnitude |z0| + |z1|",
          "Missed fire has HIGHER magnitude than detected fire, so the null-term readout pointed the wrong way",
          INPUTS["nullterm"][1], ["pixel type", "mean magnitude"], [[r["pixel_type"], F(r, "mean_magnitude")] for r in N])
    A = P["antisym"]
    a0 = [r for r in A if F(r, "beta0") == 0]
    graph("E2", "E2-03_antisymmetry_4_models", "bar", "model", "share / correlation",
          "Logit sum is 12-20% of the gap; 95-99% of pixels have opposite-signed logits (so magnitude = gap there)",
          INPUTS["antisym"][1], ["model", "logit sum / gap", "share of pixels with opposite-signed logits", "corr(sum, gap) on predicted background"],
          [[MNAME[r["model"]], F(r, "ratio_sum_to_gap"), F(r, "frac_opposite_signs"), F(r, "corr_sum_gap_predbg")] for r in a0])
    ss, rows = pivot([dict(b=F(r, "beta0"), m=MNAME[r["model"]], v=F(r, "ratio_sum_to_gap")) for r in A], "b", "m", "v")
    graph("E2", "E2-04_logit_sum_share_vs_haze", "line", B, "logit sum / gap", "Model B's auxiliary loss raised the logit sum only slightly",
          INPUTS["antisym"][1], [B] + ss, rows)
    ep, gates = P["trainlog"]
    graph("E2", "E2-05_modelB_training_iou", "line", "epoch", "IoU", "Model B seed 0 training: validation and holdout IoU per epoch",
          INPUTS["trainlog"][1], ["epoch", "validation IoU (scene 3)", "holdout IoU", "auxiliary loss weight nu"],
          [[r["epoch"], r["val_iou"], r["holdout_iou"], r["nu"]] for r in ep])
    graph("E2", "E2-06_modelB_training_logit_sum_vs_gap", "line", "epoch", "mean |logit| value",
          "Model B training: the logit sum stays far smaller than the gap even with the auxiliary loss on",
          INPUTS["trainlog"][1], ["epoch", "mean |z0 + z1| (logit sum)", "mean |z1 - z0| (gap)"],
          [[r["epoch"], r["mean_abs_logit_sum"], r["mean_abs_gap"]] for r in ep])
    graph("E2", "E2-07_modelB_training_abstention", "line", "epoch", "mean p(abstain)",
          "Model B training: abstention on all pixels vs on the model's errors", INPUTS["trainlog"][1],
          ["epoch", "mean p(abstain), all pixels", "mean p(abstain), errors"],
          [[r["epoch"], r["mean_p_abstain_all"], r["mean_p_abstain_errors"]] for r in ep])
    graph("E2", "E2-08_modelB_gate_parameters", "line", "epoch", "parameter value",
          "The trained gate's parameters converge to c = -5.65, k = 8.49, gamma = 2.75 (later borrowed by the height gate)",
          INPUTS["trainlog"][1], ["epoch", "c (floor)", "k (swing)", "gamma (sharpness)", "tau (threshold)"],
          [[r["after_epoch"], r["c"], r["k"], r["gamma"], r["tau"]] for r in gates])
    C3 = P["ft3"]
    cats = ["correct fire", "false alarm", "missed fire", "correct bg"]
    g3 = lambda m, c, rd, cat, k: next((F(r, k) for r in C3 if r["model"] == m and r["condition"] == c and r["readout"] == rd
                                         and r["category"] == cat), float("nan"))
    cols = [(m, rd) for m in ("B_s0", "B_s1") for rd in ("trained gate", "height gate")]
    graph("E2", "E2-09_trained_gate_abstention_by_pixel_type", "bar", "pixel type", "mean p(abstain)",
          "The trained gate abstains by predicted class (correct fire 0.68) instead of by error (missed fire 0.21)",
          INPUTS["ft3"][1], ["pixel type"] + [f"{rd}, {MNAME[m]}" for m, rd in cols],
          [[c] + [g3(m, "scene3 b0=0.0", rd, c, "mean_abstention") for m, rd in cols] for c in cats])
    cols = [(m, rd) for m in ("B_s0", "B_s1") for rd in ("softmax", "trained gate")]
    graph("E2", "E2-10_trained_gate_confidence_by_pixel_type", "bar", "pixel type", "mean confidence",
          "Confidence by pixel type, softmax vs the trained gate, with each type's accuracy", INPUTS["ft3"][1],
          ["pixel type", "accuracy"] + [f"{rd}, {MNAME[m]}" for m, rd in cols],
          [[c, g3("B_s0", "scene3 b0=0.0", "softmax", c, "accuracy")] + [g3(m, "scene3 b0=0.0", rd, c, "mean_confidence") for m, rd in cols] for c in cats])
    R1 = P["ft1a"]
    g1 = lambda m, c, rd, met: next((F(r, "value") for r in R1 if r["model"] == m and r["condition"] == c and r["readout"] == rd
                                      and r["metric"] == met), float("nan"))
    betas = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]
    for met, n, lab in (("ECE fire (true)", "11", "true-fire ECE"), ("ECE fire (pred)", "12", "predicted-fire ECE")):
        cols = [(m, rd) for m in ("B_s0", "B_s1") for rd in ("softmax", "trained gate", "height gate")]
        graph("E2", f"E2-{n}_trained_gate_{lab.replace(' ', '_').replace('-', '_')}_vs_haze", "line", B, lab,
              f"Model B: {lab} of softmax, its trained gate and the height gate as haze rises (scene 3)", INPUTS["ft1a"][1],
              [B] + [f"{rd}, {MNAME[m]}" for m, rd in cols], [[b] + [g1(m, f"scene3 b0={b}", rd, met) for m, rd in cols] for b in betas])
    graph("E2", "E2-13_softmax_iou_vs_haze_4_models", "line", B, "IoU",
          "Model B seed 0's flat IoU under haze did not replicate in seed 1", INPUTS["ft1a"][1],
          [B] + [MNAME[m] for m in MODELS], [[b] + [g1(m, f"scene3 b0={b}", "softmax", "IoU") for m in MODELS] for b in betas])
    Pr = P["pair"]
    pb = sorted({r["beta0"] for r in Pr}); Ip = {(r["beta0"], r["model"][6]): r for r in Pr}
    graph("E2", "E2-14_modelA_vs_modelB_seed1", "bar with error bars (grouped by haze)", B, "true-fire ECE",
          "Matched seed-1 pair (same seed, auxiliary loss off vs on): model B's lower fire ECE is within noise (paired 95% CI of B - A includes zero)",
          INPUTS["pair"][1], [B, "true-fire ECE, model A seed 1", "true-fire ECE, model B seed 1", "B - A", "B - A: 95% CI low", "B - A: 95% CI high",
                              "confidence on fire, A", "confidence on fire, B", "accuracy on fire, A", "accuracy on fire, B"],
          [[b, Ip[(b, "A")]["true_fire_ece"], Ip[(b, "B")]["true_fire_ece"], Ip[(b, "B")]["true_fire_ece"] - Ip[(b, "A")]["true_fire_ece"],
            Ip[(b, "B")].get("diff_ci_low", ""), Ip[(b, "B")].get("diff_ci_high", ""), Ip[(b, "A")]["conf_fire"], Ip[(b, "B")]["conf_fire"],
            Ip[(b, "A")]["acc_fire"], Ip[(b, "B")]["acc_fire"]] for b in pb])


# ------------------------------------------------------------------ E3
RD_ORDER = ["softmax", "temperature", "class-cond T", "Platt", "beta", "isotonic", "SAEA", "trained gate", "evidence null", "height gate"]
CONDS = {"scene3 b0=0.0": "scene 3 clear", "scene4 natural": "scene 4 (new region)"}


def idx(rows, *keys, val="value"):
    return {tuple(r[k] for k in keys): F(r, val) for r in rows}


def build_E3(P):
    S = P["signals"]
    bs = [k for k in S[0] if k.startswith("beta0_")]
    graph("E3", "E3-01_signal_auroc_finding_missed_fire", "bar (grouped by haze)", "signal", "AUROC (0.5 = chance)",
          "Six candidate signals for separating missed fire from correct background (model A, predicted background): all 0.52-0.66",
          INPUTS["signals"][1], ["signal"] + [f"AUROC at beta0 = {b.split('_')[1]}" for b in bs], [[r["signal"]] + [F(r, b) for b in bs] for r in S])
    R1 = P["ft1a"]; I1 = idx(R1, "model", "condition", "readout", "metric")
    ev = {r["evidence_from"] + "|" + r["scored_against"]: F(r, "auroc") for r in P["evhead"]}
    rows = [[rd, I1.get(("A_s0", "scene3 b0=0.0", rd, "AUROC"), ""), I1.get(("A_s0", "scene4 natural", rd, "AUROC"), "")]
            for rd in RD_ORDER if ("A_s0", "scene3 b0=0.0", rd, "AUROC") in I1]
    rows.append(["evidence head (learned from decoder features)", ev["scene 3|scene 3 errors"], ev["scene 4|scene 4 errors"]])
    graph("E3", "E3-02_evidence_head_vs_readouts_auroc", "bar", "readout", "error-detection AUROC",
          "The learned evidence head (0.853 / 0.711) barely beats the readouts' own confidence (0.77-0.85 / 0.71-0.75): little information is left to find (model A seed 0)",
          INPUTS["ft1a"][1] + " + " + INPUTS["evhead"][1], ["readout", "AUROC, scene 3 clear", "AUROC, scene 4 (new region)"], rows)
    graph("E3", "E3-03_evidence_head_transfer", "bar", "evidence head trained on -> scored on", "AUROC",
          "Evidence head: works within the region it was trained on, ~chance across regions", INPUTS["evhead"][1],
          ["trained on -> scored on", "AUROC"], [[f"{r['evidence_from']} -> {r['scored_against']}", F(r, "auroc")] for r in P["evhead"]])
    sig, var = P["gatediag"]
    for calls, n in (("background", "04"), ("fire", "05")):
        graph("E3", f"E3-{n}_logit_ceiling_pixels_called_{calls}", "bar", "model and condition", "AUROC",
              f"Best possible logit readout (cross-fitted ceiling) vs MSP, MaxLogit, energy and logit sum on pixels the network called {calls}; "
              "the ceiling falls on scene 4", INPUTS["gatediag"][1],
              ["model and condition", "MSP", "MaxLogit", "energy", "logit sum", "logit ceiling", "height overlap"],
              [[f"{MNAME[r['model']]}, {r['condition']}", r["MSP"], r["MaxLogit"], r["energy"], r["sum"], r["ceiling"], r["h_overlap"]]
               for r in sig if r["calls"] == calls])
    A = P["antisym"]
    a0 = [r for r in A if F(r, "beta0") == 0]
    graph("E3", "E3-06_gap_sum_auroc_vs_ceiling_4_models", "bar", "model", "AUROC on predicted background",
          "Logit gap carries almost all the information; the sum adds nothing; the ceiling is only 0.01-0.02 above the best single signal (beta0 = 0)",
          INPUTS["antisym"][1], ["model", "AUROC of gap", "AUROC of sum", "AUROC of better of the two", "logit ceiling"],
          [[MNAME[r["model"]], F(r, "auroc_gap_predbg"), F(r, "auroc_sum_predbg"), F(r, "auroc_winner_predbg"), F(r, "ceiling_predbg")] for r in a0])
    ss, rows = pivot([dict(b=F(r, "beta0"), m=MNAME[r["model"]], v=F(r, "ceiling_predbg")) for r in A], "b", "m", "v")
    graph("E3", "E3-07_logit_ceiling_vs_haze_4_models", "line", B, "logit ceiling AUROC",
          "The ceiling on what any logit readout can find, as haze rises (scene 3, predicted background)", INPUTS["antisym"][1], [B] + ss, rows)
    graph("E3", "E3-08_scene4_gate_counterfactuals", "bar", "gate variant", "score",
          "Scene 4, model A: refitting the gate on scene 4, a proper objective, MSP or the ceiling signal all fail; only perfect information works "
          "(selectivity 2,657 -- plot that column on a log axis)", INPUTS["gatediag"][1],
          ["gate variant", "confidence Brier", "true-fire ECE", "true-background ECE", "predicted-fire ECE", "AUROC",
           "confidence on missed fire", "confidence on correct background", "selectivity"],
          [[r["variant"], r["conf_brier"], r["true_fire_ece"], r["true_bg_ece"], r["pred_fire_ece"], r["auroc"], r["conf_missed"],
            r["conf_corr_bg"], r["selectivity"]] for r in var])
    n = 9
    for met, lab in (("ECE fire (true)", "true-fire ECE"), ("ECE fire (pred)", "predicted-fire ECE (primary endpoint)"), ("ECE", "overall ECE"),
                     ("Brier", "Brier score"), ("NLL", "NLL"), ("IoU", "IoU")):
        for cond, cl in CONDS.items():
            slug = re.sub(r"[^a-z0-9]+", "_", lab.split(" (")[0].lower()).strip("_")
            graph("E3", f"E3-{n:02d}_every_readout_{slug}_{'scene3_clear' if 'scene3' in cond else 'scene4'}", "bar (grouped by model)",
                  "readout", lab, f"Every readout on the four MODIS-label models, {cl}: {lab} (trained gate exists only in model B)",
                  INPUTS["ft1a"][1], ["readout"] + [MNAME[m] for m in MODELS],
                  [[rd] + [I1.get((m, cond, rd, met), "") for m in MODELS] for rd in RD_ORDER])
            n += 1
    D = {(r["model"], r["condition"], r["readout"], r["metric"]): r for r in R1}
    for met, lab in (("ECE fire (pred)", "predicted-fire ECE"), ("ECE fire (true)", "true-fire ECE")):
        for cond, cl in CONDS.items():
            hdr, rows = ["readout"], []
            for m in MODELS: hdr += [f"{MNAME[m]}: change", f"{MNAME[m]}: 95% CI low", f"{MNAME[m]}: 95% CI high"]
            for rd in RD_ORDER[1:]:
                row = [rd]
                for m in MODELS:
                    r = D.get((m, cond, rd, met), {})
                    row += [F(r, "diff_vs_softmax") if r else "", F(r, "ci_low") if r else "", F(r, "ci_high") if r else ""]
                rows.append(row)
            graph("E3", f"E3-{n:02d}_change_vs_softmax_{'pred' if 'pred' in met else 'true'}_fire_ece_{'scene3_clear' if 'scene3' in cond else 'scene4'}",
                  "bar with error bars", "readout", f"change in {lab} vs softmax (negative = better)",
                  f"{cl}: each readout's change in {lab} relative to softmax, with paired-bootstrap 95% CI", INPUTS["ft1a"][1], hdr, rows)
            n += 1
    H = P["ft2"]
    for cond, cl in CONDS.items():
        hdr, rows = ["model"], []
        bls = ["softmax", "temperature", "class-cond T"]
        for b_ in bls: hdr += [f"height gate - {b_}", f"vs {b_}: CI low", f"vs {b_}: CI high"]
        for m in MODELS:
            row = [MNAME[m]]
            for b_ in bls:
                r = next((r for r in H if r["model"] == m and r["condition"] == cond and r["baseline"] == b_ and r["metric"] == "ECE fire (pred)"), {})
                row += [F(r, "diff_height_minus_baseline") if r else "", F(r, "ci_low") if r else "", F(r, "ci_high") if r else ""]
            rows.append(row)
        graph("E3", f"E3-{n:02d}_height_gate_vs_baselines_pred_fire_ece_{'scene3_clear' if 'scene3' in cond else 'scene4'}",
              "bar with error bars", "model", "difference in predicted-fire ECE (negative = height gate better)",
              f"{cl}: height gate minus softmax / temperature / class-cond T on the primary endpoint, paired 95% CI", INPUTS["ft2"][1], hdr, rows)
        n += 1
    betas = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]
    for m in MODELS:
        rds = [rd for rd in RD_ORDER if (m, "scene3 b0=0.0", rd, "ECE fire (true)") in I1]
        graph("E3", f"E3-{n:02d}_true_fire_ece_vs_haze_all_readouts_{m}", "line", B, "true-fire ECE",
              f"{MNAME[m]}: every readout's true-fire ECE as haze rises (scene 3) -- the lines barely separate", INPUTS["ft1a"][1],
              [B] + rds, [[b] + [I1.get((m, f"scene3 b0={b}", rd, "ECE fire (true)"), "") for rd in rds] for b in betas])
        n += 1
    C3 = P["ft3"]; I3 = idx(C3, "model", "condition", "readout", "category", val="mean_confidence")
    cats = ["correct fire", "false alarm", "missed fire", "correct bg"]
    for m in ("A_s0", "B_s0"):
        graph("E3", f"E3-{n:02d}_softmax_confidence_by_pixel_type_vs_haze_{m}", "line", B, "mean confidence",
              f"{MNAME[m]}, softmax: confidence on missed fire stays as high as on correct background", INPUTS["ft3"][1],
              [B] + cats, [[b] + [I3.get((m, f"scene3 b0={b}", "softmax", c), "") for c in cats] for b in betas])
        n += 1
    for cond, cl in CONDS.items():
        graph("E3", f"E3-{n:02d}_confidence_on_missed_fire_every_readout_{'scene3_clear' if 'scene3' in cond else 'scene4'}", "bar (grouped by model)",
              "readout", "mean confidence on missed fire", f"{cl}: how confident each readout still is on the fire it misses", INPUTS["ft3"][1],
              ["readout"] + [MNAME[m] for m in MODELS], [[rd] + [I3.get((m, cond, rd, "missed fire"), "") for m in MODELS] for rd in RD_ORDER])
        n += 1
    Ab = idx(C3, "model", "condition", "readout", "category", val="mean_abstention")
    for rd in ("height gate", "SAEA", "evidence null"):
        rows = []
        for m in MODELS:
            for cond, cl in CONDS.items():
                mf, bg = Ab.get((m, cond, rd, "missed fire")), Ab.get((m, cond, rd, "correct bg"))
                rows.append([f"{MNAME[m]}, {cl}"] + [Ab.get((m, cond, rd, c), "") for c in cats] + [mf / bg if mf is not None and bg else ""])
        graph("E3", f"E3-{n:02d}_abstention_by_pixel_type_{rd.replace(' ', '_')}_MODIS", "bar", "model and scene", "mean p(abstain)",
              f"MODIS-label models, {rd}: abstention on each pixel type; selectivity = missed fire / correct background", INPUTS["ft3"][1],
              ["model and scene"] + [f"abstention on {c}" for c in cats] + ["selectivity (missed fire / correct bg)"], rows)
        n += 1
    front, perfect = P["anatomy"]
    conds = []
    for r in front:
        if r["condition"] not in conds: conds.append(r["condition"])
    graph("E3", f"E3-{n:02d}_ece_anatomy_tradeoff_frontier", "scatter (x = first column)", "true-fire ECE", "true-background ECE",
          "Squashing confidence lowers fire ECE only by raising background ECE: the trade-off frontier (model B seed 0)", INPUTS["anatomy"][1],
          ["true-fire ECE"] + [f"true-background ECE, {c}" for c in conds],
          [[r["true_fire_ece"]] + [r["true_bg_ece"] if r["condition"] == c else "" for c in conds] for r in front]); n += 1
    sc = []
    for r in perfect:
        if r["scenario"] not in sc: sc.append(r["scenario"])
    pc = []
    for r in perfect:
        if r["condition"] not in pc: pc.append(r["condition"])
    Ip = {(r["scenario"], r["condition"]): r["true_fire_ece"] for r in perfect}
    graph("E3", f"E3-{n:02d}_perfect_identification_scenarios", "bar", "scenario", "true-fire ECE",
          "Even perfectly identifying missed fire, a two-class readout can only reach 50%: abstention is needed", INPUTS["anatomy"][1],
          ["scenario"] + [f"true-fire ECE, {c}" for c in pc], [[s_] + [Ip.get((s_, c), "") for c in pc] for s_ in sc]); n += 1
    for key, title, nm in (("combined", "Flexible and softplus readouts", "combined_readouts"), ("objectives", "Gate fitting objectives", "gate_objectives")):
        scores, abst = P[key]
        ms = [m for m in MODELS if any(r["model"] == m for r in scores)]
        rds = []
        for r in scores:
            if r["readout"] not in rds: rds.append(r["readout"])
        for col, lab in (("TRUE fire", "true-fire ECE"), ("pred fire", "predicted-fire ECE")):
            Ix = {(r["model"], r["beta0"], r["readout"]): r[col] for r in scores}
            cs = [(m, b) for m in ms for b in (0.2, 0.5)]
            graph("E3", f"E3-{n:02d}_{nm}_{'true' if col.startswith('TRUE') else 'pred'}_fire_ece", "bar (grouped)", "readout", lab,
                  f"{title}: {lab} (scene 3)", INPUTS[key][1], ["readout"] + [f"{MNAME[m]}, beta0 {b}" for m, b in cs],
                  [[rd] + [Ix.get((m, b, rd), "") for m, b in cs] for rd in rds]); n += 1
        if abst:
            graph("E3", f"E3-{n:02d}_{nm}_abstention_by_pixel_type", "bar", "objective, model, haze", "mean p(abstain)",
                  f"{title}: abstention by pixel type -- every objective abstains roughly evenly (low selectivity)", INPUTS[key][1],
                  ["objective, model, haze", "detected fire", "false alarm", "missed fire", "correct bg", "selectivity (missed / correct bg)"],
                  [[f"{r['readout']}, {MNAME[r['model']]}, beta0 {r['beta0']}", r["detected"], r["false alarm"], r["missed"], r["correct bg"], r["missed/bg"]]
                   for r in abst]); n += 1
    rows_s, rows_a = [], []
    for m in MODELS:
        sc_, ab_ = P[f"env_{m}"]
        for r in sc_:
            rows_s.append([f"{r['readout']}, {MNAME[m]}, beta0 {r['beta0']}", r["TRUE fire"], r["TRUE bg"], r["pred fire"], r["pred bg"], r["all"]])
        for r in ab_:
            rows_a.append([f"{r['readout']}, {MNAME[m]}, beta0 {r['beta0']}", r["detected fire"], r["false alarm"], r["missed fire"], r["correct bg"],
                           r["missed fire"] / r["correct bg"] if r["correct bg"] else ""])
    graph("E3", f"E3-{n:02d}_evidence_null_vs_height_gate_ece", "bar", "readout, model, haze", "ECE",
          "Evidence null cuts true-fire ECE more than the height gate but at a large cost in background ECE", "evidence_null.py",
          ["readout, model, haze", "true-fire ECE", "true-background ECE", "predicted-fire ECE", "predicted-background ECE", "overall ECE"], rows_s); n += 1
    graph("E3", f"E3-{n:02d}_evidence_null_vs_height_gate_abstention", "bar", "readout, model, haze", "mean p(abstain)",
          "Abstention by pixel type: evidence null vs height gate on MODIS labels", "evidence_null.py",
          ["readout, model, haze", "detected fire", "false alarm", "missed fire", "correct bg", "selectivity (missed / correct bg)"], rows_a); n += 1
    Ae = P["aerosol"]
    graph("E3", f"E3-{n:02d}_scene_aerosol_index", "bar", "scene", "aerosol index",
          "Scene 4 is hazier than scene 3 (aerosol index), the covariate shift the readouts must transfer across", INPUTS["aerosol"][1],
          ["scene", "mean aerosol index", "median", "90th percentile"],
          [[r["condition"], F(r, "mean_aerosol_index"), F(r, "median"), F(r, "p90")] for r in Ae if r["model"] == "A_s0"])


# ------------------------------------------------------------------ E4
def build_E4(P):
    shares, models = P["labelchk"]
    graph("E4", "E4-01_MODIS_fire_visibility", "stacked bar", "scene", "share of MODIS fire pixels (0-1)",
          "About 95% of MODIS-labelled fire shows no fire signature at all in Sentinel-2", INPUTS["labelchk"][1],
          ["scene", "strict SWIR fire signature", "permissive signature", "within 30 m of a signature", "no visible fire"],
          [[r["scene"], r.get("strict"), r.get("permissive"), r.get("within_30m"), r.get("none")] for r in shares])
    lab = lambda r: f"{MNAME[r['model']]}, {r['scene']}"
    graph("E4", "E4-02_recall_MODIS_vs_visible_fire", "bar", "model and scene", "recall (0-1)",
          "Recall is 0.22-0.45 against MODIS labels but 0.80-0.96 against the fire Sentinel-2 can actually see", INPUTS["labelchk"][1],
          ["model and scene", "recall on all MODIS labels", "recall on visible fire", "recall on MODIS fire with no visible signature"],
          [[lab(r), r.get("recall_all"), r.get("recall_visible"), r.get("recall_invisible")] for r in models])
    graph("E4", "E4-03_confidence_on_missed_fire_visible_vs_invisible", "bar", "model and scene", "mean confidence on missed fire",
          "The network is confidently 'wrong' on invisible MODIS fire -- because there is nothing to see", INPUTS["labelchk"][1],
          ["model and scene", "missed fire that is visible", "missed fire with no visible signature"],
          [[lab(r), r.get("conf_missed_visible"), r.get("conf_missed_invisible")] for r in models])
    graph("E4", "E4-04_maxlogit_auroc_visible_vs_invisible", "bar", "model and scene", "MaxLogit AUROC vs correct background",
          "Separability of missed fire from correct background, visible vs invisible MODIS fire", INPUTS["labelchk"][1],
          ["model and scene", "missed visible fire", "missed invisible fire"],
          [[lab(r), r.get("maxlogit_auroc_visible"), r.get("maxlogit_auroc_invisible")] for r in models])
    Ag = P["agcounts"]
    graph("E4", "E4-05_agreement_label_counts", "bar", "scene", "pixels",
          "Agreement labels keep fire only where MODIS and the SWIR signature agree: 1.0-1.4% of MODIS fire (plot the share column separately)",
          INPUTS["agcounts"][1], ["scene", "MODIS fire pixels", "agreement fire pixels", "share of MODIS fire kept", "strict signatures outside MODIS"],
          [[f"scene {r['scene']}", int(r["modis_fire_pixels"]), int(r["agreement_fire_pixels"]),
            int(r["agreement_fire_pixels"]) / int(r["modis_fire_pixels"]), int(r["strict_signatures_outside_modis"])] for r in Ag])
    perf, find = P["stress"]
    betas = sorted({r["beta0"] for r in perf})
    Ip = {(r["alpha"], r["scene"], r["method"], r["beta0"]): r for r in perf}
    n = 6
    for a, an in ((1.3, "aerosol haze (alpha 1.3)"), (0.0, "grey haze (alpha 0)")):
        for met, ml in (("iou", "IoU"), ("recall", "recall"), ("precision", "precision")):
            cs = [(sc, me) for sc in ("scene3", "scene4") for me in ("rule", "network seed 0", "network seed 1")]
            graph("E4", f"E4-{n:02d}_{met}_rule_vs_network_{'aerosol' if a else 'grey'}_haze", "line", B, ml,
                  f"Agreement-label networks vs their own SWIR labelling rule, {an}: {ml}", INPUTS["stress"][1],
                  [B] + [f"{me}, {sc}" for sc, me in cs],
                  [[b] + [Ip[(a, sc, me, b)][met] if (a, sc, me, b) in Ip else "" for sc, me in cs] for b in betas]); n += 1
    If = {(r["alpha"], r["scene"], r["seed"], r["beta0"]): r for r in find}
    cs = [(a, sc, sd) for a in (1.3, 0.0) for sc in ("scene3", "scene4") for sd in (0, 1)]
    cn = lambda a, sc, sd: f"{'aerosol' if a else 'grey'}, {sc}, seed {sd}"
    for key, ml, desc in (("conf_missed", "mean confidence on missed fire", "The fire the network misses under haze, it misses confidently (softmax)"),
                          ("maxlogit_auroc", "MaxLogit AUROC (missed fire vs correct bg)", "With agreement labels, missed fire is separable again (AUROC ~1.0 under aerosol haze)"),
                          ("ceiling", "logit ceiling AUROC", "Logit ceiling under haze, agreement-label networks"),
                          ("missed_px", "missed fire pixels", "How much fire is missed as haze rises")):
        graph("E4", f"E4-{n:02d}_{key}_vs_haze_agreement_networks", "line", B, ml, desc, INPUTS["stress"][1],
              [B] + [cn(*c) for c in cs], [[b] + [If[c + (b,)][key] if c + (b,) in If else "" for c in cs] for b in betas]); n += 1
    cs2 = [(sc, sd) for sc in ("scene3", "scene4") for sd in (0, 1)]
    graph("E4", f"E4-{n:02d}_logit_height_missed_vs_correct_bg", "line", B, "logit height max(z0, z1)",
          "Aerosol haze: missed fire sits far lower in logit height than correct background -- the cue the height gate uses", INPUTS["stress"][1],
          [B] + [f"{w}, {sc}, seed {sd}" for sc, sd in cs2 for w in ("missed fire", "correct bg")],
          [[b] + [v for sc, sd in cs2 for v in ((If[(1.3, sc, sd, b)]["h_missed"], If[(1.3, sc, sd, b)]["h_corr_bg"]) if (1.3, sc, sd, b) in If else ("", ""))]
           for b in betas]); n += 1
    (_, _), ig = P["everypx"]
    cats = ["MODIS fire, nothing visible", "strict signature outside MODIS", "near a weak signature"]
    Ig = {(r["alpha"], r["scene"], r["seed"], r["beta0"], r["category"]): r for r in ig}
    graph("E4", f"E4-{n:02d}_ignored_pixels_share_of_scene", "bar", "scene", "share of scene (0-1)",
          "What the agreement labels set to 'ignore', as a share of each scene", INPUTS["everypx"][1],
          ["scene"] + cats, [[sc] + [Ig[(1.3, sc, 0, 0.0, c)]["share_of_scene"] if (1.3, sc, 0, 0.0, c) in Ig else "" for c in cats] for sc in ("scene3", "scene4")]); n += 1
    ib = sorted({r["beta0"] for r in ig})
    for key, ml in (("called_fire", "share called fire by the network"), ("gate_abstention", "height-gate abstention")):
        cs3 = [(sc, c) for sc in ("scene3", "scene4") for c in cats]
        graph("E4", f"E4-{n:02d}_ignored_pixels_{key}_vs_haze", "line", B, ml,
              f"Ignored pixels under aerosol haze (seed 0): {ml} per category", INPUTS["everypx"][1],
              [B] + [f"{c}, {sc}" for sc, c in cs3], [[b] + [Ig[(1.3, sc, 0, b, c)][key] if (1.3, sc, 0, b, c) in Ig else "" for sc, c in cs3] for b in ib]); n += 1


# ------------------------------------------------------------------ E5
EP_RD = ["softmax", "temperature", "class-cond T", "Platt", "beta", "isotonic", "height gate"]
HR_RD = ["softmax", "T mix", "ccT mix", "gateECE clr", "gateECE mix", "gateBr mix", "gateBr mtch"]
AL = {1.3: "aerosol haze (alpha 1.3)", 0.0: "grey haze (alpha 0)"}
AS = {1.3: "aerosol", 0.0: "grey"}
SC = {"scene3": "scene 3 (held-out half)", "scene4": "scene 4 (new region)"}


def build_E5(P):
    vals, gate = P["hazero"]
    Iv = {(r["alpha"], r["scene"], r["seed"], r["beta0"], r["metric"], r["readout"]): r["value"] for r in vals}
    hb = sorted({r["beta0"] for r in vals})
    n = 1
    for met, ml in (("true-fire ECE", "true-fire ECE"),):   # conf Brier is printed at 4 dp (mostly 0.0000): tidy/ only
        for a in (1.3, 0.0):
            for sc in ("scene3", "scene4"):
                cs = [(rd, sd) for rd in HR_RD for sd in (0, 1)]
                graph("E5", f"E5-{n:02d}_haze_readouts_{'true_fire_ece' if 'ECE' in met else 'conf_brier'}_{AS[a]}_{sc}", "line", B, ml,
                      f"Agreement-label networks, readouts fitted on hazed scene 3, {AL[a]}, {SC[sc]}: {ml}. "
                      "'height gate (Brier, mixture)' is the paper's height gate", INPUTS["hazero"][1],
                      [B] + [f"{RENAME.get(rd, rd)}, seed {sd}" for rd, sd in cs],
                      [[b] + [Iv.get((a, sc, sd, b, met, rd), "") for rd, sd in cs] for b in hb]); n += 1
    Ig = {(r["alpha"], r["scene"], r["seed"], r["beta0"]): r for r in gate}
    for a in (1.3, 0.0):
        cs = [(sc, sd) for sc in ("scene3", "scene4") for sd in (0, 1)]
        graph("E5", f"E5-{n:02d}_confidence_on_missed_fire_gate_vs_softmax_{AS[a]}", "line", B, "mean confidence on missed fire",
              f"{AL[a]}: the height gate cuts confidence on the fire still missed; softmax stays near 0.9 (points resting on fewer than ~10 missed pixels are noisy; counts in E4-15)", INPUTS["hazero"][1],
              [B] + [f"{w}, {sc}, seed {sd}" for sc, sd in cs for w in ("softmax", "height gate")],
              [[b] + [v for c in cs for v in ((Ig[(a,) + c + (b,)]["conf_missed_softmax"], Ig[(a,) + c + (b,)]["conf_missed_gate"])
                                               if (a,) + c + (b,) in Ig else ("", ""))] for b in hb]); n += 1
    cs = [(a, sc, sd) for a in (1.3, 0.0) for sc in ("scene3", "scene4") for sd in (0, 1)]
    graph("E5", f"E5-{n:02d}_height_gate_selectivity_vs_haze", "line (log y axis)", B, "selectivity (abstention on missed fire / on correct bg)",
          "Agreement labels: the height gate abstains hundreds to thousands of times more on missed fire than on correct background under aerosol haze; "
          "under grey haze it cannot (selectivity ~1-2) (points resting on fewer than ~10 missed pixels are noisy; counts in E4-15)", INPUTS["hazero"][1],
          [B] + [f"{AS[a]}, {sc}, seed {sd}" for a, sc, sd in cs], [[b] + [Ig[c + (b,)]["selectivity"] if c + (b,) in Ig else "" for c in cs] for b in hb]); n += 1
    graph("E5", f"E5-{n:02d}_height_gate_abstention_on_ignored_pixels", "line", B, "mean p(abstain) on ignored pixels",
          "How much the height gate abstains on the pixels the labels set to ignore", INPUTS["hazero"][1],
          [B] + [f"{AS[a]}, {sc}, seed {sd}" for a, sc, sd in cs], [[b] + [Ig[c + (b,)]["abstain_ignored"] if c + (b,) in Ig else "" for c in cs] for b in hb]); n += 1

    (long, summ), _ = P["everypx"]
    Il = {(r["labels"], r["alpha"], r["scene"], r["seed"], r["beta0"], r["metric"], r["readout"]): r["value"] for r in long}
    eb = sorted({r["beta0"] for r in long})
    METS = [("true-fire ECE", "true-fire ECE"), ("fire Brier", "fire Brier score"), ("fire NLL", "fire NLL"), ("conf Brier", "confidence Brier score"),
            ("conf NLL", "confidence NLL"), ("Brier", "Brier score, every pixel"), ("NLL", "NLL, every pixel"), ("IoU", "IoU"),
            ("conf missed", "mean confidence on missed fire")]
    slug = lambda s: re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")
    cs = [(sc, sd) for sc in ("scene4", "scene3") for sd in (0, 1)]
    for met, ml in METS:
        graph("E5", f"E5-{n:02d}_every_pixel_b4_aerosol_{slug(met)}", "bar (grouped)", "readout", ml,
              f"PIXEL-BY-PIXEL TEST, every pixel scored against visible fire, aerosol haze beta0 = 4: {ml} for every readout",
              INPUTS["everypx"][1], ["readout"] + [f"{SC[sc]}, seed {sd}" for sc, sd in cs],
              [[rd] + [Il.get(("visible", 1.3, sc, sd, 4.0, met, rd), "") for sc, sd in cs] for rd in EP_RD]); n += 1
    for met, ml in (("true-fire ECE", "true-fire ECE"), ("fire Brier", "fire Brier score"), ("IoU", "IoU"), ("conf missed", "mean confidence on missed fire")):
        graph("E5", f"E5-{n:02d}_every_pixel_b2_grey_{slug(met)}", "bar (grouped)", "readout", ml,
              f"Pixel-by-pixel test, grey haze beta0 = 2: where the boundary-moving calibrators (Platt, isotonic) win -- {ml}",
              INPUTS["everypx"][1], ["readout"] + [f"{SC[sc]}, seed {sd}" for sc, sd in cs],
              [[rd] + [Il.get(("visible", 0.0, sc, sd, 2.0, met, rd), "") for sc, sd in cs] for rd in EP_RD]); n += 1
    for a, mets in ((1.3, ["true-fire ECE", "fire Brier", "fire NLL", "conf Brier", "conf missed", "IoU"]), (0.0, ["true-fire ECE", "IoU", "conf Brier", "conf missed"])):
        for met in mets:
            ml = dict(METS)[met]
            cs2 = [(rd, sd) for rd in EP_RD for sd in (0, 1)]
            graph("E5", f"E5-{n:02d}_every_pixel_{slug(met)}_vs_haze_{AS[a]}_scene4", "line", B, ml,
                  f"Pixel-by-pixel test, {AL[a]}, scene 4 (new region), visible-fire truth: {ml} as haze rises", INPUTS["everypx"][1],
                  [B] + [f"{rd}, seed {sd}" for rd, sd in cs2], [[b] + [Il.get(("visible", a, "scene4", sd, b, met, rd), "") for rd, sd in cs2] for b in eb]); n += 1
    graph("E5", f"E5-{n:02d}_grey_haze_calibrators_on_clear_images_iou", "bar (grouped)", "readout", "IoU on clear images (beta0 = 0)",
          "Calibrators fitted under grey haze, applied to clear images: Platt / isotonic lose IoU, the gate keeps softmax's decisions",
          INPUTS["everypx"][1], ["readout"] + [f"{SC[sc]}, seed {sd}" for sc, sd in cs],
          [[rd] + [Il.get(("visible", 0.0, sc, sd, 0.0, "IoU", rd), "") for sc, sd in cs] for rd in EP_RD]); n += 1
    Is = {(r["labels"], r["alpha"], r["scene"], r["seed"], r["beta0"]): r for r in summ}
    sb = sorted({r["beta0"] for r in summ})
    labs = ["agreement", "visible", "modis"]
    for key, ml in (("iou", "IoU (softmax)"), ("maxlogit_auroc", "MaxLogit AUROC (missed fire vs correct bg)"),
                    ("selectivity", "height-gate selectivity"), ("conf_missed_gate", "height-gate confidence on missed fire"),
                    ("recall", "recall")):
        cs3 = [(lb, sc) for lb in labs for sc in ("scene3", "scene4")]
        for sd in (0, 1):
            graph("E5", f"E5-{n:02d}_{key}_by_label_version_seed{sd}", "line" + (" (log y axis)" if key == "selectivity" else ""), B, ml,
                  f"Same network (seed {sd}), aerosol haze, scored against three truths: agreement labels, visible fire (every pixel), original MODIS labels -- {ml}",
                  INPUTS["everypx"][1], [B] + [f"{lb} labels, {sc}" for lb, sc in cs3],
                  [[b] + [Is[(lb, 1.3, sc, sd, b)][key] if (lb, 1.3, sc, sd, b) in Is else "" for lb, sc in cs3] for b in sb]); n += 1
    C3 = P["ft3"]; Ab = idx(C3, "model", "condition", "readout", "category", val="mean_abstention")
    rows = []
    for m in MODELS:
        for cond, cl in CONDS.items():
            mf, bg = Ab.get((m, cond, "height gate", "missed fire")), Ab.get((m, cond, "height gate", "correct bg"))
            rows.append([f"MODIS labels: {MNAME[m]}, {cl}", mf / bg if mf is not None and bg else ""])
    for sc in ("scene3", "scene4"):
        for sd in (0, 1):
            r = Ig.get((1.3, sc, sd, 4.0))
            rows.append([f"agreement labels: seed {sd}, {SC[sc]}, aerosol beta0 = 4", r["selectivity"] if r else ""])
    graph("E5", f"E5-{n:02d}_selectivity_MODIS_vs_agreement_labels", "bar (log y axis)", "network and condition",
          "selectivity (abstention on missed fire / on correct bg)",
          "The same height gate: selectivity 1.1-4.3 on MODIS-label networks vs 593-3,702 on agreement-label networks", "final_tests.py + haze_readouts.py",
          ["network and condition", "height-gate selectivity"], rows); n += 1


# ------------------------------------------------------------------ tidy, raw, index, check
def write_tidy(P):
    T = {"haze_sweep_all_scenes_modelA": P["sweepall"], "modelB_training_epochs": P["trainlog"][0], "modelB_gate_parameters": P["trainlog"][1],
         "gate_sweep_softcap_hinge": P["softcap"], "seed1_pair_A_vs_B": P["pair"],
         "combined_readouts_scores": P["combined"][0], "gate_objectives_scores": P["objectives"][0], "gate_objectives_abstention": P["objectives"][1],
         "evidence_null_vs_gate_scores": sum((P[f"env_{m}"][0] for m in MODELS), []),
         "evidence_null_vs_gate_abstention": sum((P[f"env_{m}"][1] for m in MODELS), []),
         "ece_anatomy_frontier": P["anatomy"][0], "ece_anatomy_perfect_scenarios": P["anatomy"][1],
         "gate_diagnosis_signals": P["gatediag"][0], "gate_diagnosis_counterfactuals": P["gatediag"][1],
         "label_check_visibility": P["labelchk"][0], "label_check_models": P["labelchk"][1],
         "haze_stress_detection": P["stress"][0], "haze_stress_missed_fire": P["stress"][1],
         "haze_readouts_scores": [dict(r, readout=RENAME.get(r["readout"], r["readout"])) for r in P["hazero"][0]],
         "haze_readouts_gate_by_pixel_type": P["hazero"][1],
         "every_pixel_scores": P["everypx"][0][0], "every_pixel_summary_by_label_version": P["everypx"][0][1],
         "every_pixel_ignored_pixels": P["everypx"][1]}
    for k, rows in T.items(): tidy(k, rows)
    return len(T)


def copy_raw():
    d = OUT / "raw"; d.mkdir(parents=True, exist_ok=True); n = 0
    for sub in ("final_tests", "compile_results", "transcribed"):
        for f in sorted((RES / sub).glob("*.csv")):
            (d / sub).mkdir(exist_ok=True); shutil.copy2(f, d / sub / f.name); n += 1
    return n


def check():
    P, bad = {}, 0
    print(f"{'input':<12} {'rows':>6}  {'file':<52} produced by")
    for k, (path, src) in INPUTS.items():
        f = RES / path
        if not f.exists():
            print(f"{k:<12} {'MISSING':>6}  {path:<52} {src}"); bad += 1; continue
        try:
            r = PARSERS[k]()
        except Exception as e:
            print(f"{k:<12} {'ERROR':>6}  {path:<52} {e!r}"); bad += 1; continue
        cnt = lambda x: len(x) if isinstance(x, list) else sum(cnt(y) for y in x)
        c = cnt(r)
        if c == 0: bad += 1
        print(f"{k:<12} {c:>6}  {path:<52} {src}{'   <-- parsed nothing' if c == 0 else ''}")
        P[k] = r
    return P, bad


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--check", action="store_true", help="only check the inputs")
    a = ap.parse_args()
    P, bad = check()
    if bad:
        sys.exit(f"\n{bad} input(s) missing or unparseable -- fix before building")
    print(f"\nall {len(INPUTS)} inputs present and parsed")
    if a.check: return
    if OUT.exists(): shutil.rmtree(OUT)
    for b in (build_E1, build_E2, build_E3, build_E4, build_E5): b(P)
    nt, nr = write_tidy(P), copy_raw()
    with open(OUT / "INDEX.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(INDEX[0])); w.writeheader(); w.writerows(INDEX)
    empty = [r["file"] for r in INDEX if r["rows"] == 0]
    missing_key = KEY - {r["file"].rsplit("/", 1)[1].split("_", 1)[1][:-4] for r in INDEX}
    if missing_key: sys.exit(f"KEY names with no file: {missing_key}")
    print(f"wrote {len(INDEX)} graph-ready CSVs ({sum(r['paper_figure'] == 'yes' for r in INDEX)} marked paper_figure = yes), {nt} tidy tables, {nr} raw copies -> {OUT.relative_to(ROOT)}/")
    for e in EXPDIR: print(f"  {e}: {sum(r['experiment'] == e for r in INDEX)} graph-ready files")
    if empty: sys.exit(f"empty files: {empty}")


if __name__ == "__main__":
    main()
