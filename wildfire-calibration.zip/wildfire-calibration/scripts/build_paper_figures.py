r"""
The 10 figures and tables of the paper's Results and Discussion, as plain CSV files
(header row + data, nothing else, so they paste straight into Excel / Google Sheets).

    python scripts/build_csvs.py           # first: builds csv/
    python scripts/build_paper_figures.py  # then: writes paper_figures/

Every number is copied from csv/graph_ready/ or csv/tidy/ (which build_csvs.py parsed
from the raw results), so each figure can be traced back to the run that produced it.
"""
import csv, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
G, T, OUT = ROOT / "csv" / "graph_ready", ROOT / "csv" / "tidy", ROOT / "paper_figures"


def rd(prefix):
    f = next(G.glob(f"*/{prefix}_*.csv"))
    rows = list(csv.reader(open(f)))
    return rows[0], rows[1:]


def col(hdr, body, name):
    i = hdr.index(name); return {r[0]: r[i] for r in body}


# The paper numbers seeds from 1: run seed 0 -> "seed 1", run seed 1 -> "seed 2" (one pass, so no cascade).
_SEED = re.compile(r"\b([Ss]eed) ([01])\b")
def relabel(v):
    return _SEED.sub(lambda m: f"{m.group(1)} {int(m.group(2)) + 1}", v) if isinstance(v, str) else v


def write(name, header, rows):
    OUT.mkdir(exist_ok=True)
    si = header.index("Seed") if "Seed" in header else None
    with open(OUT / f"{name}.csv", "w", newline="") as fh:
        w = csv.writer(fh); w.writerow([relabel(h) for h in header])
        for r in rows:
            r = [str(int(v) + 1) if i == si else relabel(v) for i, v in enumerate(r)]
            w.writerow([f"{v:.4f}" if isinstance(v, float) else v for v in r])
    print(f"  {name}.csv  ({len(rows)} rows x {len(header)} columns)")


PRETTY = {"softmax": "Softmax", "temperature": "Temperature scaling", "class-cond T": "Class-conditional temperature",
          "Platt": "Platt scaling", "beta": "Beta calibration", "isotonic": "Isotonic regression", "SAEA": "SAEA",
          "evidence null": "Evidence null", "height gate": "Height gate", "trained gate": "Trained gate"}


def main():
    B = "Haze strength beta0"
    # ---- Figure 1 (3.1): confidence stays flat while accuracy collapses
    h, b = rd("E1-01")
    write("Figure_1_confidence_vs_accuracy_on_fire", [B, "Mean confidence on fire pixels", "Accuracy on fire pixels"],
          [[r[0], r[1], r[2]] for r in b])

    # ---- Figure 2 (3.1): standard calibrators and SAEA, true-fire ECE vs haze
    h, b = rd("E1-11"); cal = {r[0]: r[1:] for r in b}
    early = {(r["readout"], r["beta0"]): float(r["delta_true_fire_ece"])
             for r in csv.DictReader(l for l in open(ROOT / "results/transcribed/early_custom_readouts_modelA_scene4.csv") if not l.startswith("#"))}
    rows = []
    for beta, v in cal.items():
        sm = float(v[0])
        rows.append([beta, sm, float(v[1]), float(v[3]), float(v[2]), sm + early[("SAEA v1", beta)], sm + early[("SAEA v2", beta)]])
    write("Figure_2_true_fire_ECE_calibrators_and_SAEA", [B, "Softmax", "Temperature scaling", "Adaptive temperature", "Platt scaling", "SAEA v1", "SAEA v2"], rows)

    # ---- Figure 3 (3.2): where model B's trained gate abstains
    h, b = rd("E2-09")
    names = {"correct fire": "Correct fire", "false alarm": "False alarm", "missed fire": "Missed fire", "correct bg": "Correct background"}
    write("Figure_3_trained_gate_abstention_by_pixel_type", ["Pixel type", "Model B seed 0", "Model B seed 1"],
          [[names[r[0]], r[h.index("trained gate, model B seed 0")], r[h.index("trained gate, model B seed 1")]] for r in b])

    # ---- Figure 4 (3.3): evidence head vs every readout, error-detection AUROC
    h, b = rd("E3-02")
    write("Figure_4_error_detection_AUROC_evidence_head_vs_readouts", ["Readout", "Scene 3 (clear)", "Scene 4 (new region)"],
          [["Evidence head (learned from decoder features)" if r[0].startswith("evidence head") else PRETTY[r[0]], r[1], r[2]] for r in b])

    # ---- Table 1 (3.3): every readout on model A seed 0, MODIS labels
    L = {}
    for r in csv.DictReader(open(ROOT / "results/final_tests/1a_readouts_all_metrics.csv")):
        if r["model"] == "A_s0": L[(r["condition"], r["readout"], r["metric"])] = float(r["value"])
    s3, s4 = "scene3 b0=0.0", "scene4 natural"
    spec = [(s3, "ECE fire (true)", "True-fire ECE (scene 3)"), (s3, "ECE fire (pred)", "Predicted-fire ECE (scene 3)"),
            (s3, "ECE", "Overall ECE (scene 3)"), (s3, "Brier", "Brier (scene 3)"), (s3, "NLL", "NLL (scene 3)"),
            (s3, "AUROC", "Error-detection AUROC (scene 3)"), (s3, "IoU", "IoU (scene 3)"),
            (s4, "ECE fire (true)", "True-fire ECE (scene 4)"), (s4, "AUROC", "Error-detection AUROC (scene 4)"), (s4, "IoU", "IoU (scene 4)")]
    order = ["softmax", "temperature", "class-cond T", "Platt", "beta", "isotonic", "SAEA", "evidence null", "height gate"]
    pretty = PRETTY
    write("Table_1_every_readout_MODIS_labels_model_A", ["Readout"] + [s[2] for s in spec],
          [[pretty[o]] + [L[(c, o, m)] for c, m, _ in spec] for o in order])

    # ---- Table 2 (3.4): the label check and the agreement labels
    vis = {r["scene"]: r for r in csv.DictReader(open(T / "label_check_visibility.csv"))}
    mod = {r["scene"]: r for r in csv.DictReader(open(T / "label_check_models.csv")) if r["model"] == "A_s0"}
    ag = {f"scene{r['scene']}": r for r in csv.DictReader(l for l in open(ROOT / "results/transcribed/agreement_label_counts.csv") if not l.startswith("#"))}
    ig = list(csv.DictReader(open(T / "every_pixel_ignored_pixels.csv")))
    ign = {sc: sum(float(r["share_of_scene"]) for r in ig if r["scene"] == sc and r["seed"] == "0" and r["alpha"] == "1.3" and float(r["beta0"]) == 0)
           for sc in ("scene3", "scene4")}
    S = ("scene3", "scene4")
    write("Table_2_MODIS_label_check_and_agreement_labels", ["Quantity", "Scene 3", "Scene 4"], [
        ["MODIS fire pixels"] + [int(ag[s]["modis_fire_pixels"]) for s in S],
        ["Share of MODIS fire with a strict SWIR fire signature"] + [float(vis[s]["strict"]) for s in S],
        ["Share of MODIS fire with no visible fire at all"] + [float(vis[s]["none"]) for s in S],
        ["Model A recall, scored on MODIS labels"] + [float(mod[s]["recall_all"]) for s in S],
        ["Model A recall, scored on visible fire only"] + [float(mod[s]["recall_visible"]) for s in S],
        ["Agreement-label fire pixels"] + [int(ag[s]["agreement_fire_pixels"]) for s in S],
        ["Share of MODIS fire kept as fire"] + [int(ag[s]["agreement_fire_pixels"]) / int(ag[s]["modis_fire_pixels"]) for s in S],
        ["Share of the scene set to ignore"] + [ign[s] for s in S]])

    # ---- Figure 5 (3.5): the agreement-label network outlasts its own labelling rule
    perf = list(csv.DictReader(open(T / "haze_stress_detection.csv")))
    P = {(r["alpha"], r["method"], r["beta0"]): r["iou"] for r in perf if r["scene"] == "scene4"}
    betas = sorted({r["beta0"] for r in perf}, key=float)
    cs = [("1.3", "rule", "SWIR rule, aerosol haze"), ("1.3", "network seed 0", "Network seed 0, aerosol haze"),
          ("1.3", "network seed 1", "Network seed 1, aerosol haze"), ("0.0", "rule", "SWIR rule, grey haze"),
          ("0.0", "network seed 0", "Network seed 0, grey haze"), ("0.0", "network seed 1", "Network seed 1, grey haze")]
    write("Figure_5_IoU_network_vs_SWIR_rule_scene4", [B] + [c[2] for c in cs], [[bb] + [P[(a, m, bb)] for a, m, _ in cs] for bb in betas])

    # ---- Figure 6 (3.5): pixel-by-pixel test -- confidence on the fire each readout still misses
    h, b = rd("E5-26")
    rds = ["softmax", "temperature", "class-cond T", "Platt", "beta", "isotonic", "height gate"]
    write("Figure_6_confidence_on_missed_fire_every_readout", [B] + [pretty[r] for r in rds],
          [[r[0]] + [r[h.index(f"{x}, seed 0")] for x in rds] for r in b if float(r[0]) >= 1])

    # ---- Figure 7 (3.5): selectivity of the same height gate, MODIS vs agreement labels
    h, b = rd("E5-43")
    write("Figure_7_height_gate_selectivity_MODIS_vs_agreement", ["Network and condition", "Selectivity (abstention on missed fire / on correct background)"],
          [[r[0].replace("MODIS labels: model", "MODIS labels: Model").replace("agreement labels: seed", "Agreement labels: seed")
                .replace("scene 3 clear", "scene 3 (clear)").replace("aerosol beta0 = 4", "aerosol haze beta0 = 4"), r[1]] for r in b])

    # ---- Table 3 (3.5): pixel-by-pixel test, every readout at beta0 = 4, scene 4
    E = {(r["metric"], r["readout"], r["seed"]): r["value"] for r in csv.DictReader(open(T / "every_pixel_scores.csv"))
         if r["labels"] == "visible" and r["alpha"] == "1.3" and r["scene"] == "scene4" and float(r["beta0"]) == 4}
    mets = [("true-fire ECE", "True-fire ECE"), ("fire Brier", "Fire Brier"), ("fire NLL", "Fire NLL"), ("conf Brier", "Confidence Brier"),
            ("Brier", "Brier (all pixels)"), ("NLL", "NLL (all pixels)"), ("IoU", "IoU"), ("conf missed", "Confidence on missed fire")]
    write("Table_3_pixel_by_pixel_test_beta4_scene4", ["Readout", "Seed"] + [m[1] for m in mets],
          [[pretty[x], sd] + [E[(m, x, sd)] for m, _ in mets] for x in rds for sd in ("0", "1")])

    # ---- Figure 8 (3.5): haze dose response of EVERY readout, pixel-by-pixel test (aerosol haze, scene 4, seed 0)
    h, b = rd("E5-22")
    write("Figure_8_true_fire_ECE_vs_haze_every_readout", [B] + [pretty[r] for r in rds],
          [[r[0]] + [r[h.index(f"{x}, seed 0")] for x in rds] for r in b])

    # ---- Table 4 (3.5 / limitations): grey haze -- every readout at beta0 = 2, and the cost on clear images
    A = {(r["metric"], r["readout"], r["seed"], float(r["beta0"])): r["value"] for r in csv.DictReader(open(T / "every_pixel_scores.csv"))
         if r["labels"] == "visible" and r["alpha"] == "0.0" and r["scene"] == "scene4"}
    gm = [("true-fire ECE", 2.0, "True-fire ECE (beta0 = 2)"), ("fire Brier", 2.0, "Fire Brier (beta0 = 2)"), ("fire NLL", 2.0, "Fire NLL (beta0 = 2)"),
          ("IoU", 2.0, "IoU (beta0 = 2)"), ("conf missed", 2.0, "Confidence on missed fire (beta0 = 2)"),
          ("IoU", 0.0, "IoU on clear images (beta0 = 0)")]
    write("Table_4_grey_haze_every_readout_scene4", ["Readout", "Seed"] + [g[2] for g in gm],
          [[pretty[x], sd] + [A[(m, x, sd, bb)] for m, bb, _ in gm] for x in rds for sd in ("0", "1")])


if __name__ == "__main__":
    main()
